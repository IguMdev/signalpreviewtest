import { Q as getDefaultExportFromCjs } from "./server-LhQhv8xE.js";
import { r as requireBigInteger } from "./BigInteger-y0Xnq3bc.js";
function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== "string" && !Array.isArray(e)) {
      for (const k in e) {
        if (k !== "default" && !(k in n)) {
          const d = Object.getOwnPropertyDescriptor(e, k);
          if (d) {
            Object.defineProperty(n, k, d.get ? d : {
              enumerable: true,
              get: () => e[k]
            });
          }
        }
      }
    }
  }
  return Object.freeze(Object.defineProperty(n, Symbol.toStringTag, { value: "Module" }));
}
var BigIntegerExports = requireBigInteger();
const BigInteger = /* @__PURE__ */ getDefaultExportFromCjs(BigIntegerExports);
const BigInteger$1 = /* @__PURE__ */ _mergeNamespaces({
  __proto__: null,
  default: BigInteger
}, [BigIntegerExports]);
export {
  BigInteger$1 as B
};
