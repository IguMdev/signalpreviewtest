import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate, useLocation, Link, Outlet } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { u as useAuth, a as useTheme, B as Button, c as cn } from "./router-Cw6OHOsO.js";
import { useQuery } from "@tanstack/react-query";
import { s as supabase } from "./client-bD0og8Nx.js";
import { MessageCircle, Forward, Menu, Sun, Moon, LogOut, LayoutDashboard, Send, Sparkles, Users, UserPlus, CalendarClock, Video, Mic, Lock, Crosshair, ChevronDown, Globe, Code2, Funnel, BarChart3, Repeat, Link2, Tag, ShoppingBag, BarChart2, Bot, ScrollText, GraduationCap, Wallet, Bell, UserCircle } from "lucide-react";
import { A as Avatar, a as AvatarImage, b as AvatarFallback } from "./avatar-BU2g_-Ad.js";
import { C as Collapsible, a as CollapsibleTrigger, b as CollapsibleContent } from "./collapsible-DUtqt5i7.js";
import { T as TourProvider } from "./TourProvider-BQMn7Vcx.js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-avatar";
import "@radix-ui/react-collapsible";
import "react-dom";
const navItems = [{
  to: "/dashboard",
  label: "Dashboard",
  icon: LayoutDashboard,
  tour: "nav-dashboard"
}, {
  to: "/telegram-accounts",
  label: "Contas Telegram",
  icon: Send,
  tour: "nav-telegram-accounts"
}, {
  to: "/premium-emojis",
  label: "Emojis Premium",
  icon: Sparkles,
  tour: "nav-premium-emojis"
}, {
  to: "/rooms",
  label: "Salas",
  icon: Users,
  tour: "nav-rooms"
}, {
  to: "/membros",
  label: "Membros",
  icon: UserPlus,
  tour: "nav-membros"
}, {
  to: "/mensagens",
  label: "Agendamentos",
  icon: CalendarClock,
  tour: "nav-mensagens"
}, {
  to: "/videos",
  label: "Vídeos",
  icon: Video,
  tour: "nav-videos"
}, {
  to: "/audios",
  label: "Áudios",
  icon: Mic,
  tour: "nav-audios"
}];
const trackingItems = [{
  to: "/trackeamento/dominios",
  label: "Domínios",
  icon: Globe
}, {
  to: "/trackeamento/pixels",
  label: "Pixels",
  icon: Code2
}, {
  to: "/trackeamento/canal",
  label: "Canal",
  icon: Send
}, {
  to: "/trackeamento/funis",
  label: "Funis",
  icon: Funnel
}, {
  to: "/trackeamento/metricas",
  label: "Métricas",
  icon: BarChart3
}, {
  to: "/trackeamento/mensagens",
  label: "Mensagens",
  icon: MessageCircle
}, {
  to: "/trackeamento/postbacks",
  label: "Postbacks",
  icon: Repeat
}, {
  to: "/trackeamento/integracoes",
  label: "Integrações",
  icon: Link2
}, {
  to: "/trackeamento/utms",
  label: "UTMs",
  icon: Tag
}];
const promoItems = [{
  to: "/promocoes/contas",
  label: "Contas de afiliado",
  icon: ShoppingBag
}, {
  to: "/promocoes/estatisticas",
  label: "Estatísticas",
  icon: BarChart2
}];
const botItems = [{
  to: "/bots/boasvindas",
  label: "BotBoasVindas",
  icon: MessageCircle,
  type: "boasvindas"
}, {
  to: "/bots/encaminhador",
  label: "BotEncaminhador",
  icon: Forward,
  type: "encaminhador"
}, {
  to: "/bots/followup",
  label: "BotFollowUp",
  icon: MessageCircle,
  type: "boasvindas"
}];
const botLogsItem = {
  to: "/bots/logs",
  label: "Logs dos Bots",
  icon: ScrollText
};
const accountItems = [{
  to: "/recarga",
  label: "Assinatura",
  icon: Wallet,
  tour: "nav-recarga"
}, {
  to: "/notificacoes",
  label: "Notificações",
  icon: Bell,
  tour: "nav-notificacoes"
}, {
  to: "/perfil",
  label: "Minha conta",
  icon: UserCircle,
  tour: "nav-perfil"
}];
const footerNavItems = [{
  to: "/tutorial",
  label: "Tutorial",
  icon: GraduationCap,
  tour: "nav-tutorial"
}];
function AuthenticatedLayout() {
  const {
    user,
    loading,
    signOut
  } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const {
    theme,
    toggleTheme
  } = useTheme();
  const dark = theme === "dark";
  useEffect(() => {
    if (!loading && !user) navigate({
      to: "/login"
    });
  }, [user, loading, navigate]);
  const profileQuery = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("display_name, avatar_url, credits").eq("id", user.id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const botSubsQuery = useQuery({
    queryKey: ["bot-subs", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("user_engagement_subscriptions").select("bot_type, status, plan:engagement_plans(slug)").eq("user_id", user.id).eq("status", "active");
      return data ?? [];
    }
  });
  const activeBots = new Set((botSubsQuery.data ?? []).map((r) => r.bot_type));
  let salasTier = "NONE";
  for (const sub of botSubsQuery.data ?? []) {
    if (sub.bot_type === "salas") {
      const slug = sub.plan?.slug;
      if (slug === "salas-unlimited") salasTier = "UNLIMITED";
      else if (slug === "salas-3" && salasTier !== "UNLIMITED") salasTier = "PREMIUM";
      else if (slug === "salas-1" && salasTier === "NONE") salasTier = "BASE";
    }
  }
  const isPremiumOrHigher = salasTier === "PREMIUM" || salasTier === "UNLIMITED";
  const isUnlimited = salasTier === "UNLIMITED";
  isUnlimited ? botItems : botItems.filter((b) => activeBots.has(b.type));
  const premiumAccountsQuery = useQuery({
    queryKey: ["has-premium-account", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        count
      } = await supabase.from("telegram_accounts").select("id", {
        count: "exact",
        head: true
      }).eq("account_type", "premium").eq("is_active", true).not("tg_session", "is", null);
      return (count ?? 0) > 0;
    }
  });
  const hasPremiumAccount = premiumAccountsQuery.data === true;
  const promoRoomQuery = useQuery({
    queryKey: ["has-promo-room", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        count
      } = await supabase.from("rooms").select("id", {
        count: "exact",
        head: true
      }).eq("user_id", user.id).eq("niche", "promo");
      return (count ?? 0) > 0;
    }
  });
  const hasPromoRoom = promoRoomQuery.data === true;
  if (loading || !user) {
    return /* @__PURE__ */ jsx("div", { className: "min-h-screen grid place-items-center text-muted-foreground text-sm", children: "Carregando..." });
  }
  return /* @__PURE__ */ jsx(TourProvider, { children: /* @__PURE__ */ jsxs("div", { className: "min-h-screen text-foreground", children: [
    /* @__PURE__ */ jsxs("header", { className: "fixed top-0 inset-x-0 z-30 h-16 glass border-b border-border/60 flex items-center px-4 gap-3", children: [
      /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", className: "lg:hidden", onClick: () => setSidebarOpen((v) => !v), children: /* @__PURE__ */ jsx(Menu, { className: "size-5" }) }),
      /* @__PURE__ */ jsx(Link, { to: "/dashboard", className: "flex items-center gap-2", children: /* @__PURE__ */ jsx("img", { src: "/favicon.png", alt: "Logo", className: "size-9 rounded-lg" }) }),
      /* @__PURE__ */ jsxs("div", { className: "ml-auto flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: toggleTheme, children: dark ? /* @__PURE__ */ jsx(Sun, { className: "size-4" }) : /* @__PURE__ */ jsx(Moon, { className: "size-4" }) }),
        /* @__PURE__ */ jsx(Link, { to: "/perfil", "aria-label": "Minha conta", className: "shrink-0", children: /* @__PURE__ */ jsxs(Avatar, { className: "size-8 ring-1 ring-primary/40 hover:ring-primary transition", children: [
          /* @__PURE__ */ jsx(AvatarImage, { src: profileQuery.data?.avatar_url ?? void 0, alt: profileQuery.data?.display_name ?? "Perfil" }),
          /* @__PURE__ */ jsx(AvatarFallback, { className: "text-xs", children: (profileQuery.data?.display_name?.[0] ?? user.email?.[0] ?? "U").toUpperCase() })
        ] }) }),
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => signOut().then(() => navigate({
          to: "/login"
        })), children: /* @__PURE__ */ jsx(LogOut, { className: "size-4" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("aside", { className: cn("fixed top-16 bottom-0 left-0 z-20 w-64 glass border-r border-border/60 transition-transform flex flex-col", sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"), children: [
      /* @__PURE__ */ jsxs("nav", { className: "p-3 space-y-1 flex-1 overflow-y-auto", children: [
        navItems.map(({
          to,
          label,
          icon: Icon,
          tour
        }) => {
          if (to === "/premium-emojis" && !hasPremiumAccount) {
            return /* @__PURE__ */ jsxs("div", { "data-tour": tour, className: "relative flex items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-foreground/40 cursor-not-allowed", title: "Cadastre uma conta premium em Contas Telegram para liberar", children: [
              /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx(Icon, { className: "size-4" }),
                label
              ] }),
              /* @__PURE__ */ jsx(Lock, { className: "size-3" })
            ] }, to);
          }
          const requiresPremium = to === "/videos" || to === "/audios";
          if (requiresPremium && !isPremiumOrHigher) {
            return /* @__PURE__ */ jsxs("div", { "data-tour": tour, className: "relative flex items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-foreground/40 cursor-not-allowed", title: "Requer Plano Premium ou superior", children: [
              /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx(Icon, { className: "size-4" }),
                label
              ] }),
              /* @__PURE__ */ jsx(Lock, { className: "size-3" })
            ] }, to);
          }
          const active = location.pathname === to || location.pathname.startsWith(to + "/");
          return /* @__PURE__ */ jsxs(Link, { to, "data-tour": tour, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition", active ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
            /* @__PURE__ */ jsx(Icon, { className: cn("size-4", active && "text-primary") }),
            label
          ] }, to);
        }),
        /* @__PURE__ */ jsx("div", { className: "my-2 border-t border-border/40" }),
        /* @__PURE__ */ jsxs(Collapsible, { defaultOpen: location.pathname.startsWith("/trackeamento"), children: [
          /* @__PURE__ */ jsx(CollapsibleTrigger, { asChild: true, children: /* @__PURE__ */ jsxs("button", { type: "button", "data-tour": "nav-trackeamento", className: "w-full relative flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition text-foreground/70 hover:bg-white/5 hover:text-foreground", children: [
            /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(Crosshair, { className: "size-4" }),
              "Trackeamento"
            ] }),
            /* @__PURE__ */ jsx(ChevronDown, { className: "size-4 transition-transform data-[state=open]:rotate-180" })
          ] }) }),
          /* @__PURE__ */ jsx(CollapsibleContent, { className: "space-y-1 pl-2", children: !isPremiumOrHigher ? trackingItems.map(({
            label,
            icon: Icon
          }) => /* @__PURE__ */ jsxs("div", { className: "relative flex items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm font-medium text-foreground/40 cursor-not-allowed", title: "Requer Plano Premium ou superior", children: [
            /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(Icon, { className: "size-4" }),
              label
            ] }),
            /* @__PURE__ */ jsx(Lock, { className: "size-3" })
          ] }, label)) : trackingItems.map(({
            to,
            label,
            icon: Icon
          }) => {
            const active = location.pathname === to || location.pathname.startsWith(to + "/");
            return /* @__PURE__ */ jsxs(Link, { to, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition", active ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
              /* @__PURE__ */ jsx(Icon, { className: cn("size-4", active && "text-primary") }),
              label
            ] }, to);
          }) })
        ] }),
        hasPromoRoom && /* @__PURE__ */ jsxs(Collapsible, { defaultOpen: location.pathname.startsWith("/promocoes"), children: [
          /* @__PURE__ */ jsx(CollapsibleTrigger, { asChild: true, children: /* @__PURE__ */ jsxs("button", { type: "button", className: "w-full relative flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition text-foreground/70 hover:bg-white/5 hover:text-foreground", children: [
            /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(ShoppingBag, { className: "size-4" }),
              "Promoções"
            ] }),
            /* @__PURE__ */ jsx(ChevronDown, { className: "size-4 transition-transform data-[state=open]:rotate-180" })
          ] }) }),
          /* @__PURE__ */ jsx(CollapsibleContent, { className: "space-y-1 pl-2", children: promoItems.map(({
            to,
            label,
            icon: Icon
          }) => {
            const active = location.pathname === to || location.pathname.startsWith(to + "/");
            return /* @__PURE__ */ jsxs(Link, { to, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition", active ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
              /* @__PURE__ */ jsx(Icon, { className: cn("size-4", active && "text-primary") }),
              label
            ] }, to);
          }) })
        ] }),
        /* @__PURE__ */ jsxs(Collapsible, { defaultOpen: location.pathname.startsWith("/bots"), children: [
          /* @__PURE__ */ jsx(CollapsibleTrigger, { asChild: true, children: /* @__PURE__ */ jsxs("button", { type: "button", className: "w-full relative flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-medium transition text-foreground/70 hover:bg-white/5 hover:text-foreground", children: [
            /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(Bot, { className: "size-4" }),
              "Bots"
            ] }),
            /* @__PURE__ */ jsx(ChevronDown, { className: "size-4 transition-transform data-[state=open]:rotate-180" })
          ] }) }),
          /* @__PURE__ */ jsx(CollapsibleContent, { className: "space-y-1 pl-2", children: !isUnlimited ? [...botItems, botLogsItem].map(({
            label,
            icon: Icon
          }) => /* @__PURE__ */ jsxs("div", { className: "relative flex items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm font-medium text-foreground/40 cursor-not-allowed", title: "Requer Plano Unlimited", children: [
            /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx(Icon, { className: "size-4" }),
              label
            ] }),
            /* @__PURE__ */ jsx(Lock, { className: "size-3" })
          ] }, label)) : /* @__PURE__ */ jsxs(Fragment, { children: [
            botItems.map(({
              to,
              label,
              icon: Icon
            }) => {
              const active = location.pathname === to || location.pathname.startsWith(to + "/");
              return /* @__PURE__ */ jsxs(Link, { to, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition", active ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
                /* @__PURE__ */ jsx(Icon, { className: cn("size-4", active && "text-primary") }),
                label
              ] }, to);
            }),
            /* @__PURE__ */ jsxs(Link, { to: botLogsItem.to, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition", location.pathname === botLogsItem.to ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
              /* @__PURE__ */ jsx(ScrollText, { className: cn("size-4", location.pathname === botLogsItem.to && "text-primary") }),
              botLogsItem.label
            ] })
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "px-3 pt-3 pb-4 mt-2 border-t border-border/60 bg-background/40 backdrop-blur-sm space-y-1", children: [
        /* @__PURE__ */ jsx("p", { className: "px-3 pb-1.5 text-[10px] uppercase tracking-wider text-muted-foreground/70", children: "Ajuda" }),
        footerNavItems.map(({
          to,
          label,
          icon: Icon,
          tour
        }) => {
          const active = location.pathname === to || location.pathname.startsWith(to + "/");
          return /* @__PURE__ */ jsxs(Link, { to, "data-tour": tour, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition", active ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
            /* @__PURE__ */ jsx(Icon, { className: cn("size-4", active && "text-primary") }),
            label
          ] }, to);
        }),
        accountItems.map(({
          to,
          label,
          icon: Icon,
          tour
        }) => {
          const active = location.pathname === to || location.pathname.startsWith(to + "/");
          return /* @__PURE__ */ jsxs(Link, { to, "data-tour": tour, onClick: () => setSidebarOpen(false), className: cn("relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition", active ? "cyber-gradient-soft text-foreground cyber-border" : "text-foreground/70 hover:bg-white/5 hover:text-foreground"), children: [
            /* @__PURE__ */ jsx(Icon, { className: cn("size-4", active && "text-primary") }),
            label
          ] }, to);
        })
      ] })
    ] }),
    sidebarOpen && /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-10 bg-background/60 lg:hidden", onClick: () => setSidebarOpen(false) }),
    /* @__PURE__ */ jsx("main", { className: "pt-16 lg:pl-64 min-h-screen", children: /* @__PURE__ */ jsx("div", { className: "p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto", children: (() => {
      const p = location.pathname;
      const requiresPremium = p.startsWith("/videos") || p.startsWith("/audios") || p.startsWith("/trackeamento");
      const requiresUnlimited = p.startsWith("/bots");
      let isBlocked = false;
      let requiredTierName = "";
      if (requiresUnlimited && !isUnlimited) {
        isBlocked = true;
        requiredTierName = "Unlimited";
      } else if (requiresPremium && !isPremiumOrHigher) {
        isBlocked = true;
        requiredTierName = "Premium";
      }
      if (isBlocked) {
        return /* @__PURE__ */ jsxs("div", { className: "min-h-[60vh] flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-6", children: [
          /* @__PURE__ */ jsx("div", { className: "size-20 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20", children: /* @__PURE__ */ jsx(Lock, { className: "size-10 text-primary" }) }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-2xl font-bold", children: "Acesso Restrito" }),
            /* @__PURE__ */ jsxs("p", { className: "text-muted-foreground", children: [
              "Esta funcionalidade é exclusiva para assinantes do plano ",
              /* @__PURE__ */ jsx("strong", { className: "text-foreground", children: requiredTierName }),
              " ou superior."
            ] })
          ] }),
          /* @__PURE__ */ jsx(Button, { asChild: true, className: "w-full font-bold", size: "lg", children: /* @__PURE__ */ jsxs(Link, { to: "/recarga", children: [
            "Fazer Upgrade Agora",
            /* @__PURE__ */ jsx(Sparkles, { className: "size-4 ml-2" })
          ] }) })
        ] });
      }
      return /* @__PURE__ */ jsx(Outlet, {});
    })() }) })
  ] }) });
}
export {
  AuthenticatedLayout as component
};
