import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { ClientOnly } from "@tanstack/react-router";
import * as React from "react";
import { useState, useMemo } from "react";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useQuery } from "@tanstack/react-query";
import { g as getPixelStats, f as listRecentClicks } from "./tracking.functions-jGKb0ig9.js";
import { c as cn, X as buttonVariants, B as Button, C as Card, x as CardContent, P as Popover, J as PopoverTrigger, K as PopoverContent } from "./router-Cw6OHOsO.js";
import { ChevronLeftIcon, ChevronRightIcon, ChevronDownIcon, ChevronRight, Check, Circle, Calendar as Calendar$1, X, Filter, ChevronDown, Download } from "lucide-react";
import { getDefaultClassNames, DayPicker } from "react-day-picker";
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu";
import { u as usePixelFilter, P as PixelFilterBar } from "./PixelFilter-FzJuz8YB.js";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  captionLayout = "label",
  buttonVariant = "ghost",
  formatters,
  components,
  ...props
}) {
  const defaultClassNames = getDefaultClassNames();
  return /* @__PURE__ */ jsx(
    DayPicker,
    {
      showOutsideDays,
      className: cn(
        "bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        className
      ),
      captionLayout,
      formatters: {
        formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
        ...formatters
      },
      classNames: {
        root: cn("w-fit", defaultClassNames.root),
        months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
        month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
        nav: cn(
          "absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1",
          defaultClassNames.nav
        ),
        button_previous: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_previous
        ),
        button_next: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_next
        ),
        month_caption: cn(
          "flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)",
          defaultClassNames.month_caption
        ),
        dropdowns: cn(
          "flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium",
          defaultClassNames.dropdowns
        ),
        dropdown_root: cn(
          "has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border",
          defaultClassNames.dropdown_root
        ),
        dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
        caption_label: cn(
          "select-none font-medium",
          captionLayout === "label" ? "text-sm" : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5",
          defaultClassNames.caption_label
        ),
        table: "w-full border-collapse",
        weekdays: cn("flex", defaultClassNames.weekdays),
        weekday: cn(
          "text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal",
          defaultClassNames.weekday
        ),
        week: cn("mt-2 flex w-full", defaultClassNames.week),
        week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
        week_number: cn(
          "text-muted-foreground select-none text-[0.8rem]",
          defaultClassNames.week_number
        ),
        day: cn(
          "group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md",
          defaultClassNames.day
        ),
        range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
        range_middle: cn("rounded-none", defaultClassNames.range_middle),
        range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
        today: cn(
          "bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none",
          defaultClassNames.today
        ),
        outside: cn(
          "text-muted-foreground aria-selected:text-muted-foreground",
          defaultClassNames.outside
        ),
        disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
        hidden: cn("invisible", defaultClassNames.hidden),
        ...classNames
      },
      components: {
        Root: ({ className: className2, rootRef, ...props2 }) => {
          return /* @__PURE__ */ jsx("div", { "data-slot": "calendar", ref: rootRef, className: cn(className2), ...props2 });
        },
        Chevron: ({ className: className2, orientation, ...props2 }) => {
          if (orientation === "left") {
            return /* @__PURE__ */ jsx(ChevronLeftIcon, { className: cn("size-4", className2), ...props2 });
          }
          if (orientation === "right") {
            return /* @__PURE__ */ jsx(ChevronRightIcon, { className: cn("size-4", className2), ...props2 });
          }
          return /* @__PURE__ */ jsx(ChevronDownIcon, { className: cn("size-4", className2), ...props2 });
        },
        DayButton: CalendarDayButton,
        WeekNumber: ({ children, ...props2 }) => {
          return /* @__PURE__ */ jsx("td", { ...props2, children: /* @__PURE__ */ jsx("div", { className: "flex size-(--cell-size) items-center justify-center text-center", children }) });
        },
        ...components
      },
      ...props
    }
  );
}
function CalendarDayButton({
  className,
  day,
  modifiers,
  ...props
}) {
  const defaultClassNames = getDefaultClassNames();
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (modifiers.focused) ref.current?.focus();
  }, [modifiers.focused]);
  return /* @__PURE__ */ jsx(
    Button,
    {
      ref,
      variant: "ghost",
      size: "icon",
      "data-day": day.date.toLocaleDateString(),
      "data-selected-single": modifiers.selected && !modifiers.range_start && !modifiers.range_end && !modifiers.range_middle,
      "data-range-start": modifiers.range_start,
      "data-range-end": modifiers.range_end,
      "data-range-middle": modifiers.range_middle,
      className: cn(
        "data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70",
        defaultClassNames.day,
        className
      ),
      ...props
    }
  );
}
const DropdownMenu = DropdownMenuPrimitive.Root;
const DropdownMenuTrigger = DropdownMenuPrimitive.Trigger;
const DropdownMenuSubTrigger = React.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ jsxs(
  DropdownMenuPrimitive.SubTrigger,
  {
    ref,
    className: cn(
      "flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      inset && "pl-8",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsx(ChevronRight, { className: "ml-auto" })
    ]
  }
));
DropdownMenuSubTrigger.displayName = DropdownMenuPrimitive.SubTrigger.displayName;
const DropdownMenuSubContent = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.SubContent,
  {
    ref,
    className: cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className
    ),
    ...props
  }
));
DropdownMenuSubContent.displayName = DropdownMenuPrimitive.SubContent.displayName;
const DropdownMenuContent = React.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ jsx(DropdownMenuPrimitive.Portal, { children: /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Content,
  {
    ref,
    sideOffset,
    className: cn(
      "z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
      "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className
    ),
    ...props
  }
) }));
DropdownMenuContent.displayName = DropdownMenuPrimitive.Content.displayName;
const DropdownMenuItem = React.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Item,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0",
      inset && "pl-8",
      className
    ),
    ...props
  }
));
DropdownMenuItem.displayName = DropdownMenuPrimitive.Item.displayName;
const DropdownMenuCheckboxItem = React.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ jsxs(
  DropdownMenuPrimitive.CheckboxItem,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    checked,
    ...props,
    children: [
      /* @__PURE__ */ jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx(DropdownMenuPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Check, { className: "h-4 w-4" }) }) }),
      children
    ]
  }
));
DropdownMenuCheckboxItem.displayName = DropdownMenuPrimitive.CheckboxItem.displayName;
const DropdownMenuRadioItem = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs(
  DropdownMenuPrimitive.RadioItem,
  {
    ref,
    className: cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    ...props,
    children: [
      /* @__PURE__ */ jsx("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx(DropdownMenuPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Circle, { className: "h-2 w-2 fill-current" }) }) }),
      children
    ]
  }
));
DropdownMenuRadioItem.displayName = DropdownMenuPrimitive.RadioItem.displayName;
const DropdownMenuLabel = React.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Label,
  {
    ref,
    className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
    ...props
  }
));
DropdownMenuLabel.displayName = DropdownMenuPrimitive.Label.displayName;
const DropdownMenuSeparator = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DropdownMenuPrimitive.Separator,
  {
    ref,
    className: cn("-mx-1 my-1 h-px bg-muted", className),
    ...props
  }
));
DropdownMenuSeparator.displayName = DropdownMenuPrimitive.Separator.displayName;
const FILTER_OPTIONS = ["Funil", "Dominio", "Pagina (URL)", "UTM Source", "UTM Medium", "UTM Campaign", "UTM Content", "Status", "Trackeado", "Start Bot"];
const DONUT_COLORS = ["hsl(263 70% 60%)", "hsl(330 75% 60%)", "hsl(150 60% 50%)", "hsl(40 90% 55%)", "hsl(200 80% 55%)", "hsl(0 0% 50%)"];
function MetricasPage() {
  const {
    pixelId,
    pixels,
    setPixel
  } = usePixelFilter();
  const effectiveId = pixelId ?? pixels[0]?.id ?? null;
  const currentPixel = pixels.find((p) => p.id === effectiveId);
  const mode = currentPixel?.tracking_mode ?? "telegram";
  return /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsx(PixelFilterBar, { pixelId: effectiveId, pixels, setPixel }),
    !effectiveId && /* @__PURE__ */ jsx(Card, { className: "border-dashed", children: /* @__PURE__ */ jsxs(CardContent, { className: "p-4 text-sm text-muted-foreground", children: [
      "Configure um pixel em ",
      /* @__PURE__ */ jsx("span", { className: "text-primary font-medium", children: "Trackeamento → Pixels" }),
      " para começar a receber dados. Enquanto isso, a tela permanece disponível e os indicadores ficam zerados."
    ] }) }),
    /* @__PURE__ */ jsx(MetricsView, { pixelId: effectiveId, mode })
  ] });
}
function rangeToDays(range) {
  if (!range?.from) return 30;
  const to = range.to ?? /* @__PURE__ */ new Date();
  return Math.max(1, Math.ceil((to.getTime() - range.from.getTime()) / 864e5) + 1);
}
function detectDevice(ua) {
  if (!ua) return "Outros";
  const s = ua.toLowerCase();
  if (/iphone|ipad|ipod/.test(s)) return "iPhone";
  if (/android/.test(s)) return "Android";
  if (/windows/.test(s)) return "Windows";
  if (/mac os/.test(s)) return "Mac";
  if (/linux/.test(s)) return "Linux";
  return "Outros";
}
function MetricsView({
  pixelId,
  mode
}) {
  const [range, setRange] = useState(void 0);
  const [filters, setFilters] = useState([]);
  const days = rangeToDays(range);
  const statsFn = useServerFn(getPixelStats);
  const clicksFn = useServerFn(listRecentClicks);
  const stats = useQuery({
    queryKey: ["m-stats", pixelId, days],
    queryFn: () => statsFn({
      data: {
        pixel_id: pixelId,
        days
      }
    }),
    enabled: !!pixelId
  });
  const clicks = useQuery({
    queryKey: ["m-clicks", pixelId, days],
    queryFn: () => clicksFn({
      data: {
        pixel_id: pixelId,
        limit: 500
      }
    }),
    enabled: !!pixelId
  });
  const rows = clicks.data ?? [];
  const filtered = useMemo(() => {
    if (filters.length === 0) return rows;
    return rows.filter((r) => filters.every((f) => {
      const v = (f.value || "").toLowerCase();
      if (!v) return true;
      switch (f.key) {
        case "UTM Source":
          return (r.utm_source ?? "").toLowerCase().includes(v);
        case "UTM Medium":
          return (r.utm_medium ?? "").toLowerCase().includes(v);
        case "UTM Campaign":
          return (r.utm_campaign ?? "").toLowerCase().includes(v);
        case "UTM Content":
          return (r.utm_content ?? "").toLowerCase().includes(v);
        case "Pagina (URL)":
          return (r.landing_url ?? "").toLowerCase().includes(v);
        case "Status":
          return (r.refunded_at ? "reembolso" : r.chargeback_at ? "chargeback" : r.abandoned_cart_at ? "abandono" : r.purchased_at ? "compra" : r.payment_info_at ? "pgto" : r.checkout_at ? "checkout" : r.lead_at ? "lead" : r.viewed_at ? "view" : r.deposited_at ? "deposito" : r.registered_at ? "cadastro" : r.joined_at ? "entrou" : "clique").includes(v);
        case "Trackeado":
          return r.utm_source || r.fbclid ? v === "sim" : v === "nao";
        case "Start Bot":
          return r.joined_at ? v === "sim" : v === "nao";
        default:
          return true;
      }
    }));
  }, [rows, filters]);
  const clicksTotal = stats.data?.clicks ?? 0;
  const trackeadas = filtered.filter((r) => r.utm_source || r.fbclid).length || clicksTotal;
  const isDR = mode === "direct_response";
  const entradas = isDR ? stats.data?.views ?? 0 : stats.data?.joins ?? 0;
  const saidas = isDR ? stats.data?.purchases ?? 0 : 0;
  const leadsCount = isDR ? stats.data?.leads ?? 0 : 0;
  const revenue = stats.data?.revenue ?? 0;
  const taxaEntrada = entradas > 0 ? 100 : 0;
  const taxaConv = isDR && entradas > 0 ? Math.round(saidas / entradas * 100) : 0;
  const byDevice = aggregate(filtered, (r) => detectDevice(r.user_agent));
  const bySource = aggregate(filtered, (r) => r.utm_source ?? "(sem)");
  aggregate(filtered, (r) => r.utm_campaign ?? "(sem)");
  const byCountry = aggregate(filtered, () => "BR");
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-[260px_1fr_auto] gap-3 items-end", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground mb-1", children: "Periodo" }),
        /* @__PURE__ */ jsxs("p", { className: "text-xs text-primary mb-1", children: [
          "⏱ ",
          range?.from ? `${format(range.from, "dd/MM/yyyy")}${range.to ? ` – ${format(range.to, "dd/MM/yyyy")}` : ""}` : "Últimos 30 dias"
        ] }),
        /* @__PURE__ */ jsxs(Popover, { children: [
          /* @__PURE__ */ jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { variant: "outline", className: "w-full justify-between font-normal", children: [
            "Selecione uma Data",
            /* @__PURE__ */ jsx(Calendar$1, { className: "size-4 text-muted-foreground" })
          ] }) }),
          /* @__PURE__ */ jsx(PopoverContent, { align: "start", className: "w-auto p-0", children: /* @__PURE__ */ jsx(Calendar, { mode: "range", selected: range, onSelect: setRange, numberOfMonths: 2, locale: ptBR }) })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "text-center text-sm text-muted-foreground italic", children: filters.length === 0 ? "Nenhum filtro customizado aplicado." : /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2 justify-center", children: filters.map((f, i) => /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 bg-muted px-2 py-1 rounded text-xs not-italic", children: [
        /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
          f.key,
          ":"
        ] }),
        /* @__PURE__ */ jsx("input", { className: "bg-transparent outline-none w-24", value: f.value, onChange: (e) => setFilters((arr) => arr.map((x, j) => j === i ? {
          ...x,
          value: e.target.value
        } : x)), placeholder: "valor" }),
        /* @__PURE__ */ jsx("button", { onClick: () => setFilters((arr) => arr.filter((_, j) => j !== i)), children: /* @__PURE__ */ jsx(X, { className: "size-3" }) })
      ] }, i)) }) }),
      /* @__PURE__ */ jsxs(DropdownMenu, { children: [
        /* @__PURE__ */ jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { className: "bg-primary text-primary-foreground gap-2", children: [
          /* @__PURE__ */ jsx(Filter, { className: "size-4" }),
          " Adicionar Filtro ",
          /* @__PURE__ */ jsx(ChevronDown, { className: "size-4" })
        ] }) }),
        /* @__PURE__ */ jsx(DropdownMenuContent, { align: "end", className: "w-48", children: FILTER_OPTIONS.map((opt) => /* @__PURE__ */ jsx(DropdownMenuItem, { onClick: () => setFilters((arr) => [...arr, {
          key: opt,
          value: ""
        }]), children: opt }, opt)) })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: isDR ? /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4 col-span-1 md:col-span-3", children: [
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: /* @__PURE__ */ jsx(BigStatCard, { label: "Visualizações", value: entradas, subA: {
        label: "Leads",
        value: leadsCount
      }, subB: {
        label: "Lead rate",
        value: `${entradas > 0 ? Math.round(leadsCount / entradas * 100) : 0}%`,
        percent: entradas > 0 ? Math.round(leadsCount / entradas * 100) : 0
      } }) }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "bg-card rounded-xl border p-4 flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Checkout Inic." }),
          /* @__PURE__ */ jsx("p", { className: "text-xl font-bold mt-1", children: stats.data?.checkouts ?? 0 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-card rounded-xl border p-4 flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Abandonos" }),
          /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-yellow-500 mt-1", children: stats.data?.abandonedCarts ?? 0 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-card rounded-xl border p-4 flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Reembolsos" }),
          /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-red-400 mt-1", children: stats.data?.refunds ?? 0 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "bg-card rounded-xl border p-4 flex flex-col items-center justify-center", children: [
          /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: "Chargebacks" }),
          /* @__PURE__ */ jsx("p", { className: "text-xl font-bold text-red-500 mt-1", children: stats.data?.chargebacks ?? 0 })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsx(BigStatCard, { label: "Compras", value: saidas, subA: {
          label: "Checkouts",
          value: stats.data?.checkouts ?? 0
        }, subB: {
          label: "Conversão",
          value: `${taxaConv}%`,
          percent: taxaConv
        } }),
        /* @__PURE__ */ jsx(BigStatCard, { label: "Receita", value: `R$ ${revenue.toFixed(2)}`, valueSuffix: "", subA: {
          label: "Ticket médio",
          value: saidas > 0 ? `R$ ${(revenue / saidas).toFixed(2)}` : "—"
        }, subB: {
          label: "Dados pgto",
          value: String(stats.data?.paymentInfos ?? 0),
          percent: entradas > 0 ? Math.round((stats.data?.paymentInfos ?? 0) / entradas * 100) : 0
        } })
      ] })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(BigStatCard, { label: "Entradas", value: entradas, subA: {
        label: "Trackeadas",
        value: trackeadas
      }, subB: {
        label: "Taxa de trackeamento",
        value: `${taxaEntrada}%`,
        percent: taxaEntrada
      } }),
      /* @__PURE__ */ jsx(BigStatCard, { label: "Saidas", value: saidas, subA: {
        label: "Trackeadas",
        value: 0
      }, subB: {
        label: "Taxa de trackeamento",
        value: `${taxaConv}%`,
        percent: taxaConv
      } }),
      /* @__PURE__ */ jsx(BigStatCard, { label: "Tempo Medio de Permanencia", value: "—", valueSuffix: "", subB: {
        label: "Bounce rate (1d-)",
        value: "0%",
        percent: 0
      } })
    ] }) }),
    /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "p-6 space-y-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Visao Geral" }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsx(DonutCard, { title: "Por Pais", data: byCountry }),
        /* @__PURE__ */ jsx(DonutCard, { title: "Por Estado", data: [{
          name: "(sem)",
          value: filtered.length || 1
        }] }),
        /* @__PURE__ */ jsx(DonutCard, { title: "Por Dispositivo", data: byDevice }),
        /* @__PURE__ */ jsx(DonutCard, { title: "Por Funil", data: bySource })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "p-6 space-y-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Leads" }),
        /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", className: "gap-2", onClick: () => exportCsv(filtered), children: [
          /* @__PURE__ */ jsx(Download, { className: "size-4" }),
          " Exportar CSV"
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto rounded-md border", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-xs", children: [
        /* @__PURE__ */ jsx("thead", { className: "text-muted-foreground bg-muted/30", children: /* @__PURE__ */ jsx("tr", { children: (isDR ? ["Data", "Horario", "Trackeado", "Email/ID", "Status", "Valor", "URL", "utm_source", "utm_medium", "utm_campaign", "utm_content", "Dispositivo"] : ["Data", "Horario", "Trackeado", "ID Telegram", "Nome", "Status", "Funil", "URL", "utm_source", "utm_medium", "utm_campaign", "utm_content", "Dispositivo", "Pais", "Estado", "Cidade", "Data Saída", "Hora Saída", "Permanência"]).map((h) => /* @__PURE__ */ jsx("th", { className: "text-left p-3 font-medium uppercase tracking-wider whitespace-nowrap", children: h }, h)) }) }),
        /* @__PURE__ */ jsxs("tbody", { children: [
          filtered.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: isDR ? 12 : 19, className: "p-6 text-center text-muted-foreground", children: "Sem leads no período." }) }),
          filtered.map((c) => {
            const d = new Date(c.created_at);
            const status = isDR ? c.refunded_at ? "Reembolso" : c.chargeback_at ? "Chargeback" : c.purchased_at ? "Compra" : c.abandoned_cart_at ? "Abandono" : c.payment_info_at ? "Pgto" : c.checkout_at ? "Checkout" : c.lead_at ? "Lead" : c.viewed_at ? "View" : "Clique" : c.deposited_at ? "Depósito" : c.registered_at ? "Cadastro" : c.joined_at ? "Entrou" : "Clique";
            const tracked = !!(c.utm_source || c.fbclid);
            if (isDR) return /* @__PURE__ */ jsxs("tr", { className: "border-t hover:bg-muted/30", children: [
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: format(d, "dd/MM/yyyy") }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: format(d, "HH:mm") }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: tracked ? /* @__PURE__ */ jsx(Check, { className: "size-4 text-emerald-500" }) : /* @__PURE__ */ jsx(X, { className: "size-4 text-muted-foreground" }) }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.external_id ? `${String(c.external_id).slice(0, 10)}…` : "-" }),
              /* @__PURE__ */ jsx("td", { className: `p-3 whitespace-nowrap ${c.refunded_at ? "text-red-400" : c.chargeback_at ? "text-red-500" : c.purchased_at ? "text-emerald-500" : c.abandoned_cart_at ? "text-yellow-500" : "text-emerald-500"}`, children: status }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.sale_value ? `R$ ${Number(c.sale_value).toFixed(2)}` : "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 max-w-[180px] truncate text-primary", children: c.landing_url ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_source ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_medium ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_campaign ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_content ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 max-w-[160px] truncate", children: detectDevice(c.user_agent) })
            ] }, c.click_id);
            return /* @__PURE__ */ jsxs("tr", { className: "border-t hover:bg-muted/30", children: [
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: format(d, "dd/MM/yyyy") }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: format(d, "HH:mm") }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: tracked ? /* @__PURE__ */ jsx(Check, { className: "size-4 text-emerald-500" }) : /* @__PURE__ */ jsx(X, { className: "size-4 text-muted-foreground" }) }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.tg_user_id ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.tg_username ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 text-emerald-500 whitespace-nowrap", children: status }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_campaign ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 max-w-[180px] truncate text-primary", children: c.landing_url ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_source ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_medium ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_campaign ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 whitespace-nowrap", children: c.utm_content ?? "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3 max-w-[160px] truncate", children: detectDevice(c.user_agent) }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: "BR" }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: "-" }),
              /* @__PURE__ */ jsx("td", { className: "p-3", children: "-" })
            ] }, c.click_id);
          })
        ] })
      ] }) })
    ] }) })
  ] });
}
function aggregate(rows, pick) {
  const m = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const k = pick(r) || "(sem)";
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return Array.from(m.entries()).map(([name, value]) => ({
    name,
    value
  })).sort((a, b) => b.value - a.value).slice(0, 6);
}
function exportCsv(rows) {
  const header = ["data", "horario", "trackeado", "tg_user_id", "tg_username", "status", "url", "utm_source", "utm_medium", "utm_campaign", "utm_content", "dispositivo"];
  const lines = [header.join(",")];
  for (const c of rows) {
    const d = new Date(c.created_at);
    const status = c.refunded_at ? "Reembolso" : c.chargeback_at ? "Chargeback" : c.purchased_at ? "Compra" : c.abandoned_cart_at ? "Abandono" : c.deposited_at ? "Deposito" : c.registered_at ? "Cadastro" : c.joined_at ? "Entrou" : "Clique";
    lines.push([format(d, "dd/MM/yyyy"), format(d, "HH:mm"), c.utm_source || c.fbclid ? "sim" : "nao", c.tg_user_id ?? "", c.tg_username ?? "", status, c.landing_url ?? "", c.utm_source ?? "", c.utm_medium ?? "", c.utm_campaign ?? "", c.utm_content ?? "", detectDevice(c.user_agent)].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","));
  }
  const blob = new Blob([lines.join("\n")], {
    type: "text/csv;charset=utf-8"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `leads-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
function BigStatCard({
  label,
  value,
  valueSuffix = "total",
  subA,
  subB
}) {
  return /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsx("p", { className: "text-[11px] uppercase tracking-wider text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxs("p", { className: "text-5xl font-bold leading-none", children: [
      value,
      valueSuffix && /* @__PURE__ */ jsx("span", { className: "text-base font-normal text-muted-foreground ml-2", children: valueSuffix })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4 pt-3 border-t border-border/50", children: [
      /* @__PURE__ */ jsx("div", { children: subA && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: subA.label }),
        /* @__PURE__ */ jsx("p", { className: "text-2xl font-semibold mt-1", children: subA.value })
      ] }) }),
      /* @__PURE__ */ jsx("div", { children: subB && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("p", { className: "text-[10px] uppercase tracking-wider text-muted-foreground", children: subB.label }),
        /* @__PURE__ */ jsx("p", { className: "text-2xl font-semibold mt-1", children: subB.value }),
        /* @__PURE__ */ jsx("div", { className: "h-1 bg-muted rounded-full mt-2 overflow-hidden", children: /* @__PURE__ */ jsx("div", { className: "h-full bg-primary", style: {
          width: `${subB.percent}%`
        } }) })
      ] }) })
    ] })
  ] }) });
}
function DonutCard({
  title,
  data
}) {
  const safe = data.length > 0 ? data : [{
    name: "(sem dados)",
    value: 1
  }];
  return /* @__PURE__ */ jsxs("div", { className: "rounded-lg border bg-card/50 p-4", children: [
    /* @__PURE__ */ jsx("p", { className: "text-center text-[11px] uppercase tracking-wider text-muted-foreground mb-2", children: title }),
    /* @__PURE__ */ jsx("div", { className: "h-48", children: /* @__PURE__ */ jsx(ClientOnly, { fallback: /* @__PURE__ */ jsx("div", { className: "h-full" }) }) }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-x-3 gap-y-1 justify-center text-[11px] mt-1", children: safe.map((d, i) => /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1", children: [
      /* @__PURE__ */ jsx("span", { className: "inline-block size-2 rounded-sm", style: {
        background: DONUT_COLORS[i % DONUT_COLORS.length]
      } }),
      /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: d.name })
    ] }, d.name)) })
  ] });
}
export {
  MetricasPage as component
};
