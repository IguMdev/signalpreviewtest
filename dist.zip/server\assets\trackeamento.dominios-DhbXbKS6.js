import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { q as listDomains, r as createDomain, s as deleteDomain, v as verifyDomain } from "./tracking.functions-jGKb0ig9.js";
import { D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, h as DialogHeader, i as DialogTitle, I as Input, j as DialogFooter, C as Card, x as CardContent, H as Badge, O as CardHeader, Q as CardTitle, W as CardDescription } from "./router-Cw6OHOsO.js";
import { Globe, Plus, AlertTriangle, ShieldCheck, Trash2, Copy } from "lucide-react";
import "@tanstack/react-router";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function validateDomain(value) {
  const v = value.trim();
  if (!v) return null;
  if (/^https?:\/\//i.test(v)) return "Não inclua https://, //, ou slugs. Digite apenas o domínio - ex: www.track4you.app";
  if (v.startsWith("//")) return "Não inclua https://, //, ou slugs. Digite apenas o domínio - ex: www.track4you.app";
  if (v.includes("/")) return "Não inclua https://, //, ou slugs. Digite apenas o domínio - ex: www.track4you.app";
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(v)) return "Digite um domínio válido - ex: www.track4you.app";
  return null;
}
function DomainsPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listDomains);
  const createFn = useServerFn(createDomain);
  const delFn = useServerFn(deleteDomain);
  const verFn = useServerFn(verifyDomain);
  const domains = useQuery({
    queryKey: ["tracking-domains"],
    queryFn: () => listFn()
  });
  const [open, setOpen] = useState(false);
  const [domain, setDomain] = useState("");
  const domainError = validateDomain(domain);
  const canSave = domain.trim().length > 0 && !domainError;
  const create = useMutation({
    mutationFn: () => createFn({
      data: {
        domain
      }
    }),
    onSuccess: () => {
      toast.success("Domínio adicionado. Configure o registro TXT para verificar.");
      setOpen(false);
      setDomain("");
      qc.invalidateQueries({
        queryKey: ["tracking-domains"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const remove = useMutation({
    mutationFn: (id) => delFn({
      data: {
        id
      }
    }),
    onSuccess: () => {
      toast.success("Removido");
      qc.invalidateQueries({
        queryKey: ["tracking-domains"]
      });
    }
  });
  const verify = useMutation({
    mutationFn: (id) => verFn({
      data: {
        id
      }
    }),
    onSuccess: () => {
      toast.success("Domínio verificado!");
      qc.invalidateQueries({
        queryKey: ["tracking-domains"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-4xl", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Globe, { className: "size-6" }),
          " Domínios"
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground mt-1 max-w-2xl", children: [
          "Use um domínio próprio nos seus links de redirect (ex.: ",
          /* @__PURE__ */ jsx("code", { children: "track.seusite.com/g/..." }),
          ") em vez do domínio padrão. Isso melhora a entregabilidade e o branding."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange: (o) => {
        setOpen(o);
        if (!o) setDomain("");
      }, children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { children: [
          /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
          " Adicionar domínio"
        ] }) }),
        /* @__PURE__ */ jsxs(DialogContent, { children: [
          /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Novo domínio" }) }),
          /* @__PURE__ */ jsx("div", { className: "space-y-3", children: /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Input, { value: domain, onChange: (e) => setDomain(e.target.value.toLowerCase()), placeholder: "www.track4you.app", className: domainError ? "border-destructive focus-visible:ring-destructive" : "" }),
            domainError && /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2 text-xs text-destructive", children: [
              /* @__PURE__ */ jsx(AlertTriangle, { className: "size-4 shrink-0 mt-0.5" }),
              /* @__PURE__ */ jsxs("span", { children: [
                "Não inclua ",
                /* @__PURE__ */ jsx("em", { children: "https://" }),
                ", ",
                /* @__PURE__ */ jsx("em", { children: "//" }),
                ", ou slugs. Digite apenas o domínio - ex: ",
                /* @__PURE__ */ jsx("em", { children: "www.track4you.app" })
              ] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxs(DialogFooter, { children: [
            /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setOpen(false), children: "Cancelar" }),
            /* @__PURE__ */ jsx(Button, { onClick: () => create.mutate(), disabled: !canSave || create.isPending, children: "Salvar" })
          ] })
        ] })
      ] })
    ] }),
    domains.isLoading ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Carregando..." }) : domains.data && domains.data.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid gap-3", children: domains.data.map((d) => /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "p-4 space-y-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 flex-wrap", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "font-semibold text-lg", children: d.domain }),
          /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2 mt-1", children: d.verified_at ? /* @__PURE__ */ jsxs(Badge, { className: "bg-emerald-600 hover:bg-emerald-700", children: [
            /* @__PURE__ */ jsx(ShieldCheck, { className: "size-3 mr-1" }),
            " Verificado"
          ] }) : /* @__PURE__ */ jsx(Badge, { variant: "outline", children: "Aguardando DNS" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          !d.verified_at && /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", onClick: () => verify.mutate(d.id), disabled: verify.isPending, children: "Verificar agora" }),
          /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => {
            if (confirm("Remover domínio?")) remove.mutate(d.id);
          }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
        ] })
      ] }),
      !d.verified_at && /* @__PURE__ */ jsxs("div", { className: "rounded-lg bg-muted/50 p-3 space-y-2 text-xs", children: [
        /* @__PURE__ */ jsx("p", { className: "font-semibold", children: "Configure os registros DNS:" }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-muted-foreground", children: [
            "1. Registro ",
            /* @__PURE__ */ jsx("strong", { children: "TXT" }),
            " para verificar a propriedade:"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[80px_1fr] gap-2 font-mono", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Tipo:" }),
            /* @__PURE__ */ jsx("span", { children: "TXT" }),
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Nome:" }),
            /* @__PURE__ */ jsx(CopyChip, { value: `_signal.${d.domain}` }),
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Valor:" }),
            /* @__PURE__ */ jsx(CopyChip, { value: `signal_verify=${d.verification_token}` })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1 pt-2 border-t border-border/50", children: [
          /* @__PURE__ */ jsxs("p", { className: "text-muted-foreground", children: [
            "2. Registro ",
            /* @__PURE__ */ jsx("strong", { children: "CNAME" }),
            " para apontar o tráfego:"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[80px_1fr] gap-2 font-mono", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Tipo:" }),
            /* @__PURE__ */ jsx("span", { children: "CNAME" }),
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Nome:" }),
            /* @__PURE__ */ jsx(CopyChip, { value: d.domain }),
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Valor:" }),
            /* @__PURE__ */ jsx(CopyChip, { value: "cname.telesignal.com.br" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-muted-foreground pt-1", children: "Use Cloudflare (modo proxy) para SSL automático. Pode levar até 1h para propagar." })
        ] })
      ] })
    ] }) }, d.id)) }) : /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardHeader, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: "Nenhum domínio configurado" }),
      /* @__PURE__ */ jsx(CardDescription, { children: "Sem domínio próprio, seus links usarão o domínio padrão da plataforma." })
    ] }) })
  ] });
}
function CopyChip({
  value
}) {
  return /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => {
    navigator.clipboard.writeText(value);
    toast.success("Copiado");
  }, className: "inline-flex items-center gap-1 bg-background border rounded px-2 py-0.5 text-left break-all hover:bg-accent transition w-fit max-w-full", children: [
    /* @__PURE__ */ jsx("span", { className: "truncate", children: value }),
    /* @__PURE__ */ jsx(Copy, { className: "size-3 shrink-0 opacity-60" })
  ] });
}
export {
  DomainsPage as component
};
