import { jsxs, jsx } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useState, useMemo, useEffect } from "react";
import { g as getMemberStats, a as getCurrentMemberCounts } from "./telegram-tracking.functions-CF7nyJdP.js";
import { C as Card, I as Input, B as Button, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem } from "./router-Cw6OHOsO.js";
import { T as Tabs, a as TabsList, b as TabsTrigger, c as TabsContent } from "./tabs-Bc7VJTwT.js";
import { RefreshCw, UserPlus, UserMinus, TrendingUp, Users } from "lucide-react";
import "@tanstack/react-router";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-tabs";
function MembrosPage() {
  const fetchStats = useServerFn(getMemberStats);
  const fetchCurrentCounts = useServerFn(getCurrentMemberCounts);
  const today = /* @__PURE__ */ new Date();
  const fmt = (d) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  };
  const [from, setFrom] = useState(fmt(today));
  const [to, setTo] = useState(fmt(today));
  const q = useQuery({
    queryKey: ["member-stats", from, to],
    queryFn: () => fetchStats({
      data: {
        from,
        to
      }
    })
  });
  const countsQ = useQuery({
    queryKey: ["member-current-counts"],
    queryFn: () => fetchCurrentCounts()
  });
  const data = q.data;
  const currentCounts = countsQ.data;
  const [tab, setTab] = useState("group");
  const [selectedGroup, setSelectedGroup] = useState("all");
  const [selectedChannel, setSelectedChannel] = useState("all");
  const typeByChatId = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const c of currentCounts?.chats ?? []) m.set(String(c.chatId), c.chatType);
    return m;
  }, [currentCounts]);
  const groups = (currentCounts?.chats ?? []).filter((c) => c.chatType === "group" || c.chatType === "unknown");
  const channels = (currentCounts?.chats ?? []).filter((c) => c.chatType === "channel");
  useEffect(() => {
    if (!currentCounts) return;
    if (groups.length === 0 && channels.length > 0 && tab === "group") setTab("channel");
    else if (channels.length === 0 && groups.length > 0 && tab === "channel") setTab("group");
  }, [currentCounts, groups.length, channels.length, tab]);
  const selectedId = tab === "group" ? selectedGroup : selectedChannel;
  const visibleChats = (tab === "group" ? groups : channels).filter((c) => selectedId === "all" || String(c.chatId) === selectedId);
  const visiblePerChat = (data?.perChat ?? []).filter((c) => {
    const chatId = String(c.chat_id);
    const t = typeByChatId.get(chatId) ?? "unknown";
    const inTab = tab === "group" ? t !== "channel" : t === "channel";
    return inTab && (selectedId === "all" || chatId === selectedId);
  });
  const perChatById = useMemo(() => new Map(visiblePerChat.map((c) => [String(c.chat_id), c])), [visiblePerChat]);
  const visibleChatActivity = visibleChats.map((chat) => {
    const stats = perChatById.get(String(chat.chatId));
    return {
      chat_id: chat.chatId,
      chat_title: stats?.chat_title || chat.chatTitle || chat.roomName || null,
      joins: stats?.joins ?? 0,
      leaves: stats?.leaves ?? 0
    };
  });
  const visibleRecent = (data?.recent ?? []).filter((e) => {
    const chatId = String(e.chat_id);
    const t = typeByChatId.get(chatId) ?? "unknown";
    const inTab = tab === "group" ? t !== "channel" : t === "channel";
    return inTab && (selectedId === "all" || chatId === selectedId);
  });
  const totalMembers = visibleChats.reduce((s, c) => s + (c.count ?? 0), 0);
  const totalJoins = visiblePerChat.reduce((s, c) => s + c.joins, 0);
  const totalLeaves = visiblePerChat.reduce((s, c) => s + c.leaves, 0);
  const cards = [{
    label: "Entradas hoje",
    value: totalJoins,
    icon: UserPlus,
    color: "text-emerald-500"
  }, {
    label: "Saídas hoje",
    value: totalLeaves,
    icon: UserMinus,
    color: "text-rose-500"
  }, {
    label: "Saldo no período",
    value: totalJoins - totalLeaves,
    icon: TrendingUp,
    color: "text-primary"
  }, {
    label: "Membros atuais",
    value: totalMembers,
    icon: Users,
    color: "text-foreground"
  }];
  const maxBar = Math.max(1, ...(data?.daily ?? []).flatMap((d) => [d.joins, d.leaves]));
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Membros dos grupos" }),
      /* @__PURE__ */ jsxs("p", { className: "text-muted-foreground text-sm", children: [
        "Entradas e saídas detectadas pelos bots. Ative o rastreamento em ",
        /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Contas Telegram" }),
        " para começar a coletar dados."
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-4 flex flex-wrap items-end gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-1", children: [
        /* @__PURE__ */ jsx("label", { className: "text-xs text-muted-foreground", children: "De" }),
        /* @__PURE__ */ jsx(Input, { type: "date", value: from, max: to, onChange: (e) => setFrom(e.target.value), className: "w-[160px]" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-1", children: [
        /* @__PURE__ */ jsx("label", { className: "text-xs text-muted-foreground", children: "Até" }),
        /* @__PURE__ */ jsx(Input, { type: "date", value: to, min: from, max: fmt(/* @__PURE__ */ new Date()), onChange: (e) => setTo(e.target.value), className: "w-[160px]" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: () => {
          setFrom(fmt(/* @__PURE__ */ new Date()));
          setTo(fmt(/* @__PURE__ */ new Date()));
        }, children: "Hoje" }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: () => {
          const d = /* @__PURE__ */ new Date();
          d.setDate(d.getDate() - 1);
          setFrom(fmt(d));
          setTo(fmt(d));
        }, children: "Ontem" }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: () => {
          const d = /* @__PURE__ */ new Date();
          d.setDate(d.getDate() - 6);
          setFrom(fmt(d));
          setTo(fmt(/* @__PURE__ */ new Date()));
        }, children: "7 dias" }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: () => {
          const d = /* @__PURE__ */ new Date();
          d.setDate(d.getDate() - 29);
          setFrom(fmt(d));
          setTo(fmt(/* @__PURE__ */ new Date()));
        }, children: "30 dias" })
      ] }),
      q.isFetching && /* @__PURE__ */ jsx(RefreshCw, { className: "size-4 text-muted-foreground animate-spin ml-auto" })
    ] }),
    /* @__PURE__ */ jsxs(Tabs, { value: tab, onValueChange: (v) => setTab(v), children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-3 justify-between", children: [
        /* @__PURE__ */ jsxs(TabsList, { children: [
          /* @__PURE__ */ jsxs(TabsTrigger, { value: "group", children: [
            "Grupos (",
            groups.length,
            ")"
          ] }),
          /* @__PURE__ */ jsxs(TabsTrigger, { value: "channel", children: [
            "Canais (",
            channels.length,
            ")"
          ] })
        ] }),
        tab === "group" ? /* @__PURE__ */ jsxs(Select, { value: selectedGroup, onValueChange: setSelectedGroup, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-[280px]", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione um grupo" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos os grupos" }),
            groups.map((c) => /* @__PURE__ */ jsx(SelectItem, { value: String(c.chatId), children: c.chatTitle || c.roomName || `Chat ${c.chatId}` }, c.chatId))
          ] })
        ] }) : /* @__PURE__ */ jsxs(Select, { value: selectedChannel, onValueChange: setSelectedChannel, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-[280px]", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione um canal" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos os canais" }),
            channels.map((c) => /* @__PURE__ */ jsx(SelectItem, { value: String(c.chatId), children: c.chatTitle || c.roomName || `Chat ${c.chatId}` }, c.chatId))
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(TabsContent, { value: tab, className: "mt-4 space-y-6", children: [
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-4", children: cards.map(({
          label,
          value,
          icon: Icon,
          color
        }) => /* @__PURE__ */ jsxs(Card, { className: "p-5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-sm text-muted-foreground", children: label }),
            /* @__PURE__ */ jsx(Icon, { className: `size-4 ${color}` })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-3 text-3xl font-bold", children: value })
        ] }, label)) }),
        /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
          /* @__PURE__ */ jsx("h2", { className: "font-semibold mb-4", children: "Entradas e saídas por dia" }),
          !data?.daily.length ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground py-8 text-center", children: "Sem eventos ainda." }) : /* @__PURE__ */ jsx("div", { className: "space-y-1", children: data.daily.slice(-30).map((d) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-xs", children: [
            /* @__PURE__ */ jsx("span", { className: "w-20 text-muted-foreground tabular-nums", children: d.day }),
            /* @__PURE__ */ jsxs("div", { className: "flex-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsx("div", { className: "h-3 bg-emerald-500/70 rounded", style: {
                width: `${d.joins / maxBar * 100}%`
              }, title: `+${d.joins}` }),
              /* @__PURE__ */ jsxs("span", { className: "tabular-nums w-8 text-emerald-600", children: [
                "+",
                d.joins
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsx("div", { className: "h-3 bg-rose-500/70 rounded", style: {
                width: `${d.leaves / maxBar * 100}%`
              }, title: `-${d.leaves}` }),
              /* @__PURE__ */ jsxs("span", { className: "tabular-nums w-8 text-rose-600", children: [
                "-",
                d.leaves
              ] })
            ] })
          ] }, d.day)) })
        ] }),
        /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 mb-4", children: [
            /* @__PURE__ */ jsxs("h2", { className: "font-semibold", children: [
              "Contagem atual ",
              tab === "group" ? "por grupo" : "por canal"
            ] }),
            countsQ.isFetching && /* @__PURE__ */ jsx(RefreshCw, { className: "size-4 text-muted-foreground animate-spin" })
          ] }),
          !visibleChats.length ? /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground py-8 text-center", children: [
            "Nenhum ",
            tab === "group" ? "grupo" : "canal",
            " vinculado às salas."
          ] }) : /* @__PURE__ */ jsx("div", { className: "space-y-2", children: visibleChats.map((c) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg bg-muted/50 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate", children: c.chatTitle || c.roomName || `Chat ${c.chatId}` }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground truncate", children: [
                "ID: ",
                c.chatId,
                c.accountLabel ? ` • ${c.accountLabel}` : ""
              ] }),
              c.error && /* @__PURE__ */ jsx("p", { className: "text-xs text-destructive mt-1", children: c.error })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-lg font-semibold tabular-nums shrink-0", children: c.count?.toLocaleString("pt-BR") ?? "—" })
          ] }, `${c.roomId}-${c.chatId}`)) })
        ] }),
        /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
          /* @__PURE__ */ jsxs("h2", { className: "font-semibold mb-4", children: [
            "Entradas e saídas ",
            tab === "group" ? "por grupo" : "por canal"
          ] }),
          !visibleChatActivity.length ? /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground py-8 text-center", children: [
            "Nenhum ",
            tab === "group" ? "grupo" : "canal",
            " vinculado às salas."
          ] }) : /* @__PURE__ */ jsx("div", { className: "space-y-2", children: visibleChatActivity.map((c) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg bg-muted/50", children: [
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate", children: c.chat_title || `Chat ${c.chat_id}` }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
                "ID: ",
                c.chat_id
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-3 text-sm tabular-nums", children: [
              /* @__PURE__ */ jsxs("span", { className: "text-emerald-500", children: [
                "+",
                c.joins
              ] }),
              /* @__PURE__ */ jsxs("span", { className: "text-rose-500", children: [
                "-",
                c.leaves
              ] }),
              /* @__PURE__ */ jsxs("span", { className: "font-semibold", children: [
                "= ",
                c.joins - c.leaves
              ] })
            ] })
          ] }, c.chat_id)) })
        ] }),
        /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
          /* @__PURE__ */ jsx("h2", { className: "font-semibold mb-4", children: "Eventos recentes (entradas e saídas)" }),
          !visibleRecent.length ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground py-8 text-center", children: "Nenhum evento para a seleção." }) : /* @__PURE__ */ jsx("div", { className: "space-y-1", children: visibleRecent.map((e) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between py-2 border-b border-border last:border-0 text-sm", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
              e.event_type === "join" ? /* @__PURE__ */ jsx(UserPlus, { className: "size-3.5 text-emerald-500 shrink-0" }) : /* @__PURE__ */ jsx(UserMinus, { className: "size-3.5 text-rose-500 shrink-0" }),
              /* @__PURE__ */ jsxs("span", { className: "truncate", children: [
                e.tg_first_name || e.tg_username || "Usuário",
                " ",
                /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: e.event_type === "join" ? "entrou em" : e.event_type === "kicked" ? "foi removido de" : "saiu de" }),
                " ",
                e.chat_title || e.chat_id
              ] })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground tabular-nums shrink-0 ml-2", children: new Date(e.occurred_at).toLocaleString("pt-BR") })
          ] }, e.id)) })
        ] })
      ] })
    ] })
  ] });
}
export {
  MembrosPage as component
};
