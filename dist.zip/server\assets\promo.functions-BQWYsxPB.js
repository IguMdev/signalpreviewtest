import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const StoreSchema = z.enum(["amazon", "shopee", "aliexpress", "mercadolivre", "privacy", "crakrevenue", "awempire", "bet365", "betano", "blaze", "kto", "sportingbet"]);
const listAffiliateAccounts_createServerFn_handler = createServerRpc({
  id: "845178501925ff025a9075c6462f357f94ec9cb82a28dbfd46f6218c98fdc76e",
  name: "listAffiliateAccounts",
  filename: "src/lib/promo.functions.ts"
}, (opts) => listAffiliateAccounts.__executeServer(opts));
const listAffiliateAccounts = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listAffiliateAccounts_createServerFn_handler, async ({
  context
}) => {
  const {
    data,
    error
  } = await context.supabase.from("affiliate_accounts").select("id, store, label, credentials, is_active, last_check_at, last_error, last_sync_at, created_at").order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return {
    accounts: data ?? []
  };
});
const upsertAffiliateAccount_createServerFn_handler = createServerRpc({
  id: "9afc4db0fbd526bdaab58d3ce560f1706664391f3d15201b0fdb4bff6680416e",
  name: "upsertAffiliateAccount",
  filename: "src/lib/promo.functions.ts"
}, (opts) => upsertAffiliateAccount.__executeServer(opts));
const upsertAffiliateAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid().optional(),
  store: StoreSchema,
  label: z.string().min(1).max(80),
  credentials: z.record(z.string(), z.string().max(500)),
  is_active: z.boolean().default(true)
})).handler(upsertAffiliateAccount_createServerFn_handler, async ({
  data,
  context
}) => {
  const payload = {
    user_id: context.userId,
    store: data.store,
    label: data.label,
    credentials: data.credentials,
    is_active: data.is_active
  };
  const q = data.id ? context.supabase.from("affiliate_accounts").update(payload).eq("id", data.id).select("id").single() : context.supabase.from("affiliate_accounts").insert(payload).select("id").single();
  const {
    data: row,
    error
  } = await q;
  if (error) throw new Error(error.message);
  return {
    id: row.id
  };
});
const deleteAffiliateAccount_createServerFn_handler = createServerRpc({
  id: "e8b80aab3a5edd12c8cd36b84055ad3e0a0a07fecf4aaac6a831e395d4556df3",
  name: "deleteAffiliateAccount",
  filename: "src/lib/promo.functions.ts"
}, (opts) => deleteAffiliateAccount.__executeServer(opts));
const deleteAffiliateAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid()
})).handler(deleteAffiliateAccount_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("affiliate_accounts").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const testAffiliateAccount_createServerFn_handler = createServerRpc({
  id: "669cdc114ce30c21c3b0bb25985c1773530a9a91b1a8a14bbda1ed26cb2597ff",
  name: "testAffiliateAccount",
  filename: "src/lib/promo.functions.ts"
}, (opts) => testAffiliateAccount.__executeServer(opts));
const testAffiliateAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid()
})).handler(testAffiliateAccount_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    STORE_CLIENTS
  } = await import("./registry.server-BHRe8HTK.js");
  const {
    data: acc,
    error
  } = await context.supabase.from("affiliate_accounts").select("store, credentials").eq("id", data.id).single();
  if (error || !acc) throw new Error(error?.message || "Conta não encontrada");
  const client = STORE_CLIENTS[acc.store];
  try {
    const offers = await client.fetchOffers(acc.credentials, {
      keywords: ["promocao"]
    });
    await context.supabase.from("affiliate_accounts").update({
      last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_error: null
    }).eq("id", data.id);
    return {
      ok: true,
      sampleCount: offers.length
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    await context.supabase.from("affiliate_accounts").update({
      last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_error: msg
    }).eq("id", data.id);
    return {
      ok: false,
      error: msg
    };
  }
});
const PromoSettingsSchema = z.object({
  room_id: z.string().uuid(),
  enabled: z.boolean(),
  interval_hours: z.number().int().min(1).max(168),
  stores: z.array(StoreSchema).min(0).max(12),
  min_discount_pct: z.number().int().min(0).max(100),
  min_price: z.number().nullable(),
  max_price: z.number().nullable(),
  categories: z.array(z.string().max(80)).max(20),
  keywords: z.array(z.string().max(80)).max(20),
  blacklist_keywords: z.array(z.string().max(80)).max(20),
  message_template: z.string().min(1).max(2e3),
  parse_mode: z.enum(["HTML", "MarkdownV2"]),
  send_image: z.boolean(),
  premium_account_id: z.string().uuid().nullable(),
  premium_enabled: z.boolean()
});
const getPromoBotSettings_createServerFn_handler = createServerRpc({
  id: "5c064b1cd7807dad52ee0e35ec5f01be01887e7c00d782fb369be6e9abcc33ae",
  name: "getPromoBotSettings",
  filename: "src/lib/promo.functions.ts"
}, (opts) => getPromoBotSettings.__executeServer(opts));
const getPromoBotSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid()
})).handler(getPromoBotSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    data: row,
    error
  } = await context.supabase.from("promo_bot_settings").select("*").eq("room_id", data.room_id).maybeSingle();
  if (error) throw new Error(error.message);
  return {
    settings: row
  };
});
const upsertPromoBotSettings_createServerFn_handler = createServerRpc({
  id: "feb054bee80e3924b6fe4bdf91fa85c425c969a5bb0f4f861806e4f33b8119da",
  name: "upsertPromoBotSettings",
  filename: "src/lib/promo.functions.ts"
}, (opts) => upsertPromoBotSettings.__executeServer(opts));
const upsertPromoBotSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(PromoSettingsSchema).handler(upsertPromoBotSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("promo_bot_settings").upsert({
    ...data,
    user_id: context.userId
  }, {
    onConflict: "room_id"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const previewPromoOffers_createServerFn_handler = createServerRpc({
  id: "ce9a7d566fb40d3e8cc4ebc0df1f0b6341c8e1fef77b8effaf4f6fc4a482e59c",
  name: "previewPromoOffers",
  filename: "src/lib/promo.functions.ts"
}, (opts) => previewPromoOffers.__executeServer(opts));
const previewPromoOffers = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid()
})).handler(previewPromoOffers_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    STORE_CLIENTS
  } = await import("./registry.server-BHRe8HTK.js");
  const {
    data: settings
  } = await context.supabase.from("promo_bot_settings").select("*").eq("room_id", data.room_id).maybeSingle();
  if (!settings) return {
    offers: []
  };
  const {
    data: accs
  } = await context.supabase.from("affiliate_accounts").select("store, credentials").eq("is_active", true);
  const accMap = new Map((accs ?? []).map((a) => [a.store, a.credentials]));
  const collected = [];
  for (const storeRaw of settings.stores) {
    const store = storeRaw;
    const creds = accMap.get(store);
    if (!creds) continue;
    try {
      const client = STORE_CLIENTS[store];
      const offers = await client.fetchOffers(creds, {
        keywords: settings.keywords ?? [],
        minDiscountPct: settings.min_discount_pct,
        minPrice: settings.min_price ?? void 0,
        maxPrice: settings.max_price ?? void 0
      });
      collected.push(...offers.slice(0, 5).map((o) => ({
        store: o.store,
        title: o.title,
        price: o.price ?? null,
        oldPrice: o.oldPrice ?? null,
        discountPct: o.discountPct ?? null,
        imageUrl: o.imageUrl ?? null,
        productUrl: o.productUrl
      })));
    } catch (e) {
      collected.push({
        store,
        error: e instanceof Error ? e.message : String(e)
      });
    }
  }
  return {
    offers: collected
  };
});
const listPromoDispatches_createServerFn_handler = createServerRpc({
  id: "2ce89b173a66e2e1bc8690700f4d6aa2606470a5648c1a92072d2f895353964e",
  name: "listPromoDispatches",
  filename: "src/lib/promo.functions.ts"
}, (opts) => listPromoDispatches.__executeServer(opts));
const listPromoDispatches = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid().optional(),
  limit: z.number().int().min(1).max(200).default(50)
})).handler(listPromoDispatches_createServerFn_handler, async ({
  data,
  context
}) => {
  let q = context.supabase.from("promo_dispatches").select("id, room_id, store, external_id, affiliate_link, ok, error, sent_at, telegram_message_id").order("sent_at", {
    ascending: false
  }).limit(data.limit);
  if (data.room_id) q = q.eq("room_id", data.room_id);
  const {
    data: rows,
    error
  } = await q;
  if (error) throw new Error(error.message);
  return {
    dispatches: rows ?? []
  };
});
const getPromoStats_createServerFn_handler = createServerRpc({
  id: "dd19c28962d785d1e990e836471a4acb4b5543ce828b5b28741b36a8e474263d",
  name: "getPromoStats",
  filename: "src/lib/promo.functions.ts"
}, (opts) => getPromoStats.__executeServer(opts));
const getPromoStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid().optional(),
  days: z.number().int().min(1).max(180).default(30)
})).handler(getPromoStats_createServerFn_handler, async ({
  data,
  context
}) => {
  const since = new Date(Date.now() - data.days * 864e5).toISOString();
  let dispatchQ = context.supabase.from("promo_dispatches").select("id, store, room_id, ok", {
    count: "exact"
  }).gte("sent_at", since);
  if (data.room_id) dispatchQ = dispatchQ.eq("room_id", data.room_id);
  const {
    data: dispatches
  } = await dispatchQ;
  const {
    data: clicks
  } = await context.supabase.from("promo_clicks").select("dispatch_id, clicked_at").gte("clicked_at", since);
  const {
    data: conversions
  } = await context.supabase.from("promo_conversions").select("commission_value, sale_value, status, store").gte("created_at", since);
  return {
    sent: dispatches?.length ?? 0,
    clicks: clicks?.length ?? 0,
    conversions: conversions?.length ?? 0,
    commissionTotal: (conversions ?? []).reduce((s, c) => s + Number(c.commission_value || 0), 0),
    saleTotal: (conversions ?? []).reduce((s, c) => s + Number(c.sale_value || 0), 0),
    byStore: groupByStore(dispatches ?? [])
  };
});
function groupByStore(rows) {
  const map = {};
  for (const r of rows) map[r.store] = (map[r.store] ?? 0) + 1;
  return map;
}
export {
  deleteAffiliateAccount_createServerFn_handler,
  getPromoBotSettings_createServerFn_handler,
  getPromoStats_createServerFn_handler,
  listAffiliateAccounts_createServerFn_handler,
  listPromoDispatches_createServerFn_handler,
  previewPromoOffers_createServerFn_handler,
  testAffiliateAccount_createServerFn_handler,
  upsertAffiliateAccount_createServerFn_handler,
  upsertPromoBotSettings_createServerFn_handler
};
