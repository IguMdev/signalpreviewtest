import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { C as Card, O as CardHeader, Q as CardTitle, x as CardContent, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, N as Switch, L as Label, I as Input, B as Button, T as Textarea } from "./router-Cw6OHOsO.js";
import { MessageCircle, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./client.server-CDheR9QG.js";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
const TimeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
const getFollowupSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("f48828778ab4b266229fca37c08d9cabbb9dbc1c3dabb92a1cfa06342d0cc3da"));
const upsertFollowupSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  enabled: z.boolean(),
  timezone: z.string().max(64).default("America/Sao_Paulo"),
  ctaEnabled: z.boolean(),
  ctaButtonText: z.string().min(1).max(64)
}).parse(d)).handler(createSsrRpc("7df86b85148b921548fad209068bd2a4df1065e2faf92d77d46f443bfb583327"));
const listFollowupMessages = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("80441ab02eac154f6657535381da3d124701a05d170692798cd1d17dc4db2f25"));
const MessageInput = z.object({
  id: z.string().uuid().optional(),
  roomId: z.string().uuid(),
  dayNumber: z.number().int().min(1).max(365),
  sendTime: z.string().regex(TimeRe).default("09:00"),
  content: z.string().max(4e3).nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  premiumEnabled: z.boolean().default(false),
  premiumAccountId: z.string().uuid().nullable().optional(),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional()
});
const upsertFollowupMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => MessageInput.parse(d)).handler(createSsrRpc("d56497e25ef5da3d47b18edba31efa6c353d09ea5a59cbdf36c3fa274d1cca34"));
const deleteFollowupMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("8a4a9f25a4085c0541cc9e082c48eb8180b7581ec60b5e1c348b0b1313986344"));
const listFollowupLeads = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("89ecdf9193e124ab5c95ef460718580f06c31c416785688a45efaee2a3ea49e0"));
const setFollowupLeadStatus = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  status: z.enum(["active", "stopped"])
}).parse(d)).handler(createSsrRpc("5322917ff3d34b3b9b9fa76ed9eaa81529bb8d180eab85ac31a0ff84efd147f9"));
const testFollowupMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  chatId: z.number().int()
}).parse(d)).handler(createSsrRpc("a9396ecd29149ed85ff4893dd56fd9164d94f50a3a3b93bdfe53e9d74ae7fbff"));
const SUPABASE_URL = "https://baemmrntfvoxtkttexyn.supabase.co";
function publicUrl(bucket, path) {
  return `${SUPABASE_URL.replace(/\/$/, "")}/storage/v1/object/public/${bucket}/${path}`;
}
function FollowUpPage() {
  const qc = useQueryClient();
  const getSettings = useServerFn(getFollowupSettings);
  const upsertSettings = useServerFn(upsertFollowupSettings);
  const listMsgs = useServerFn(listFollowupMessages);
  const upsertMsg = useServerFn(upsertFollowupMessage);
  const delMsg = useServerFn(deleteFollowupMessage);
  const listLeads = useServerFn(listFollowupLeads);
  const setLeadStatus = useServerFn(setFollowupLeadStatus);
  const testMsg = useServerFn(testFollowupMessage);
  const roomsQ = useQuery({
    queryKey: ["rooms-pick"],
    queryFn: async () => (await supabase.from("rooms").select("id, name").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const videosQ = useQuery({
    queryKey: ["videos-pick-fu"],
    queryFn: async () => (await supabase.from("videos").select("id, title, kind, storage_path").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const [roomId, setRoomId] = useState("");
  useEffect(() => {
    if (!roomId && roomsQ.data?.[0]?.id) setRoomId(roomsQ.data[0].id);
  }, [roomsQ.data, roomId]);
  const settingsQ = useQuery({
    queryKey: ["followup-settings", roomId],
    enabled: !!roomId,
    queryFn: () => getSettings({
      data: {
        roomId
      }
    })
  });
  const msgsQ = useQuery({
    queryKey: ["followup-messages", roomId],
    enabled: !!roomId,
    queryFn: () => listMsgs({
      data: {
        roomId
      }
    })
  });
  const leadsQ = useQuery({
    queryKey: ["followup-leads", roomId],
    enabled: !!roomId,
    queryFn: () => listLeads({
      data: {
        roomId
      }
    })
  });
  const [enabled, setEnabled] = useState(false);
  const [ctaEnabled, setCtaEnabled] = useState(true);
  const [ctaText, setCtaText] = useState("Iniciar conversa privada 💬");
  useEffect(() => {
    const s = settingsQ.data?.settings;
    const c = settingsQ.data?.cta;
    if (s) setEnabled(s.enabled);
    if (c) {
      setCtaEnabled(c.followup_cta_enabled);
      setCtaText(c.followup_cta_button_text || "Iniciar conversa privada 💬");
    }
  }, [settingsQ.data]);
  const saveSettings = useMutation({
    mutationFn: () => upsertSettings({
      data: {
        roomId,
        enabled,
        timezone: "America/Sao_Paulo",
        ctaEnabled,
        ctaButtonText: ctaText
      }
    }),
    onSuccess: () => {
      toast.success("Configurações salvas");
      qc.invalidateQueries({
        queryKey: ["followup-settings", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const [editing, setEditing] = useState(null);
  const saveMsg = useMutation({
    mutationFn: () => {
      if (!editing) throw new Error("Sem dados");
      return upsertMsg({
        data: {
          id: editing.id,
          roomId,
          dayNumber: Number(editing.day_number ?? 1),
          sendTime: editing.send_time?.slice(0, 5) || "09:00",
          content: editing.content || null,
          imagePath: editing.image_path || null,
          imageMime: editing.image_mime || null,
          videoId: editing.video_id || null,
          parseMode: "HTML",
          premiumEnabled: false,
          buttonText: editing.button_text || null,
          buttonUrl: editing.button_url || null
        }
      });
    },
    onSuccess: () => {
      toast.success("Mensagem salva");
      setEditing(null);
      qc.invalidateQueries({
        queryKey: ["followup-messages", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  async function uploadImage(file) {
    const ext = file.name.split(".").pop() ?? "jpg";
    const path = `followup/${roomId}/${Date.now()}.${ext}`;
    const {
      error
    } = await supabase.storage.from("room-images").upload(path, file, {
      upsert: true,
      contentType: file.type
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    setEditing((prev) => prev ? {
      ...prev,
      image_path: path,
      image_mime: file.type
    } : prev);
    toast.success("Imagem enviada");
  }
  const removeMsg = useMutation({
    mutationFn: (id) => delMsg({
      data: {
        id
      }
    }),
    onSuccess: () => {
      toast.success("Removida");
      qc.invalidateQueries({
        queryKey: ["followup-messages", roomId]
      });
    }
  });
  const counts = leadsQ.data?.counts ?? {
    active: 0,
    stopped: 0,
    completed: 0
  };
  const messages = msgsQ.data ?? [];
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-4xl", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(MessageCircle, { className: "size-6 text-primary" }),
        " Bot Follow-Up"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Sequência diária de mensagens enviadas no privado dos leads que iniciaram seu bot." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Sala" }) }),
      /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsxs(Select, { value: roomId, onValueChange: setRoomId, children: [
        /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione a sala" }) }),
        /* @__PURE__ */ jsx(SelectContent, { children: (roomsQ.data ?? []).map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
      ] }) })
    ] }),
    roomId && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center justify-between", children: [
        "Configuração",
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
          "Ativado ",
          /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "rounded-lg border p-3 space-y-3 bg-muted/20", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(Label, { className: "text-sm", children: 'Botão "Iniciar" no Boas-Vindas' }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-muted-foreground", children: "Anexa um botão na mensagem do Bot Boas-Vindas que leva o lead ao privado e o inscreve no follow-up." })
            ] }),
            /* @__PURE__ */ jsx(Switch, { checked: ctaEnabled, onCheckedChange: setCtaEnabled })
          ] }),
          ctaEnabled && /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Texto do botão" }),
            /* @__PURE__ */ jsx(Input, { value: ctaText, onChange: (e) => setCtaText(e.target.value), maxLength: 64 })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => saveSettings.mutate(), disabled: saveSettings.isPending, children: saveSettings.isPending ? "Salvando..." : "Salvar configurações" })
      ] })
    ] }),
    roomId && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center justify-between", children: [
        "Sequência de mensagens",
        /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: () => setEditing({
          day_number: (messages[messages.length - 1]?.day_number ?? 0) + 1,
          send_time: "09:00",
          content: ""
        }), children: [
          /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-1" }),
          " Adicionar dia"
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-2", children: [
        messages.length === 0 && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhuma mensagem cadastrada ainda." }),
        messages.map((m) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 rounded-md border p-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxs("p", { className: "text-sm font-medium", children: [
              "Dia ",
              m.day_number,
              " · ",
              m.send_time?.slice(0, 5)
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground truncate", children: m.content || "(sem texto)" })
          ] }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => setEditing(m), children: "Editar" }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => {
            if (confirm("Remover mensagem?")) removeMsg.mutate(m.id);
          }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
        ] }, m.id))
      ] })
    ] }),
    editing && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: editing.id ? "Editar mensagem" : "Nova mensagem" }) }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Dia" }),
            /* @__PURE__ */ jsx(Input, { type: "number", min: 1, max: 365, value: editing.day_number ?? 1, onChange: (e) => setEditing({
              ...editing,
              day_number: parseInt(e.target.value, 10) || 1
            }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Horário (HH:MM)" }),
            /* @__PURE__ */ jsx(Input, { type: "time", value: editing.send_time?.slice(0, 5) || "09:00", onChange: (e) => setEditing({
              ...editing,
              send_time: e.target.value
            }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs(Label, { className: "text-xs", children: [
            "Texto (use ",
            "{name}",
            " para mencionar o lead)"
          ] }),
          /* @__PURE__ */ jsx(Textarea, { rows: 5, value: editing.content ?? "", onChange: (e) => setEditing({
            ...editing,
            content: e.target.value
          }), maxLength: 4e3 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Imagem (opcional)" }),
            /* @__PURE__ */ jsx(Input, { type: "file", accept: "image/*", onChange: (e) => e.target.files?.[0] && uploadImage(e.target.files[0]) }),
            editing.image_path && /* @__PURE__ */ jsxs("div", { className: "mt-2 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx("img", { src: publicUrl("room-images", editing.image_path), alt: "prévia", className: "size-16 rounded object-cover" }),
              /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => setEditing({
                ...editing,
                image_path: null,
                image_mime: null
              }), children: "Remover" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Vídeo (opcional)" }),
            /* @__PURE__ */ jsxs(Select, { value: editing.video_id || "none", onValueChange: (v) => setEditing({
              ...editing,
              video_id: v === "none" ? null : v
            }), children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhum" }) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum" }),
                (videosQ.data ?? []).map((v) => /* @__PURE__ */ jsxs(SelectItem, { value: v.id, children: [
                  v.title,
                  " ",
                  v.kind === "round" ? "(redondo)" : ""
                ] }, v.id))
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Texto do botão (opcional)" }),
            /* @__PURE__ */ jsx(Input, { value: editing.button_text ?? "", onChange: (e) => setEditing({
              ...editing,
              button_text: e.target.value
            }), maxLength: 64 })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "URL do botão (opcional)" }),
            /* @__PURE__ */ jsx(Input, { value: editing.button_url ?? "", onChange: (e) => setEditing({
              ...editing,
              button_url: e.target.value
            }), placeholder: "https://..." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2 flex-wrap", children: [
          /* @__PURE__ */ jsx(Button, { onClick: () => saveMsg.mutate(), disabled: saveMsg.isPending, children: saveMsg.isPending ? "Salvando..." : "Salvar" }),
          editing.id && /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: async () => {
            const raw = prompt("Chat ID do Telegram para teste (seu user_id ou de um lead):");
            if (!raw) return;
            const chatId = parseInt(raw, 10);
            if (!Number.isFinite(chatId)) {
              toast.error("Chat ID inválido");
              return;
            }
            try {
              await testMsg({
                data: {
                  id: editing.id,
                  chatId
                }
              });
              toast.success("Enviado");
            } catch (e) {
              toast.error(e instanceof Error ? e.message : String(e));
            }
          }, children: "Testar agora" }),
          /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setEditing(null), children: "Cancelar" })
        ] })
      ] })
    ] }),
    roomId && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Leads" }) }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex gap-4 text-sm", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "Ativos: ",
            /* @__PURE__ */ jsx("b", { children: counts.active })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            "Parados: ",
            /* @__PURE__ */ jsx("b", { children: counts.stopped })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            "Completos: ",
            /* @__PURE__ */ jsx("b", { children: counts.completed })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1 max-h-96 overflow-auto", children: [
          (leadsQ.data?.leads ?? []).map((l) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 text-xs border-b py-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsx("span", { className: "font-medium", children: l.first_name ?? "—" }),
              l.username ? /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
                " @",
                l.username
              ] }) : null,
              /* @__PURE__ */ jsxs("span", { className: "ml-2 text-muted-foreground", children: [
                "dia ",
                l.last_sent_day ?? 0,
                " · ",
                l.status
              ] })
            ] }),
            /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => setLeadStatus({
              data: {
                id: l.id,
                status: l.status === "active" ? "stopped" : "active"
              }
            }).then(() => qc.invalidateQueries({
              queryKey: ["followup-leads", roomId]
            })), children: l.status === "active" ? "Pausar" : "Reativar" })
          ] }, l.id)),
          (leadsQ.data?.leads ?? []).length === 0 && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhum lead ainda." })
        ] })
      ] })
    ] })
  ] });
}
export {
  FollowUpPage as component
};
