import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
async function makeClient(apiId, apiHash, session = "") {
  const {
    TelegramClient
  } = await import("telegram");
  const {
    StringSession
  } = await import("telegram/sessions/index.js");
  const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
    connectionRetries: 2,
    useWSS: true
  });
  await client.connect();
  return client;
}
function detectMime(bytes) {
  if (!bytes.length) return null;
  const hex4 = bytes.subarray(0, 4).toString("hex");
  const hex8 = bytes.subarray(0, 8).toString("hex");
  if (hex4.startsWith("ffd8")) return "image/jpeg";
  if (hex8 === "89504e470d0a1a0a") return "image/png";
  if (bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (hex4 === "1a45dfa3") return "video/webm";
  if (bytes[0] === 31 && bytes[1] === 139) return "application/x-tgsticker";
  return null;
}
function mediaDataUrl(bytes) {
  const mime = detectMime(bytes);
  if (!mime) return null;
  return {
    url: `data:${mime};base64,${bytes.toString("base64")}`,
    mime
  };
}
async function hydrateEmojiDocuments(client, items) {
  if (!items.length) return;
  const {
    Api
  } = await import("telegram");
  const {
    strippedPhotoToJpg
  } = await import("telegram/Utils.js");
  const {
    default: bigInt
  } = await import("big-integer");
  const docs = await client.invoke(new Api.messages.GetCustomEmojiDocuments({
    documentId: items.map((i) => bigInt(i.custom_emoji_id))
  }));
  const hydrateOne = async (doc) => {
    const id = doc.id ? String(doc.id) : null;
    if (!id) return;
    const target = items.find((i) => i.custom_emoji_id === id);
    if (!target) return;
    const webpThumb = (doc.thumbs ?? []).filter((t) => t.className !== "PhotoPathSize").sort((a, b) => (b.size ?? 0) - (a.size ?? 0))[0];
    if (webpThumb) {
      const thumbBytes = await client.downloadMedia(doc, {
        thumb: webpThumb
      }).catch(() => null);
      if (thumbBytes?.length) {
        const detected = mediaDataUrl(thumbBytes);
        if (detected) {
          target.thumb_data_url = detected.url;
          target.thumb_mime = detected.mime;
        }
      }
    }
    if (!target.thumb_data_url) {
      const fullBytes = await client.downloadMedia(doc).catch(() => null);
      const detected = fullBytes?.length ? mediaDataUrl(fullBytes) : null;
      if (detected) {
        target.thumb_data_url = detected.url;
        target.thumb_mime = detected.mime;
      }
    }
    if (!target.thumb_data_url) {
      const embedded = (doc.thumbs ?? []).find((t) => t.className !== "PhotoPathSize" && t.bytes?.length);
      if (embedded?.bytes) {
        const raw = Buffer.from(embedded.bytes);
        const normalized = embedded.className === "PhotoStrippedSize" ? strippedPhotoToJpg(raw) : raw;
        const detected = mediaDataUrl(normalized);
        if (detected) {
          target.thumb_data_url = detected.url;
          target.thumb_mime = detected.mime;
        }
      }
    }
  };
  for (let i = 0; i < (docs ?? []).length; i += 6) {
    await Promise.all((docs ?? []).slice(i, i + 6).map((doc) => hydrateOne(doc)));
  }
}
const requestPremiumCode_createServerFn_handler = createServerRpc({
  id: "eafcf68c09ef7117507f8eb27b92e2fcf831b9c8e147ab56792c657a56b9b98f",
  name: "requestPremiumCode",
  filename: "src/lib/premium-account.functions.ts"
}, (opts) => requestPremiumCode.__executeServer(opts));
const requestPremiumCode = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  apiId: z.number().int().positive(),
  apiHash: z.string().min(10),
  phone: z.string().min(5)
}).parse(d)).handler(requestPremiumCode_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const client = await makeClient(data.apiId, data.apiHash);
  let phoneCodeHash;
  let sessionString;
  try {
    const r = await client.sendCode({
      apiId: data.apiId,
      apiHash: data.apiHash
    }, data.phone);
    phoneCodeHash = r.phoneCodeHash;
    sessionString = client.session.save() ?? "";
  } finally {
    await client.disconnect().catch(() => {
    });
  }
  const {
    error
  } = await supabase.from("telegram_accounts").update({
    tg_api_id: data.apiId,
    tg_api_hash: data.apiHash,
    phone: data.phone,
    tg_phone_code_hash: phoneCodeHash,
    tg_session: sessionString,
    status: "unknown",
    last_error: null
  }).eq("id", data.accountId);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const confirmPremiumCode_createServerFn_handler = createServerRpc({
  id: "e11e0b634bc507696d761a8e13f279ff5d7bcd325326316d1fb3a4e8049b6714",
  name: "confirmPremiumCode",
  filename: "src/lib/premium-account.functions.ts"
}, (opts) => confirmPremiumCode.__executeServer(opts));
const confirmPremiumCode = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  code: z.string().min(3),
  password: z.string().optional()
}).parse(d)).handler(confirmPremiumCode_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("tg_api_id, tg_api_hash, phone, tg_phone_code_hash, tg_session").eq("id", data.accountId).maybeSingle();
  if (error || !acc) throw new Error("Conta não encontrada");
  if (!acc.tg_api_id || !acc.tg_api_hash || !acc.phone || !acc.tg_phone_code_hash) {
    throw new Error("Solicite o código novamente.");
  }
  const client = await makeClient(acc.tg_api_id, acc.tg_api_hash, acc.tg_session ?? "");
  try {
    const me = await client.signInUser({
      apiId: acc.tg_api_id,
      apiHash: acc.tg_api_hash
    }, {
      phoneNumber: acc.phone,
      phoneCode: async () => data.code,
      password: data.password ? async () => data.password : void 0,
      onError: (err) => {
        throw err;
      }
    });
    const sessionString = client.session.save() ?? "";
    await supabase.from("telegram_accounts").update({
      tg_session: sessionString,
      tg_phone_code_hash: null,
      status: "ok",
      last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_error: null,
      bot_first_name: me?.firstName ?? null,
      bot_username: me?.username ?? null
    }).eq("id", data.accountId);
    return {
      ok: true,
      needsPassword: false
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (/SESSION_PASSWORD_NEEDED/i.test(msg)) {
      return {
        ok: false,
        needsPassword: true
      };
    }
    await supabase.from("telegram_accounts").update({
      status: "error",
      last_error: msg
    }).eq("id", data.accountId);
    throw e;
  } finally {
    await client.disconnect().catch(() => {
    });
  }
});
const syncPremiumEmojis_createServerFn_handler = createServerRpc({
  id: "2664d9c35138f431d18be3f3d5ebc7a5d45d618ffb31ec9e4c10f957970348c1",
  name: "syncPremiumEmojis",
  filename: "src/lib/premium-account.functions.ts"
}, (opts) => syncPremiumEmojis.__executeServer(opts));
const syncPremiumEmojis = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  since: z.string().datetime().optional()
}).parse(d)).handler(syncPremiumEmojis_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("tg_api_id, tg_api_hash, tg_session").eq("id", data.accountId).maybeSingle();
  if (error || !acc) throw new Error("Conta não encontrada");
  if (!acc.tg_session) throw new Error("Conecte a conta premium primeiro.");
  const {
    Api
  } = await import("telegram");
  const {
    default: bigInt
  } = await import("big-integer");
  const client = await makeClient(acc.tg_api_id, acc.tg_api_hash, acc.tg_session);
  const items = [];
  const sinceUnix = data.since ? Math.floor(new Date(data.since).getTime() / 1e3) : 0;
  try {
    const seen = /* @__PURE__ */ new Set();
    const dialogs = await client.getDialogs({
      limit: 50
    });
    const peers = [new Api.InputPeerSelf()];
    for (const d of dialogs) {
      if (d.inputEntity) peers.push(d.inputEntity);
    }
    for (const peer of peers) {
      try {
        const history = await client.invoke(new Api.messages.GetHistory({
          peer,
          offsetId: 0,
          offsetDate: 0,
          addOffset: 0,
          limit: 100,
          maxId: 0,
          minId: 0,
          hash: bigInt(0)
        }));
        for (const msg of history.messages ?? []) {
          const msgUnix = typeof msg.date === "number" ? msg.date : msg.date instanceof Date ? Math.floor(msg.date.getTime() / 1e3) : 0;
          if (sinceUnix && msgUnix < sinceUnix) continue;
          if (msg.out !== true) continue;
          const text = msg.message ?? "";
          for (const ent of msg.entities ?? []) {
            if (ent.className === "MessageEntityCustomEmoji" && ent.documentId) {
              const id = String(ent.documentId);
              if (seen.has(id)) continue;
              seen.add(id);
              const preview = typeof ent.offset === "number" && typeof ent.length === "number" ? text.substr(ent.offset, ent.length) : null;
              items.push({
                custom_emoji_id: id,
                preview_char: preview,
                thumb_data_url: null,
                thumb_mime: null
              });
            }
          }
        }
      } catch {
      }
    }
    if (items.length) {
      try {
        await hydrateEmojiDocuments(client, items);
      } catch {
      }
    }
  } finally {
    await client.disconnect().catch(() => {
    });
  }
  const {
    data: existing
  } = await supabase.from("premium_emojis").select("custom_emoji_id").eq("user_id", userId);
  const known = new Set((existing ?? []).map((r) => r.custom_emoji_id));
  const fresh = items.filter((i) => !known.has(i.custom_emoji_id));
  return {
    ok: true,
    items: fresh,
    count: fresh.length
  };
});
const getPremiumEmojiThumbs_createServerFn_handler = createServerRpc({
  id: "06dd158bb8d31327cc0235b073df3cffa204292936a232ec40e53bfd54012078",
  name: "getPremiumEmojiThumbs",
  filename: "src/lib/premium-account.functions.ts"
}, (opts) => getPremiumEmojiThumbs.__executeServer(opts));
const getPremiumEmojiThumbs = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  ids: z.array(z.string().min(1)).min(1).max(100)
}).parse(d)).handler(getPremiumEmojiThumbs_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("tg_api_id, tg_api_hash, tg_session").eq("account_type", "premium").eq("is_active", true).not("tg_session", "is", null).limit(1).maybeSingle();
  if (error || !acc?.tg_session || !acc.tg_api_id || !acc.tg_api_hash) return {
    ok: false,
    items: []
  };
  const client = await makeClient(acc.tg_api_id, acc.tg_api_hash, acc.tg_session);
  const items = data.ids.map((id) => ({
    custom_emoji_id: id,
    thumb_data_url: null,
    thumb_mime: null
  }));
  try {
    await hydrateEmojiDocuments(client, items);
    return {
      ok: true,
      items
    };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
});
const sendPremiumMessage_createServerFn_handler = createServerRpc({
  id: "a68c6ea077e0df4dc32ab7c1a8554c7fcac10c65f376ef7beb23fabed1bbbee8",
  name: "sendPremiumMessage",
  filename: "src/lib/premium-account.functions.ts"
}, (opts) => sendPremiumMessage.__executeServer(opts));
const sendPremiumMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  chatId: z.string().min(1),
  text: z.string().min(1).max(4e3)
}).parse(d)).handler(sendPremiumMessage_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("tg_api_id, tg_api_hash, tg_session").eq("id", data.accountId).maybeSingle();
  if (error || !acc) throw new Error("Conta não encontrada");
  if (!acc.tg_session) throw new Error("Conecte a conta premium primeiro.");
  const client = await makeClient(acc.tg_api_id, acc.tg_api_hash, acc.tg_session);
  try {
    const msg = await client.sendMessage(data.chatId, {
      message: data.text
    });
    return {
      ok: true,
      messageId: Number(msg.id)
    };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
});
const getPremiumAccountAvatar_createServerFn_handler = createServerRpc({
  id: "76bf59276293617ba82d876f45ee762518ab372249f24bcbe360406a24d32dea",
  name: "getPremiumAccountAvatar",
  filename: "src/lib/premium-account.functions.ts"
}, (opts) => getPremiumAccountAvatar.__executeServer(opts));
const getPremiumAccountAvatar = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(getPremiumAccountAvatar_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("tg_api_id, tg_api_hash, tg_session").eq("id", data.accountId).maybeSingle();
  if (error || !acc?.tg_session || !acc.tg_api_id || !acc.tg_api_hash) {
    return {
      dataUrl: null
    };
  }
  const client = await makeClient(acc.tg_api_id, acc.tg_api_hash, acc.tg_session);
  try {
    const me = await client.getMe();
    const buf = await client.downloadProfilePhoto(me, {
      isBig: false
    });
    if (!buf || !buf.length) return {
      dataUrl: null
    };
    const media = mediaDataUrl(buf);
    return {
      dataUrl: media?.url ?? null
    };
  } catch {
    return {
      dataUrl: null
    };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
});
export {
  confirmPremiumCode_createServerFn_handler,
  getPremiumAccountAvatar_createServerFn_handler,
  getPremiumEmojiThumbs_createServerFn_handler,
  requestPremiumCode_createServerFn_handler,
  sendPremiumMessage_createServerFn_handler,
  syncPremiumEmojis_createServerFn_handler
};
