import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useRef, useCallback, useEffect, useLayoutEffect, useMemo, useContext, createContext } from "react";
import { createPortal } from "react-dom";
import { useNavigate, useLocation } from "@tanstack/react-router";
import { B as Button } from "./router-Cw6OHOsO.js";
import { X, ArrowLeft, Check, ArrowRight } from "lucide-react";
const TourContext = createContext(null);
function useTour() {
  const ctx = useContext(TourContext);
  if (!ctx) throw new Error("useTour must be used inside <TourProvider>");
  return ctx;
}
const PADDING = 8;
function TourProvider({ children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [steps, setSteps] = useState([]);
  const [index, setIndex] = useState(0);
  const [active, setActive] = useState(false);
  const [rect, setRect] = useState(null);
  const [, setTick] = useState(0);
  const targetRef = useRef(null);
  const step = active ? steps[index] : null;
  const start = useCallback((s) => {
    setSteps(s);
    setIndex(0);
    setActive(true);
  }, []);
  const stop = useCallback(() => {
    setActive(false);
    setSteps([]);
    setIndex(0);
    setRect(null);
    targetRef.current = null;
  }, []);
  useEffect(() => {
    if (!step?.route) return;
    if (location.pathname !== step.route) {
      navigate({ to: step.route });
    }
  }, [step, location.pathname, navigate]);
  useLayoutEffect(() => {
    if (!active || !step) return;
    if (!step.selector) {
      setRect(null);
      targetRef.current = null;
      return;
    }
    if (step.route && location.pathname !== step.route) {
      setRect(null);
      targetRef.current = null;
      return;
    }
    let cancelled = false;
    let observer = null;
    let timeoutId = null;
    const apply = (el) => {
      targetRef.current = el;
      setRect(el.getBoundingClientRect());
      try {
        el.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
      } catch {
      }
    };
    const tryFind = () => {
      if (cancelled) return true;
      const el = document.querySelector(step.selector);
      if (el) {
        apply(el);
        return true;
      }
      return false;
    };
    if (!tryFind()) {
      observer = new MutationObserver(() => {
        if (tryFind() && observer) observer.disconnect();
      });
      observer.observe(document.body, { childList: true, subtree: true });
      timeoutId = window.setTimeout(() => {
        if (observer) observer.disconnect();
      }, 4e3);
    }
    return () => {
      cancelled = true;
      if (observer) observer.disconnect();
      if (timeoutId) window.clearTimeout(timeoutId);
    };
  }, [active, step, location.pathname]);
  useEffect(() => {
    if (!active) return;
    const recompute = () => {
      if (targetRef.current) {
        setRect(targetRef.current.getBoundingClientRect());
      }
      setTick((t) => t + 1);
    };
    window.addEventListener("resize", recompute);
    window.addEventListener("scroll", recompute, true);
    return () => {
      window.removeEventListener("resize", recompute);
      window.removeEventListener("scroll", recompute, true);
    };
  }, [active]);
  const next = useCallback(() => {
    setIndex((i) => {
      if (i >= steps.length - 1) {
        setActive(false);
        return 0;
      }
      return i + 1;
    });
  }, [steps.length]);
  const prev = useCallback(() => {
    setIndex((i) => Math.max(0, i - 1));
  }, []);
  useEffect(() => {
    if (!active) return;
    const onKey = (e) => {
      if (e.key === "Escape") stop();
      else if (e.key === "ArrowRight" || e.key === "Enter") next();
      else if (e.key === "ArrowLeft") prev();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, next, prev, stop]);
  const value = useMemo(() => ({ start, stop, isActive: active }), [start, stop, active]);
  return /* @__PURE__ */ jsxs(TourContext.Provider, { value, children: [
    children,
    active && step && typeof document !== "undefined" ? createPortal(
      /* @__PURE__ */ jsx(
        TourOverlay,
        {
          step,
          stepIndex: index,
          total: steps.length,
          rect,
          onNext: next,
          onPrev: prev,
          onClose: stop
        }
      ),
      document.body
    ) : null
  ] });
}
function TourOverlay({
  step,
  stepIndex,
  total,
  rect,
  onNext,
  onPrev,
  onClose
}) {
  const isLast = stepIndex === total - 1;
  const isFirst = stepIndex === 0;
  const placement = step.placement ?? (rect ? "right" : "center");
  const TOOLTIP_W = 360;
  const tooltipStyle = {};
  if (rect && placement !== "center") {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const margin = 16;
    if (placement === "right") {
      tooltipStyle.left = Math.min(rect.right + margin, vw - TOOLTIP_W - margin);
      tooltipStyle.top = Math.max(margin, Math.min(rect.top, vh - 240));
    } else if (placement === "left") {
      tooltipStyle.left = Math.max(margin, rect.left - TOOLTIP_W - margin);
      tooltipStyle.top = Math.max(margin, Math.min(rect.top, vh - 240));
    } else if (placement === "bottom") {
      tooltipStyle.left = Math.max(
        margin,
        Math.min(rect.left, vw - TOOLTIP_W - margin)
      );
      tooltipStyle.top = rect.bottom + margin;
    } else if (placement === "top") {
      tooltipStyle.left = Math.max(
        margin,
        Math.min(rect.left, vw - TOOLTIP_W - margin)
      );
      tooltipStyle.top = Math.max(margin, rect.top - 240);
    }
  }
  return /* @__PURE__ */ jsxs("div", { className: "fixed inset-0 z-[100] pointer-events-none", children: [
    /* @__PURE__ */ jsxs(
      "svg",
      {
        className: "absolute inset-0 w-full h-full pointer-events-auto text-primary",
        onClick: (e) => {
          e.stopPropagation();
        },
        children: [
          /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsxs("mask", { id: "tour-mask", children: [
            /* @__PURE__ */ jsx("rect", { width: "100%", height: "100%", fill: "white" }),
            rect && /* @__PURE__ */ jsx(
              "rect",
              {
                x: Math.max(0, rect.left - PADDING),
                y: Math.max(0, rect.top - PADDING),
                width: rect.width + PADDING * 2,
                height: rect.height + PADDING * 2,
                rx: 12,
                ry: 12,
                fill: "black"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx(
            "rect",
            {
              width: "100%",
              height: "100%",
              fill: "rgba(0,0,0,0.65)",
              mask: "url(#tour-mask)"
            }
          ),
          rect && /* @__PURE__ */ jsx(
            "rect",
            {
              x: Math.max(0, rect.left - PADDING),
              y: Math.max(0, rect.top - PADDING),
              width: rect.width + PADDING * 2,
              height: rect.height + PADDING * 2,
              rx: 12,
              ry: 12,
              fill: "none",
              stroke: "currentColor",
              strokeWidth: 2,
              className: "animate-pulse"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: "pointer-events-auto absolute",
        style: placement === "center" ? {
          left: "50%",
          top: "50%",
          transform: "translate(-50%, -50%)",
          width: TOOLTIP_W
        } : { ...tooltipStyle, width: TOOLTIP_W },
        children: /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-border bg-card text-card-foreground shadow-2xl p-5 space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
                "Passo ",
                stepIndex + 1,
                " de ",
                total
              ] }),
              /* @__PURE__ */ jsx("h3", { className: "font-semibold text-base mt-0.5", children: step.title })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: onClose,
                className: "text-muted-foreground hover:text-foreground",
                "aria-label": "Fechar tutorial",
                children: /* @__PURE__ */ jsx(X, { className: "size-4" })
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground leading-relaxed", children: step.description }),
          /* @__PURE__ */ jsx("div", { className: "h-1 rounded-full bg-muted overflow-hidden", children: /* @__PURE__ */ jsx(
            "div",
            {
              className: "h-full bg-primary transition-all",
              style: { width: `${(stepIndex + 1) / total * 100}%` }
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
            /* @__PURE__ */ jsxs(
              Button,
              {
                variant: "ghost",
                size: "sm",
                onClick: onPrev,
                disabled: isFirst,
                children: [
                  /* @__PURE__ */ jsx(ArrowLeft, { className: "size-4" }),
                  "Anterior"
                ]
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: onClose, children: "Pular" }),
              /* @__PURE__ */ jsx(Button, { size: "sm", onClick: onNext, children: isLast ? /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx(Check, { className: "size-4" }),
                " Concluir"
              ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
                "Próximo ",
                /* @__PURE__ */ jsx(ArrowRight, { className: "size-4" })
              ] }) })
            ] })
          ] })
        ] })
      }
    )
  ] });
}
export {
  TourProvider as T,
  useTour as u
};
