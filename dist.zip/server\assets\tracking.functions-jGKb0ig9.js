import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
const VERTICALS = ["bet", "igaming", "hot", "promo", "outro"];
const TRACKING_MODES = ["telegram", "direct_response"];
const MODE_PRESETS = {
  telegram: {
    label: "Telegram (bot + canal)",
    description: "Anúncio Meta → bot do Telegram → oferta → cadastro/depósito. Ideal para bet, iGaming, +18 e promoções.",
    stages: [{
      key: "join",
      label: "Entrada no bot",
      defaultEvent: "Lead"
    }, {
      key: "offer_click",
      label: "Clique na oferta",
      defaultEvent: "InitiateCheckout"
    }, {
      key: "register",
      label: "Cadastro",
      defaultEvent: "CompleteRegistration"
    }, {
      key: "deposit",
      label: "Depósito",
      defaultEvent: "Purchase"
    }]
  },
  direct_response: {
    label: "Direct Response (Meta → página → checkout)",
    description: "Anúncio Meta → página de vendas/VSL → checkout → compra. Ideal para infoprodutos, mentorias e e-commerce direto.",
    stages: [{
      key: "view",
      label: "Visualização da página",
      defaultEvent: "ViewContent"
    }, {
      key: "lead",
      label: "Lead qualificado (opt-in)",
      defaultEvent: "Lead"
    }, {
      key: "checkout",
      label: "Iniciou checkout",
      defaultEvent: "InitiateCheckout"
    }, {
      key: "payment_info",
      label: "Escolheu pagamento",
      defaultEvent: "AddPaymentInfo"
    }, {
      key: "purchase",
      label: "Compra confirmada",
      defaultEvent: "Purchase"
    }]
  }
};
const EVENT_OPTIONS = ["off", "Lead", "CompleteRegistration", "Subscribe", "ViewContent", "Contact", "InitiateCheckout", "AddPaymentInfo", "AddToCart", "Purchase", "StartTrial"];
const drConfigSchema = z.object({
  enable_lead: z.boolean().default(false),
  enable_add_to_cart: z.boolean().default(false),
  enable_initiate_checkout: z.boolean().default(true),
  initiate_checkout_url_contains: z.string().default(""),
  purchase_approval_only: z.boolean().default(true),
  purchase_value_mode: z.string().default("Valor da venda"),
  purchase_product: z.string().default("Qualquer"),
  ipv6_enabled: z.boolean().default(true)
});
const pixelSchema = z.object({
  name: z.string().min(1).max(120),
  vertical: z.enum(VERTICALS).default("outro"),
  tracking_mode: z.enum(TRACKING_MODES).default("telegram"),
  sales_page_url: z.string().url().nullable().optional(),
  is_active: z.boolean().default(true),
  meta_integration_id: z.string().uuid().nullable().optional(),
  account_id: z.string().uuid().nullable().optional(),
  room_id: z.string().uuid().nullable().optional(),
  event_on_join: z.enum(EVENT_OPTIONS).default("Lead"),
  event_on_offer_click: z.enum(EVENT_OPTIONS).default("InitiateCheckout"),
  event_on_register: z.enum(EVENT_OPTIONS).default("CompleteRegistration"),
  event_on_deposit: z.enum(EVENT_OPTIONS).default("Purchase"),
  event_on_view: z.enum(EVENT_OPTIONS).default("ViewContent"),
  event_on_lead: z.enum(EVENT_OPTIONS).default("Lead"),
  event_on_checkout: z.enum(EVENT_OPTIONS).default("InitiateCheckout"),
  event_on_payment_info: z.enum(EVENT_OPTIONS).default("AddPaymentInfo"),
  event_on_purchase: z.enum(EVENT_OPTIONS).default("Purchase"),
  meta_pixel_id: z.string().trim().max(64).nullable().optional(),
  meta_access_token: z.string().trim().max(1024).nullable().optional(),
  meta_test_event_code: z.string().trim().max(64).nullable().optional(),
  dr_config: drConfigSchema.default({})
});
const listPixels = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("9a10855ec68031a68272278346d1dff6878e9ca23aca2143f5361ed6e1999988"));
const getPixel = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("0dcec4b9cde2b59d27fa7c851f4731b8ee539ee35173ba2dac5b7d4360ab1781"));
const createPixel = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => pixelSchema.parse(d)).handler(createSsrRpc("c74905e5b6be9caaa44375d7a8476db9001866bf833e9ddf2bf6af80ff10fee1"));
const updatePixel = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => pixelSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("0de27157edb1f132e151a83c8f9e064786d2d19283a3cc6231c0c188e7b6e136"));
const deletePixel = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("bb80e000109e2704a88d684dd91dc5b6552d35f5daa1afeeaf70542335e38d5d"));
const offerSchema = z.object({
  pixel_id: z.string().uuid(),
  slug: z.string().min(1).max(60).regex(/^[a-z0-9_-]+$/, "Use apenas letras minúsculas, números, _ e -"),
  name: z.string().min(1).max(120),
  destination_url: z.string().url(),
  subid_param: z.string().min(1).max(30).default("sub1"),
  default_event: z.enum(EVENT_OPTIONS).default("InitiateCheckout"),
  default_value: z.number().nullable().optional(),
  default_currency: z.string().min(3).max(3).default("BRL")
});
const listOffers = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("27c7594de8b00f91bee8593f78ef8045b23a3ca9be78fd7ab18928b268712a7a"));
const createOffer = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => offerSchema.parse(d)).handler(createSsrRpc("31ca301441616645f30db96bc49571b709b78a2d22f922a9a2f65e504988b205"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => offerSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("8dd1db2506dfb0ca23b3f6ffc3014b58a2cfa90d8a8707946b766d28211f787a"));
const deleteOffer = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("137608e79fc828d8251f37acb791d6e58da349bffd7f102fbfd6c1a1e868803f"));
const listRecentClicks = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  limit: z.number().min(1).max(500).default(100)
}).parse(d)).handler(createSsrRpc("603a464eb3d9ed9a9091fb89c5ee43d6f317bd408dafcc7b41007fb386c6f1cc"));
const listClicksFiltered = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  from: z.string().datetime().nullable().optional(),
  to: z.string().datetime().nullable().optional(),
  event: z.enum(["any", "click", "join", "offer_click", "register", "deposit"]).default("any"),
  limit: z.number().min(1).max(5e3).default(500)
}).parse(d)).handler(createSsrRpc("4a80c7840c491ab9f8012a891470726e98f09f087a859a194d0f9959ce1157ad"));
const getPixelStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  days: z.number().min(1).max(365).default(30)
}).parse(d)).handler(createSsrRpc("fada98e77b81fcc3e7bcc077f7cccb4c683a7c4e420844d4d01829e14763ad18"));
createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  group_col: z.enum(["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"]),
  days: z.number().min(1).max(365).default(30)
}).parse(d)).handler(createSsrRpc("0cddd13570369a4ad87bb38fee349e91178aa4866dbce9ce78820cc23bf59712"));
const domainRegex = /^(?!-)[a-z0-9-]+(\.[a-z0-9-]+)+$/i;
const listDomains = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("ec3e4aab6fa1fda6669b11ce64bbd0f5feb1c8cab1eb3e008af7cdfa1a10b665"));
const createDomain = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  domain: z.string().min(3).max(253).regex(domainRegex, "Domínio inválido")
}).parse(d)).handler(createSsrRpc("7e93f0071e8d14bade8182e0ac6c981e6975479a2830d19f553fc947bd2066fd"));
const deleteDomain = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("08b0290c79c5eed474def48c5d28ed3e6576e135bb3939fba22331814f266393"));
const verifyDomain = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("405119693096c8c51536e705666171437c26673d31d457b94f3269e876607e03"));
const getMyRedirectBase = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("ffbaafa2e4a8c30c2601b49c918a3eeafc5590146bc4893f15f21552caf35ebe"));
const POSTBACK_EVENTS = [
  // Telegram
  "viewpage",
  "click_button",
  "channel_enter",
  "channel_leave",
  // Direct Response
  "lead",
  "checkout_started",
  "payment_info",
  "purchase"
];
const POSTBACK_EVENTS_BY_MODE = {
  telegram: ["viewpage", "click_button", "channel_enter", "channel_leave"],
  direct_response: ["viewpage", "lead", "checkout_started", "payment_info", "purchase"]
};
const postbackSchema = z.object({
  pixel_id: z.string().uuid(),
  name: z.string().min(1).max(120),
  url: z.string().url().max(2e3),
  event: z.enum(POSTBACK_EVENTS),
  is_active: z.boolean().default(true)
});
const listPostbacks = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("f1fe9cee74edca82ab25a8005f4facdae55424220808b4503441a76c54d67e02"));
const createPostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => postbackSchema.parse(d)).handler(createSsrRpc("46c276df3aeb65f0b673ec795ecc36d785b430d4a34a595baa239369d56fa9f2"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => postbackSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("da255167f1cbb9205d568a80e1f0cc3b4c294b5c10a06c6b31d226ed0e08ce5b"));
const deletePostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("1b1724c9b582de6a00b91d2a46dbe6e6c66f53457d67f41bf7749d6936489a70"));
const testPostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  url: z.string().url()
}).parse(d)).handler(createSsrRpc("af30abf22edeebe07aa538f2da264e02c7cadf4db801c8ade00fef1443da9e31"));
const INTEGRATION_EVENT_TYPES = ["register", "ftd", "deposit", "custom"];
const integrationSchema = z.object({
  pixel_id: z.string().uuid(),
  name: z.string().min(1).max(120),
  event_type: z.enum(INTEGRATION_EVENT_TYPES),
  custom_event_name: z.string().max(60).nullable().optional(),
  redirect_url: z.string().url(),
  meta_custom_event: z.string().max(60).nullable().optional(),
  meta_value: z.number().nullable().optional(),
  meta_currency: z.string().min(3).max(3).default("BRL"),
  is_active: z.boolean().default(true)
});
const listIntegrations = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("012931baad73d5749e90b854282885cfc580ade3f7d0d9ed951ef097e3bb934c"));
const createIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => integrationSchema.parse(d)).handler(createSsrRpc("b2e722c57872a7c358fe30a5ae8d88af9b2c420396c4db28f9c7e2c075eb2cb8"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => integrationSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("6f5c39bb1cba1c244d4a224e6b64556531006e5dae4abd55b0ceff0885511e44"));
const deleteIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("759cfed5600289cb15ac7c5dc2cdb7f9bef1fa57643dd610c0ac37a74747be74"));
export {
  EVENT_OPTIONS as E,
  MODE_PRESETS as M,
  POSTBACK_EVENTS_BY_MODE as P,
  TRACKING_MODES as T,
  VERTICALS as V,
  listPixels as a,
  deletePixel as b,
  createPostback as c,
  deletePostback as d,
  createPixel as e,
  listRecentClicks as f,
  getPixelStats as g,
  listIntegrations as h,
  getMyRedirectBase as i,
  deleteIntegration as j,
  listClicksFiltered as k,
  listPostbacks as l,
  createIntegration as m,
  listOffers as n,
  createOffer as o,
  deleteOffer as p,
  listDomains as q,
  createDomain as r,
  deleteDomain as s,
  testPostback as t,
  updatePixel as u,
  verifyDomain as v,
  getPixel as w
};
