import { jsxs, jsx } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { s as supabase } from "./client-bD0og8Nx.js";
import { u as useAuth, D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, h as DialogHeader, i as DialogTitle, H as Badge, L as Label, I as Input, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, T as Textarea, j as DialogFooter, C as Card, y as Table, z as TableHeader, A as TableRow, E as TableHead, F as TableBody, G as TableCell, N as Switch } from "./router-Cw6OHOsO.js";
import { P as PremiumEmojiPicker } from "./PremiumEmojiPicker-KRfbHKuL.js";
import { toast } from "sonner";
import { Plus, TrendingUp, ShoppingBag, Flame, Dice5, GraduationCap, Search, Users, Pencil, FileText, CalendarClock, Power, RefreshCw, Trash2 } from "lucide-react";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "./useServerFn-DL2oePlL.js";
function getInitials(name) {
  if (!name) return "?";
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
}
function stringToColor(str) {
  if (!str) return "#64748b";
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
  const c = (hash & 16777215).toString(16).padStart(6, "0");
  return `#${c}`;
}
function RoomsPage() {
  const {
    user
  } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [niche, setNiche] = useState(null);
  const [chatIdInput, setChatIdInput] = useState("");
  const [chatTitleInput, setChatTitleInput] = useState("");
  const [name, setName] = useState("");
  const [broker, setBroker] = useState("");
  const [accountId, setAccountId] = useState("");
  const [welcome, setWelcome] = useState("");
  const accounts = useQuery({
    queryKey: ["telegram-accounts"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("telegram_accounts").select("id, label, bot_first_name, bot_username");
      return data ?? [];
    }
  });
  const rooms = useQuery({
    queryKey: ["rooms-list"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("rooms").select("id, name, description, photo_url, broker, is_active, expires_at, default_account_id, niche, telegram_accounts:default_account_id(id, label, bot_first_name, bot_username), room_chats(id, chat_id, chat_title)").order("created_at", {
        ascending: false
      });
      if (error) throw error;
      return data;
    }
  });
  function resetWizard() {
    setChatIdInput("");
    setChatTitleInput("");
    setName("");
    setBroker("");
    setAccountId("");
    setWelcome("");
    setNiche(null);
  }
  const createMut = useMutation({
    mutationFn: async () => {
      const {
        data: room,
        error
      } = await supabase.from("rooms").insert({
        user_id: user.id,
        name,
        broker: broker || null,
        welcome_message: welcome || null,
        default_account_id: accountId || null,
        niche: niche ?? "ob"
      }).select("id").single();
      if (error) throw error;
      if (chatIdInput) {
        const {
          error: e2
        } = await supabase.from("room_chats").insert({
          room_id: room.id,
          user_id: user.id,
          chat_id: Number(chatIdInput),
          chat_title: chatTitleInput || null
        });
        if (e2) throw e2;
      }
      return room.id;
    },
    onSuccess: (roomId) => {
      toast.success("Sala criada — continue a configuração");
      setOpen(false);
      resetWizard();
      qc.invalidateQueries({
        queryKey: ["rooms-list"]
      });
      navigate({
        to: "/rooms/$roomId/edit",
        params: {
          roomId
        }
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const delMut = useMutation({
    mutationFn: async (id) => {
      const {
        error
      } = await supabase.from("rooms").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["rooms-list"]
    })
  });
  const toggleActive = useMutation({
    mutationFn: async (r) => {
      const {
        error
      } = await supabase.from("rooms").update({
        is_active: !r.is_active
      }).eq("id", r.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["rooms-list"]
    })
  });
  const renew = useMutation({
    mutationFn: async (id) => {
      const next = /* @__PURE__ */ new Date();
      next.setDate(next.getDate() + 30);
      const {
        error
      } = await supabase.from("rooms").update({
        expires_at: next.toISOString(),
        is_active: true
      }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Sala renovada por 30 dias");
      qc.invalidateQueries({
        queryKey: ["rooms-list"]
      });
    }
  });
  const filtered = (rooms.data ?? []).filter((r) => {
    if (filter === "active" && !r.is_active) return false;
    if (filter === "inactive" && r.is_active) return false;
    if (search && !r.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });
  const fixedRef = useRef(/* @__PURE__ */ new Set());
  useEffect(() => {
    if (!rooms.data) return;
    const toFix = rooms.data.filter((r) => {
      if (fixedRef.current.has(r.id)) return false;
      const username = r.telegram_accounts?.bot_username?.toLowerCase();
      const chatTitle = r.room_chats?.[0]?.chat_title;
      const nameNorm = r.name.replace(/^@/, "").toLowerCase();
      return !!username && !!chatTitle && nameNorm === username && chatTitle !== r.name;
    });
    if (!toFix.length) return;
    (async () => {
      for (const r of toFix) {
        fixedRef.current.add(r.id);
        const newName = r.room_chats[0].chat_title;
        await supabase.from("rooms").update({
          name: newName
        }).eq("id", r.id);
      }
      qc.invalidateQueries({
        queryKey: ["rooms-list"]
      });
    })();
  }, [rooms.data, qc]);
  function fmtDate(d) {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("pt-BR");
  }
  return /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Salas" }),
        /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground", children: [
          filtered.length,
          " sala(s) — gerencie seus grupos de sinais."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange: setOpen, children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { "data-tour": "add-room", children: [
          /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-2" }),
          "Adicionar sala"
        ] }) }),
        /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-lg", children: [
          /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: niche ? "Nova sala — informações básicas" : "Nova sala — escolha o nicho" }) }),
          !niche ? /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3 py-2", children: [
            [{
              v: "ob",
              icon: TrendingUp,
              t: "Opções Binárias",
              d: "Sinais, janelas de operação, templates de entrada/resultado, relatórios."
            }, {
              v: "promo",
              icon: ShoppingBag,
              t: "Promoções",
              d: "Amazon, Shopee, AliExpress e Mercado Livre com link de afiliado."
            }, {
              v: "hot",
              icon: Flame,
              t: "Hot",
              d: "Conteúdo adulto: prévias, funil VIP e promoções de redes adultas."
            }, {
              v: "igaming",
              icon: Dice5,
              t: "iGaming",
              d: "Sinais de cassino (Tigrinho, Aviator…) + promos de casas de aposta."
            }, {
              v: "expert",
              icon: GraduationCap,
              t: "Comunidade Expert",
              d: "Funil de mentoria/curso + engajamento diário + agenda."
            }].map((opt) => {
              const Icon = opt.icon;
              return /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => setNiche(opt.v), className: "rounded-lg border border-border hover:border-primary hover:bg-accent transition p-4 text-left space-y-2", children: [
                /* @__PURE__ */ jsx(Icon, { className: "size-6 text-primary" }),
                /* @__PURE__ */ jsx("div", { className: "font-semibold", children: opt.t }),
                /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: opt.d })
              ] }, opt.v);
            }),
            /* @__PURE__ */ jsx("div", { className: "col-span-2 text-[11px] text-muted-foreground", children: "⚠️ O nicho é fixo após a criação. Para outro nicho, crie outra sala." })
          ] }) : /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
              /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: {
                ob: "Opções Binárias",
                promo: "Promoções",
                hot: "Hot",
                igaming: "iGaming",
                expert: "Comunidade Expert"
              }[niche] }),
              /* @__PURE__ */ jsx("button", { className: "text-muted-foreground hover:text-foreground underline", onClick: () => setNiche(null), children: "trocar" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "ID do grupo / canal" }),
                /* @__PURE__ */ jsx(Input, { value: chatIdInput, onChange: (e) => setChatIdInput(e.target.value), placeholder: "-1001234..." })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Nome do grupo" }),
                /* @__PURE__ */ jsx(Input, { value: chatTitleInput, onChange: (e) => setChatTitleInput(e.target.value), placeholder: "opcional" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Título da sala" }),
              /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), placeholder: niche === "ob" ? "Ex: Sinais VIP — Manhã" : "Ex: Ofertas Relâmpago" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
              niche === "ob" && /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Corretora" }),
                /* @__PURE__ */ jsx(Input, { value: broker, onChange: (e) => setBroker(e.target.value), placeholder: "Ex: Quotex" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Conta Telegram" }),
                /* @__PURE__ */ jsxs(Select, { value: accountId, onValueChange: setAccountId, children: [
                  /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Escolha o bot" }) }),
                  /* @__PURE__ */ jsx(SelectContent, { children: accounts.data?.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Mensagem de boas-vindas" }),
              /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: welcome, onChange: setWelcome }) }),
              /* @__PURE__ */ jsx(Textarea, { value: welcome, onChange: (e) => setWelcome(e.target.value), rows: 3, placeholder: "Mensagem enviada ao iniciar a sessão" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs(DialogFooter, { children: [
            /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setOpen(false), children: "Cancelar" }),
            /* @__PURE__ */ jsx(Button, { onClick: () => createMut.mutate(), disabled: !niche || !name || createMut.isPending, children: createMut.isPending ? "Criando..." : "Próximo" })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative flex-1 max-w-sm", children: [
        /* @__PURE__ */ jsx(Search, { className: "size-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsx(Input, { value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Buscar sala...", className: "pl-8" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex gap-1", children: ["all", "active", "inactive"].map((f) => /* @__PURE__ */ jsx(Button, { size: "sm", variant: filter === f ? "default" : "outline", onClick: () => setFilter(f), children: f === "all" ? "Todas" : f === "active" ? "Ativas" : "Inativas" }, f)) })
    ] }),
    /* @__PURE__ */ jsx(Card, { className: "overflow-hidden", children: filtered.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "p-10 text-center text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsx(Users, { className: "size-8 mx-auto mb-2 opacity-50" }),
      'Nenhuma sala. Clique em "Adicionar sala" para começar.'
    ] }) : /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableHead, { children: "Bot" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Conta Telegram" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Sala" }),
        /* @__PURE__ */ jsx(TableHead, { children: "ID grupo" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Vencimento" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Ativa" }),
        /* @__PURE__ */ jsx(TableHead, { className: "text-right", children: "Ações" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: filtered.map((r) => {
        const acc = r.telegram_accounts;
        const chat = r.room_chats?.[0];
        return /* @__PURE__ */ jsxs(TableRow, { children: [
          /* @__PURE__ */ jsx(TableCell, { className: "font-mono text-xs", children: acc?.bot_username ? `@${acc.bot_username}` : acc?.label ? acc.label : /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "—" }) }),
          /* @__PURE__ */ jsx(TableCell, { className: "text-sm", children: acc ? /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
            /* @__PURE__ */ jsx("div", { className: "size-7 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0", style: {
              backgroundColor: stringToColor(acc.id)
            }, title: acc.label, children: getInitials(acc.bot_first_name || acc.label) }),
            /* @__PURE__ */ jsx("span", { className: "truncate", children: acc.bot_first_name ?? acc.label })
          ] }) : /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "—" }) }),
          /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
            r.photo_url ? /* @__PURE__ */ jsx("img", { src: r.photo_url, alt: "", className: "size-8 rounded-full object-cover shrink-0" }) : /* @__PURE__ */ jsx("div", { className: "size-8 rounded-full bg-muted flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(Users, { className: "size-4 text-muted-foreground" }) }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("div", { className: "font-medium text-sm truncate", children: chat?.chat_title || r.name }),
              r.broker && /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground truncate", children: r.broker })
            ] })
          ] }) }),
          /* @__PURE__ */ jsx(TableCell, { className: "font-mono text-xs", children: chat?.chat_id ?? /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "—" }) }),
          /* @__PURE__ */ jsx(TableCell, { children: r.expires_at ? /* @__PURE__ */ jsx(Badge, { variant: new Date(r.expires_at) < /* @__PURE__ */ new Date() ? "destructive" : "secondary", children: fmtDate(r.expires_at) }) : /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs", children: "—" }) }),
          /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsx(Switch, { checked: r.is_active, onCheckedChange: () => toggleActive.mutate(r) }) }),
          /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-1", children: [
            /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", variant: "ghost", title: "Editar", children: /* @__PURE__ */ jsx(Link, { to: "/rooms/$roomId/edit", params: {
              roomId: r.id
            }, children: /* @__PURE__ */ jsx(Pencil, { className: "size-4" }) }) }),
            /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", variant: "ghost", title: "Logs", children: /* @__PURE__ */ jsx(Link, { to: "/bots/logs", children: /* @__PURE__ */ jsx(FileText, { className: "size-4" }) }) }),
            /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", variant: "ghost", title: "Agendados", children: /* @__PURE__ */ jsx(Link, { to: "/mensagens", children: /* @__PURE__ */ jsx(CalendarClock, { className: "size-4" }) }) }),
            /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", title: r.is_active ? "Desativar" : "Ativar", onClick: () => toggleActive.mutate(r), children: /* @__PURE__ */ jsx(Power, { className: `size-4 ${r.is_active ? "text-emerald-500" : "text-muted-foreground"}` }) }),
            /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", title: "Renovar +30 dias", onClick: () => renew.mutate(r.id), children: /* @__PURE__ */ jsx(RefreshCw, { className: "size-4" }) }),
            /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", title: "Excluir", onClick: () => {
              if (confirm(`Excluir "${r.name}"?`)) delMut.mutate(r.id);
            }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
          ] }) })
        ] }, r.id);
      }) })
    ] }) })
  ] });
}
export {
  RoomsPage as component
};
