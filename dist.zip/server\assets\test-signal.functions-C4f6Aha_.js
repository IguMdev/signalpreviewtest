import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { g as getUserEmojiLookup, r as renderEmojiTokens, b as renderEmojiTokensToHtml, a as sendTextWithPremiumEmojis } from "./premium-send.server-B6I-0YLO.js";
import { p as pickRandom, r as renderTemplate, c as categoryFor } from "./signals.server-CxsfAlOW.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
function fmtHHMM(d, tz) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).format(d);
}
function dirLabel(d) {
  return d === "buy" ? "🟢 COMPRA" : "🔴 VENDA";
}
const testWindow_createServerFn_handler = createServerRpc({
  id: "124b67b88312178f40f4489f9bbb49f4f3b5dd9d256a7171ef7515d7039df67e",
  name: "testWindow",
  filename: "src/lib/test-signal.functions.ts"
}, (opts) => testWindow.__executeServer(opts));
const testWindow = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({
  windowId: z.string().uuid()
}).parse(input)).handler(testWindow_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  const {
    data: w,
    error: we
  } = await supabaseAdmin.from("room_windows").select("id, user_id, room_id, asset_filter, use_all_assets, timeframes, martingale").eq("id", data.windowId).maybeSingle();
  if (we || !w) throw new Error("Janela não encontrada");
  if (w.user_id !== userId) throw new Error("Sem permissão");
  const {
    data: room
  } = await supabaseAdmin.from("rooms").select("id, user_id, timezone, default_account_id").eq("id", w.room_id).maybeSingle();
  if (!room) throw new Error("Sala não encontrada");
  const {
    data: chats
  } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", w.room_id);
  const chatIds = (chats ?? []).map((c) => Number(c.chat_id));
  if (!chatIds.length) throw new Error("Vincule um chat/canal à sala antes de testar");
  let botToken = null;
  if (room.default_account_id) {
    const {
      data: acc
    } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
    botToken = acc?.bot_token ?? null;
  }
  if (!botToken) throw new Error("Defina uma conta bot padrão na sala");
  let pool = [];
  if (w.use_all_assets || !w.asset_filter?.length) {
    const {
      data: ras
    } = await supabaseAdmin.from("room_assets").select("asset_code").eq("room_id", w.room_id).eq("is_open", true);
    pool = (ras ?? []).map((r) => r.asset_code);
  } else {
    pool = w.asset_filter;
  }
  if (!pool.length) throw new Error("Nenhum ativo disponível");
  const asset = pickRandom(pool);
  const direction = Math.random() < 0.5 ? "buy" : "sell";
  const timeframe = pickRandom(w.timeframes?.length ? w.timeframes : ["M1"]);
  const tz = room.timezone ?? "America/Sao_Paulo";
  const now = /* @__PURE__ */ new Date();
  const entry = new Date(Math.ceil((now.getTime() + 1) / 6e4) * 6e4 + 12e4);
  const expires = new Date(entry.getTime() + 6e4);
  const {
    data: tpls
  } = await supabaseAdmin.from("room_templates").select("kind, content, parse_mode").eq("room_id", w.room_id);
  const {
    data: btnsRaw
  } = await supabaseAdmin.from("room_template_buttons").select("template_kind, label, url, sort_order").eq("room_id", w.room_id).order("sort_order", {
    ascending: true
  });
  const emojiLookup = await getUserEmojiLookup(userId);
  const signalButtons = (btnsRaw ?? []).filter((b) => b.template_kind === "signal" && b.label && b.url).map((b) => [{
    text: renderEmojiTokens(b.label, emojiLookup).text,
    url: b.url
  }]);
  const replyMarkup = signalButtons.length ? {
    inline_keyboard: signalButtons
  } : void 0;
  const tpl = (tpls ?? []).find((t) => t.kind === "signal") ?? {
    parse_mode: "HTML",
    content: "🧪 TESTE 🧪\n✅ ENTRADA CONFIRMADA ✅\n🌎 Ativo: {ATIVO}\n⏳ Expiração: {TIMEFRAME}\n📊 Direção: {DIRECAO}\n⏰ Entrada: {ENTRADA}\nGale 1: {ENTRADAGALE1}\nGale 2: {ENTRADAGALE2}"
  };
  const text = "🧪 TESTE 🧪\n" + renderTemplate(tpl.content, {
    ATIVO: asset,
    TIMEFRAME: timeframe,
    DIRECAO: dirLabel(direction),
    ENTRADA: fmtHHMM(entry, tz),
    ENTRADAGALE1: fmtHHMM(new Date(entry.getTime() + 6e4), tz),
    ENTRADAGALE2: fmtHHMM(new Date(entry.getTime() + 12e4), tz),
    MARTINGALE: String(w.martingale ?? 2)
  });
  const botText = replyMarkup ? renderEmojiTokensToHtml(text, emojiLookup).text : text;
  const ids = {};
  const errors = [];
  for (const cid of chatIds) {
    const premium = await sendTextWithPremiumEmojis({
      userId: w.user_id,
      chatId: cid,
      text,
      buttonRows: signalButtons.length ? signalButtons : void 0
    });
    if (premium.applied) {
      if (premium.ok && premium.messageId) {
        ids[String(cid)] = premium.messageId;
      } else errors.push(`chat ${cid}: ${premium.ok ? "erro" : premium.error}`);
      continue;
    }
    const r = await callTelegram(botToken, "sendMessage", {
      chat_id: cid,
      text: botText,
      parse_mode: tpl.parse_mode || "HTML",
      reply_markup: replyMarkup
    });
    if (r.ok && r.result?.message_id) ids[String(cid)] = r.result.message_id;
    else errors.push(`chat ${cid}: ${r.description ?? "erro"}`);
  }
  if (Object.keys(ids).length) {
    await supabaseAdmin.from("signal_events").insert({
      user_id: w.user_id,
      room_id: w.room_id,
      window_id: w.id,
      asset_code: asset,
      asset_category: categoryFor(asset),
      direction,
      timeframe,
      entry_at: entry.toISOString(),
      expires_at: expires.toISOString(),
      max_gales: w.martingale ?? 0,
      status: "sent",
      signal_message_ids: ids
    });
  }
  return {
    ok: Object.keys(ids).length > 0,
    asset,
    direction,
    timeframe,
    entry_at: entry.toISOString(),
    sent: Object.keys(ids).length,
    errors
  };
});
export {
  testWindow_createServerFn_handler
};
