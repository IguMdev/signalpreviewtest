import { jsxs, jsx } from "react/jsx-runtime";
import { C as Card, O as CardHeader, Q as CardTitle, W as CardDescription, x as CardContent, B as Button, I as Input, D as Dialog, g as DialogContent, h as DialogHeader, i as DialogTitle, t as DialogDescription } from "./router-Cw6OHOsO.js";
import { useState } from "react";
import { toast } from "sonner";
import { List, Code2, Copy, ExternalLink, Facebook, Search, Video, Tag } from "lucide-react";
import "@tanstack/react-query";
import "@tanstack/react-router";
import "./client-bD0og8Nx.js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const UTM_SOURCES = [{
  id: "facebook",
  name: "Código de UTMs do Facebook",
  description: "Copie o código para colocar nos anúncios do Facebook",
  icon: /* @__PURE__ */ jsx(Facebook, { className: "w-6 h-6 text-[#1877F2]" }),
  code: "utm_source=FB&utm_campaign={{campaign.name}}|{{campaign.id}}&utm_medium={{adset.name}}|{{adset.id}}&utm_content={{ad.name}}|{{ad.id}}&utm_term={{placement}}"
}, {
  id: "google",
  name: "Código de UTMs do Google",
  description: "Copie o código para colocar nos anúncios do Google",
  icon: /* @__PURE__ */ jsx(Search, { className: "w-6 h-6 text-[#4285F4]" }),
  code: "utm_source=Google&utm_campaign={campaignid}&utm_medium={adgroupid}&utm_content={creative}&utm_term={keyword}"
}, {
  id: "kwai",
  name: "Código de UTMs do Kwai",
  description: "Copie o código para colocar nos anúncios do Kwai",
  icon: /* @__PURE__ */ jsx(Video, { className: "w-6 h-6 text-[#FF6300]" }),
  // Placeholder for Kwai
  code: "utm_source=Kwai&utm_campaign={{campaign.name}}|{{campaign.id}}&utm_medium={{adset.name}}|{{adset.id}}&utm_content={{ad.name}}|{{ad.id}}"
}, {
  id: "tiktok",
  name: "Código de UTMs do TikTok",
  description: "Copie o código para colocar nos anúncios do TikTok",
  icon: /* @__PURE__ */ jsx(Video, { className: "w-6 h-6 text-[#000000] dark:text-white" }),
  // Placeholder for TikTok
  code: "utm_source=TikTok&utm_campaign=__CAMPAIGN_NAME__|__CAMPAIGN_ID__&utm_medium=__ADGROUP_NAME__|__ADGROUP_ID__&utm_content=__AD_NAME__|__AD_ID__"
}, {
  id: "taboola",
  name: "Código de UTMs do Taboola",
  description: "Copie o código para colocar nos anúncios do Taboola",
  icon: /* @__PURE__ */ jsx(Tag, { className: "w-6 h-6 text-[#0052C2]" }),
  // Placeholder for Taboola
  code: "utm_source=Taboola&utm_campaign={campaign_name}&utm_medium={site}&utm_content={title}"
}];
const SALES_PLATFORMS = [{
  id: "hotmart",
  name: "Hotmart"
}, {
  id: "cartpanda",
  name: "Cartpanda"
}, {
  id: "kiwify",
  name: "Kiwify"
}, {
  id: "braip",
  name: "Braip"
}, {
  id: "perfectpay",
  name: "Perfect Pay"
}, {
  id: "eduzz",
  name: "Eduzz"
}, {
  id: "monetizze",
  name: "Monetizze"
}, {
  id: "doppus",
  name: "Doppus"
}, {
  id: "yampi",
  name: "Yampi"
}, {
  id: "outra",
  name: "Outra"
}];
function UtmsRoute() {
  const [selectedSource, setSelectedSource] = useState(null);
  const [testUrl, setTestUrl] = useState("");
  const handleCopy = (code) => {
    navigator.clipboard.writeText(code);
    toast.success("Código UTM copiado com sucesso!");
    setSelectedSource(null);
  };
  const handleCopyScript = () => {
    const scriptCode = `<script>
(function(){
  var url = new URL(window.location.href);
  var links = document.querySelectorAll('a');
  links.forEach(function(link) {
    var href = new URL(link.href, window.location.href);
    url.searchParams.forEach(function(value, key) {
      href.searchParams.set(key, value);
    });
    link.href = href.toString();
  });
})();
<\/script>`;
    navigator.clipboard.writeText(scriptCode);
    toast.success("Script de UTMs copiado com sucesso!");
  };
  const handleTestUrl = () => {
    if (!testUrl) {
      toast.error("Insira uma URL válida.");
      return;
    }
    let urlString = testUrl;
    if (!urlString.startsWith("http://") && !urlString.startsWith("https://")) {
      urlString = "https://" + urlString;
    }
    try {
      const url = new URL(urlString);
      url.searchParams.set("utm_source", "telesignal_test");
      url.searchParams.set("utm_medium", "test_medium");
      url.searchParams.set("utm_campaign", "test_campaign");
      url.searchParams.set("utm_content", "test_content");
      url.searchParams.set("utm_term", "test_term");
      window.open(url.toString(), "_blank");
    } catch (e) {
      toast.error("URL inválida.");
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-[1200px] mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Códigos UTM" }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground mt-2", children: "Gere e copie os parâmetros e scripts de UTMs para suas campanhas de tráfego pago." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "glass cyber-border", children: [
      /* @__PURE__ */ jsxs(CardHeader, { className: "border-b border-border/40 pb-4", children: [
        /* @__PURE__ */ jsx(CardTitle, { className: "text-lg", children: "Códigos" }),
        /* @__PURE__ */ jsx(CardDescription, { children: "Obtenha os parâmetros de rastreamento para anexar aos seus links de anúncios." })
      ] }),
      /* @__PURE__ */ jsx(CardContent, { className: "p-0", children: /* @__PURE__ */ jsx("div", { className: "divide-y divide-border/40", children: UTM_SOURCES.map((source) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-4 hover:bg-white/5 transition-colors", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx("div", { className: "flex-shrink-0 w-10 h-10 rounded-full bg-background flex items-center justify-center shadow-sm", children: source.icon }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "font-semibold text-sm", children: source.name }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: source.description })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Button, { variant: "secondary", className: "bg-primary/10 hover:bg-primary/20 text-primary border-primary/20", onClick: () => setSelectedSource(source), children: [
          /* @__PURE__ */ jsx(List, { className: "w-4 h-4 mr-2" }),
          "Ver opções"
        ] })
      ] }, source.id)) }) })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "glass cyber-border", children: [
      /* @__PURE__ */ jsx(CardHeader, { className: "border-b border-border/40 pb-4", children: /* @__PURE__ */ jsx(CardTitle, { className: "text-lg", children: "Scripts" }) }),
      /* @__PURE__ */ jsx(CardContent, { className: "p-0", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-4 hover:bg-white/5 transition-colors", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx("div", { className: "flex-shrink-0 w-10 h-10 rounded-full bg-background flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx(Code2, { className: "w-5 h-5 text-primary" }) }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "font-semibold text-sm", children: "Script de UTMs" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Use esse script nas suas PVs para repassar as UTMs para o checkout" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Button, { variant: "secondary", className: "bg-primary/10 hover:bg-primary/20 text-primary border-primary/20", onClick: handleCopyScript, children: [
          /* @__PURE__ */ jsx(Copy, { className: "w-4 h-4 mr-2" }),
          "Copiar Script"
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "glass cyber-border", children: [
      /* @__PURE__ */ jsxs(CardHeader, { className: "border-b border-border/40 pb-4", children: [
        /* @__PURE__ */ jsx(CardTitle, { className: "text-lg", children: "Testar Rastreamento" }),
        /* @__PURE__ */ jsx(CardDescription, { children: "Insira o link da sua página (Landing Page ou Pre-Sell) para abri-la com UTMs de teste e verificar se estão sendo repassadas corretamente para o checkout." })
      ] }),
      /* @__PURE__ */ jsx(CardContent, { className: "p-4", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row items-center gap-3", children: [
        /* @__PURE__ */ jsx(Input, { placeholder: "Ex: https://filhoslibertos.online/deus", value: testUrl, onChange: (e) => setTestUrl(e.target.value), className: "flex-1 bg-black/20 h-11" }),
        /* @__PURE__ */ jsxs(Button, { onClick: handleTestUrl, className: "w-full sm:w-auto h-11 px-6", children: [
          /* @__PURE__ */ jsx(ExternalLink, { className: "w-4 h-4 mr-2" }),
          "Testar UTMs"
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(Dialog, { open: !!selectedSource, onOpenChange: (open) => !open && setSelectedSource(null), children: /* @__PURE__ */ jsxs(DialogContent, { className: "sm:max-w-[500px] glass cyber-border", children: [
      /* @__PURE__ */ jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsx(DialogTitle, { children: "Plataforma de Vendas" }),
        /* @__PURE__ */ jsxs(DialogDescription, { children: [
          "Obtenha os códigos de UTMs do ",
          selectedSource?.name.replace("Código de UTMs do ", ""),
          " apropriados para a sua plataforma de vendas:"
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "max-h-[60vh] overflow-y-auto pr-2 space-y-2 mt-4", children: SALES_PLATFORMS.map((platform) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg border border-border/50 bg-black/20 hover:border-primary/50 transition-colors", children: [
        /* @__PURE__ */ jsx("span", { className: "font-medium text-sm", children: platform.name }),
        /* @__PURE__ */ jsxs(Button, { size: "sm", onClick: () => handleCopy(selectedSource?.code || ""), children: [
          /* @__PURE__ */ jsx(Copy, { className: "w-4 h-4 mr-2" }),
          "Copiar"
        ] })
      ] }, platform.id)) }),
      /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground mt-4 text-center", children: "Utiliza cloaker? Verifique as integrações na documentação." })
    ] }) })
  ] });
}
export {
  UtmsRoute as component
};
