import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { h as listIntegrations, a as listPixels, i as getMyRedirectBase, j as deleteIntegration, k as listClicksFiltered, m as createIntegration } from "./tracking.functions-jGKb0ig9.js";
import { C as Card, O as CardHeader, Q as CardTitle, W as CardDescription, H as Badge, B as Button, x as CardContent, L as Label, I as Input, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, D as Dialog, g as DialogContent, h as DialogHeader, i as DialogTitle, t as DialogDescription, j as DialogFooter } from "./router-Cw6OHOsO.js";
import { Link2, Plug, Plus, AlertTriangle, Copy, Trash2, Wrench, Download, Search, Facebook, CheckCircle2, ArrowRight, ArrowLeft } from "lucide-react";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const EVENT_LABEL = {
  register: "Registro",
  ftd: "FTD (Primeiro Depósito)",
  deposit: "Depósito",
  custom: "Lead / Custom"
};
function IntegracoesPage() {
  const listFn = useServerFn(listIntegrations);
  const pixelsFn = useServerFn(listPixels);
  const baseFn = useServerFn(getMyRedirectBase);
  const integrations = useQuery({
    queryKey: ["integrations"],
    queryFn: () => listFn()
  });
  const pixels = useQuery({
    queryKey: ["tracking-pixels"],
    queryFn: () => pixelsFn()
  });
  const base = useQuery({
    queryKey: ["redirect-base"],
    queryFn: () => baseFn()
  });
  const baseHost = base.data?.domain ? `https://${base.data.domain}` : typeof window !== "undefined" ? window.location.origin : "";
  const [wizardOpen, setWizardOpen] = useState(false);
  const rows = integrations.data ?? [];
  const pixelMap = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const p of pixels.data ?? []) m.set(p.id, p);
    return m;
  }, [pixels.data]);
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Link2, { className: "size-6" }),
        " Integrações"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1 max-w-3xl", children: "Gerencie integrações com Casas de Aposta, Corretoras e outros sistemas para rastrear Registros, FTD, Depósitos ou Outros." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsxs(CardHeader, { className: "flex flex-row items-start sm:items-center justify-between gap-4 flex-wrap", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Plug, { className: "size-4" }),
            " Integrações Realizadas"
          ] }),
          /* @__PURE__ */ jsx(CardDescription, { children: "Configure URLs de webhook e acompanhe o status dos seus postbacks." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxs(Badge, { variant: "outline", className: "rounded-full", children: [
            rows.length,
            " integrações"
          ] }),
          /* @__PURE__ */ jsxs(Button, { onClick: () => setWizardOpen(true), children: [
            /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
            " Nova Integração"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsx("div", { className: "rounded-lg border overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-muted/40 text-xs uppercase text-muted-foreground", children: /* @__PURE__ */ jsxs("tr", { className: "text-left", children: [
          /* @__PURE__ */ jsx("th", { className: "p-3", children: "Nome" }),
          /* @__PURE__ */ jsx("th", { className: "p-3", children: "Evento" }),
          /* @__PURE__ */ jsx("th", { className: "p-3", children: "Link de Divulgação" }),
          /* @__PURE__ */ jsx("th", { className: "p-3", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "p-3 text-right", children: "Ações" })
        ] }) }),
        /* @__PURE__ */ jsxs("tbody", { children: [
          integrations.isLoading && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 5, className: "p-6 text-center text-muted-foreground", children: "Carregando..." }) }),
          !integrations.isLoading && rows.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 5, className: "p-8 text-center text-muted-foreground", children: 'Nenhuma integração cadastrada. Clique em "Nova Integração" para começar.' }) }),
          rows.map((r) => {
            const pixel = pixelMap.get(r.pixel_id);
            const divulgUrl = `${baseHost}/api/public/track/postback/${r.pixel_id}?secret=${pixel?.postback_secret ?? ""}&sub1={click_id}&event=${r.event_type}&integration=${r.id}`;
            return /* @__PURE__ */ jsx(IntegrationRow, { row: r, pixel, divulgUrl }, r.id);
          })
        ] })
      ] }) }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 flex items-start gap-3", children: [
      /* @__PURE__ */ jsx(AlertTriangle, { className: "size-5 text-amber-500 mt-0.5 shrink-0" }),
      /* @__PURE__ */ jsxs("div", { className: "text-sm", children: [
        /* @__PURE__ */ jsx("div", { className: "font-semibold text-amber-500", children: "Atenção: Requisito de Integração" }),
        /* @__PURE__ */ jsxs("p", { className: "text-muted-foreground mt-1", children: [
          "A integração só funciona corretamente com plataformas que permitam o envio do parâmetro",
          " ",
          /* @__PURE__ */ jsx("code", { className: "bg-background/60 px-1 rounded text-amber-400", children: "click_id" }),
          " através de Postback (S2S). Antes de realizar a configuração, verifique com o suporte do seu sistema ou provedor se eles oferecem suporte ao repasse desse parâmetro."
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(EventsHistoryCard, { pixels: pixels.data ?? [] }),
    wizardOpen && /* @__PURE__ */ jsx(NewIntegrationWizard, { open: wizardOpen, onOpenChange: setWizardOpen, pixels: pixels.data ?? [], baseHost })
  ] });
}
function IntegrationRow({
  row,
  pixel,
  divulgUrl
}) {
  const qc = useQueryClient();
  const delFn = useServerFn(deleteIntegration);
  const del = useMutation({
    mutationFn: () => delFn({
      data: {
        id: row.id
      }
    }),
    onSuccess: () => {
      toast.success("Integração removida");
      qc.invalidateQueries({
        queryKey: ["integrations"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const evLabel = row.event_type === "custom" && row.custom_event_name ? row.custom_event_name : EVENT_LABEL[row.event_type];
  return /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
    /* @__PURE__ */ jsxs("td", { className: "p-3 font-medium", children: [
      /* @__PURE__ */ jsx("div", { children: row.name }),
      /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: pixel?.name ?? "—" })
    ] }),
    /* @__PURE__ */ jsx("td", { className: "p-3", children: /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: evLabel }) }),
    /* @__PURE__ */ jsx("td", { className: "p-3", children: /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => {
      navigator.clipboard.writeText(divulgUrl);
      toast.success("Link copiado");
    }, className: "text-xs font-mono text-muted-foreground hover:text-foreground inline-flex items-center gap-1 max-w-xs truncate", title: divulgUrl, children: [
      /* @__PURE__ */ jsx(Copy, { className: "size-3 shrink-0" }),
      " ",
      /* @__PURE__ */ jsx("span", { className: "truncate", children: divulgUrl })
    ] }) }),
    /* @__PURE__ */ jsx("td", { className: "p-3", children: /* @__PURE__ */ jsx(Badge, { variant: row.is_active ? "default" : "outline", children: row.is_active ? "Ativa" : "Inativa" }) }),
    /* @__PURE__ */ jsx("td", { className: "p-3 text-right", children: /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => del.mutate(), disabled: del.isPending, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) }) })
  ] });
}
function NewIntegrationWizard({
  open,
  onOpenChange,
  pixels,
  baseHost
}) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [pixelId, setPixelId] = useState("");
  const [eventType, setEventType] = useState("");
  const [customEventName, setCustomEventName] = useState("");
  const [redirectUrl, setRedirectUrl] = useState("");
  const [metaCustomEvent, setMetaCustomEvent] = useState("");
  const [metaValue, setMetaValue] = useState("");
  const [createdId, setCreatedId] = useState(null);
  const qc = useQueryClient();
  const createFn = useServerFn(createIntegration);
  const create = useMutation({
    mutationFn: () => createFn({
      data: {
        pixel_id: pixelId,
        name,
        event_type: eventType,
        custom_event_name: eventType === "custom" ? customEventName || null : null,
        redirect_url: redirectUrl,
        meta_custom_event: metaCustomEvent || null,
        meta_value: metaValue ? Number(metaValue) : null,
        meta_currency: "BRL",
        is_active: true
      }
    }),
    onSuccess: (res) => {
      toast.success("Integração criada");
      qc.invalidateQueries({
        queryKey: ["integrations"]
      });
      setCreatedId(res.id);
      setStep(3);
    },
    onError: (e) => toast.error(e.message)
  });
  const pixel = pixels.find((p) => p.id === pixelId);
  const finalUrl = pixel ? `${baseHost}/api/public/track/postback/${pixel.id}?secret=${pixel.postback_secret}&sub1={click_id}&event=${eventType}${createdId ? `&integration=${createdId}` : ""}` : "";
  const canNext1 = !!(name && pixelId && eventType && redirectUrl && (eventType !== "custom" || customEventName));
  const reset = () => {
    setStep(1);
    setName("");
    setPixelId("");
    setEventType("");
    setCustomEventName("");
    setRedirectUrl("");
    setMetaCustomEvent("");
    setMetaValue("");
    setCreatedId(null);
  };
  return /* @__PURE__ */ jsx(Dialog, { open, onOpenChange: (v) => {
    if (!v) reset();
    onOpenChange(v);
  }, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-2xl", children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx("div", { className: "size-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center", children: /* @__PURE__ */ jsx(Plug, { className: "size-5" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(DialogTitle, { children: "Nova Integração" }),
          /* @__PURE__ */ jsx(DialogDescription, { children: "Configure o webhook de tracking para sua plataforma" })
        ] })
      ] }),
      /* @__PURE__ */ jsx(Stepper, { step })
    ] }) }),
    step === 1 && /* @__PURE__ */ jsxs("div", { className: "space-y-4 py-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Nome" }),
          /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), placeholder: "Ex: Registro VIP" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Pixel" }),
          /* @__PURE__ */ jsxs(Select, { value: pixelId, onValueChange: setPixelId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione um Pixel" }) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              pixels.length === 0 && /* @__PURE__ */ jsxs("div", { className: "p-2 text-xs text-muted-foreground", children: [
                "Nenhum pixel. ",
                /* @__PURE__ */ jsx(Link, { to: "/trackeamento/pixels", className: "underline", children: "Criar pixel" })
              ] }),
              pixels.map((p) => /* @__PURE__ */ jsx(SelectItem, { value: p.id, children: p.name }, p.id))
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Tipo de Evento" }),
        /* @__PURE__ */ jsxs(Select, { value: eventType, onValueChange: (v) => setEventType(v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione o Evento" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "register", children: "Registro" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "ftd", children: "FTD (Primeiro Depósito)" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "deposit", children: "Depósito" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "custom", children: "Lead / Custom" })
          ] })
        ] })
      ] }),
      eventType === "custom" && /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Nome do Evento Customizado" }),
        /* @__PURE__ */ jsx(Input, { value: customEventName, onChange: (e) => setCustomEventName(e.target.value), placeholder: "ex: LeadHotmart" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Link de Redirect (Destino)" }),
        /* @__PURE__ */ jsx(Input, { value: redirectUrl, onChange: (e) => setRedirectUrl(e.target.value), placeholder: "https://seu-site.com/obrigado" })
      ] })
    ] }),
    step === 2 && /* @__PURE__ */ jsxs("div", { className: "space-y-4 py-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsx(Facebook, { className: "size-4 text-blue-500" }),
        " Configurações Meta Pixel CAPI (opcional)"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Nome do Evento Meta (opcional)" }),
        /* @__PURE__ */ jsx(Input, { value: metaCustomEvent, onChange: (e) => setMetaCustomEvent(e.target.value), placeholder: "ex: Purchase, CompleteRegistration, Lead" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Deixe em branco para usar o evento padrão do pixel." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Valor padrão (opcional)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", value: metaValue, onChange: (e) => setMetaValue(e.target.value), placeholder: "ex: 50.00" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Usado quando o postback não enviar valor. Moeda: BRL." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground", children: [
        /* @__PURE__ */ jsx("strong", { className: "text-foreground", children: "Dica:" }),
        " se você ainda não conectou sua conta Meta,",
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/integracoes/meta", className: "underline", children: "abra a integração Meta" }),
        " primeiro."
      ] })
    ] }),
    step === 3 && /* @__PURE__ */ jsxs("div", { className: "space-y-4 py-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-green-500", children: [
        /* @__PURE__ */ jsx(CheckCircle2, { className: "size-5" }),
        /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Integração criada com sucesso!" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "URL de Postback (S2S)" }),
        /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => {
          navigator.clipboard.writeText(finalUrl);
          toast.success("Copiado");
        }, className: "w-full text-left text-xs font-mono bg-muted/50 hover:bg-muted rounded p-3 break-all relative", children: [
          /* @__PURE__ */ jsx(Copy, { className: "size-3 absolute top-2 right-2 opacity-60" }),
          finalUrl
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
          "Configure esta URL na sua plataforma. Substitua ",
          /* @__PURE__ */ jsx("code", { className: "bg-muted px-1 rounded", children: "{click_id}" }),
          " pela variável de click_id (SubID) da plataforma."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Link de Redirect" }),
        /* @__PURE__ */ jsx("div", { className: "text-xs font-mono bg-muted/50 rounded p-3 break-all", children: redirectUrl })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { className: "gap-2", children: [
      step === 1 && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => onOpenChange(false), children: "Cancelar" }),
        /* @__PURE__ */ jsxs(Button, { onClick: () => setStep(2), disabled: !canNext1, children: [
          "Próximo ",
          /* @__PURE__ */ jsx(ArrowRight, { className: "size-4" })
        ] })
      ] }),
      step === 2 && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs(Button, { variant: "ghost", onClick: () => setStep(1), children: [
          /* @__PURE__ */ jsx(ArrowLeft, { className: "size-4" }),
          " Voltar"
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => create.mutate(), disabled: create.isPending, children: create.isPending ? "Criando..." : /* @__PURE__ */ jsxs(Fragment, { children: [
          "Criar e ver instalação ",
          /* @__PURE__ */ jsx(ArrowRight, { className: "size-4" })
        ] }) })
      ] }),
      step === 3 && /* @__PURE__ */ jsx(Button, { onClick: () => {
        reset();
        onOpenChange(false);
      }, children: "Concluir" })
    ] })
  ] }) });
}
function Stepper({
  step
}) {
  const items = [{
    n: 1,
    label: "Configuração"
  }, {
    n: 2,
    label: "Facebook"
  }, {
    n: 3,
    label: "Instalação"
  }];
  return /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: items.map((it, i) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsx("div", { className: `size-7 rounded-full flex items-center justify-center text-xs font-semibold ${step >= it.n ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`, children: it.n }),
    /* @__PURE__ */ jsx("span", { className: `text-xs ${step >= it.n ? "text-foreground" : "text-muted-foreground"}`, children: it.label }),
    i < items.length - 1 && /* @__PURE__ */ jsx("div", { className: "w-6 h-px bg-border" })
  ] }, it.n)) });
}
function EventsHistoryCard({
  pixels
}) {
  const [pixelId, setPixelId] = useState("any");
  const [from, setFrom] = useState("");
  const [event, setEvent] = useState("any");
  const [search, setSearch] = useState("");
  const fn = useServerFn(listClicksFiltered);
  const effectivePixel = pixelId === "any" ? pixels[0]?.id ?? null : pixelId;
  const q = useQuery({
    queryKey: ["integ-events", effectivePixel, from, event],
    enabled: !!effectivePixel,
    queryFn: () => fn({
      data: {
        pixel_id: effectivePixel,
        from: from ? new Date(from).toISOString() : null,
        to: null,
        event,
        limit: 1e3
      }
    })
  });
  const rows = q.data ?? [];
  const filtered = useMemo(() => {
    if (!search.trim()) return rows;
    const s = search.toLowerCase();
    return rows.filter((r) => (r.click_id ?? "").toLowerCase().includes(s) || (r.utm_source ?? "").toLowerCase().includes(s) || (r.utm_campaign ?? "").toLowerCase().includes(s));
  }, [rows, search]);
  const exportCsv = () => {
    const headers = ["created_at", "click_id", "event_type", "utm_source", "utm_campaign", "sale_value", "sale_currency"];
    const esc = (v) => {
      if (v == null) return "";
      const s = String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [headers.join(",")];
    for (const r of filtered) {
      const evType = r.deposited_at ? "deposit" : r.registered_at ? "register" : r.clicked_offer_at ? "offer_click" : r.joined_at ? "join" : "click";
      lines.push(headers.map((h) => esc(h === "event_type" ? evType : r[h])).join(","));
    }
    const blob = new Blob([lines.join("\n")], {
      type: "text/csv;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `eventos-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return /* @__PURE__ */ jsxs(Card, { children: [
    /* @__PURE__ */ jsxs(CardHeader, { className: "flex flex-row items-start sm:items-center justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Wrench, { className: "size-4" }),
          " Histórico de Eventos"
        ] }),
        /* @__PURE__ */ jsx(CardDescription, { children: "Acompanhe todos os postbacks recebidos das suas integrações." })
      ] }),
      /* @__PURE__ */ jsxs(Button, { variant: "outline", onClick: exportCsv, disabled: filtered.length === 0, children: [
        /* @__PURE__ */ jsx(Download, { className: "size-4" }),
        " Exportar CSV"
      ] })
    ] }),
    /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid sm:grid-cols-4 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs uppercase text-muted-foreground", children: "Período" }),
          /* @__PURE__ */ jsx(Input, { type: "datetime-local", value: from, onChange: (e) => setFrom(e.target.value), placeholder: "Selecione uma Data" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs uppercase text-muted-foreground", children: "Tipo" }),
          /* @__PURE__ */ jsxs(Select, { value: event, onValueChange: (v) => setEvent(v), children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "any", children: "Todos os Tipos" }),
              /* @__PURE__ */ jsx(SelectItem, { value: "click", children: "Clique" }),
              /* @__PURE__ */ jsx(SelectItem, { value: "join", children: "Entrou no grupo" }),
              /* @__PURE__ */ jsx(SelectItem, { value: "offer_click", children: "Clique na oferta" }),
              /* @__PURE__ */ jsx(SelectItem, { value: "register", children: "Registro" }),
              /* @__PURE__ */ jsx(SelectItem, { value: "deposit", children: "Depósito" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs uppercase text-muted-foreground", children: "Pixel" }),
          /* @__PURE__ */ jsxs(Select, { value: pixelId, onValueChange: setPixelId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "any", children: "Todos os Pixels" }),
              pixels.map((p) => /* @__PURE__ */ jsx(SelectItem, { value: p.id, children: p.name }, p.id))
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs uppercase text-muted-foreground", children: "Buscar" }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx(Search, { className: "size-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ jsx(Input, { className: "pl-8", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Nome Interno, Tipo ou ClickID..." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "rounded-lg border overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-xs", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-muted/40 uppercase text-muted-foreground", children: /* @__PURE__ */ jsxs("tr", { className: "text-left", children: [
          /* @__PURE__ */ jsx("th", { className: "p-2", children: "Data" }),
          /* @__PURE__ */ jsx("th", { className: "p-2", children: "Horário" }),
          /* @__PURE__ */ jsx("th", { className: "p-2", children: "Tipo do Evento" }),
          /* @__PURE__ */ jsx("th", { className: "p-2", children: "Valor" }),
          /* @__PURE__ */ jsx("th", { className: "p-2", children: "ClickID" }),
          /* @__PURE__ */ jsx("th", { className: "p-2", children: "UTM Source" })
        ] }) }),
        /* @__PURE__ */ jsxs("tbody", { children: [
          !effectivePixel && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 6, className: "p-8 text-center text-muted-foreground", children: "Crie um pixel para visualizar eventos." }) }),
          effectivePixel && q.isLoading && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 6, className: "p-6 text-center text-muted-foreground", children: "Carregando..." }) }),
          effectivePixel && !q.isLoading && filtered.length === 0 && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 6, className: "p-8 text-center text-muted-foreground", children: "Nenhum evento encontrado com os filtros aplicados." }) }),
          filtered.map((r) => {
            const evType = r.deposited_at ? "deposit" : r.registered_at ? "register" : r.clicked_offer_at ? "offer_click" : r.joined_at ? "join" : "click";
            const d = new Date(r.created_at);
            return /* @__PURE__ */ jsxs("tr", { className: "border-t", children: [
              /* @__PURE__ */ jsx("td", { className: "p-2 whitespace-nowrap", children: d.toLocaleDateString("pt-BR") }),
              /* @__PURE__ */ jsx("td", { className: "p-2 whitespace-nowrap", children: d.toLocaleTimeString("pt-BR") }),
              /* @__PURE__ */ jsx("td", { className: "p-2", children: /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: evType }) }),
              /* @__PURE__ */ jsx("td", { className: "p-2", children: r.sale_value ? `${r.sale_value} ${r.sale_currency ?? ""}` : "—" }),
              /* @__PURE__ */ jsx("td", { className: "p-2 font-mono", children: r.click_id }),
              /* @__PURE__ */ jsx("td", { className: "p-2", children: r.utm_source ?? "—" })
            ] }, r.click_id);
          })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
        "Mostrando ",
        filtered.length,
        " de ",
        rows.length,
        " eventos."
      ] })
    ] })
  ] });
}
export {
  IntegracoesPage as component
};
