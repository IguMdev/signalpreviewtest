const ASSETS_CATALOG = {
  Forex: [
    "AUDCAD",
    "AUDCHF",
    "AUDJPY",
    "AUDNZD",
    "AUDUSD",
    "CADCHF",
    "CADJPY",
    "CHFJPY",
    "COPPER",
    "EURAUD",
    "EURCAD",
    "EURCHF",
    "EURGBP",
    "EURJPY",
    "EURNZD",
    "EURUSD",
    "GBPAUD",
    "GBPCAD",
    "GBPCHF",
    "GBPJPY",
    "GBPNZD",
    "GBPUSD",
    "GOLD",
    "NZDCAD",
    "NZDCHF",
    "NZDJPY",
    "NZDUSD",
    "OIL_BRENT",
    "SILVER",
    "USDAUD",
    "USDCAD",
    "USDCHF",
    "USDJPY",
    "XLMUSD"
  ],
  Cripto: [
    "ADAUSDT",
    "ADAUSDTOTC",
    "BNBUSDT",
    "BNBUSDTOTC",
    "BTCUSDT",
    "BTCUSDTOTC",
    "DOGEUSDT",
    "ETHOTC",
    "ETHUSDT",
    "LTCUSDT",
    "LTCUSDTOTC",
    "SOLOTC",
    "SOLUSDT",
    "SUIUSDT",
    "XRPUSDT"
  ],
  "Ações": [
    "AAPL",
    "AMZN",
    "BABA",
    "BA",
    "CSCO",
    "DIS",
    "FB",
    "FORD",
    "GOOGL",
    "IBM",
    "INTC",
    "JNJ",
    "JPM",
    "KO",
    "MA",
    "MCD",
    "META",
    "MSFT",
    "NFLX",
    "NIKE",
    "NVDA",
    "PYPL",
    "SBUX",
    "SPOT",
    "TSLA",
    "V",
    "VISA",
    "XOM"
  ],
  OTC: [
    "AAPLOTC",
    "AMZNOTC",
    "AUDCHFOTC",
    "AUDJPYOTC",
    "AVAXOTC",
    "CADCHFOTC",
    "DISOTC",
    "DOGEOTC",
    "EURAUDOTC",
    "EURCADOTC",
    "EURCHFOTC",
    "EURGBPOTC",
    "EURJPYOTC",
    "EURNZDOTC",
    "EURUSDOTC",
    "FBOTC",
    "FORDOTC",
    "GBPAUDOTC",
    "GBPCHFOTC",
    "GBPJPYOTC",
    "GOLDOTC",
    "IBMOTC",
    "INTCOTC",
    "KOOTC",
    "LINKOTC",
    "MAOTC",
    "MSFTOTC",
    "NFLXOTC",
    "NIKEOTC",
    "NVDAOTC",
    "NZDJPYOTC",
    "PYPLOTC",
    "SBUXOTC",
    "SPOTOTC",
    "SUIOTC",
    "TSLAOTC",
    "USDAUDOTC",
    "USDBRLOTC",
    "USDCHFOTC",
    "VISAOTC",
    "XAUUSDOTC",
    "XPLOTC"
  ]
};
const DEFAULT_PAYOUT = 1.85;
const BINANCE_SYMBOL_MAP = {
  ADAUSDT: "ADAUSDT",
  BNBUSDT: "BNBUSDT",
  BTCUSDT: "BTCUSDT",
  DOGEUSDT: "DOGEUSDT",
  ETHUSDT: "ETHUSDT",
  LTCUSDT: "LTCUSDT",
  SOLUSDT: "SOLUSDT",
  SUIUSDT: "SUIUSDT",
  XRPUSDT: "XRPUSDT",
  Litecoin: "LTCUSDT",
  Bitcoin: "BTCUSDT",
  Ethereum: "ETHUSDT"
};
function categoryFor(assetCode) {
  for (const [cat, list] of Object.entries(ASSETS_CATALOG)) {
    if (list.includes(assetCode)) return cat;
  }
  return null;
}
async function getBinanceCandle(asset, entryAt, timeframe) {
  const symbol = BINANCE_SYMBOL_MAP[asset];
  if (!symbol) return null;
  const intervalMap = { M1: "1m", M5: "5m", M15: "15m" };
  const interval = intervalMap[timeframe?.toUpperCase()] || "1m";
  const minuteStart = Math.floor(entryAt.getTime() / 6e4) * 6e4;
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&startTime=${minuteStart}&limit=1`;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const arr = await res.json();
    if (!Array.isArray(arr) || arr.length === 0) return null;
    const k = arr[0];
    return { open: Number(k[1]), close: Number(k[4]) };
  } catch {
    return null;
  }
}
function resolveBinary(direction, open, close) {
  if (close === open) return "draw";
  const up = close > open;
  if (direction === "buy" && up) return "win";
  if (direction === "sell" && !up) return "win";
  return "loss";
}
function renderTemplate(tpl, vars) {
  return tpl.replace(/\{(\w+)\}/g, (_m, key) => {
    const v = vars[key];
    return v ?? `{${key}}`;
  });
}
function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function buildSlots(startHHMM, endHHMM, qty) {
  const toMin = (s) => {
    const [h, m] = s.split(":").map(Number);
    return h * 60 + m;
  };
  const start = toMin(startHHMM);
  let end = toMin(endHHMM);
  if (end < start) end += 1440;
  const total = Math.max(0, end - start);
  if (qty <= 0 || total <= 0) return [];
  const available = total;
  const effectiveQty = Math.min(qty, available);
  const slots = /* @__PURE__ */ new Set();
  for (let i = 0; i < effectiveQty; i++) {
    const offset = Math.floor(i * total / effectiveQty);
    const m = (start + offset) % 1440;
    const hh = String(Math.floor(m / 60)).padStart(2, "0");
    const mm = String(m % 60).padStart(2, "0");
    slots.add(`${hh}:${mm}`);
  }
  return Array.from(slots);
}
function nowParts(tz) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
  const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
  const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
  const wdMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return {
    weekday: wdMap[get("weekday")] ?? 0,
    hhmm: `${get("hour").padStart(2, "0")}:${get("minute").padStart(2, "0")}`
  };
}
export {
  ASSETS_CATALOG as A,
  DEFAULT_PAYOUT as D,
  resolveBinary as a,
  buildSlots as b,
  categoryFor as c,
  getBinanceCandle as g,
  nowParts as n,
  pickRandom as p,
  renderTemplate as r
};
