import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const syncRoomPhoto_createServerFn_handler = createServerRpc({
  id: "caab0abaa72a33b59460709845e7aec17500521150d731dc3ac8e2d4a6450b92",
  name: "syncRoomPhoto",
  filename: "src/lib/room-photos.functions.ts"
}, (opts) => syncRoomPhoto.__executeServer(opts));
const syncRoomPhoto = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(syncRoomPhoto_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: room
  } = await supabase.from("rooms").select("id, default_account_id").eq("id", data.roomId).maybeSingle();
  if (!room) throw new Error("Sala não encontrada");
  const {
    data: chats
  } = await supabase.from("room_chats").select("chat_id").eq("room_id", data.roomId).limit(1);
  const chat = chats?.[0];
  if (!chat) throw new Error("Esta sala ainda não tem grupo vinculado");
  let accountId = room.default_account_id;
  if (!accountId) {
    const {
      data: anyAcc
    } = await supabase.from("telegram_accounts").select("id").eq("is_active", true).limit(1).maybeSingle();
    accountId = anyAcc?.id ?? null;
  }
  if (!accountId) throw new Error("Nenhuma conta Telegram disponível");
  const {
    data: acc
  } = await supabase.from("telegram_accounts").select("bot_token").eq("id", accountId).maybeSingle();
  if (!acc?.bot_token) throw new Error("Conta sem token");
  const info = await callTelegram(acc.bot_token, "getChat", {
    chat_id: chat.chat_id
  });
  if (!info.ok || !info.result) {
    const desc = info.description ?? "Falha ao consultar grupo";
    return {
      ok: false,
      photoUrl: null,
      message: desc
    };
  }
  if (!info.result.photo) {
    await supabase.from("rooms").update({
      photo_url: null,
      photo_updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", data.roomId);
    return {
      ok: true,
      photoUrl: null,
      message: "Grupo sem foto"
    };
  }
  const fileId = info.result.photo.big_file_id;
  const f = await callTelegram(acc.bot_token, "getFile", {
    file_id: fileId
  });
  if (!f.ok || !f.result?.file_path) {
    throw new Error(f.description ?? "Falha ao obter arquivo");
  }
  const dl = await fetch(`https://api.telegram.org/file/bot${acc.bot_token}/${f.result.file_path}`);
  if (!dl.ok) throw new Error(`Download falhou (${dl.status})`);
  const bytes = new Uint8Array(await dl.arrayBuffer());
  const ext = f.result.file_path.split(".").pop()?.toLowerCase() || "jpg";
  const contentType = ext === "png" ? "image/png" : "image/jpeg";
  const path = `${userId}/${data.roomId}-${Date.now()}.${ext}`;
  const {
    error: upErr
  } = await supabase.storage.from("room-photos").upload(path, bytes, {
    contentType,
    upsert: true
  });
  if (upErr) throw new Error(upErr.message);
  const {
    data: pub
  } = supabase.storage.from("room-photos").getPublicUrl(path);
  const photoUrl = pub.publicUrl;
  await supabase.from("rooms").update({
    photo_url: photoUrl,
    photo_updated_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", data.roomId);
  return {
    ok: true,
    photoUrl
  };
});
export {
  syncRoomPhoto_createServerFn_handler
};
