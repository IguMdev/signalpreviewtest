import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { s as supabase } from "./client-bD0og8Nx.js";
import { w as getPixel, u as updatePixel } from "./tracking.functions-jGKb0ig9.js";
import { C as Card, O as CardHeader, Q as CardTitle, W as CardDescription, x as CardContent, L as Label, I as Input, B as Button, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem } from "./router-Cw6OHOsO.js";
import { Send, Copy } from "lucide-react";
import { u as usePixelFilter, P as PixelFilterBar } from "./PixelFilter-FzJuz8YB.js";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function CanalPage() {
  const {
    pixelId,
    pixels,
    setPixel
  } = usePixelFilter();
  const effectiveId = pixelId ?? pixels[0]?.id ?? null;
  const currentPixel = pixels.find((p) => p.id === effectiveId);
  const mode = currentPixel?.tracking_mode ?? "telegram";
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-3xl", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Send, { className: "size-6" }),
        " Canal"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1", children: mode === "direct_response" ? "Configure a página de vendas e copie o snippet de tracking para colar no <head>." : "Vincule cada pixel a um bot do Telegram e a uma sala." })
    ] }),
    /* @__PURE__ */ jsx(PixelFilterBar, { pixelId: effectiveId, pixels, setPixel }),
    effectiveId && (mode === "direct_response" ? /* @__PURE__ */ jsx(DirectResponsePanel, { pixelId: effectiveId }) : /* @__PURE__ */ jsx(CanalForm, { pixelId: effectiveId }))
  ] });
}
function DirectResponsePanel({
  pixelId
}) {
  const qc = useQueryClient();
  const getFn = useServerFn(getPixel);
  const updFn = useServerFn(updatePixel);
  const pixel = useQuery({
    queryKey: ["pixel", pixelId],
    queryFn: () => getFn({
      data: {
        id: pixelId
      }
    })
  });
  const [salesUrl, setSalesUrl] = useState("");
  useEffect(() => {
    if (pixel.data) setSalesUrl(pixel.data.sales_page_url ?? "");
  }, [pixel.data]);
  const save = useMutation({
    mutationFn: () => updFn({
      data: {
        id: pixelId,
        sales_page_url: salesUrl || null
      }
    }),
    onSuccess: () => {
      toast.success("Página de vendas salva");
      qc.invalidateQueries({
        queryKey: ["pixel", pixelId]
      });
      qc.invalidateQueries({
        queryKey: ["tracking-pixels"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const snippet = `<!-- Signal Tracking (Direct Response) -->
<script>
(function(){
  var PIXEL = "${pixelId}";
  var ENDPOINT = "${origin}/api/public/track/dr/" + PIXEL;
  function q(k){return new URLSearchParams(location.search).get(k);}
  function ck(n){var m=document.cookie.match(new RegExp('(?:^|; )'+n+'=([^;]*)'));return m?decodeURIComponent(m[1]):null;}
  var CID = localStorage.getItem('lv_cid') || q('click_id') || null;
  function setCid(id){ CID = id; if(id) localStorage.setItem('lv_cid', id); }
  function send(stage, extra){
    var body = Object.assign({
      stage: stage, click_id: CID,
      fbp: ck('_fbp'), fbc: ck('_fbc'), fbclid: q('fbclid'),
      landing_url: location.href, referrer: document.referrer,
      utm_source: q('utm_source'), utm_medium: q('utm_medium'),
      utm_campaign: q('utm_campaign'), utm_content: q('utm_content'), utm_term: q('utm_term')
    }, extra || {});
    return fetch(ENDPOINT, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)})
      .then(function(r){return r.json();})
      .then(function(j){ if(j && j.click_id) setCid(j.click_id); return j; })
      .catch(function(){});
  }
  window.lvTrack = send;
  send('view');
})();
<\/script>`;
  const leadExample = `lvTrack('lead', { email: 'user@dominio.com', phone: '+5511999998888' });`;
  const purchaseExample = `lvTrack('purchase', { value: 297, currency: 'BRL', email: 'comprador@dominio.com' });`;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsxs(CardHeader, { children: [
        /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Página de vendas" }),
        /* @__PURE__ */ jsx(CardDescription, { children: "URL onde o anúncio Meta cai. Usada como referência nos relatórios." })
      ] }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "URL da página" }),
          /* @__PURE__ */ jsx(Input, { value: salesUrl, onChange: (e) => setSalesUrl(e.target.value), placeholder: "https://meuproduto.com.br/oferta" })
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: "Salvar" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsxs(CardHeader, { children: [
        /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Snippet de tracking" }),
        /* @__PURE__ */ jsxs(CardDescription, { children: [
          "Cole no ",
          /* @__PURE__ */ jsx("code", { children: "<head>" }),
          " da página de vendas. Dispara ",
          /* @__PURE__ */ jsx("code", { children: "view" }),
          " automaticamente e expõe ",
          /* @__PURE__ */ jsx("code", { children: "lvTrack(stage, extra)" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
        /* @__PURE__ */ jsx("pre", { className: "text-xs bg-muted/40 border rounded p-3 overflow-x-auto whitespace-pre", children: snippet }),
        /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: () => {
          navigator.clipboard.writeText(snippet);
          toast.success("Snippet copiado");
        }, children: [
          /* @__PURE__ */ jsx(Copy, { className: "size-3.5" }),
          " Copiar snippet"
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pt-3 border-t space-y-2", children: [
          /* @__PURE__ */ jsx("p", { className: "text-xs font-medium", children: "Dispare eventos extras no fluxo:" }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] text-muted-foreground", children: "No opt-in / captura de lead:" }),
          /* @__PURE__ */ jsx("pre", { className: "text-xs bg-muted/40 border rounded p-2 overflow-x-auto", children: leadExample }),
          /* @__PURE__ */ jsx("p", { className: "text-[11px] text-muted-foreground", children: "Na página de obrigado / pós-compra:" }),
          /* @__PURE__ */ jsx("pre", { className: "text-xs bg-muted/40 border rounded p-2 overflow-x-auto", children: purchaseExample }),
          /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-muted-foreground", children: [
            "Outros estágios: ",
            /* @__PURE__ */ jsx("code", { children: "lvTrack('checkout')" }),
            ", ",
            /* @__PURE__ */ jsx("code", { children: "lvTrack('payment_info')" }),
            "."
          ] })
        ] })
      ] })
    ] })
  ] });
}
function CanalForm({
  pixelId
}) {
  const qc = useQueryClient();
  const getFn = useServerFn(getPixel);
  const updFn = useServerFn(updatePixel);
  const pixel = useQuery({
    queryKey: ["pixel", pixelId],
    queryFn: () => getFn({
      data: {
        id: pixelId
      }
    })
  });
  const accounts = useQuery({
    queryKey: ["ta-mini-canal"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("telegram_accounts").select("id,bot_username");
      return data ?? [];
    }
  });
  const rooms = useQuery({
    queryKey: ["rooms-mini-canal"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("rooms").select("id,name");
      return data ?? [];
    }
  });
  const [accountId, setAccountId] = useState("");
  const [roomId, setRoomId] = useState("");
  useEffect(() => {
    if (pixel.data) {
      setAccountId(pixel.data.account_id ?? "");
      setRoomId(pixel.data.room_id ?? "");
    }
  }, [pixel.data]);
  const save = useMutation({
    mutationFn: () => updFn({
      data: {
        id: pixelId,
        account_id: accountId || null,
        room_id: roomId || null
      }
    }),
    onSuccess: () => {
      toast.success("Vínculos salvos");
      qc.invalidateQueries({
        queryKey: ["pixel", pixelId]
      });
      qc.invalidateQueries({
        queryKey: ["tracking-pixels"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs(Card, { children: [
    /* @__PURE__ */ jsxs(CardHeader, { children: [
      /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Vínculos do pixel" }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        "O bot recebe o ",
        /* @__PURE__ */ jsx("code", { children: "/start tk_<click_id>" }),
        " e a sala é onde os usuários entram."
      ] })
    ] }),
    /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Bot do Telegram" }),
        /* @__PURE__ */ jsxs(Select, { value: accountId || "none", onValueChange: (v) => setAccountId(v === "none" ? "" : v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhum" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum" }),
            accounts.data?.map((a) => /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
              "@",
              a.bot_username ?? "(sem)"
            ] }, a.id))
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Sala (opcional)" }),
        /* @__PURE__ */ jsxs(Select, { value: roomId || "none", onValueChange: (v) => setRoomId(v === "none" ? "" : v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhuma" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhuma" }),
            rooms.data?.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id))
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: "Salvar" })
    ] })
  ] });
}
export {
  CanalPage as component
};
