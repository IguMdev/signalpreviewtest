import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import "./client.server-CDheR9QG.js";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "zod";
import "./telegram.server-CxWEOea-.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
async function sendVoiceToChat(opts) {
  if (!opts.botToken) {
    return {
      ok: false,
      description: "Conta sem bot_token"
    };
  }
  const form = new FormData();
  form.append("chat_id", String(opts.chatId));
  if (opts.duration) form.append("duration", String(opts.duration));
  if (opts.caption) form.append("caption", opts.caption);
  form.append("voice", new Blob([opts.fileBytes], {
    type: opts.mimeType || "audio/ogg"
  }), opts.filename);
  const res = await fetch(`https://api.telegram.org/bot${opts.botToken}/sendVoice`, {
    method: "POST",
    body: form
  });
  return await res.json();
}
const sendAudioNow = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(createSsrRpc("7d6d81fc49c7fc84551bd929bf5a67d4d916f804fdf846fb012c69b9e6ba41a9"));
const deleteAudio = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((id) => id).handler(createSsrRpc("8a7527746586e344d6ed82b12250cdb4270db02a4d02289b4eb367cb65a8215f"));
export {
  deleteAudio,
  sendAudioNow,
  sendVoiceToChat
};
