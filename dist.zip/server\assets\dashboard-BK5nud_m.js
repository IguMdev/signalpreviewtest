import { jsxs, jsx } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useState, useEffect, useMemo } from "react";
import { s as supabase } from "./client-bD0og8Nx.js";
import { u as useAuth, C as Card, H as Badge, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem } from "./router-Cw6OHOsO.js";
import { T as Tabs, a as TabsList, b as TabsTrigger, c as TabsContent } from "./tabs-Bc7VJTwT.js";
import { CreditCard, Send, Bot, Users, UserPlus, UserMinus, RefreshCw, Sparkles } from "lucide-react";
import { g as getMySubscriptions } from "./engagement.functions-BnPQkoHV.js";
import { a as getCurrentMemberCounts, g as getMemberStats } from "./telegram-tracking.functions-CF7nyJdP.js";
import "@supabase/supabase-js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "./client.server-CDheR9QG.js";
import "zod";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-tabs";
function getTzParts(date, tz) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    weekday: "short",
    hour12: false
  }).formatToParts(date);
  const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
  const wkMap = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6
  };
  return {
    year: Number(get("year")),
    month: Number(get("month")),
    day: Number(get("day")),
    hour: Number(get("hour")),
    minute: Number(get("minute")),
    weekday: wkMap[get("weekday")] ?? 0
  };
}
function tzDateAt(year, month, day, hour, minute, tz) {
  const utcGuess = Date.UTC(year, month - 1, day, hour, minute);
  const parts = getTzParts(new Date(utcGuess), tz);
  const asUtcOfParts = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute);
  const offset = asUtcOfParts - utcGuess;
  return new Date(utcGuess - offset);
}
function nextFireAt(now, dayOffset, hhmm, tz) {
  const today = getTzParts(now, tz);
  const base = tzDateAt(today.year, today.month, today.day, 0, 0, tz);
  const target = new Date(base.getTime() + dayOffset * 864e5);
  const parts = getTzParts(target, tz);
  const [h, m] = hhmm.split(":").map(Number);
  return tzDateAt(parts.year, parts.month, parts.day, h, m, tz);
}
function DashboardPage() {
  const {
    user
  } = useAuth();
  const fetchSubs = useServerFn(getMySubscriptions);
  const fetchCurrentCounts = useServerFn(getCurrentMemberCounts);
  const fetchStats = useServerFn(getMemberStats);
  const stats = useQuery({
    queryKey: ["dashboard-stats", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const todayStart = /* @__PURE__ */ new Date();
      todayStart.setHours(0, 0, 0, 0);
      const [accounts, activeBots, rooms, scheduled, profile, joinsToday, leavesToday, totalJoins2, totalLeaves2] = await Promise.all([supabase.from("telegram_accounts").select("id", {
        count: "exact",
        head: true
      }), supabase.from("telegram_accounts").select("id", {
        count: "exact",
        head: true
      }).eq("is_active", true).eq("status", "ok"), supabase.from("rooms").select("id", {
        count: "exact",
        head: true
      }), supabase.from("scheduled_messages").select("id", {
        count: "exact",
        head: true
      }).eq("status", "pending"), supabase.from("profiles").select("credits, display_name").eq("id", user.id).maybeSingle(), supabase.from("telegram_member_events").select("id", {
        count: "exact",
        head: true
      }).eq("event_type", "join").gte("occurred_at", todayStart.toISOString()), supabase.from("telegram_member_events").select("id", {
        count: "exact",
        head: true
      }).in("event_type", ["leave", "kicked"]).gte("occurred_at", todayStart.toISOString()), supabase.from("telegram_member_events").select("id", {
        count: "exact",
        head: true
      }).eq("event_type", "join"), supabase.from("telegram_member_events").select("id", {
        count: "exact",
        head: true
      }).in("event_type", ["leave", "kicked"])]);
      return {
        accounts: accounts.count ?? 0,
        activeBots: activeBots.count ?? 0,
        rooms: rooms.count ?? 0,
        pending: scheduled.count ?? 0,
        credits: profile.data?.credits ?? 0,
        name: profile.data?.display_name ?? "",
        joinsToday: joinsToday.count ?? 0,
        leavesToday: leavesToday.count ?? 0,
        netTotal: (totalJoins2.count ?? 0) - (totalLeaves2.count ?? 0)
      };
    }
  });
  const upcoming = useQuery({
    queryKey: ["upcoming", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [oneTime, recurring] = await Promise.all([supabase.from("scheduled_messages").select("id, content, scheduled_at, status, room_id").eq("status", "pending").order("scheduled_at").limit(10), supabase.from("recurring_schedules").select("id, title, content, times, weekdays, timezone, is_active").eq("is_active", true)]);
      const items = (oneTime.data ?? []).map((m) => ({
        id: m.id,
        content: m.content,
        scheduled_at: m.scheduled_at,
        status: m.status ?? "pending"
      }));
      const now = /* @__PURE__ */ new Date();
      const list = recurring.data ?? [];
      for (const r of list) {
        const tz = r.timezone || "America/Sao_Paulo";
        const times = (r.times ?? []).filter((t) => /^\d{2}:\d{2}$/.test(t));
        const weekdays = r.weekdays ?? [0, 1, 2, 3, 4, 5, 6];
        if (!times.length || !weekdays.length) continue;
        let next = null;
        for (let d = 0; d < 14 && !next; d++) {
          for (const t of times) {
            const candidate = nextFireAt(now, d, t, tz);
            const dow = getTzParts(candidate, tz).weekday;
            if (!weekdays.includes(dow)) continue;
            if (candidate.getTime() <= now.getTime()) continue;
            if (!next || candidate < next) next = candidate;
          }
        }
        if (next) {
          items.push({
            id: `r:${r.id}`,
            content: r.title || r.content,
            scheduled_at: next.toISOString(),
            status: "recorrente"
          });
        }
      }
      items.sort((a, b) => a.scheduled_at.localeCompare(b.scheduled_at));
      return items.slice(0, 5);
    }
  });
  const subsQ = useQuery({
    queryKey: ["dashboard-subs", user?.id],
    enabled: !!user,
    queryFn: () => fetchSubs()
  });
  const countsQ = useQuery({
    queryKey: ["dashboard-current-counts", user?.id],
    enabled: !!user,
    queryFn: () => fetchCurrentCounts()
  });
  const statsQ = useQuery({
    queryKey: ["dashboard-member-stats", user?.id],
    enabled: !!user,
    queryFn: () => fetchStats()
  });
  const [tab, setTab] = useState("group");
  const [selectedGroup, setSelectedGroup] = useState("all");
  const [selectedChannel, setSelectedChannel] = useState("all");
  const allChats = countsQ.data?.chats ?? [];
  const groups = allChats.filter((c) => c.chatType === "group" || c.chatType === "unknown");
  const channels = allChats.filter((c) => c.chatType === "channel");
  useEffect(() => {
    if (!countsQ.data) return;
    if (groups.length === 0 && channels.length > 0 && tab === "group") setTab("channel");
    else if (channels.length === 0 && groups.length > 0 && tab === "channel") setTab("group");
  }, [countsQ.data, groups.length, channels.length, tab]);
  const typeByChatId = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const c of allChats) m.set(String(c.chatId), c.chatType);
    return m;
  }, [allChats]);
  const selectedId = tab === "group" ? selectedGroup : selectedChannel;
  const visibleChats = (tab === "group" ? groups : channels).filter((c) => selectedId === "all" || String(c.chatId) === selectedId);
  const visiblePerChat = (statsQ.data?.perChat ?? []).filter((c) => {
    const chatId = String(c.chat_id);
    const t = typeByChatId.get(chatId) ?? "unknown";
    const inTab = tab === "group" ? t !== "channel" : t === "channel";
    return inTab && (selectedId === "all" || chatId === selectedId);
  });
  const perChatById = useMemo(() => new Map(visiblePerChat.map((c) => [String(c.chat_id), c])), [visiblePerChat]);
  const visibleChatActivity = visibleChats.map((chat) => {
    const stats2 = perChatById.get(String(chat.chatId));
    return {
      chat_id: chat.chatId,
      chat_title: stats2?.chat_title || chat.chatTitle || chat.roomName || null,
      joins: stats2?.joins ?? 0,
      leaves: stats2?.leaves ?? 0
    };
  });
  const visibleRecent = (statsQ.data?.recent ?? []).filter((e) => {
    const chatId = String(e.chat_id);
    const t = typeByChatId.get(chatId) ?? "unknown";
    const inTab = tab === "group" ? t !== "channel" : t === "channel";
    return inTab && (selectedId === "all" || chatId === selectedId);
  });
  const totalMembers = visibleChats.reduce((s, c) => s + (c.count ?? 0), 0);
  const totalJoins = visiblePerChat.reduce((s, c) => s + c.joins, 0);
  const totalLeaves = visiblePerChat.reduce((s, c) => s + c.leaves, 0);
  const activeSubs = (subsQ.data ?? []).filter((s) => s.status === "active");
  const monthlyTotal = activeSubs.reduce((sum, s) => sum + Number(s.plan?.price_brl ?? 0), 0);
  const fmtBRL = (v) => v.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
  const cards = [{
    label: "Mensalidade atual",
    value: fmtBRL(monthlyTotal),
    icon: CreditCard
  }, {
    label: "Contas Telegram",
    value: stats.data?.accounts ?? 0,
    icon: Send
  }, {
    label: "Bots ativos",
    value: stats.data?.activeBots ?? 0,
    icon: Bot
  }, {
    label: "Grupos",
    value: stats.data?.rooms ?? 0,
    icon: Users
  }];
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold tracking-tight", children: [
        "Olá",
        stats.data?.name ? `, ${stats.data.name}` : ""
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground text-sm", children: "Visão geral da sua automação Telegram." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-4", children: cards.map(({
      label,
      value,
      icon: Icon
    }) => /* @__PURE__ */ jsxs(Card, { className: "p-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsx("span", { className: "text-sm text-muted-foreground", children: label }),
        /* @__PURE__ */ jsx(Icon, { className: "size-4 text-primary" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-3 text-3xl font-bold", children: value })
    ] }, label)) }),
    /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { className: "font-semibold", children: "Planos ativos" }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
            "Total mensal: ",
            /* @__PURE__ */ jsx("span", { className: "font-semibold text-foreground", children: fmtBRL(monthlyTotal) })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Link, { to: "/recarga", className: "text-sm text-primary hover:underline", children: "Gerenciar" })
      ] }),
      activeSubs.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "text-center py-10 text-muted-foreground text-sm", children: [
        /* @__PURE__ */ jsx(CreditCard, { className: "size-8 mx-auto mb-2 opacity-50" }),
        "Você ainda não tem planos ativos."
      ] }) : /* @__PURE__ */ jsx("div", { className: "space-y-2", children: activeSubs.map((s) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg bg-muted/50", children: [
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate", children: s.plan?.name ?? "Plano" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground capitalize", children: s.plan?.bot_type ?? "" })
        ] }),
        /* @__PURE__ */ jsxs(Badge, { variant: "secondary", children: [
          fmtBRL(Number(s.plan?.price_brl ?? 0)),
          "/mês"
        ] })
      ] }, s.id)) })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { className: "font-semibold", children: "Membros por grupo / canal" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Selecione um chat para ver entradas, saídas e total atual." })
        ] }),
        /* @__PURE__ */ jsx(Link, { to: "/membros", className: "text-sm text-primary hover:underline shrink-0", children: "Ver detalhes" })
      ] }),
      /* @__PURE__ */ jsxs(Tabs, { value: tab, onValueChange: (v) => setTab(v), children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-3 justify-between mb-4", children: [
          /* @__PURE__ */ jsxs(TabsList, { children: [
            /* @__PURE__ */ jsxs(TabsTrigger, { value: "group", children: [
              "Grupos (",
              groups.length,
              ")"
            ] }),
            /* @__PURE__ */ jsxs(TabsTrigger, { value: "channel", children: [
              "Canais (",
              channels.length,
              ")"
            ] })
          ] }),
          tab === "group" ? /* @__PURE__ */ jsxs(Select, { value: selectedGroup, onValueChange: setSelectedGroup, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { className: "w-[260px]", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione um grupo" }) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos os grupos" }),
              groups.map((c) => /* @__PURE__ */ jsx(SelectItem, { value: String(c.chatId), children: c.chatTitle || c.roomName || `Chat ${c.chatId}` }, c.chatId))
            ] })
          ] }) : /* @__PURE__ */ jsxs(Select, { value: selectedChannel, onValueChange: setSelectedChannel, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { className: "w-[260px]", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione um canal" }) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos os canais" }),
              channels.map((c) => /* @__PURE__ */ jsx(SelectItem, { value: String(c.chatId), children: c.chatTitle || c.roomName || `Chat ${c.chatId}` }, c.chatId))
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(TabsContent, { value: tab, className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "p-3 rounded-lg bg-muted/50", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-xs text-muted-foreground", children: [
                /* @__PURE__ */ jsx("span", { children: "Membros atuais" }),
                /* @__PURE__ */ jsx(Users, { className: "size-3.5" })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold mt-1", children: totalMembers.toLocaleString("pt-BR") })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-3 rounded-lg bg-muted/50", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-xs text-muted-foreground", children: [
                /* @__PURE__ */ jsx("span", { children: "Entradas (30d)" }),
                /* @__PURE__ */ jsx(UserPlus, { className: "size-3.5 text-emerald-500" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "text-2xl font-bold mt-1 text-emerald-600", children: [
                "+",
                totalJoins
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "p-3 rounded-lg bg-muted/50", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-xs text-muted-foreground", children: [
                /* @__PURE__ */ jsx("span", { children: "Saídas (30d)" }),
                /* @__PURE__ */ jsx(UserMinus, { className: "size-3.5 text-rose-500" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "text-2xl font-bold mt-1 text-rose-600", children: [
                "-",
                totalLeaves
              ] })
            ] })
          ] }),
          countsQ.isLoading ? /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center py-6 text-muted-foreground text-sm gap-2", children: [
            /* @__PURE__ */ jsx(RefreshCw, { className: "size-4 animate-spin" }),
            " Carregando…"
          ] }) : visibleChats.length === 0 ? /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground py-6 text-center", children: [
            "Nenhum ",
            tab === "group" ? "grupo" : "canal",
            " encontrado."
          ] }) : /* @__PURE__ */ jsx("div", { className: "space-y-2", children: visibleChats.map((c) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg bg-muted/50 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate", children: c.chatTitle || c.roomName || `Chat ${c.chatId}` }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground truncate", children: [
                "ID: ",
                c.chatId,
                c.accountLabel ? ` • ${c.accountLabel}` : ""
              ] }),
              c.error && /* @__PURE__ */ jsx("p", { className: "text-xs text-destructive mt-1", children: c.error })
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-lg font-semibold tabular-nums shrink-0", children: c.count?.toLocaleString("pt-BR") ?? "—" })
          ] }, `${c.roomId}-${c.chatId}`)) }),
          visibleRecent.length > 0 && /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h3", { className: "text-sm font-medium mb-2", children: "Últimos eventos" }),
            /* @__PURE__ */ jsx("div", { className: "space-y-1", children: visibleRecent.slice(0, 8).map((e) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between py-1.5 text-xs border-b border-border last:border-0", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                e.event_type === "join" ? /* @__PURE__ */ jsx(UserPlus, { className: "size-3 text-emerald-500 shrink-0" }) : /* @__PURE__ */ jsx(UserMinus, { className: "size-3 text-rose-500 shrink-0" }),
                /* @__PURE__ */ jsxs("span", { className: "truncate", children: [
                  e.tg_first_name || e.tg_username || "Usuário",
                  " ",
                  /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: e.event_type === "join" ? "entrou em" : e.event_type === "kicked" ? "foi removido de" : "saiu de" }),
                  " ",
                  e.chat_title || e.chat_id
                ] })
              ] }),
              /* @__PURE__ */ jsx("span", { className: "text-muted-foreground tabular-nums shrink-0 ml-2", children: new Date(e.occurred_at).toLocaleString("pt-BR") })
            ] }, e.id)) })
          ] }),
          visibleChatActivity.length > 0 && /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-sm font-medium mb-2", children: [
              "Entradas e saídas ",
              tab === "group" ? "por grupo" : "por canal"
            ] }),
            /* @__PURE__ */ jsx("div", { className: "space-y-2", children: visibleChatActivity.map((c) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg bg-muted/50 gap-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate", children: c.chat_title || `Chat ${c.chat_id}` }),
                /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
                  "ID: ",
                  c.chat_id
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex gap-3 text-sm tabular-nums shrink-0", children: [
                /* @__PURE__ */ jsxs("span", { className: "text-emerald-500", children: [
                  "+",
                  c.joins
                ] }),
                /* @__PURE__ */ jsxs("span", { className: "text-rose-500", children: [
                  "-",
                  c.leaves
                ] }),
                /* @__PURE__ */ jsxs("span", { className: "font-semibold", children: [
                  "= ",
                  c.joins - c.leaves
                ] })
              ] })
            ] }, c.chat_id)) })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsx("h2", { className: "font-semibold", children: "Próximos agendamentos" }),
        /* @__PURE__ */ jsx(Link, { to: "/mensagens", className: "text-sm text-primary hover:underline", children: "Ver todos" })
      ] }),
      upcoming.data?.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "text-center py-10 text-muted-foreground text-sm", children: [
        /* @__PURE__ */ jsx(Sparkles, { className: "size-8 mx-auto mb-2 opacity-50" }),
        "Nenhum agendamento por enquanto."
      ] }) : /* @__PURE__ */ jsx("div", { className: "space-y-2", children: upcoming.data?.map((m) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between p-3 rounded-lg bg-muted/50", children: [
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate", children: (m.content ?? "🎬 Vídeo").slice(0, 80) }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: new Date(m.scheduled_at).toLocaleString("pt-BR") })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "text-xs px-2 py-1 rounded bg-primary/10 text-primary", children: m.status })
      ] }, m.id)) })
    ] })
  ] });
}
export {
  DashboardPage as component
};
