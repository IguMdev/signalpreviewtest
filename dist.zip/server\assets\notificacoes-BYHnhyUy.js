import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { R as subscribeToWebPush, B as Button, c as cn, u as useAuth, C as Card, O as CardHeader, Q as CardTitle, x as CardContent, L as Label, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, N as Switch, U as getPushSettings, V as updatePushSettings } from "./router-Cw6OHOsO.js";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import * as React from "react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { Loader2, BellOff, Bell, Circle } from "lucide-react";
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group";
import "@tanstack/react-router";
import "./client-bD0og8Nx.js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const VAPID_PUBLIC_KEY = "BFKqXc-W6UVwFY3jNiGBNf_SagKqravIWhOyVrgRNjWgVPjdvN9-Z-0TBf9fRuP9I7oBTaR_fSgVWxv0ciZ3YsI";
function WebPushButton() {
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(true);
  const subscribeFn = useServerFn(subscribeToWebPush);
  const isIOS = typeof window !== "undefined" && (/iPad|iPhone|iPod/.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isStandalone = typeof window !== "undefined" && (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone);
  useEffect(() => {
    if ("serviceWorker" in navigator && "PushManager" in window) {
      setIsSupported(true);
      checkSubscription();
    } else {
      setLoading(false);
    }
  }, []);
  async function checkSubscription() {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) {
        const subscription = await registration.pushManager.getSubscription();
        setIsSubscribed(!!subscription);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }
  function urlBase64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/\-/g, "+").replace(/_/g, "/");
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }
  async function handleSubscribe() {
    setLoading(true);
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        toast.error("Permissão de notificação negada.");
        setLoading(false);
        return;
      }
      const registration = await navigator.serviceWorker.register("/sw.js");
      await navigator.serviceWorker.ready;
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) {
        if (!VAPID_PUBLIC_KEY) ;
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
        });
      }
      await subscribeFn({ data: { subscription: subscription.toJSON() } });
      setIsSubscribed(true);
      toast.success("Notificações de vendas ativadas!");
      if (registration && registration.showNotification) {
        registration.showNotification("Telesignal", {
          body: "Teste: Sua notificação está configurada!",
          icon: "/favicon.png"
        });
      } else {
        new Notification("Telesignal", {
          body: "Teste: Sua notificação está configurada!",
          icon: "/favicon.png"
        });
      }
    } catch (error) {
      console.error("Error subscribing:", error);
      toast.error(`Erro ao ativar: ${error?.message || error}`);
    } finally {
      setLoading(false);
    }
  }
  async function handleUnsubscribe() {
    setLoading(true);
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) {
        const subscription = await registration.pushManager.getSubscription();
        if (subscription) {
          await subscription.unsubscribe();
        }
      }
      setIsSubscribed(false);
      toast.success("Notificações desativadas.");
    } catch (e) {
      console.error("Error unsubscribing:", e);
      toast.error("Erro ao desativar notificações.");
    } finally {
      setLoading(false);
    }
  }
  if (!isSupported) {
    if (isIOS && !isStandalone) {
      return /* @__PURE__ */ jsxs("div", { className: "text-sm text-zinc-400 bg-zinc-900/50 p-3 rounded-md border border-zinc-800", children: [
        /* @__PURE__ */ jsx("p", { className: "font-medium text-white mb-1", children: "Dica para iPhone (iOS):" }),
        "Para ativar as notificações push no seu iPhone, toque no botão ",
        /* @__PURE__ */ jsx("strong", { children: "Compartilhar" }),
        " do Safari e depois em ",
        /* @__PURE__ */ jsx("strong", { children: '"Adicionar à Tela de Início"' }),
        "."
      ] });
    }
    return /* @__PURE__ */ jsx(Button, { disabled: true, variant: "outline", children: "Notificações não suportadas neste navegador" });
  }
  return /* @__PURE__ */ jsxs(
    Button,
    {
      variant: isSubscribed ? "outline" : "default",
      onClick: isSubscribed ? handleUnsubscribe : handleSubscribe,
      disabled: loading,
      className: "flex items-center gap-2",
      children: [
        loading ? /* @__PURE__ */ jsx(Loader2, { className: "w-4 h-4 animate-spin" }) : isSubscribed ? /* @__PURE__ */ jsx(BellOff, { className: "w-4 h-4" }) : /* @__PURE__ */ jsx(Bell, { className: "w-4 h-4" }),
        isSubscribed ? "Desativar Notificações" : "Ativar Alertas de Venda (Push)"
      ]
    }
  );
}
const RadioGroup = React.forwardRef(({ className, ...props }, ref) => {
  return /* @__PURE__ */ jsx(RadioGroupPrimitive.Root, { className: cn("grid gap-2", className), ...props, ref });
});
RadioGroup.displayName = RadioGroupPrimitive.Root.displayName;
const RadioGroupItem = React.forwardRef(({ className, ...props }, ref) => {
  return /* @__PURE__ */ jsx(
    RadioGroupPrimitive.Item,
    {
      ref,
      className: cn(
        "aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx(RadioGroupPrimitive.Indicator, { className: "flex items-center justify-center", children: /* @__PURE__ */ jsx(Circle, { className: "h-3.5 w-3.5 fill-primary" }) })
    }
  );
});
RadioGroupItem.displayName = RadioGroupPrimitive.Item.displayName;
function NotificacoesPage() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const getSettingsFn = useServerFn(getPushSettings);
  const updateSettingsFn = useServerFn(updatePushSettings);
  const {
    data: settings,
    isLoading
  } = useQuery({
    queryKey: ["push_settings", user?.id],
    enabled: !!user,
    queryFn: () => getSettingsFn()
  });
  const [form, setForm] = useState({
    sales_pending: false,
    sales_approved: true,
    sale_value: "total",
    show_product: false,
    show_utm: false,
    show_dashboard: true,
    report_times: [],
    report_style: "profit"
  });
  useEffect(() => {
    if (settings) {
      setForm(settings);
    }
  }, [settings]);
  const updateMut = useMutation({
    mutationFn: async (newData) => {
      await updateSettingsFn({
        data: newData
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({
        queryKey: ["push_settings"]
      });
    },
    onError: (err) => {
      toast.error(err.message);
    }
  });
  const handleChange = (key, value) => {
    const newData = {
      ...form,
      [key]: value
    };
    setForm(newData);
    updateMut.mutate(newData);
  };
  const handleTimeToggle = (time, checked) => {
    const times = new Set(form.report_times);
    if (checked) times.add(time);
    else times.delete(time);
    handleChange("report_times", Array.from(times));
  };
  if (isLoading) return /* @__PURE__ */ jsx("div", { className: "p-4 text-muted-foreground", children: "Carregando configurações..." });
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2 mb-8", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold tracking-tight", children: "Notificações" }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground", children: "Configure as notificações de vendas e de relatório da sua conta." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "mb-6", children: /* @__PURE__ */ jsx(WebPushButton, {}) }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-8", children: [
      /* @__PURE__ */ jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxs(Card, { className: "glass border-border/50", children: [
        /* @__PURE__ */ jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsx(CardTitle, { children: "Notificações de Venda" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Seja notificado no app sempre que for realizada uma nova venda:" })
        ] }),
        /* @__PURE__ */ jsxs(CardContent, { className: "space-y-6", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-semibold text-lg", children: "Opções" }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Enviar vendas pendentes" }),
              /* @__PURE__ */ jsxs(Select, { value: form.sales_pending ? "enabled" : "disabled", onValueChange: (v) => handleChange("sales_pending", v === "enabled"), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50 border-border/50", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "enabled", children: "Habilitado" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "disabled", children: "Desabilitado" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Enviar vendas aprovadas" }),
              /* @__PURE__ */ jsxs(Select, { value: form.sales_approved ? "enabled" : "disabled", onValueChange: (v) => handleChange("sales_approved", v === "enabled"), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50 border-border/50", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "enabled", children: "Habilitado" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "disabled", children: "Desabilitado" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Valor da venda" }),
              /* @__PURE__ */ jsxs(Select, { value: form.sale_value, onValueChange: (v) => handleChange("sale_value", v), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50 border-border/50", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "total", children: "Total" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "hide", children: "Esconder" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Nome do produto" }),
              /* @__PURE__ */ jsxs(Select, { value: form.show_product ? "show" : "hide", onValueChange: (v) => handleChange("show_product", v === "show"), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50 border-border/50", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "show", children: "Mostrar" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "hide", children: "Esconder" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Valor de utm_campaign" }),
              /* @__PURE__ */ jsxs(Select, { value: form.show_utm ? "show" : "hide", onValueChange: (v) => handleChange("show_utm", v === "show"), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50 border-border/50", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "show", children: "Mostrar" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "hide", children: "Esconder" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Nome do dashboard" }),
              /* @__PURE__ */ jsxs(Select, { value: form.show_dashboard ? "show" : "hide", onValueChange: (v) => handleChange("show_dashboard", v === "show"), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50 border-border/50", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "show", children: "Mostrar" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "hide", children: "Esconder" })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "pt-4 space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsx("h3", { className: "font-semibold text-lg", children: "Prévia de Notificação" }),
              /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: async () => {
                try {
                  const res = await fetch("/api/public/wiven/webhook", {
                    method: "POST",
                    body: JSON.stringify({
                      action: "TEST_PUSH",
                      userId: user?.id
                    })
                  });
                  if (res.ok) toast.success("Notificação enviada! Olhe seu celular.");
                } catch (e) {
                  toast.error("Erro ao testar");
                }
              }, children: "Testar Notificação" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-zinc-950 p-4 rounded-xl border border-zinc-800 flex items-start gap-4 shadow-xl", children: [
              /* @__PURE__ */ jsx("div", { className: "shrink-0 size-10 bg-black rounded-lg border border-zinc-800 flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsx("img", { src: "/push-icon.jpg", alt: "logo", className: "w-full h-full object-cover" }) }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1 text-sm text-zinc-100", children: [
                /* @__PURE__ */ jsxs("p", { className: "font-semibold text-white text-base", children: [
                  "Venda aprovada! ",
                  form.show_dashboard && "| igu.ads"
                ] }),
                form.show_product && /* @__PURE__ */ jsx("p", { className: "text-zinc-300", children: "Nome do Produto Aqui" }),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-0.5 text-zinc-400", children: [
                  form.sale_value === "total" && /* @__PURE__ */ jsx("span", { children: "Valor: R$ 99,90" }),
                  form.show_utm && /* @__PURE__ */ jsx("span", { children: "UTM: nome_da_campanha" })
                ] })
              ] })
            ] })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "space-y-6", children: /* @__PURE__ */ jsxs(Card, { className: "glass border-border/50", children: [
        /* @__PURE__ */ jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsx(CardTitle, { children: "Notificações de Relatório" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Configure as notificações de relatório que quer visualizar:" })
        ] }),
        /* @__PURE__ */ jsxs(CardContent, { className: "space-y-6", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-semibold text-lg", children: "Horários" }),
          /* @__PURE__ */ jsx("div", { className: "space-y-4", children: ["08:00", "12:00", "18:00", "23:00"].map((time) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs(Label, { className: "text-base font-normal", children: [
              "Notificação das ",
              time
            ] }),
            /* @__PURE__ */ jsx(Switch, { checked: form.report_times.includes(time), onCheckedChange: (c) => handleTimeToggle(time, c) })
          ] }, time)) }),
          /* @__PURE__ */ jsxs("div", { className: "pt-4 space-y-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "font-semibold text-lg", children: "Padrão de Notificação" }),
            /* @__PURE__ */ jsx(RadioGroup, { value: form.report_style, onValueChange: (v) => handleChange("report_style", v), children: /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxs(Label, { className: "flex items-center gap-3 p-4 rounded-lg border border-border/50 bg-background/50 hover:bg-white/5 cursor-pointer transition", children: [
                /* @__PURE__ */ jsx(RadioGroupItem, { value: "profit" }),
                "Status de Lucro"
              ] }),
              /* @__PURE__ */ jsxs(Label, { className: "flex items-center gap-3 p-4 rounded-lg border border-border/50 bg-background/50 hover:bg-white/5 cursor-pointer transition", children: [
                /* @__PURE__ */ jsx(RadioGroupItem, { value: "summary" }),
                "Resumo Detalhado"
              ] }),
              /* @__PURE__ */ jsxs(Label, { className: "flex items-center gap-3 p-4 rounded-lg border border-primary/50 bg-primary/10 hover:bg-primary/20 cursor-pointer transition", children: [
                /* @__PURE__ */ jsx(RadioGroupItem, { value: "creative" }),
                "Notificações Criativas"
              ] })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "pt-4 space-y-4", children: [
            /* @__PURE__ */ jsx("h3", { className: "font-semibold text-lg", children: "Prévia de Notificação" }),
            /* @__PURE__ */ jsxs("div", { className: "bg-zinc-950 p-4 rounded-xl border border-zinc-800 flex items-start gap-4 shadow-xl", children: [
              /* @__PURE__ */ jsx("div", { className: "shrink-0 size-10 bg-black rounded-lg border border-zinc-800 flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsx("img", { src: "/push-icon.jpg", alt: "logo", className: "w-full h-full object-cover" }) }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1 text-sm text-zinc-100", children: [
                form.report_style === "creative" && /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-semibold text-white text-base", children: "Dois reais ou um lucro misterioso?" }),
                  /* @__PURE__ */ jsx("p", { className: "text-zinc-400", children: "Parabéns! Você teve R$ 149,43 de lucro até agora... 🤑" })
                ] }),
                form.report_style === "profit" && /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-semibold text-white text-base", children: "Status de Lucro Diário" }),
                  /* @__PURE__ */ jsx("p", { className: "text-zinc-400", children: "Você já lucrou R$ 149,43 hoje." })
                ] }),
                form.report_style === "summary" && /* @__PURE__ */ jsxs(Fragment, { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-semibold text-white text-base", children: "Resumo do dia" }),
                  /* @__PURE__ */ jsx("p", { className: "text-zinc-400", children: "Vendas: 12 | Lucro: R$ 149,43 | ROI: 45%" })
                ] })
              ] })
            ] })
          ] })
        ] })
      ] }) })
    ] })
  ] });
}
export {
  NotificacoesPage as component
};
