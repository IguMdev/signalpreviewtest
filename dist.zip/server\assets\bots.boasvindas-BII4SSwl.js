import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect, useRef } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { C as Card, O as CardHeader, Q as CardTitle, x as CardContent, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, N as Switch, L as Label, T as Textarea, I as Input, B as Button, l as getPremiumAccountAvatar } from "./router-Cw6OHOsO.js";
import { MessageCircle, ImageIcon, Plus, ArrowUp, ArrowDown, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { j as getWelcomeBotConfig, k as upsertWelcomeBotConfig } from "./engagement.functions-BnPQkoHV.js";
import { P as PremiumEmojiPicker } from "./PremiumEmojiPicker-KRfbHKuL.js";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "./client.server-CDheR9QG.js";
import "zod";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const SUPABASE_URL = "https://baemmrntfvoxtkttexyn.supabase.co";
function publicUrl(bucket, path) {
  return `${SUPABASE_URL.replace(/\/$/, "")}/storage/v1/object/public/${bucket}/${path}`;
}
function renderTemplate(tpl, vars) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? "");
}
function getInitials(name) {
  if (!name) return "?";
  return name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
}
function PremiumAccountIdentity({
  account,
  compact = false
}) {
  const avatarQ = useQuery({
    queryKey: ["premium-avatar", account.id],
    queryFn: () => getPremiumAccountAvatar({
      data: {
        accountId: account.id
      }
    }),
    enabled: Boolean(account?.id),
    staleTime: 1e3 * 60 * 60,
    refetchOnWindowFocus: false
  });
  const handle = account.bot_username ? `@${account.bot_username}` : account.phone || "";
  const avatarUrl = avatarQ.data?.dataUrl ?? null;
  const sizeClass = compact ? "w-7 h-7" : "w-8 h-8";
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1", children: [
    avatarUrl ? /* @__PURE__ */ jsx("img", { src: avatarUrl, alt: account.label, className: `${sizeClass} rounded-full object-cover border border-border/60 shrink-0` }) : /* @__PURE__ */ jsx("div", { className: `${sizeClass} rounded-full flex items-center justify-center bg-primary text-[10px] font-bold text-primary-foreground shrink-0`, title: account.label, children: getInitials(account.label) }),
    /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-muted-foreground", children: [
      "Conectada como ",
      /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: account.label }),
      handle ? ` (${handle})` : "",
      "."
    ] })
  ] });
}
function BoasVindasPage() {
  const qc = useQueryClient();
  const get = useServerFn(getWelcomeBotConfig);
  const upsert = useServerFn(upsertWelcomeBotConfig);
  const roomsQ = useQuery({
    queryKey: ["rooms-pick"],
    queryFn: async () => (await supabase.from("rooms").select("id, name, photo_url").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const videosQ = useQuery({
    queryKey: ["videos-pick"],
    queryFn: async () => (await supabase.from("videos").select("id, title, kind, storage_path").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const premiumAccountsQ = useQuery({
    queryKey: ["premium-accounts-pick"],
    queryFn: async () => (await supabase.from("telegram_accounts").select("id, label, status, bot_username, phone, bot_first_name, last_error").eq("account_type", "premium").eq("is_active", true).order("label")).data ?? []
  });
  const [roomId, setRoomId] = useState("");
  useEffect(() => {
    if (!roomId && roomsQ.data?.[0]?.id) setRoomId(roomsQ.data[0].id);
  }, [roomsQ.data, roomId]);
  const selectedRoom = (roomsQ.data ?? []).find((r) => r.id === roomId);
  const cfgQ = useQuery({
    queryKey: ["welcome-cfg", roomId],
    enabled: !!roomId,
    queryFn: () => get({
      data: {
        roomId
      }
    })
  });
  const [enabled, setEnabled] = useState(false);
  const [message, setMessage] = useState("Seja bem-vindo(a), {name}! 🎉");
  const [imagePath, setImagePath] = useState("");
  const [videoId, setVideoId] = useState("");
  const [premiumEnabled, setPremiumEnabled] = useState(false);
  const [premiumAccountId, setPremiumAccountId] = useState("");
  const [roomPhotoError, setRoomPhotoError] = useState(false);
  const messageRef = useRef(null);
  useEffect(() => {
    setRoomPhotoError(false);
  }, [roomId]);
  useEffect(() => {
    const c = cfgQ.data;
    if (!c) return;
    setEnabled(c.welcome_bot_enabled ?? false);
    setMessage(c.welcome_message ?? "Seja bem-vindo(a), {name}! 🎉");
    setImagePath(c.welcome_image_path ?? "");
    setVideoId(c.welcome_video_id ?? "");
    setPremiumEnabled(c.welcome_premium_enabled ?? false);
    setPremiumAccountId(c.welcome_premium_account_id ?? "");
  }, [cfgQ.data]);
  async function uploadImage(file) {
    const ext = file.name.split(".").pop() ?? "jpg";
    const path = `welcome/${roomId}/${Date.now()}.${ext}`;
    const {
      error
    } = await supabase.storage.from("room-images").upload(path, file, {
      upsert: true,
      contentType: file.type
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    setImagePath(path);
    toast.success("Imagem enviada");
  }
  const save = useMutation({
    mutationFn: () => upsert({
      data: {
        roomId,
        enabled,
        message: message || null,
        imagePath: imagePath || null,
        videoId: videoId || null,
        premiumEnabled,
        premiumAccountId: premiumAccountId || null
      }
    }),
    onSuccess: () => {
      toast.success("Salvo");
      qc.invalidateQueries({
        queryKey: ["welcome-cfg", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-3xl", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(MessageCircle, { className: "size-6 text-primary" }),
        " BotBoasVindas"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Mensagem automática para novos membros do seu grupo." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Sala" }) }),
      /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        selectedRoom?.photo_url && !roomPhotoError ? /* @__PURE__ */ jsx("img", { src: selectedRoom.photo_url, alt: selectedRoom.name, className: "size-14 rounded-md object-cover border border-border/60 shrink-0", onError: () => setRoomPhotoError(true) }) : /* @__PURE__ */ jsx("div", { className: "size-14 rounded-md border border-border/60 bg-muted shrink-0 flex items-center justify-center", children: /* @__PURE__ */ jsx(ImageIcon, { className: "size-6 text-muted-foreground" }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
          selectedRoom && /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate mb-1", children: selectedRoom.name }),
          /* @__PURE__ */ jsxs(Select, { value: roomId, onValueChange: setRoomId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione a sala" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: (roomsQ.data ?? []).map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] })
      ] }) })
    ] }),
    roomId && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center justify-between", children: [
        "Configuração",
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
          "Ativado ",
          /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: (v) => {
            setEnabled(v);
            upsert({
              data: {
                roomId,
                enabled: v,
                message: message || null,
                imagePath: imagePath || null,
                videoId: videoId || null,
                premiumEnabled,
                premiumAccountId: premiumAccountId || null
              }
            }).then(() => {
              toast.success(v ? "BotBoasVindas ativado" : "BotBoasVindas desativado");
              qc.invalidateQueries({
                queryKey: ["welcome-cfg", roomId]
              });
            }).catch((e) => {
              setEnabled(!v);
              toast.error(e.message);
            });
          } })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs(Label, { children: [
              "Mensagem (use ",
              /* @__PURE__ */ jsx("code", { children: "{name}" }),
              " para mencionar o membro)"
            ] }),
            /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: message, onChange: setMessage, targetRef: messageRef })
          ] }),
          /* @__PURE__ */ jsx(Textarea, { ref: messageRef, value: message, onChange: (e) => setMessage(e.target.value), rows: 5, maxLength: 4e3 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { children: "Imagem (opcional)" }),
          /* @__PURE__ */ jsx(Input, { type: "file", accept: "image/*", onChange: (e) => e.target.files?.[0] && uploadImage(e.target.files[0]) }),
          imagePath && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
            "Atual: ",
            imagePath,
            " ",
            /* @__PURE__ */ jsx("button", { onClick: () => setImagePath(""), className: "underline ml-2", children: "remover" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { children: "Vídeo (opcional, prioridade sobre imagem)" }),
          /* @__PURE__ */ jsxs(Select, { value: videoId || "none", onValueChange: (v) => setVideoId(v === "none" ? "" : v), children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Sem vídeo" }) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Sem vídeo" }),
              (videosQ.data ?? []).map((v) => /* @__PURE__ */ jsxs(SelectItem, { value: v.id, children: [
                v.title,
                " ",
                v.kind === "round" ? "(redondo)" : ""
              ] }, v.id))
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-border/60 p-3 space-y-3 bg-muted/20", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(Label, { className: "text-sm", children: "Enviar via conta Premium (emojis animados)" }),
              /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-muted-foreground", children: [
                "Necessário para que os emojis premium ",
                /* @__PURE__ */ jsx("code", { children: "{NOME}" }),
                " sejam renderizados."
              ] })
            ] }),
            /* @__PURE__ */ jsx(Switch, { checked: premiumEnabled, onCheckedChange: setPremiumEnabled })
          ] }),
          premiumEnabled && /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Conta Premium" }),
            /* @__PURE__ */ jsxs(Select, { value: premiumAccountId || "none", onValueChange: (v) => setPremiumAccountId(v === "none" ? "" : v), children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione uma conta premium" }) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Selecione..." }),
                (premiumAccountsQ.data ?? []).map((a) => {
                  const handle = a.bot_username ? `@${a.bot_username}` : a.phone || "";
                  return /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
                    a.label,
                    handle ? ` — ${handle}` : "",
                    a.status !== "ok" ? ` (${a.status})` : ""
                  ] }, a.id);
                })
              ] })
            ] }),
            premiumAccountId && (() => {
              const acc = (premiumAccountsQ.data ?? []).find((a) => a.id === premiumAccountId);
              return acc ? /* @__PURE__ */ jsx(PremiumAccountIdentity, { account: acc }) : null;
            })(),
            (premiumAccountsQ.data ?? []).length === 0 && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-amber-500", children: 'Nenhuma conta Premium conectada. Conecte uma em "Contas Telegram".' })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar" })
      ] })
    ] }),
    roomId && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Pré-visualização" }) }),
      /* @__PURE__ */ jsxs(CardContent, { children: [
        /* @__PURE__ */ jsxs("div", { className: "max-w-md rounded-2xl border border-border/60 bg-muted/30 p-3 space-y-2", children: [
          (() => {
            const selectedVideo = (videosQ.data ?? []).find((v) => v.id === videoId);
            if (selectedVideo?.storage_path) {
              const url = publicUrl("videos", selectedVideo.storage_path);
              return selectedVideo.kind === "round" ? /* @__PURE__ */ jsx("video", { src: url, controls: true, className: "size-48 rounded-full object-cover mx-auto" }) : /* @__PURE__ */ jsx("video", { src: url, controls: true, className: "w-full rounded-lg" });
            }
            if (imagePath) {
              return /* @__PURE__ */ jsx("img", { src: publicUrl("room-images", imagePath), alt: "prévia", className: "w-full rounded-lg" });
            }
            return null;
          })(),
          /* @__PURE__ */ jsx("div", { className: "text-sm whitespace-pre-wrap", dangerouslySetInnerHTML: {
            __html: renderTemplate(message || "", {
              name: '<a class="text-primary underline">Novo Membro</a>',
              first_name: "Novo Membro",
              username: "novomembro"
            })
          } })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-2", children: "Aproximação visual — o Telegram pode renderizar com pequenas diferenças." })
      ] })
    ] }),
    roomId && /* @__PURE__ */ jsx(ExtrasSection, { roomId, videos: videosQ.data ?? [], premiumAccounts: premiumAccountsQ.data ?? [] })
  ] });
}
function ExtrasSection({
  roomId,
  videos,
  premiumAccounts
}) {
  const qc = useQueryClient();
  const listQ = useQuery({
    queryKey: ["welcome-extras", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("welcome_extra_messages").select("*").eq("room_id", roomId).order("sort_order", {
        ascending: true
      });
      if (error) throw new Error(error.message);
      return data ?? [];
    }
  });
  async function addExtra() {
    const {
      data: u
    } = await supabase.auth.getUser();
    const userId = u.user?.id;
    if (!userId) return;
    const nextOrder = (listQ.data?.length ?? 0) + 1;
    const {
      error
    } = await supabase.from("welcome_extra_messages").insert({
      user_id: userId,
      room_id: roomId,
      sort_order: nextOrder,
      content: "",
      delay_seconds: 2,
      parse_mode: "HTML"
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    qc.invalidateQueries({
      queryKey: ["welcome-extras", roomId]
    });
  }
  async function removeExtra(id) {
    const {
      error
    } = await supabase.from("welcome_extra_messages").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    qc.invalidateQueries({
      queryKey: ["welcome-extras", roomId]
    });
  }
  async function move(id, dir) {
    const list = listQ.data ?? [];
    const idx = list.findIndex((r) => r.id === id);
    const swap = list[idx + dir];
    if (!swap) return;
    await supabase.from("welcome_extra_messages").update({
      sort_order: swap.sort_order
    }).eq("id", id);
    await supabase.from("welcome_extra_messages").update({
      sort_order: list[idx].sort_order
    }).eq("id", swap.id);
    qc.invalidateQueries({
      queryKey: ["welcome-extras", roomId]
    });
  }
  return /* @__PURE__ */ jsxs(Card, { children: [
    /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center justify-between", children: [
      "Sequência de mensagens",
      /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: addExtra, children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-1" }),
        " Adicionar mensagem"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs(CardContent, { className: "space-y-3", children: [
      (listQ.data ?? []).length === 0 && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: 'Nenhuma mensagem extra. A mensagem principal acima é enviada sozinha. Clique em "Adicionar mensagem" para criar uma sequência.' }),
      (listQ.data ?? []).map((row, i) => /* @__PURE__ */ jsx(ExtraEditor, { row, index: i, total: (listQ.data ?? []).length, videos, premiumAccounts, roomId, onChanged: () => qc.invalidateQueries({
        queryKey: ["welcome-extras", roomId]
      }), onRemove: () => removeExtra(row.id), onMoveUp: () => move(row.id, -1), onMoveDown: () => move(row.id, 1) }, row.id))
    ] })
  ] });
}
function ExtraEditor({
  // ╔════════════════════════════════════════════════════════╗
  // ║  EDITOR DE UMA MENSAGEM EXTRA                          ║
  // ╚════════════════════════════════════════════════════════╝
  row,
  index,
  total,
  videos,
  premiumAccounts,
  roomId,
  onChanged,
  onRemove,
  onMoveUp,
  onMoveDown
}) {
  const [content, setContent] = useState(row.content ?? "");
  const [imagePath, setImagePath] = useState(row.image_path ?? "");
  const [videoId, setVideoId] = useState(row.video_id ?? "");
  const [premiumEnabled, setPremiumEnabled] = useState(row.premium_enabled ?? false);
  const [premiumAccountId, setPremiumAccountId] = useState(row.premium_account_id ?? "");
  const [delay, setDelay] = useState(row.delay_seconds ?? 2);
  const [saving, setSaving] = useState(false);
  const contentRef = useRef(null);
  async function uploadImage(file) {
    const ext = file.name.split(".").pop() ?? "jpg";
    const path = `welcome/${roomId}/extra-${row.id}-${Date.now()}.${ext}`;
    const {
      error
    } = await supabase.storage.from("room-images").upload(path, file, {
      upsert: true,
      contentType: file.type
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    setImagePath(path);
    toast.success("Imagem enviada");
  }
  async function save() {
    setSaving(true);
    const {
      error
    } = await supabase.from("welcome_extra_messages").update({
      content: content || null,
      image_path: imagePath || null,
      video_id: videoId || null,
      premium_enabled: premiumEnabled,
      premium_account_id: premiumAccountId || null,
      delay_seconds: Math.max(0, Math.min(300, Number(delay) || 0))
    }).eq("id", row.id);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Salvo");
    onChanged();
  }
  return /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-border/60 p-3 space-y-3 bg-muted/20", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-sm font-semibold", children: [
        "Mensagem #",
        index + 2
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: onMoveUp, disabled: index === 0, children: /* @__PURE__ */ jsx(ArrowUp, { className: "size-4" }) }),
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: onMoveDown, disabled: index === total - 1, children: /* @__PURE__ */ jsx(ArrowDown, { className: "size-4" }) }),
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: onRemove, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[1fr_140px] gap-3 items-end", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(Label, { children: "Texto" }),
          /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: content, onChange: setContent, targetRef: contentRef })
        ] }),
        /* @__PURE__ */ jsx(Textarea, { ref: contentRef, value: content, onChange: (e) => setContent(e.target.value), rows: 3, maxLength: 4e3 })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { children: "Esperar (s)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 0, max: 300, value: delay, onChange: (e) => setDelay(Number(e.target.value)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { children: "Imagem (opcional)" }),
        /* @__PURE__ */ jsx(Input, { type: "file", accept: "image/*", onChange: (e) => e.target.files?.[0] && uploadImage(e.target.files[0]) }),
        imagePath && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground truncate", children: [
          imagePath,
          " ",
          /* @__PURE__ */ jsx("button", { onClick: () => setImagePath(""), className: "underline ml-2", children: "remover" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { children: "Vídeo (opcional)" }),
        /* @__PURE__ */ jsxs(Select, { value: videoId || "none", onValueChange: (v) => setVideoId(v === "none" ? "" : v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Sem vídeo" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Sem vídeo" }),
            videos.map((v) => /* @__PURE__ */ jsxs(SelectItem, { value: v.id, children: [
              v.title,
              " ",
              v.kind === "round" ? "(redondo)" : ""
            ] }, v.id))
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-border/60 p-3 space-y-3 bg-background/50", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-sm", children: "Enviar via conta Premium" }),
        /* @__PURE__ */ jsx(Switch, { checked: premiumEnabled, onCheckedChange: setPremiumEnabled })
      ] }),
      premiumEnabled && /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsxs(Select, { value: premiumAccountId || "none", onValueChange: (v) => setPremiumAccountId(v === "none" ? "" : v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione uma conta premium" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Selecione..." }),
            premiumAccounts.map((a) => {
              const handle = a.bot_username ? `@${a.bot_username}` : a.phone || "";
              return /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
                a.label,
                handle ? ` — ${handle}` : "",
                a.status !== "ok" ? ` (${a.status})` : ""
              ] }, a.id);
            })
          ] })
        ] }),
        premiumAccountId && (() => {
          const acc = premiumAccounts.find((a) => a.id === premiumAccountId);
          return acc ? /* @__PURE__ */ jsx(PremiumAccountIdentity, { account: acc, compact: true }) : null;
        })()
      ] })
    ] }),
    /* @__PURE__ */ jsx(Button, { size: "sm", onClick: save, disabled: saving, children: saving ? "Salvando..." : "Salvar mensagem" })
  ] });
}
export {
  BoasVindasPage as component
};
