import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const VERTICALS = ["bet", "igaming", "hot", "promo", "outro"];
const TRACKING_MODES = ["telegram", "direct_response"];
const EVENT_OPTIONS = ["off", "Lead", "CompleteRegistration", "Subscribe", "ViewContent", "Contact", "InitiateCheckout", "AddPaymentInfo", "AddToCart", "Purchase", "StartTrial"];
const drConfigSchema = z.object({
  enable_lead: z.boolean().default(false),
  enable_add_to_cart: z.boolean().default(false),
  enable_initiate_checkout: z.boolean().default(true),
  initiate_checkout_url_contains: z.string().default(""),
  purchase_approval_only: z.boolean().default(true),
  purchase_value_mode: z.string().default("Valor da venda"),
  purchase_product: z.string().default("Qualquer"),
  ipv6_enabled: z.boolean().default(true)
});
const pixelSchema = z.object({
  name: z.string().min(1).max(120),
  vertical: z.enum(VERTICALS).default("outro"),
  tracking_mode: z.enum(TRACKING_MODES).default("telegram"),
  sales_page_url: z.string().url().nullable().optional(),
  is_active: z.boolean().default(true),
  meta_integration_id: z.string().uuid().nullable().optional(),
  account_id: z.string().uuid().nullable().optional(),
  room_id: z.string().uuid().nullable().optional(),
  event_on_join: z.enum(EVENT_OPTIONS).default("Lead"),
  event_on_offer_click: z.enum(EVENT_OPTIONS).default("InitiateCheckout"),
  event_on_register: z.enum(EVENT_OPTIONS).default("CompleteRegistration"),
  event_on_deposit: z.enum(EVENT_OPTIONS).default("Purchase"),
  event_on_view: z.enum(EVENT_OPTIONS).default("ViewContent"),
  event_on_lead: z.enum(EVENT_OPTIONS).default("Lead"),
  event_on_checkout: z.enum(EVENT_OPTIONS).default("InitiateCheckout"),
  event_on_payment_info: z.enum(EVENT_OPTIONS).default("AddPaymentInfo"),
  event_on_purchase: z.enum(EVENT_OPTIONS).default("Purchase"),
  meta_pixel_id: z.string().trim().max(64).nullable().optional(),
  meta_access_token: z.string().trim().max(1024).nullable().optional(),
  meta_test_event_code: z.string().trim().max(64).nullable().optional(),
  dr_config: drConfigSchema.default({})
});
const listPixels_createServerFn_handler = createServerRpc({
  id: "9a10855ec68031a68272278346d1dff6878e9ca23aca2143f5361ed6e1999988",
  name: "listPixels",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listPixels.__executeServer(opts));
const listPixels = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listPixels_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("tracking_pixels").select("*").order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const getPixel_createServerFn_handler = createServerRpc({
  id: "0dcec4b9cde2b59d27fa7c851f4731b8ee539ee35173ba2dac5b7d4360ab1781",
  name: "getPixel",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => getPixel.__executeServer(opts));
const getPixel = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(getPixel_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: pixel,
    error
  } = await supabase.from("tracking_pixels").select("*").eq("id", data.id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!pixel) throw new Error("Pixel não encontrado");
  return pixel;
});
const createPixel_createServerFn_handler = createServerRpc({
  id: "c74905e5b6be9caaa44375d7a8476db9001866bf833e9ddf2bf6af80ff10fee1",
  name: "createPixel",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => createPixel.__executeServer(opts));
const createPixel = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => pixelSchema.parse(d)).handler(createPixel_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  let botUsername = null;
  if (data.account_id) {
    const {
      data: acc
    } = await supabase.from("telegram_accounts").select("bot_username").eq("id", data.account_id).maybeSingle();
    botUsername = acc?.bot_username ?? null;
  }
  const {
    data: inserted,
    error
  } = await supabase.from("tracking_pixels").insert({
    ...data,
    user_id: userId,
    bot_username: botUsername
  }).select().single();
  if (error) throw new Error(error.message);
  return inserted;
});
const updatePixel_createServerFn_handler = createServerRpc({
  id: "0de27157edb1f132e151a83c8f9e064786d2d19283a3cc6231c0c188e7b6e136",
  name: "updatePixel",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => updatePixel.__executeServer(opts));
const updatePixel = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => pixelSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(updatePixel_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    id,
    ...rest
  } = data;
  let botUsername = void 0;
  if (rest.account_id) {
    const {
      data: acc
    } = await supabase.from("telegram_accounts").select("bot_username").eq("id", rest.account_id).maybeSingle();
    botUsername = acc?.bot_username ?? void 0;
  }
  const update = {
    ...rest
  };
  if (botUsername !== void 0) update.bot_username = botUsername;
  const {
    error
  } = await supabase.from("tracking_pixels").update(update).eq("id", id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const deletePixel_createServerFn_handler = createServerRpc({
  id: "bb80e000109e2704a88d684dd91dc5b6552d35f5daa1afeeaf70542335e38d5d",
  name: "deletePixel",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => deletePixel.__executeServer(opts));
const deletePixel = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deletePixel_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    error
  } = await supabase.from("tracking_pixels").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const offerSchema = z.object({
  pixel_id: z.string().uuid(),
  slug: z.string().min(1).max(60).regex(/^[a-z0-9_-]+$/, "Use apenas letras minúsculas, números, _ e -"),
  name: z.string().min(1).max(120),
  destination_url: z.string().url(),
  subid_param: z.string().min(1).max(30).default("sub1"),
  default_event: z.enum(EVENT_OPTIONS).default("InitiateCheckout"),
  default_value: z.number().nullable().optional(),
  default_currency: z.string().min(3).max(3).default("BRL")
});
const listOffers_createServerFn_handler = createServerRpc({
  id: "27c7594de8b00f91bee8593f78ef8045b23a3ca9be78fd7ab18928b268712a7a",
  name: "listOffers",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listOffers.__executeServer(opts));
const listOffers = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid()
}).parse(d)).handler(listOffers_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: rows,
    error
  } = await supabase.from("tracking_offers").select("*").eq("pixel_id", data.pixel_id).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return rows ?? [];
});
const createOffer_createServerFn_handler = createServerRpc({
  id: "31ca301441616645f30db96bc49571b709b78a2d22f922a9a2f65e504988b205",
  name: "createOffer",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => createOffer.__executeServer(opts));
const createOffer = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => offerSchema.parse(d)).handler(createOffer_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: inserted,
    error
  } = await supabase.from("tracking_offers").insert({
    ...data,
    user_id: userId
  }).select().single();
  if (error) throw new Error(error.message);
  return inserted;
});
const updateOffer_createServerFn_handler = createServerRpc({
  id: "8dd1db2506dfb0ca23b3f6ffc3014b58a2cfa90d8a8707946b766d28211f787a",
  name: "updateOffer",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => updateOffer.__executeServer(opts));
const updateOffer = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => offerSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(updateOffer_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    id,
    ...rest
  } = data;
  const {
    error
  } = await supabase.from("tracking_offers").update(rest).eq("id", id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const deleteOffer_createServerFn_handler = createServerRpc({
  id: "137608e79fc828d8251f37acb791d6e58da349bffd7f102fbfd6c1a1e868803f",
  name: "deleteOffer",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => deleteOffer.__executeServer(opts));
const deleteOffer = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteOffer_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    error
  } = await supabase.from("tracking_offers").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listRecentClicks_createServerFn_handler = createServerRpc({
  id: "603a464eb3d9ed9a9091fb89c5ee43d6f317bd408dafcc7b41007fb386c6f1cc",
  name: "listRecentClicks",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listRecentClicks.__executeServer(opts));
const listRecentClicks = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  limit: z.number().min(1).max(500).default(100)
}).parse(d)).handler(listRecentClicks_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: rows,
    error
  } = await supabase.from("tracking_clicks").select("click_id, created_at, utm_source, utm_medium, utm_campaign, utm_content, utm_term, fbclid, ttclid, gclid, ip, joined_at, clicked_offer_at, registered_at, deposited_at, tg_username, tg_user_id, sale_value, sale_currency, viewed_at, lead_at, checkout_at, payment_info_at, purchased_at, abandoned_cart_at, chargeback_at, refunded_at").eq("pixel_id", data.pixel_id).order("created_at", {
    ascending: false
  }).limit(data.limit);
  if (error) throw new Error(error.message);
  return rows ?? [];
});
const listClicksFiltered_createServerFn_handler = createServerRpc({
  id: "4a80c7840c491ab9f8012a891470726e98f09f087a859a194d0f9959ce1157ad",
  name: "listClicksFiltered",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listClicksFiltered.__executeServer(opts));
const listClicksFiltered = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  from: z.string().datetime().nullable().optional(),
  to: z.string().datetime().nullable().optional(),
  event: z.enum(["any", "click", "join", "offer_click", "register", "deposit"]).default("any"),
  limit: z.number().min(1).max(5e3).default(500)
}).parse(d)).handler(listClicksFiltered_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  let q = supabase.from("tracking_clicks").select("click_id, created_at, utm_source, utm_medium, utm_campaign, utm_content, utm_term, fbclid, ttclid, gclid, ip, joined_at, clicked_offer_at, registered_at, deposited_at, tg_username, tg_user_id, sale_value, sale_currency, external_user_id, viewed_at, lead_at, checkout_at, payment_info_at, purchased_at, abandoned_cart_at, chargeback_at, refunded_at").eq("pixel_id", data.pixel_id).order("created_at", {
    ascending: false
  }).limit(data.limit);
  if (data.from) q = q.gte("created_at", data.from);
  if (data.to) q = q.lte("created_at", data.to);
  if (data.event === "join") q = q.not("joined_at", "is", null);
  else if (data.event === "offer_click") q = q.not("clicked_offer_at", "is", null);
  else if (data.event === "register") q = q.not("registered_at", "is", null);
  else if (data.event === "deposit") q = q.not("deposited_at", "is", null);
  const {
    data: rows,
    error
  } = await q;
  if (error) throw new Error(error.message);
  return rows ?? [];
});
const getPixelStats_createServerFn_handler = createServerRpc({
  id: "fada98e77b81fcc3e7bcc077f7cccb4c683a7c4e420844d4d01829e14763ad18",
  name: "getPixelStats",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => getPixelStats.__executeServer(opts));
const getPixelStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  days: z.number().min(1).max(365).default(30)
}).parse(d)).handler(getPixelStats_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: pixel
  } = await supabase.from("tracking_pixels").select("id").eq("id", data.pixel_id).maybeSingle();
  if (!pixel) throw new Error("Pixel não encontrado");
  const from = new Date(Date.now() - data.days * 864e5).toISOString();
  const {
    data: rows,
    error
  } = await supabaseAdmin.from("tracking_clicks").select("created_at, joined_at, clicked_offer_at, registered_at, deposited_at, viewed_at, lead_at, checkout_at, payment_info_at, purchased_at, abandoned_cart_at, chargeback_at, refunded_at, sale_value").eq("pixel_id", data.pixel_id).eq("user_id", userId).gte("created_at", from);
  if (error) throw new Error(error.message);
  const clicks = rows?.length ?? 0;
  let joins = 0, offerClicks = 0, registers = 0, deposits = 0, revenue = 0;
  let views = 0, leads = 0, checkouts = 0, paymentInfos = 0, purchases = 0;
  let abandonedCarts = 0, chargebacks = 0, refunds = 0;
  for (const r of rows ?? []) {
    if (r.joined_at) joins++;
    if (r.clicked_offer_at) offerClicks++;
    if (r.registered_at) registers++;
    if (r.deposited_at) deposits++;
    if (r.viewed_at) views++;
    if (r.lead_at) leads++;
    if (r.checkout_at) checkouts++;
    if (r.payment_info_at) paymentInfos++;
    if (r.purchased_at) purchases++;
    if (r.abandoned_cart_at) abandonedCarts++;
    if (r.chargeback_at) chargebacks++;
    if (r.refunded_at) refunds++;
    if (r.sale_value && !r.refunded_at && !r.chargeback_at) revenue += Number(r.sale_value);
  }
  const byDay = /* @__PURE__ */ new Map();
  for (const r of rows ?? []) {
    const day = r.created_at.slice(0, 10);
    const cur = byDay.get(day) ?? {
      clicks: 0,
      joins: 0,
      registers: 0,
      deposits: 0
    };
    cur.clicks++;
    if (r.joined_at) cur.joins++;
    if (r.registered_at) cur.registers++;
    if (r.deposited_at) cur.deposits++;
    byDay.set(day, cur);
  }
  const series = Array.from(byDay.entries()).sort((a, b) => a[0].localeCompare(b[0])).map(([day, v]) => ({
    day,
    ...v
  }));
  return {
    clicks,
    joins,
    offerClicks,
    registers,
    deposits,
    views,
    leads,
    checkouts,
    paymentInfos,
    purchases,
    abandonedCarts,
    chargebacks,
    refunds,
    revenue,
    series
  };
});
const getAttribution_createServerFn_handler = createServerRpc({
  id: "0cddd13570369a4ad87bb38fee349e91178aa4866dbce9ce78820cc23bf59712",
  name: "getAttribution",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => getAttribution.__executeServer(opts));
const getAttribution = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid(),
  group_col: z.enum(["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"]),
  days: z.number().min(1).max(365).default(30)
}).parse(d)).handler(getAttribution_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: pixel
  } = await supabase.from("tracking_pixels").select("id").eq("id", data.pixel_id).maybeSingle();
  if (!pixel) throw new Error("Pixel não encontrado");
  const from = new Date(Date.now() - data.days * 864e5).toISOString();
  const {
    data: rows,
    error
  } = await supabaseAdmin.from("tracking_clicks").select(`${data.group_col}, joined_at, clicked_offer_at, registered_at, deposited_at, sale_value`).eq("pixel_id", data.pixel_id).eq("user_id", userId).gte("created_at", from);
  if (error) throw new Error(error.message);
  const agg = /* @__PURE__ */ new Map();
  for (const r of rows ?? []) {
    const key = r[data.group_col] ?? "(sem valor)";
    const cur = agg.get(key) ?? {
      dimension: key,
      clicks: 0,
      joins: 0,
      offer_clicks: 0,
      registers: 0,
      deposits: 0,
      revenue: 0
    };
    cur.clicks++;
    if (r.joined_at) cur.joins++;
    if (r.clicked_offer_at) cur.offer_clicks++;
    if (r.registered_at) cur.registers++;
    if (r.deposited_at) cur.deposits++;
    if (r.sale_value) cur.revenue += Number(r.sale_value);
    agg.set(key, cur);
  }
  return Array.from(agg.values()).sort((a, b) => b.clicks - a.clicks).slice(0, 200);
});
const domainRegex = /^(?!-)[a-z0-9-]+(\.[a-z0-9-]+)+$/i;
const listDomains_createServerFn_handler = createServerRpc({
  id: "ec3e4aab6fa1fda6669b11ce64bbd0f5feb1c8cab1eb3e008af7cdfa1a10b665",
  name: "listDomains",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listDomains.__executeServer(opts));
const listDomains = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listDomains_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("tracking_domains").select("*").order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const createDomain_createServerFn_handler = createServerRpc({
  id: "7e93f0071e8d14bade8182e0ac6c981e6975479a2830d19f553fc947bd2066fd",
  name: "createDomain",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => createDomain.__executeServer(opts));
const createDomain = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  domain: z.string().min(3).max(253).regex(domainRegex, "Domínio inválido")
}).parse(d)).handler(createDomain_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const domain = data.domain.toLowerCase().trim();
  const {
    data: inserted,
    error
  } = await supabase.from("tracking_domains").insert({
    user_id: userId,
    domain
  }).select().single();
  if (error) throw new Error(error.message);
  return inserted;
});
const deleteDomain_createServerFn_handler = createServerRpc({
  id: "08b0290c79c5eed474def48c5d28ed3e6576e135bb3939fba22331814f266393",
  name: "deleteDomain",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => deleteDomain.__executeServer(opts));
const deleteDomain = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteDomain_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    error
  } = await supabase.from("tracking_domains").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const verifyDomain_createServerFn_handler = createServerRpc({
  id: "405119693096c8c51536e705666171437c26673d31d457b94f3269e876607e03",
  name: "verifyDomain",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => verifyDomain.__executeServer(opts));
const verifyDomain = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(verifyDomain_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: dom
  } = await supabase.from("tracking_domains").select("*").eq("id", data.id).maybeSingle();
  if (!dom) throw new Error("Domínio não encontrado");
  const d = dom;
  const dns = await import("dns/promises");
  const recordName = `_signal.${d.domain}`;
  let txtRecords = [];
  try {
    txtRecords = await dns.resolveTxt(recordName);
  } catch (e) {
    throw new Error(`Falha ao consultar DNS (${recordName}). O registro TXT ainda pode não ter propagado.`);
  }
  const flat = txtRecords.flat().map((s) => s.trim());
  const expected = `signal_verify=${d.verification_token}`;
  if (!flat.includes(expected)) {
    throw new Error(`Registro TXT não encontrado. Esperado: ${expected}`);
  }
  await supabase.from("tracking_domains").update({
    verified_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", data.id);
  return {
    ok: true
  };
});
const getMyRedirectBase_createServerFn_handler = createServerRpc({
  id: "ffbaafa2e4a8c30c2601b49c918a3eeafc5590146bc4893f15f21552caf35ebe",
  name: "getMyRedirectBase",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => getMyRedirectBase.__executeServer(opts));
const getMyRedirectBase = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMyRedirectBase_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data
  } = await supabase.from("tracking_domains").select("domain, verified_at, is_active").not("verified_at", "is", null).eq("is_active", true).order("created_at", {
    ascending: true
  }).limit(1).maybeSingle();
  const d = data;
  return {
    domain: d?.domain ?? null
  };
});
const POSTBACK_EVENTS = [
  // Telegram
  "viewpage",
  "click_button",
  "channel_enter",
  "channel_leave",
  // Direct Response
  "lead",
  "checkout_started",
  "payment_info",
  "purchase"
];
const postbackSchema = z.object({
  pixel_id: z.string().uuid(),
  name: z.string().min(1).max(120),
  url: z.string().url().max(2e3),
  event: z.enum(POSTBACK_EVENTS),
  is_active: z.boolean().default(true)
});
const listPostbacks_createServerFn_handler = createServerRpc({
  id: "f1fe9cee74edca82ab25a8005f4facdae55424220808b4503441a76c54d67e02",
  name: "listPostbacks",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listPostbacks.__executeServer(opts));
const listPostbacks = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixel_id: z.string().uuid()
}).parse(d)).handler(listPostbacks_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: rows,
    error
  } = await supabase.from("tracking_postbacks").select("*").eq("pixel_id", data.pixel_id).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return rows ?? [];
});
const createPostback_createServerFn_handler = createServerRpc({
  id: "46c276df3aeb65f0b673ec795ecc36d785b430d4a34a595baa239369d56fa9f2",
  name: "createPostback",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => createPostback.__executeServer(opts));
const createPostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => postbackSchema.parse(d)).handler(createPostback_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: inserted,
    error
  } = await supabase.from("tracking_postbacks").insert({
    ...data,
    user_id: userId
  }).select().single();
  if (error) throw new Error(error.message);
  return inserted;
});
const updatePostback_createServerFn_handler = createServerRpc({
  id: "da255167f1cbb9205d568a80e1f0cc3b4c294b5c10a06c6b31d226ed0e08ce5b",
  name: "updatePostback",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => updatePostback.__executeServer(opts));
const updatePostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => postbackSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(updatePostback_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    id,
    ...rest
  } = data;
  const {
    error
  } = await supabase.from("tracking_postbacks").update(rest).eq("id", id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const deletePostback_createServerFn_handler = createServerRpc({
  id: "1b1724c9b582de6a00b91d2a46dbe6e6c66f53457d67f41bf7749d6936489a70",
  name: "deletePostback",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => deletePostback.__executeServer(opts));
const deletePostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deletePostback_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    error
  } = await supabase.from("tracking_postbacks").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const testPostback_createServerFn_handler = createServerRpc({
  id: "af30abf22edeebe07aa538f2da264e02c7cadf4db801c8ade00fef1443da9e31",
  name: "testPostback",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => testPostback.__executeServer(opts));
const testPostback = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  url: z.string().url()
}).parse(d)).handler(testPostback_createServerFn_handler, async ({
  data
}) => {
  try {
    const res = await fetch(data.url, {
      method: "GET"
    });
    return {
      ok: res.ok,
      status: res.status
    };
  } catch (e) {
    return {
      ok: false,
      status: 0,
      error: e?.message ?? "Falha de rede"
    };
  }
});
const INTEGRATION_EVENT_TYPES = ["register", "ftd", "deposit", "custom"];
const integrationSchema = z.object({
  pixel_id: z.string().uuid(),
  name: z.string().min(1).max(120),
  event_type: z.enum(INTEGRATION_EVENT_TYPES),
  custom_event_name: z.string().max(60).nullable().optional(),
  redirect_url: z.string().url(),
  meta_custom_event: z.string().max(60).nullable().optional(),
  meta_value: z.number().nullable().optional(),
  meta_currency: z.string().min(3).max(3).default("BRL"),
  is_active: z.boolean().default(true)
});
const listIntegrations_createServerFn_handler = createServerRpc({
  id: "012931baad73d5749e90b854282885cfc580ade3f7d0d9ed951ef097e3bb934c",
  name: "listIntegrations",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => listIntegrations.__executeServer(opts));
const listIntegrations = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listIntegrations_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("tracking_integrations").select("*").order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const createIntegration_createServerFn_handler = createServerRpc({
  id: "b2e722c57872a7c358fe30a5ae8d88af9b2c420396c4db28f9c7e2c075eb2cb8",
  name: "createIntegration",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => createIntegration.__executeServer(opts));
const createIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => integrationSchema.parse(d)).handler(createIntegration_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: inserted,
    error
  } = await supabase.from("tracking_integrations").insert({
    ...data,
    user_id: userId
  }).select().single();
  if (error) throw new Error(error.message);
  return inserted;
});
const updateIntegration_createServerFn_handler = createServerRpc({
  id: "6f5c39bb1cba1c244d4a224e6b64556531006e5dae4abd55b0ceff0885511e44",
  name: "updateIntegration",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => updateIntegration.__executeServer(opts));
const updateIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => integrationSchema.partial().extend({
  id: z.string().uuid()
}).parse(d)).handler(updateIntegration_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    id,
    ...rest
  } = data;
  const {
    error
  } = await supabase.from("tracking_integrations").update(rest).eq("id", id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const deleteIntegration_createServerFn_handler = createServerRpc({
  id: "759cfed5600289cb15ac7c5dc2cdb7f9bef1fa57643dd610c0ac37a74747be74",
  name: "deleteIntegration",
  filename: "src/lib/tracking.functions.ts"
}, (opts) => deleteIntegration.__executeServer(opts));
const deleteIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteIntegration_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    error
  } = await supabase.from("tracking_integrations").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
export {
  createDomain_createServerFn_handler,
  createIntegration_createServerFn_handler,
  createOffer_createServerFn_handler,
  createPixel_createServerFn_handler,
  createPostback_createServerFn_handler,
  deleteDomain_createServerFn_handler,
  deleteIntegration_createServerFn_handler,
  deleteOffer_createServerFn_handler,
  deletePixel_createServerFn_handler,
  deletePostback_createServerFn_handler,
  getAttribution_createServerFn_handler,
  getMyRedirectBase_createServerFn_handler,
  getPixelStats_createServerFn_handler,
  getPixel_createServerFn_handler,
  listClicksFiltered_createServerFn_handler,
  listDomains_createServerFn_handler,
  listIntegrations_createServerFn_handler,
  listOffers_createServerFn_handler,
  listPixels_createServerFn_handler,
  listPostbacks_createServerFn_handler,
  listRecentClicks_createServerFn_handler,
  testPostback_createServerFn_handler,
  updateIntegration_createServerFn_handler,
  updateOffer_createServerFn_handler,
  updatePixel_createServerFn_handler,
  updatePostback_createServerFn_handler,
  verifyDomain_createServerFn_handler
};
