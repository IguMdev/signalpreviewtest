import { w } from "./assets/worker-entry-BZgWNXsH.js";
import "node:events";
export {
  w as default
};
