import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const subscribeToWebPush_createServerFn_handler = createServerRpc({
  id: "b0779274d026cee49e2f496b1308fdf4f5f1f3e5de91278300acb1c16518c541",
  name: "subscribeToWebPush",
  filename: "src/lib/webpush.server.ts"
}, (opts) => subscribeToWebPush.__executeServer(opts));
const subscribeToWebPush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  subscription: z.any()
}).parse(d)).handler(subscribeToWebPush_createServerFn_handler, async (ctx) => {
  const {
    supabase,
    userId
  } = ctx.context;
  const {
    error
  } = await supabaseAdmin.auth.admin.updateUserById(userId, {
    user_metadata: {
      push_subscription: ctx.data.subscription
    }
  });
  if (error) {
    console.error("Erro ao salvar push_subscription:", error);
    throw new Error("Erro ao salvar inscrição");
  }
  return {
    success: true
  };
});
const PushSettingsSchema = z.object({
  sales_pending: z.boolean().default(false),
  sales_approved: z.boolean().default(true),
  sale_value: z.enum(["total", "hide"]).default("total"),
  show_product: z.boolean().default(false),
  show_utm: z.boolean().default(false),
  show_dashboard: z.boolean().default(true),
  report_times: z.array(z.string()).default([]),
  report_style: z.enum(["profit", "summary", "creative"]).default("profit")
});
const getPushSettings_createServerFn_handler = createServerRpc({
  id: "9466a54ef971f4cd6a7a1443d5910ac11966795d1365e65adb861340118e6607",
  name: "getPushSettings",
  filename: "src/lib/webpush.server.ts"
}, (opts) => getPushSettings.__executeServer(opts));
const getPushSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getPushSettings_createServerFn_handler, async (ctx) => {
  const {
    userId
  } = ctx.context;
  const {
    data,
    error
  } = await supabaseAdmin.auth.admin.getUserById(userId);
  if (error || !data.user) throw new Error("Usuário não encontrado");
  const rawSettings = data.user.user_metadata?.push_settings || {};
  return PushSettingsSchema.parse(rawSettings);
});
const updatePushSettings_createServerFn_handler = createServerRpc({
  id: "21a2bd418abda5888124a9b90fafe712ec4ba263111a97f33cb800fa1e0c3392",
  name: "updatePushSettings",
  filename: "src/lib/webpush.server.ts"
}, (opts) => updatePushSettings.__executeServer(opts));
const updatePushSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => PushSettingsSchema.parse(d)).handler(updatePushSettings_createServerFn_handler, async (ctx) => {
  const {
    userId
  } = ctx.context;
  const {
    error
  } = await supabaseAdmin.auth.admin.updateUserById(userId, {
    user_metadata: {
      push_settings: ctx.data
    }
  });
  if (error) {
    console.error("Erro ao salvar push_settings:", error);
    throw new Error("Erro ao salvar configurações");
  }
  return {
    success: true
  };
});
export {
  getPushSettings_createServerFn_handler,
  subscribeToWebPush_createServerFn_handler,
  updatePushSettings_createServerFn_handler
};
