import { AsyncLocalStorage } from "node:async_hooks";
import { H3Event, toResponse } from "h3-v2";
import { rootRouteId, parseRedirect, isRedirect, defaultSerovalPlugins, makeSerovalPlugin, createRawStreamRPCPlugin, invariant, isNotFound, resolveManifestAssetLink, createSerializationAdapter, isResolvedRedirect, executeRewriteInput } from "@tanstack/router-core";
import { toCrossJSONStream, fromJSON, toCrossJSONAsync } from "seroval";
import { createMemoryHistory } from "@tanstack/history";
import { mergeHeaders } from "@tanstack/router-core/ssr/client";
import { getNormalizedURL, getOrigin, attachRouterServerSsrUtils } from "@tanstack/router-core/ssr/server";
import "react";
import { RouterProvider } from "@tanstack/react-router";
import { jsx } from "react/jsx-runtime";
import { defineHandlerCallback, renderRouterToStream } from "@tanstack/react-router/ssr/server";
function StartServer(props) {
  return /* @__PURE__ */ jsx(RouterProvider, { router: props.router });
}
var defaultStreamHandler = defineHandlerCallback(({ request, router, responseHeaders }) => renderRouterToStream({
  request,
  router,
  responseHeaders,
  children: /* @__PURE__ */ jsx(StartServer, { router })
}));
var GLOBAL_EVENT_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:event-storage");
var globalObj$1 = globalThis;
if (!globalObj$1[GLOBAL_EVENT_STORAGE_KEY]) globalObj$1[GLOBAL_EVENT_STORAGE_KEY] = new AsyncLocalStorage();
var eventStorage = globalObj$1[GLOBAL_EVENT_STORAGE_KEY];
function isPromiseLike(value) {
  return typeof value.then === "function";
}
function getSetCookieValues(headers) {
  const headersWithSetCookie = headers;
  if (typeof headersWithSetCookie.getSetCookie === "function") return headersWithSetCookie.getSetCookie();
  const value = headers.get("set-cookie");
  return value ? [value] : [];
}
function mergeEventResponseHeaders(response, event) {
  if (response.ok) return;
  const eventSetCookies = getSetCookieValues(event.res.headers);
  if (eventSetCookies.length === 0) return;
  const responseSetCookies = getSetCookieValues(response.headers);
  response.headers.delete("set-cookie");
  for (const cookie of responseSetCookies) response.headers.append("set-cookie", cookie);
  for (const cookie of eventSetCookies) response.headers.append("set-cookie", cookie);
}
function attachResponseHeaders(value, event) {
  if (isPromiseLike(value)) return value.then((resolved) => {
    if (resolved instanceof Response) mergeEventResponseHeaders(resolved, event);
    return resolved;
  });
  if (value instanceof Response) mergeEventResponseHeaders(value, event);
  return value;
}
function requestHandler(handler) {
  return (request, requestOpts) => {
    let h3Event;
    try {
      h3Event = new H3Event(request);
    } catch (error) {
      if (error instanceof URIError) return new Response(null, {
        status: 400,
        statusText: "Bad Request"
      });
      throw error;
    }
    return toResponse(attachResponseHeaders(eventStorage.run({ h3Event }, () => handler(request, requestOpts)), h3Event), h3Event);
  };
}
function getH3Event() {
  const event = eventStorage.getStore();
  if (!event) throw new Error(`No StartEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`);
  return event.h3Event;
}
function getRequest() {
  return getH3Event().req;
}
function getResponse() {
  return getH3Event().res;
}
var HEADERS = { TSS_SHELL: "X-TSS_SHELL" };
async function getStartManifest(matchedRoutes) {
  const { tsrStartManifest } = await import("./_tanstack-start-manifest_v-FsPV_q3m.js");
  const startManifest = tsrStartManifest();
  const rootRoute = startManifest.routes[rootRouteId] = startManifest.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  let injectedHeadScripts;
  return {
    manifest: {
      inlineCss: startManifest.inlineCss,
      routes: Object.fromEntries(Object.entries(startManifest.routes).flatMap(([k, v]) => {
        const result = {};
        let hasData = false;
        if (v.preloads && v.preloads.length > 0) {
          result["preloads"] = v.preloads;
          hasData = true;
        }
        if (v.assets && v.assets.length > 0) {
          result["assets"] = v.assets;
          hasData = true;
        }
        if (!hasData) return [];
        return [[k, result]];
      }))
    },
    clientEntry: startManifest.clientEntry,
    injectedHeadScripts
  };
}
const manifest = {
  "1bd6e0100cdd735b7b3aee9616caffc00f4cf2497c9b6ebcd94c7a0c4b68b37d": {
    functionName: "listEngagementPlans_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "aa876c540e70dc067f56f08c5b988573ee749cc119a305bcc78462388746fb86": {
    functionName: "getMySubscription_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "da16a63bdab39f1e819d98d4d8e867c0a3c96df6ad7153176087ee19ffb3e0ee": {
    functionName: "getMySubscriptions_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "3d27619f2fab50c5cbed08145758bef45ecd8e80b09b7263a336756fb59102eb": {
    functionName: "getRoomEngagementSettings_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "fd647e1258179beb6ef150bfd1ab4dae7b6a931b738812cda56c36a089b86185": {
    functionName: "upsertRoomEngagementSettings_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "9141a8c4a5d2cac0a43cd7b56801b5a30b380dd6728e462dfe5dee62bf1032e7": {
    functionName: "getWelcomeBotConfig_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "eeef8403ac4754c69ca7fc9e1ae201751be1ea260d8f3df11123836fe0acecc9": {
    functionName: "upsertWelcomeBotConfig_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "520161aadea83353aab9313ee81b67c26d693d76f5fb557fe23959921b3d49ce": {
    functionName: "getForwarderConfig_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "c34908e8207ac3e6b51381875e4ad4d47cbf48ba13ce18a00b61a6c3b4b5cae7": {
    functionName: "upsertForwarderConfig_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "8222aea8cddd21daa30a34176c278c2ff1b0c8ffc97ccabe96fee4264ff3023d": {
    functionName: "listAccountChats_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "e49642dc954ff7560817b9728dedb29fe050efa27e1ffd298454cb47b797ecc1": {
    functionName: "listForwarderSourceItems_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "17eae8fd17f1c83ba64e6ae635fe6345b974fae93d39fd4813fbdff10993a575": {
    functionName: "dispatchEngagementBoost_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "be61ba610464f2a6ce575de6faab72ec24f462f385ee814c9812cbe96e83c542": {
    functionName: "listMyEngagementOrders_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "70ebf1cace5a6167ae9f5feba347cc6da057d22e2aa044d7f10ee81280a6b6e8": {
    functionName: "listEngagementAudit_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "1dd1a0f1764fb9a74e32a0e6d3508bb3857bdc4b644c9440962468839e7957df": {
    functionName: "listMyPaymentHistory_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "55d5439e5566db59dd84035a91b041ab955fc04c0f4932a0c6cec3199f1712aa": {
    functionName: "listPendingBoostAllocations_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "f46508554c2f0f4b657b3bc94b8f0db79f9dd6c228d9258459e231eb123d566a": {
    functionName: "listEligibleBoostRooms_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "2ed761f88ef8c0e1f8ccc61181823b9d92fec2f852ec4f567df50d01e191a5fd": {
    functionName: "allocateSubscriptionToRoom_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "c83a0df8caf1e6a68c81136d80c86b3e2ed1ac14a5104b3fcc1210dc358776b2": {
    functionName: "setSubscriptionTarget_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "13d157f4f68be2d92e9ed9665cdaf03785e1a4db0f7546cc5ab12f9a724b0d84": {
    functionName: "retryEngagementOrder_createServerFn_handler",
    importer: () => import("./engagement.functions-cu7wDuPY.js")
  },
  "4a076d7479753b932f9099c0e14826f639f88204af2dfc90155ac3cd1709f93a": {
    functionName: "verifyAccount_createServerFn_handler",
    importer: () => import("./accounts.functions-BbXMKscK.js")
  },
  "9d672f1b1145acd5f53de234dd6706a0c1e2dd86fe6670f5ad41ed73bdce3017": {
    functionName: "sendTestMessage_createServerFn_handler",
    importer: () => import("./accounts.functions-BbXMKscK.js")
  },
  "0a01656cd747bbe876270e0d8d002d5de74fd71d2f56128cccd31ed18ee88355": {
    functionName: "refreshChats_createServerFn_handler",
    importer: () => import("./accounts.functions-BbXMKscK.js")
  },
  "40fcf5e29c7970fea9b71db6b24426d496c10dbf59ef04683fd7842621b9abcf": {
    functionName: "sendRoomTest_createServerFn_handler",
    importer: () => import("./accounts.functions-BbXMKscK.js")
  },
  "bdd37fe8aa26d3bad1eb29e3a757bbf04c7a3d08ba659057e6302f09cc264909": {
    functionName: "sendVideoNoteNow_createServerFn_handler",
    importer: () => import("./videos.functions-xYXuyq3u.js")
  },
  "3fcd159205240d6926126acac1e16e0b826c923dfac07b14dd13822331355611": {
    functionName: "deleteVideo_createServerFn_handler",
    importer: () => import("./videos.functions-xYXuyq3u.js")
  },
  "b0779274d026cee49e2f496b1308fdf4f5f1f3e5de91278300acb1c16518c541": {
    functionName: "subscribeToWebPush_createServerFn_handler",
    importer: () => import("./webpush.server-CMtnPvYq.js")
  },
  "9466a54ef971f4cd6a7a1443d5910ac11966795d1365e65adb861340118e6607": {
    functionName: "getPushSettings_createServerFn_handler",
    importer: () => import("./webpush.server-CMtnPvYq.js")
  },
  "21a2bd418abda5888124a9b90fafe712ec4ba263111a97f33cb800fa1e0c3392": {
    functionName: "updatePushSettings_createServerFn_handler",
    importer: () => import("./webpush.server-CMtnPvYq.js")
  },
  "7d6d81fc49c7fc84551bd929bf5a67d4d916f804fdf846fb012c69b9e6ba41a9": {
    functionName: "sendAudioNow_createServerFn_handler",
    importer: () => import("./audios.functions-C2UiBwdu.js")
  },
  "8a7527746586e344d6ed82b12250cdb4270db02a4d02289b4eb367cb65a8215f": {
    functionName: "deleteAudio_createServerFn_handler",
    importer: () => import("./audios.functions-C2UiBwdu.js")
  },
  "73562d24cd31fbd26f4cab24ac3b6e132c58ee857d20f8bbae7d26c33088d38a": {
    functionName: "enableMemberTracking_createServerFn_handler",
    importer: () => import("./telegram-tracking.functions-Br2rsZSn.js")
  },
  "466f3e9f548b02e4b45cb9628872cce1539e03478760d01fe3a29070c2fc5b91": {
    functionName: "disableMemberTracking_createServerFn_handler",
    importer: () => import("./telegram-tracking.functions-Br2rsZSn.js")
  },
  "6d56c54f8361e3f4a856af7bdd3239d6c8196c320aec96e6194653ea5841d2f9": {
    functionName: "getMemberStats_createServerFn_handler",
    importer: () => import("./telegram-tracking.functions-Br2rsZSn.js")
  },
  "636af64b9c4b9e724ed8981b4acc7661c7099eb373fab9234898005009f700e0": {
    functionName: "getCurrentMemberCounts_createServerFn_handler",
    importer: () => import("./telegram-tracking.functions-Br2rsZSn.js")
  },
  "eafcf68c09ef7117507f8eb27b92e2fcf831b9c8e147ab56792c657a56b9b98f": {
    functionName: "requestPremiumCode_createServerFn_handler",
    importer: () => import("./premium-account.functions-Cr_KM2C5.js")
  },
  "e11e0b634bc507696d761a8e13f279ff5d7bcd325326316d1fb3a4e8049b6714": {
    functionName: "confirmPremiumCode_createServerFn_handler",
    importer: () => import("./premium-account.functions-Cr_KM2C5.js")
  },
  "2664d9c35138f431d18be3f3d5ebc7a5d45d618ffb31ec9e4c10f957970348c1": {
    functionName: "syncPremiumEmojis_createServerFn_handler",
    importer: () => import("./premium-account.functions-Cr_KM2C5.js")
  },
  "06dd158bb8d31327cc0235b073df3cffa204292936a232ec40e53bfd54012078": {
    functionName: "getPremiumEmojiThumbs_createServerFn_handler",
    importer: () => import("./premium-account.functions-Cr_KM2C5.js")
  },
  "a68c6ea077e0df4dc32ab7c1a8554c7fcac10c65f376ef7beb23fabed1bbbee8": {
    functionName: "sendPremiumMessage_createServerFn_handler",
    importer: () => import("./premium-account.functions-Cr_KM2C5.js")
  },
  "76bf59276293617ba82d876f45ee762518ab372249f24bcbe360406a24d32dea": {
    functionName: "getPremiumAccountAvatar_createServerFn_handler",
    importer: () => import("./premium-account.functions-Cr_KM2C5.js")
  },
  "caab0abaa72a33b59460709845e7aec17500521150d731dc3ac8e2d4a6450b92": {
    functionName: "syncRoomPhoto_createServerFn_handler",
    importer: () => import("./room-photos.functions-L-MkH_0n.js")
  },
  "a6eb9cfecce08eeca471a5584dd509eec92be5b9515d87e410241db9f4e87631": {
    functionName: "generateWivenCheckout_createServerFn_handler",
    importer: () => import("./checkout.functions-Bm0pm0Sm.js")
  },
  "fe9a16f4db01d7aec400648cf6b6d02a2e165627cc80ebce4dc8dbca82262f56": {
    functionName: "generateDirectPix_createServerFn_handler",
    importer: () => import("./checkout.functions-Bm0pm0Sm.js")
  },
  "b0cf405fbeeba96b0eb1db1c6c8fbd933356d60651d8e45d00afde4d9382a307": {
    functionName: "generateDirectCard_createServerFn_handler",
    importer: () => import("./checkout.functions-Bm0pm0Sm.js")
  },
  "124b67b88312178f40f4489f9bbb49f4f3b5dd9d256a7171ef7515d7039df67e": {
    functionName: "testWindow_createServerFn_handler",
    importer: () => import("./test-signal.functions-C4f6Aha_.js")
  },
  "845178501925ff025a9075c6462f357f94ec9cb82a28dbfd46f6218c98fdc76e": {
    functionName: "listAffiliateAccounts_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "9afc4db0fbd526bdaab58d3ce560f1706664391f3d15201b0fdb4bff6680416e": {
    functionName: "upsertAffiliateAccount_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "e8b80aab3a5edd12c8cd36b84055ad3e0a0a07fecf4aaac6a831e395d4556df3": {
    functionName: "deleteAffiliateAccount_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "669cdc114ce30c21c3b0bb25985c1773530a9a91b1a8a14bbda1ed26cb2597ff": {
    functionName: "testAffiliateAccount_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "5c064b1cd7807dad52ee0e35ec5f01be01887e7c00d782fb369be6e9abcc33ae": {
    functionName: "getPromoBotSettings_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "feb054bee80e3924b6fe4bdf91fa85c425c969a5bb0f4f861806e4f33b8119da": {
    functionName: "upsertPromoBotSettings_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "ce9a7d566fb40d3e8cc4ebc0df1f0b6341c8e1fef77b8effaf4f6fc4a482e59c": {
    functionName: "previewPromoOffers_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "2ce89b173a66e2e1bc8690700f4d6aa2606470a5648c1a92072d2f895353964e": {
    functionName: "listPromoDispatches_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "dd19c28962d785d1e990e836471a4acb4b5543ce828b5b28741b36a8e474263d": {
    functionName: "getPromoStats_createServerFn_handler",
    importer: () => import("./promo.functions-BQWYsxPB.js")
  },
  "9a10855ec68031a68272278346d1dff6878e9ca23aca2143f5361ed6e1999988": {
    functionName: "listPixels_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "0dcec4b9cde2b59d27fa7c851f4731b8ee539ee35173ba2dac5b7d4360ab1781": {
    functionName: "getPixel_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "c74905e5b6be9caaa44375d7a8476db9001866bf833e9ddf2bf6af80ff10fee1": {
    functionName: "createPixel_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "0de27157edb1f132e151a83c8f9e064786d2d19283a3cc6231c0c188e7b6e136": {
    functionName: "updatePixel_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "bb80e000109e2704a88d684dd91dc5b6552d35f5daa1afeeaf70542335e38d5d": {
    functionName: "deletePixel_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "27c7594de8b00f91bee8593f78ef8045b23a3ca9be78fd7ab18928b268712a7a": {
    functionName: "listOffers_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "31ca301441616645f30db96bc49571b709b78a2d22f922a9a2f65e504988b205": {
    functionName: "createOffer_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "8dd1db2506dfb0ca23b3f6ffc3014b58a2cfa90d8a8707946b766d28211f787a": {
    functionName: "updateOffer_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "137608e79fc828d8251f37acb791d6e58da349bffd7f102fbfd6c1a1e868803f": {
    functionName: "deleteOffer_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "603a464eb3d9ed9a9091fb89c5ee43d6f317bd408dafcc7b41007fb386c6f1cc": {
    functionName: "listRecentClicks_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "4a80c7840c491ab9f8012a891470726e98f09f087a859a194d0f9959ce1157ad": {
    functionName: "listClicksFiltered_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "fada98e77b81fcc3e7bcc077f7cccb4c683a7c4e420844d4d01829e14763ad18": {
    functionName: "getPixelStats_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "0cddd13570369a4ad87bb38fee349e91178aa4866dbce9ce78820cc23bf59712": {
    functionName: "getAttribution_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "ec3e4aab6fa1fda6669b11ce64bbd0f5feb1c8cab1eb3e008af7cdfa1a10b665": {
    functionName: "listDomains_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "7e93f0071e8d14bade8182e0ac6c981e6975479a2830d19f553fc947bd2066fd": {
    functionName: "createDomain_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "08b0290c79c5eed474def48c5d28ed3e6576e135bb3939fba22331814f266393": {
    functionName: "deleteDomain_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "405119693096c8c51536e705666171437c26673d31d457b94f3269e876607e03": {
    functionName: "verifyDomain_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "ffbaafa2e4a8c30c2601b49c918a3eeafc5590146bc4893f15f21552caf35ebe": {
    functionName: "getMyRedirectBase_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "f1fe9cee74edca82ab25a8005f4facdae55424220808b4503441a76c54d67e02": {
    functionName: "listPostbacks_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "46c276df3aeb65f0b673ec795ecc36d785b430d4a34a595baa239369d56fa9f2": {
    functionName: "createPostback_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "da255167f1cbb9205d568a80e1f0cc3b4c294b5c10a06c6b31d226ed0e08ce5b": {
    functionName: "updatePostback_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "1b1724c9b582de6a00b91d2a46dbe6e6c66f53457d67f41bf7749d6936489a70": {
    functionName: "deletePostback_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "af30abf22edeebe07aa538f2da264e02c7cadf4db801c8ade00fef1443da9e31": {
    functionName: "testPostback_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "012931baad73d5749e90b854282885cfc580ade3f7d0d9ed951ef097e3bb934c": {
    functionName: "listIntegrations_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "b2e722c57872a7c358fe30a5ae8d88af9b2c420396c4db28f9c7e2c075eb2cb8": {
    functionName: "createIntegration_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "6f5c39bb1cba1c244d4a224e6b64556531006e5dae4abd55b0ceff0885511e44": {
    functionName: "updateIntegration_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "759cfed5600289cb15ac7c5dc2cdb7f9bef1fa57643dd610c0ac37a74747be74": {
    functionName: "deleteIntegration_createServerFn_handler",
    importer: () => import("./tracking.functions-DkIN1hsj.js")
  },
  "30ce60d49560fcf320a3a093acb10d55e657cdf4c528a23f700015448776354f": {
    functionName: "getMetaIntegration_createServerFn_handler",
    importer: () => import("./meta-capi.functions-BmrEl3-u.js")
  },
  "9d460463a69d1d09a9ecdf7507943a909f8e8353acc22ca2f63749a4dc1c9511": {
    functionName: "upsertMetaIntegration_createServerFn_handler",
    importer: () => import("./meta-capi.functions-BmrEl3-u.js")
  },
  "f5b8d4937c62913dcb9bf1b20173daa211b68e17bb379a9742e0090a20b9b26a": {
    functionName: "deleteMetaIntegration_createServerFn_handler",
    importer: () => import("./meta-capi.functions-BmrEl3-u.js")
  },
  "f577b17f42b4ffc5eced72efbef6329ff0c4c1541605a624ec6066a450ae6cfe": {
    functionName: "sendMetaTestEvent_createServerFn_handler",
    importer: () => import("./meta-capi.functions-BmrEl3-u.js")
  },
  "cdd38ff44aee3057891b299148a5f45f2fbc3bfea5efb820f335a626c82ea503": {
    functionName: "listMetaEventLogs_createServerFn_handler",
    importer: () => import("./meta-capi.functions-BmrEl3-u.js")
  },
  "557a3bb959592512346d395daec1e205af9872cf293cc245cb8edf0c9dfa42b6": {
    functionName: "upsertSchedule_createServerFn_handler",
    importer: () => import("./recurring-schedules.functions-D_qPkH5G.js")
  },
  "ede179f930977d4129f87a568ea5835e8ed726860a04033e7d1e2c366ef1ada1": {
    functionName: "toggleSchedule_createServerFn_handler",
    importer: () => import("./recurring-schedules.functions-D_qPkH5G.js")
  },
  "f010fecd0eae223fea7e6b9faba5094a2b823de23e6ba7de800826723cc7fd01": {
    functionName: "deleteSchedule_createServerFn_handler",
    importer: () => import("./recurring-schedules.functions-D_qPkH5G.js")
  },
  "cda58577c6df6b3babc9e9f22ba663807cc2836d974d3f733910922dc91aa8e0": {
    functionName: "testSchedule_createServerFn_handler",
    importer: () => import("./recurring-schedules.functions-D_qPkH5G.js")
  },
  "e9cfdb4483e73620518a22b85d5af41f696ed908522b5a2b91558a187c530439": {
    functionName: "testMessage_createServerFn_handler",
    importer: () => import("./recurring-schedules.functions-D_qPkH5G.js")
  },
  "cf9fb7d494ca0dc248c68827ebce13e7b58a3849c2b47f8d8c7bbae511326c12": {
    functionName: "upsertFolder_createServerFn_handler",
    importer: () => import("./schedule-folders.functions-DmZ7NZUK.js")
  },
  "61862fba5b5b90c901af2a948eb0b0dacbcc29b7531291ee094eb7eb5b12d6cb": {
    functionName: "deleteFolder_createServerFn_handler",
    importer: () => import("./schedule-folders.functions-DmZ7NZUK.js")
  },
  "7ddac3775442677f15be4eb2baf7b48fb9a762abcb3f88759782abe845d23c8c": {
    functionName: "moveScheduleToFolder_createServerFn_handler",
    importer: () => import("./schedule-folders.functions-DmZ7NZUK.js")
  },
  "b9ff1a6bc1d5c7403ffc0951cb8843216e98d11123f4a3455fb6f287af1a8f87": {
    functionName: "bulkReplaceLinks_createServerFn_handler",
    importer: () => import("./bulk-replace.functions-CUiNiYxV.js")
  },
  "f48828778ab4b266229fca37c08d9cabbb9dbc1c3dabb92a1cfa06342d0cc3da": {
    functionName: "getFollowupSettings_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "7df86b85148b921548fad209068bd2a4df1065e2faf92d77d46f443bfb583327": {
    functionName: "upsertFollowupSettings_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "80441ab02eac154f6657535381da3d124701a05d170692798cd1d17dc4db2f25": {
    functionName: "listFollowupMessages_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "d56497e25ef5da3d47b18edba31efa6c353d09ea5a59cbdf36c3fa274d1cca34": {
    functionName: "upsertFollowupMessage_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "8a4a9f25a4085c0541cc9e082c48eb8180b7581ec60b5e1c348b0b1313986344": {
    functionName: "deleteFollowupMessage_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "89ecdf9193e124ab5c95ef460718580f06c31c416785688a45efaee2a3ea49e0": {
    functionName: "listFollowupLeads_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "5322917ff3d34b3b9b9fa76ed9eaa81529bb8d180eab85ac31a0ff84efd147f9": {
    functionName: "setFollowupLeadStatus_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "a9396ecd29149ed85ff4893dd56fd9164d94f50a3a3b93bdfe53e9d74ae7fbff": {
    functionName: "testFollowupMessage_createServerFn_handler",
    importer: () => import("./followup.functions-D3jMdSjq.js")
  },
  "b392229ab5a6014b011ceea3c1c702258afd9b7b2a619034946329703eba5c01": {
    functionName: "upsertQuickTemplate_createServerFn_handler",
    importer: () => import("./quick-send-templates.functions-DnmbA3tG.js")
  },
  "716d17b8e661d753397d1e51ded83da886a463c2294a1ca686ce8e05f356c907": {
    functionName: "deleteQuickTemplate_createServerFn_handler",
    importer: () => import("./quick-send-templates.functions-DnmbA3tG.js")
  },
  "0116fb79c44cd0c53b7ca426a1052f443a6a8715978f67ad804186a95b4a0855": {
    functionName: "sendQuickTemplate_createServerFn_handler",
    importer: () => import("./quick-send-templates.functions-DnmbA3tG.js")
  }
};
async function getServerFnById(id, access) {
  const serverFnInfo = manifest[id];
  if (!serverFnInfo) {
    throw new Error("Server function info not found for " + id);
  }
  const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
  if (!fnModule) {
    throw new Error("Server function module not resolved for " + id);
  }
  const action = fnModule[serverFnInfo.functionName];
  if (!action) {
    throw new Error("Server function module export not resolved for serverFn ID: " + id);
  }
  return action;
}
var TSS_FORMDATA_CONTEXT = "__TSS_CONTEXT";
var TSS_SERVER_FUNCTION = /* @__PURE__ */ Symbol.for("TSS_SERVER_FUNCTION");
var TSS_SERVER_FUNCTION_FACTORY = /* @__PURE__ */ Symbol.for("TSS_SERVER_FUNCTION_FACTORY");
var X_TSS_SERIALIZED = "x-tss-serialized";
var X_TSS_RAW_RESPONSE = "x-tss-raw";
var TSS_CONTENT_TYPE_FRAMED = "application/x-tss-framed";
var FrameType = {
  JSON: 0,
  CHUNK: 1,
  END: 2,
  ERROR: 3
};
var FRAME_HEADER_SIZE = 9;
var TSS_CONTENT_TYPE_FRAMED_VERSIONED = `${TSS_CONTENT_TYPE_FRAMED}; v=1`;
function isSafeKey(key) {
  return key !== "__proto__" && key !== "constructor" && key !== "prototype";
}
function safeObjectMerge(target, source) {
  const result = /* @__PURE__ */ Object.create(null);
  if (target) {
    for (const key of Object.keys(target)) if (isSafeKey(key)) result[key] = target[key];
  }
  if (source && typeof source === "object") {
    for (const key of Object.keys(source)) if (isSafeKey(key)) result[key] = source[key];
  }
  return result;
}
function createNullProtoObject(source) {
  if (!source) return /* @__PURE__ */ Object.create(null);
  const obj = /* @__PURE__ */ Object.create(null);
  for (const key of Object.keys(source)) if (isSafeKey(key)) obj[key] = source[key];
  return obj;
}
var GLOBAL_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:start-storage-context");
var globalObj = globalThis;
if (!globalObj[GLOBAL_STORAGE_KEY]) globalObj[GLOBAL_STORAGE_KEY] = new AsyncLocalStorage();
var startStorage = globalObj[GLOBAL_STORAGE_KEY];
async function runWithStartContext(context, fn) {
  return startStorage.run(context, fn);
}
function getStartContext(opts) {
  const context = startStorage.getStore();
  if (!context && opts?.throwIfNotFound !== false) throw new Error(`No Start context found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`);
  return context;
}
var getStartOptions = () => getStartContext().startOptions;
var getStartContextServerOnly = getStartContext;
var createServerFn = (options, __opts) => {
  const resolvedOptions = __opts || options || {};
  if (typeof resolvedOptions.method === "undefined") resolvedOptions.method = "GET";
  const res = {
    options: resolvedOptions,
    middleware: (middleware) => {
      const newMiddleware = [...resolvedOptions.middleware || []];
      middleware.map((m) => {
        if (TSS_SERVER_FUNCTION_FACTORY in m) {
          if (m.options.middleware) newMiddleware.push(...m.options.middleware);
        } else newMiddleware.push(m);
      });
      const res2 = createServerFn(void 0, {
        ...resolvedOptions,
        middleware: newMiddleware
      });
      res2[TSS_SERVER_FUNCTION_FACTORY] = true;
      return res2;
    },
    inputValidator: (inputValidator) => {
      return createServerFn(void 0, {
        ...resolvedOptions,
        inputValidator
      });
    },
    handler: (...args) => {
      const [extractedFn, serverFn] = args;
      const newOptions = {
        ...resolvedOptions,
        extractedFn,
        serverFn
      };
      const resolvedMiddleware = [...newOptions.middleware || [], serverFnBaseToMiddleware(newOptions)];
      extractedFn.method = resolvedOptions.method;
      return Object.assign(async (opts) => {
        const result = await executeMiddleware$1(resolvedMiddleware, "client", {
          ...extractedFn,
          ...newOptions,
          data: opts?.data,
          headers: opts?.headers,
          signal: opts?.signal,
          fetch: opts?.fetch,
          context: createNullProtoObject()
        });
        const redirect = parseRedirect(result.error);
        if (redirect) throw redirect;
        if (result.error) throw result.error;
        return result.result;
      }, {
        ...extractedFn,
        method: resolvedOptions.method,
        __executeServer: async (opts) => {
          const startContext = getStartContextServerOnly();
          const serverContextAfterGlobalMiddlewares = startContext.contextAfterGlobalMiddlewares;
          return await executeMiddleware$1(resolvedMiddleware, "server", {
            ...extractedFn,
            ...opts,
            serverFnMeta: extractedFn.serverFnMeta,
            context: safeObjectMerge(opts.context, serverContextAfterGlobalMiddlewares),
            request: startContext.request
          }).then((d) => ({
            result: d.result,
            error: d.error,
            context: d.sendContext
          }));
        }
      });
    }
  };
  const fun = (options2) => {
    return createServerFn(void 0, {
      ...resolvedOptions,
      ...options2
    });
  };
  return Object.assign(fun, res);
};
async function executeMiddleware$1(middlewares, env, opts) {
  let flattenedMiddlewares = flattenMiddlewares([...getStartOptions()?.functionMiddleware || [], ...middlewares]);
  if (env === "server") {
    const startContext = getStartContextServerOnly({ throwIfNotFound: false });
    if (startContext?.executedRequestMiddlewares) flattenedMiddlewares = flattenedMiddlewares.filter((m) => !startContext.executedRequestMiddlewares.has(m));
  }
  const callNextMiddleware = async (ctx) => {
    const nextMiddleware = flattenedMiddlewares.shift();
    if (!nextMiddleware) return ctx;
    try {
      if ("inputValidator" in nextMiddleware.options && nextMiddleware.options.inputValidator && env === "server") ctx.data = await execValidator(nextMiddleware.options.inputValidator, ctx.data);
      let middlewareFn = void 0;
      if (env === "client") {
        if ("client" in nextMiddleware.options) middlewareFn = nextMiddleware.options.client;
      } else if ("server" in nextMiddleware.options) middlewareFn = nextMiddleware.options.server;
      if (middlewareFn) {
        const userNext = async (userCtx = {}) => {
          const result2 = await callNextMiddleware({
            ...ctx,
            ...userCtx,
            context: safeObjectMerge(ctx.context, userCtx.context),
            sendContext: safeObjectMerge(ctx.sendContext, userCtx.sendContext),
            headers: mergeHeaders(ctx.headers, userCtx.headers),
            _callSiteFetch: ctx._callSiteFetch,
            fetch: ctx._callSiteFetch ?? userCtx.fetch ?? ctx.fetch,
            result: userCtx.result !== void 0 ? userCtx.result : userCtx instanceof Response ? userCtx : ctx.result,
            error: userCtx.error ?? ctx.error
          });
          if (result2.error) throw result2.error;
          return result2;
        };
        const result = await middlewareFn({
          ...ctx,
          next: userNext
        });
        if (isRedirect(result)) return {
          ...ctx,
          error: result
        };
        if (result instanceof Response) return {
          ...ctx,
          result
        };
        if (!result) throw new Error("User middleware returned undefined. You must call next() or return a result in your middlewares.");
        return result;
      }
      return callNextMiddleware(ctx);
    } catch (error) {
      return {
        ...ctx,
        error
      };
    }
  };
  return callNextMiddleware({
    ...opts,
    headers: opts.headers || {},
    sendContext: opts.sendContext || {},
    context: opts.context || createNullProtoObject(),
    _callSiteFetch: opts.fetch
  });
}
function flattenMiddlewares(middlewares, maxDepth = 100) {
  const seen = /* @__PURE__ */ new Set();
  const flattened = [];
  const recurse = (middleware, depth) => {
    if (depth > maxDepth) throw new Error(`Middleware nesting depth exceeded maximum of ${maxDepth}. Check for circular references.`);
    middleware.forEach((m) => {
      if (m.options.middleware) recurse(m.options.middleware, depth + 1);
      if (!seen.has(m)) {
        seen.add(m);
        flattened.push(m);
      }
    });
  };
  recurse(middlewares, 0);
  return flattened;
}
async function execValidator(validator, input) {
  if (validator == null) return {};
  if ("~standard" in validator) {
    const result = await validator["~standard"].validate(input);
    if (result.issues) throw new Error(JSON.stringify(result.issues, void 0, 2));
    return result.value;
  }
  if ("parse" in validator) return validator.parse(input);
  if (typeof validator === "function") return validator(input);
  throw new Error("Invalid validator type!");
}
function serverFnBaseToMiddleware(options) {
  return {
    "~types": void 0,
    options: {
      inputValidator: options.inputValidator,
      client: async ({ next, sendContext, fetch: fetch2, ...ctx }) => {
        const payload = {
          ...ctx,
          context: sendContext,
          fetch: fetch2
        };
        return next(await options.extractedFn?.(payload));
      },
      server: async ({ next, ...ctx }) => {
        const result = await options.serverFn?.(ctx);
        return next({
          ...ctx,
          result
        });
      }
    }
  };
}
function getDefaultSerovalPlugins() {
  return [...getStartOptions()?.serializationAdapters?.map(makeSerovalPlugin) ?? [], ...defaultSerovalPlugins];
}
var textEncoder = new TextEncoder();
var EMPTY_PAYLOAD = new Uint8Array(0);
function encodeFrame(type, streamId, payload) {
  const frame = new Uint8Array(FRAME_HEADER_SIZE + payload.length);
  frame[0] = type;
  frame[1] = streamId >>> 24 & 255;
  frame[2] = streamId >>> 16 & 255;
  frame[3] = streamId >>> 8 & 255;
  frame[4] = streamId & 255;
  frame[5] = payload.length >>> 24 & 255;
  frame[6] = payload.length >>> 16 & 255;
  frame[7] = payload.length >>> 8 & 255;
  frame[8] = payload.length & 255;
  frame.set(payload, FRAME_HEADER_SIZE);
  return frame;
}
function encodeJSONFrame(json) {
  return encodeFrame(FrameType.JSON, 0, textEncoder.encode(json));
}
function encodeChunkFrame(streamId, chunk) {
  return encodeFrame(FrameType.CHUNK, streamId, chunk);
}
function encodeEndFrame(streamId) {
  return encodeFrame(FrameType.END, streamId, EMPTY_PAYLOAD);
}
function encodeErrorFrame(streamId, error) {
  const message = error instanceof Error ? error.message : String(error ?? "Unknown error");
  return encodeFrame(FrameType.ERROR, streamId, textEncoder.encode(message));
}
function createMultiplexedStream(jsonStream, rawStreams, lateStreamSource) {
  let controller;
  let cancelled = false;
  const readers = [];
  const enqueue = (frame) => {
    if (cancelled) return false;
    try {
      controller.enqueue(frame);
      return true;
    } catch {
      return false;
    }
  };
  const errorOutput = (error) => {
    if (cancelled) return;
    cancelled = true;
    try {
      controller.error(error);
    } catch {
    }
    for (const reader of readers) reader.cancel().catch(() => {
    });
  };
  async function pumpRawStream(streamId, stream) {
    const reader = stream.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) {
          enqueue(encodeEndFrame(streamId));
          return;
        }
        if (!enqueue(encodeChunkFrame(streamId, value))) return;
      }
    } catch (error) {
      enqueue(encodeErrorFrame(streamId, error));
    } finally {
      reader.releaseLock();
    }
  }
  async function pumpJSON() {
    const reader = jsonStream.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) return;
        if (!enqueue(encodeJSONFrame(value))) return;
      }
    } catch (error) {
      errorOutput(error);
      throw error;
    } finally {
      reader.releaseLock();
    }
  }
  async function pumpLateStreams() {
    if (!lateStreamSource) return [];
    const lateStreamPumps = [];
    const reader = lateStreamSource.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) break;
        lateStreamPumps.push(pumpRawStream(value.id, value.stream));
      }
    } finally {
      reader.releaseLock();
    }
    return lateStreamPumps;
  }
  return new ReadableStream({
    async start(ctrl) {
      controller = ctrl;
      const pumps = [pumpJSON()];
      for (const [streamId, stream] of rawStreams) pumps.push(pumpRawStream(streamId, stream));
      if (lateStreamSource) pumps.push(pumpLateStreams());
      try {
        const latePumps = (await Promise.all(pumps)).find(Array.isArray);
        if (latePumps && latePumps.length > 0) await Promise.all(latePumps);
        if (!cancelled) try {
          controller.close();
        } catch {
        }
      } catch {
      }
    },
    cancel() {
      cancelled = true;
      for (const reader of readers) reader.cancel().catch(() => {
      });
      readers.length = 0;
    }
  });
}
var serovalPlugins = void 0;
var FORM_DATA_CONTENT_TYPES = ["multipart/form-data", "application/x-www-form-urlencoded"];
var MAX_PAYLOAD_SIZE = 1e6;
var handleServerAction = async ({ request, context, serverFnId }) => {
  const methodUpper = request.method.toUpperCase();
  const url = new URL(request.url);
  const action = await getServerFnById(serverFnId);
  if (action.method && methodUpper !== action.method) return new Response(`expected ${action.method} method. Got ${methodUpper}`, {
    status: 405,
    headers: { Allow: action.method }
  });
  const isServerFn = request.headers.get("x-tsr-serverFn") === "true";
  if (!serovalPlugins) serovalPlugins = getDefaultSerovalPlugins();
  const contentType = request.headers.get("Content-Type");
  function parsePayload(payload) {
    return fromJSON(payload, { plugins: serovalPlugins });
  }
  return await (async () => {
    try {
      let serializeResult = function(res2) {
        let nonStreamingBody = void 0;
        const alsResponse = getResponse();
        if (res2 !== void 0) {
          const rawStreams = /* @__PURE__ */ new Map();
          let initialPhase = true;
          let lateStreamWriter;
          let lateStreamReadable = void 0;
          const pendingLateStreams = [];
          const plugins = [createRawStreamRPCPlugin((id, stream) => {
            if (initialPhase) {
              rawStreams.set(id, stream);
              return;
            }
            if (lateStreamWriter) {
              lateStreamWriter.write({
                id,
                stream
              }).catch(() => {
              });
              return;
            }
            pendingLateStreams.push({
              id,
              stream
            });
          }), ...serovalPlugins || []];
          let done = false;
          const callbacks = {
            onParse: (value) => {
              nonStreamingBody = value;
            },
            onDone: () => {
              done = true;
            },
            onError: (error) => {
              throw error;
            }
          };
          toCrossJSONStream(res2, {
            refs: /* @__PURE__ */ new Map(),
            plugins,
            onParse(value) {
              callbacks.onParse(value);
            },
            onDone() {
              callbacks.onDone();
            },
            onError: (error) => {
              callbacks.onError(error);
            }
          });
          initialPhase = false;
          if (done && rawStreams.size === 0) return new Response(nonStreamingBody ? JSON.stringify(nonStreamingBody) : void 0, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": "application/json",
              [X_TSS_SERIALIZED]: "true"
            }
          });
          const { readable, writable } = new TransformStream();
          lateStreamReadable = readable;
          lateStreamWriter = writable.getWriter();
          for (const registration of pendingLateStreams) lateStreamWriter.write(registration).catch(() => {
          });
          pendingLateStreams.length = 0;
          const multiplexedStream = createMultiplexedStream(new ReadableStream({
            start(controller) {
              callbacks.onParse = (value) => {
                controller.enqueue(JSON.stringify(value) + "\n");
              };
              callbacks.onDone = () => {
                try {
                  controller.close();
                } catch {
                }
                lateStreamWriter?.close().catch(() => {
                }).finally(() => {
                  lateStreamWriter = void 0;
                });
              };
              callbacks.onError = (error) => {
                controller.error(error);
                lateStreamWriter?.abort(error).catch(() => {
                }).finally(() => {
                  lateStreamWriter = void 0;
                });
              };
              if (nonStreamingBody !== void 0) callbacks.onParse(nonStreamingBody);
              if (done) callbacks.onDone();
            },
            cancel() {
              lateStreamWriter?.abort().catch(() => {
              });
              lateStreamWriter = void 0;
            }
          }), rawStreams, lateStreamReadable);
          return new Response(multiplexedStream, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": TSS_CONTENT_TYPE_FRAMED_VERSIONED,
              [X_TSS_SERIALIZED]: "true"
            }
          });
        }
        return new Response(void 0, {
          status: alsResponse.status,
          statusText: alsResponse.statusText
        });
      };
      let res = await (async () => {
        if (FORM_DATA_CONTENT_TYPES.some((type) => contentType && contentType.includes(type))) {
          if (methodUpper === "GET") {
            if (false) ;
            invariant();
          }
          const formData = await request.formData();
          const serializedContext = formData.get(TSS_FORMDATA_CONTEXT);
          formData.delete(TSS_FORMDATA_CONTEXT);
          const params = {
            context,
            data: formData,
            method: methodUpper
          };
          if (typeof serializedContext === "string") try {
            const deserializedContext = fromJSON(JSON.parse(serializedContext), { plugins: serovalPlugins });
            if (typeof deserializedContext === "object" && deserializedContext) params.context = safeObjectMerge(deserializedContext, context);
          } catch (e) {
            if (false) ;
          }
          return await action(params);
        }
        if (methodUpper === "GET") {
          const payloadParam = url.searchParams.get("payload");
          if (payloadParam && payloadParam.length > MAX_PAYLOAD_SIZE) throw new Error("Payload too large");
          const payload2 = payloadParam ? parsePayload(JSON.parse(payloadParam)) : {};
          payload2.context = safeObjectMerge(payload2.context, context);
          payload2.method = methodUpper;
          return await action(payload2);
        }
        let jsonPayload;
        if (contentType?.includes("application/json")) jsonPayload = await request.json();
        const payload = jsonPayload ? parsePayload(jsonPayload) : {};
        payload.context = safeObjectMerge(payload.context, context);
        payload.method = methodUpper;
        return await action(payload);
      })();
      const unwrapped = res.result || res.error;
      if (isNotFound(res)) res = isNotFoundResponse(res);
      if (!isServerFn) return unwrapped;
      if (unwrapped instanceof Response) {
        if (isRedirect(unwrapped)) return unwrapped;
        unwrapped.headers.set(X_TSS_RAW_RESPONSE, "true");
        return unwrapped;
      }
      return serializeResult(res);
    } catch (error) {
      if (error instanceof Response) return error;
      if (isNotFound(error)) return isNotFoundResponse(error);
      console.info();
      console.info("Server Fn Error!");
      console.info();
      console.error(error);
      console.info();
      const serializedError = JSON.stringify(await Promise.resolve(toCrossJSONAsync(error, {
        refs: /* @__PURE__ */ new Map(),
        plugins: serovalPlugins
      })));
      const response = getResponse();
      return new Response(serializedError, {
        status: response.status ?? 500,
        statusText: response.statusText,
        headers: {
          "Content-Type": "application/json",
          [X_TSS_SERIALIZED]: "true"
        }
      });
    }
  })();
};
function isNotFoundResponse(error) {
  const { headers, ...rest } = error;
  return new Response(JSON.stringify(rest), {
    status: 404,
    headers: {
      "Content-Type": "application/json",
      ...headers || {}
    }
  });
}
function normalizeTransformAssetResult(result) {
  if (typeof result === "string") return { href: result };
  return result;
}
function resolveTransformAssetsCrossOrigin(config, kind) {
  if (!config) return void 0;
  if (typeof config === "string") return config;
  return config[kind];
}
function isObjectShorthand(transform) {
  return "prefix" in transform;
}
function resolveTransformAssetsConfig(transform) {
  if (typeof transform === "string") {
    const prefix = transform;
    return {
      type: "transform",
      transformFn: ({ url }) => ({ href: `${prefix}${url}` }),
      cache: true
    };
  }
  if (typeof transform === "function") return {
    type: "transform",
    transformFn: transform,
    cache: true
  };
  if (isObjectShorthand(transform)) {
    const { prefix, crossOrigin } = transform;
    return {
      type: "transform",
      transformFn: ({ url, kind }) => {
        const href = `${prefix}${url}`;
        if (kind === "clientEntry") return { href };
        const co = resolveTransformAssetsCrossOrigin(crossOrigin, kind);
        return co ? {
          href,
          crossOrigin: co
        } : { href };
      },
      cache: true
    };
  }
  if ("createTransform" in transform && transform.createTransform) return {
    type: "createTransform",
    createTransform: transform.createTransform,
    cache: transform.cache !== false
  };
  return {
    type: "transform",
    transformFn: typeof transform.transform === "string" ? (({ url }) => ({ href: `${transform.transform}${url}` })) : transform.transform,
    cache: transform.cache !== false
  };
}
function adaptTransformAssetUrlsToTransformAssets(transformFn) {
  return async ({ url, kind }) => ({ href: await transformFn({
    url,
    type: kind
  }) });
}
function adaptTransformAssetUrlsConfigToTransformAssets(transform) {
  if (typeof transform === "string") return transform;
  if (typeof transform === "function") return adaptTransformAssetUrlsToTransformAssets(transform);
  if ("createTransform" in transform && transform.createTransform) return {
    createTransform: async (ctx) => adaptTransformAssetUrlsToTransformAssets(await transform.createTransform(ctx)),
    cache: transform.cache,
    warmup: transform.warmup
  };
  return {
    transform: typeof transform.transform === "string" ? transform.transform : adaptTransformAssetUrlsToTransformAssets(transform.transform),
    cache: transform.cache,
    warmup: transform.warmup
  };
}
function buildClientEntryScriptTag(clientEntry, injectedHeadScripts) {
  let script = `import(${JSON.stringify(clientEntry)})`;
  if (injectedHeadScripts) script = `${injectedHeadScripts};${script}`;
  return {
    tag: "script",
    attrs: {
      type: "module",
      async: true
    },
    children: script
  };
}
function assignManifestAssetLink(link, next) {
  if (typeof link === "string") return next.crossOrigin ? next : next.href;
  return next.crossOrigin ? next : { href: next.href };
}
async function transformManifestAssets(source, transformFn, _opts) {
  const manifest2 = structuredClone(source.manifest);
  for (const route of Object.values(manifest2.routes)) {
    if (route.preloads) route.preloads = await Promise.all(route.preloads.map(async (link) => {
      const result = normalizeTransformAssetResult(await transformFn({
        url: resolveManifestAssetLink(link).href,
        kind: "modulepreload"
      }));
      return assignManifestAssetLink(link, {
        href: result.href,
        crossOrigin: result.crossOrigin
      });
    }));
    if (route.assets && !source.manifest.inlineCss) {
      for (const asset of route.assets) if (asset.tag === "link" && asset.attrs?.href) {
        const rel = asset.attrs.rel;
        if (!(typeof rel === "string" ? rel.split(/\s+/) : []).includes("stylesheet")) continue;
        const result = normalizeTransformAssetResult(await transformFn({
          url: asset.attrs.href,
          kind: "stylesheet"
        }));
        asset.attrs.href = result.href;
        if (result.crossOrigin) asset.attrs.crossOrigin = result.crossOrigin;
        else delete asset.attrs.crossOrigin;
      }
    }
  }
  const transformedClientEntry = normalizeTransformAssetResult(await transformFn({
    url: source.clientEntry,
    kind: "clientEntry"
  }));
  const rootRoute = manifest2.routes[rootRouteId] = manifest2.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  rootRoute.assets.push(buildClientEntryScriptTag(transformedClientEntry.href, source.injectedHeadScripts));
  return manifest2;
}
function buildManifestWithClientEntry(source) {
  const scriptTag = buildClientEntryScriptTag(source.clientEntry, source.injectedHeadScripts);
  const baseRootRoute = source.manifest.routes[rootRouteId];
  const routes = {
    ...source.manifest.routes,
    [rootRouteId]: {
      ...baseRootRoute,
      assets: [...baseRootRoute?.assets || [], scriptTag]
    }
  };
  return {
    inlineCss: source.manifest.inlineCss,
    routes
  };
}
var ServerFunctionSerializationAdapter = createSerializationAdapter({
  key: "$TSS/serverfn",
  test: (v) => {
    if (typeof v !== "function") return false;
    if (!(TSS_SERVER_FUNCTION in v)) return false;
    return !!v[TSS_SERVER_FUNCTION];
  },
  toSerializable: ({ serverFnMeta }) => ({ functionId: serverFnMeta.id }),
  fromSerializable: ({ functionId }) => {
    const fn = async (opts, signal) => {
      return (await (await getServerFnById(functionId))(opts ?? {}, signal)).result;
    };
    return fn;
  }
});
function getStartResponseHeaders(opts) {
  return mergeHeaders({ "Content-Type": "text/html; charset=utf-8" }, ...opts.router.stores.matches.get().map((match) => {
    return match.headers;
  }));
}
var entriesPromise;
var baseManifestPromise;
var cachedFinalManifestPromise;
async function loadEntries() {
  const [routerEntry, startEntry, pluginAdapters] = await Promise.all([
    import("./router-Cw6OHOsO.js").then((n) => n.Z),
    import("./start-DJk90e3f.js"),
    import("./__23tanstack-start-plugin-adapters-Cwee5PKy.js")
  ]);
  return {
    routerEntry,
    startEntry,
    pluginAdapters
  };
}
function getEntries() {
  if (!entriesPromise) entriesPromise = loadEntries();
  return entriesPromise;
}
function getBaseManifest(matchedRoutes) {
  if (!baseManifestPromise) baseManifestPromise = getStartManifest();
  return baseManifestPromise;
}
async function resolveManifest(matchedRoutes, transformFn, cache) {
  const base = await getBaseManifest();
  const computeFinalManifest = async () => {
    return transformFn ? await transformManifestAssets(base, transformFn) : buildManifestWithClientEntry(base);
  };
  if (!transformFn || cache) {
    if (!cachedFinalManifestPromise) cachedFinalManifestPromise = computeFinalManifest();
    return cachedFinalManifestPromise;
  }
  return computeFinalManifest();
}
var ROUTER_BASEPATH = "/";
var SERVER_FN_BASE = "/_serverFn/";
var IS_PRERENDERING = process.env.TSS_PRERENDERING === "true";
var IS_SHELL_ENV = process.env.TSS_SHELL === "true";
var ERR_NO_RESPONSE = "Internal Server Error";
var ERR_NO_DEFER = "Internal Server Error";
function throwRouteHandlerError() {
  throw new Error(ERR_NO_RESPONSE);
}
function throwIfMayNotDefer() {
  throw new Error(ERR_NO_DEFER);
}
function isSpecialResponse(value) {
  return value instanceof Response || isRedirect(value);
}
function handleCtxResult(result) {
  if (isSpecialResponse(result)) return { response: result };
  return result;
}
function executeMiddleware(middlewares, ctx) {
  let index = -1;
  const next = async (nextCtx) => {
    if (nextCtx) {
      if (nextCtx.context) ctx.context = safeObjectMerge(ctx.context, nextCtx.context);
      for (const key of Object.keys(nextCtx)) if (key !== "context") ctx[key] = nextCtx[key];
    }
    index++;
    const middleware = middlewares[index];
    if (!middleware) return ctx;
    let result;
    try {
      result = await middleware({
        ...ctx,
        next
      });
    } catch (err) {
      if (isSpecialResponse(err)) {
        ctx.response = err;
        return ctx;
      }
      throw err;
    }
    const normalized = handleCtxResult(result);
    if (normalized) {
      if (normalized.response !== void 0) ctx.response = normalized.response;
      if (normalized.context) ctx.context = safeObjectMerge(ctx.context, normalized.context);
    }
    return ctx;
  };
  return next();
}
function handlerToMiddleware(handler, mayDefer = false) {
  if (mayDefer) return handler;
  return async (ctx) => {
    const response = await handler({
      ...ctx,
      next: throwIfMayNotDefer
    });
    if (!response) throwRouteHandlerError();
    return response;
  };
}
function createStartHandler(cbOrOptions) {
  const cb = typeof cbOrOptions === "function" ? cbOrOptions : cbOrOptions.handler;
  const transformAssetsOption = typeof cbOrOptions === "function" ? void 0 : cbOrOptions.transformAssets;
  const transformAssetUrlsOption = typeof cbOrOptions === "function" ? void 0 : cbOrOptions.transformAssetUrls;
  const transformOption = transformAssetsOption !== void 0 ? resolveTransformAssetsConfig(transformAssetsOption) : transformAssetUrlsOption !== void 0 ? resolveTransformAssetsConfig(adaptTransformAssetUrlsConfigToTransformAssets(transformAssetUrlsOption)) : void 0;
  const warmupTransformManifest = !!transformAssetsOption && typeof transformAssetsOption === "object" && "warmup" in transformAssetsOption && transformAssetsOption.warmup === true || !!transformAssetUrlsOption && typeof transformAssetUrlsOption === "object" && transformAssetUrlsOption.warmup === true;
  const resolvedTransformConfig = transformOption;
  const cache = resolvedTransformConfig ? resolvedTransformConfig.cache : true;
  const shouldCacheCreateTransform = cache && true;
  let cachedCreateTransformPromise;
  const getTransformFn = async (opts) => {
    if (!resolvedTransformConfig) return void 0;
    if (resolvedTransformConfig.type === "createTransform") {
      if (shouldCacheCreateTransform) {
        if (!cachedCreateTransformPromise) cachedCreateTransformPromise = Promise.resolve(resolvedTransformConfig.createTransform(opts)).catch((error) => {
          cachedCreateTransformPromise = void 0;
          throw error;
        });
        return cachedCreateTransformPromise;
      }
      return resolvedTransformConfig.createTransform(opts);
    }
    return resolvedTransformConfig.transformFn;
  };
  if (warmupTransformManifest && cache && true && !cachedFinalManifestPromise) {
    const warmupPromise = (async () => {
      const base = await getBaseManifest();
      const transformFn = await getTransformFn({ warmup: true });
      return transformFn ? await transformManifestAssets(base, transformFn) : buildManifestWithClientEntry(base);
    })();
    cachedFinalManifestPromise = warmupPromise;
    warmupPromise.catch(() => {
      if (cachedFinalManifestPromise === warmupPromise) cachedFinalManifestPromise = void 0;
      cachedCreateTransformPromise = void 0;
    });
  }
  const startRequestResolver = async (request, requestOpts) => {
    let router = null;
    let cbWillCleanup = false;
    try {
      const { url, handledProtocolRelativeURL } = getNormalizedURL(request.url);
      const href = url.pathname + url.search + url.hash;
      const origin = getOrigin(request);
      if (handledProtocolRelativeURL) return Response.redirect(url, 308);
      const entries = await getEntries();
      const startOptions = await entries.startEntry.startInstance?.getOptions() || {};
      const { hasPluginAdapters, pluginSerializationAdapters } = entries.pluginAdapters;
      const serializationAdapters = [
        ...startOptions.serializationAdapters || [],
        ...hasPluginAdapters ? pluginSerializationAdapters : [],
        ServerFunctionSerializationAdapter
      ];
      const requestStartOptions = {
        ...startOptions,
        serializationAdapters
      };
      const flattenedRequestMiddlewares = startOptions.requestMiddleware ? flattenMiddlewares(startOptions.requestMiddleware) : [];
      const executedRequestMiddlewares = new Set(flattenedRequestMiddlewares);
      const getRouter = async () => {
        if (router) return router;
        router = await entries.routerEntry.getRouter();
        let isShell = IS_SHELL_ENV;
        if (IS_PRERENDERING && !isShell) isShell = request.headers.get(HEADERS.TSS_SHELL) === "true";
        const history = createMemoryHistory({ initialEntries: [href] });
        router.update({
          history,
          isShell,
          isPrerendering: IS_PRERENDERING,
          origin: router.options.origin ?? origin,
          defaultSsr: requestStartOptions.defaultSsr,
          serializationAdapters: [...requestStartOptions.serializationAdapters, ...router.options.serializationAdapters || []],
          basepath: ROUTER_BASEPATH
        });
        return router;
      };
      if (SERVER_FN_BASE && url.pathname.startsWith(SERVER_FN_BASE)) {
        const serverFnId = url.pathname.slice(SERVER_FN_BASE.length).split("/")[0];
        if (!serverFnId) throw new Error("Invalid server action param for serverFnId");
        const serverFnHandler = async ({ context }) => {
          return runWithStartContext({
            getRouter,
            startOptions: requestStartOptions,
            contextAfterGlobalMiddlewares: context,
            request,
            executedRequestMiddlewares,
            handlerType: "serverFn"
          }, () => handleServerAction({
            request,
            context: requestOpts?.context,
            serverFnId
          }));
        };
        return handleRedirectResponse((await executeMiddleware([...flattenedRequestMiddlewares.map((d) => d.options.server), serverFnHandler], {
          request,
          pathname: url.pathname,
          context: createNullProtoObject(requestOpts?.context)
        })).response, request, getRouter);
      }
      const executeRouter = async (serverContext, matchedRoutes) => {
        const acceptParts = (request.headers.get("Accept") || "*/*").split(",");
        if (!["*/*", "text/html"].some((mimeType) => acceptParts.some((part) => part.trim().startsWith(mimeType)))) return Response.json({ error: "Only HTML requests are supported here" }, { status: 500 });
        const manifest2 = await resolveManifest(matchedRoutes, await getTransformFn({
          warmup: false,
          request
        }), cache);
        const routerInstance = await getRouter();
        attachRouterServerSsrUtils({
          router: routerInstance,
          manifest: manifest2,
          getRequestAssets: () => getStartContext({ throwIfNotFound: false })?.requestAssets,
          includeUnmatchedRouteAssets: false
        });
        routerInstance.update({ additionalContext: { serverContext } });
        await routerInstance.load();
        if (routerInstance.state.redirect) return routerInstance.state.redirect;
        const ctx = getStartContext({ throwIfNotFound: false });
        await routerInstance.serverSsr.dehydrate({ requestAssets: ctx?.requestAssets });
        const responseHeaders = getStartResponseHeaders({ router: routerInstance });
        cbWillCleanup = true;
        return cb({
          request,
          router: routerInstance,
          responseHeaders
        });
      };
      const requestHandlerMiddleware = async ({ context }) => {
        return runWithStartContext({
          getRouter,
          startOptions: requestStartOptions,
          contextAfterGlobalMiddlewares: context,
          request,
          executedRequestMiddlewares,
          handlerType: "router"
        }, async () => {
          try {
            return await handleServerRoutes({
              getRouter,
              request,
              url,
              executeRouter,
              context,
              executedRequestMiddlewares
            });
          } catch (err) {
            if (err instanceof Response) return err;
            throw err;
          }
        });
      };
      return handleRedirectResponse((await executeMiddleware([...flattenedRequestMiddlewares.map((d) => d.options.server), requestHandlerMiddleware], {
        request,
        pathname: url.pathname,
        context: createNullProtoObject(requestOpts?.context)
      })).response, request, getRouter);
    } finally {
      if (router && !cbWillCleanup) router.serverSsr?.cleanup();
      router = null;
    }
  };
  return requestHandler(startRequestResolver);
}
async function handleRedirectResponse(response, request, getRouter) {
  if (!isRedirect(response)) return response;
  if (isResolvedRedirect(response)) {
    if (request.headers.get("x-tsr-serverFn") === "true") return Response.json({
      ...response.options,
      isSerializedRedirect: true
    }, { headers: response.headers });
    return response;
  }
  const opts = response.options;
  if (opts.to && typeof opts.to === "string" && !opts.to.startsWith("/")) throw new Error(`Server side redirects must use absolute paths via the 'href' or 'to' options. The redirect() method's "to" property accepts an internal path only. Use the "href" property to provide an external URL. Received: ${JSON.stringify(opts)}`);
  if ([
    "params",
    "search",
    "hash"
  ].some((d) => typeof opts[d] === "function")) throw new Error(`Server side redirects must use static search, params, and hash values and do not support functional values. Received functional values for: ${Object.keys(opts).filter((d) => typeof opts[d] === "function").map((d) => `"${d}"`).join(", ")}`);
  const redirect = (await getRouter()).resolveRedirect(response);
  if (request.headers.get("x-tsr-serverFn") === "true") return Response.json({
    ...response.options,
    isSerializedRedirect: true
  }, { headers: response.headers });
  return redirect;
}
async function handleServerRoutes({ getRouter, request, url, executeRouter, context, executedRequestMiddlewares }) {
  const router = await getRouter();
  const pathname = executeRewriteInput(router.rewrite, url).pathname;
  const { matchedRoutes, foundRoute, routeParams } = router.getMatchedRoutes(pathname);
  const isExactMatch = foundRoute && routeParams["**"] === void 0;
  const routeMiddlewares = [];
  for (const route of matchedRoutes) {
    const serverMiddleware = route.options.server?.middleware;
    if (serverMiddleware) {
      const flattened = flattenMiddlewares(serverMiddleware);
      for (const m of flattened) if (!executedRequestMiddlewares.has(m)) routeMiddlewares.push(m.options.server);
    }
  }
  const server2 = foundRoute?.options.server;
  if (server2?.handlers && isExactMatch) {
    const handlers = typeof server2.handlers === "function" ? server2.handlers({ createHandlers: (d) => d }) : server2.handlers;
    const handler = handlers[request.method.toUpperCase()] ?? handlers["ANY"];
    if (handler) {
      const mayDefer = !!foundRoute.options.component;
      if (typeof handler === "function") routeMiddlewares.push(handlerToMiddleware(handler, mayDefer));
      else {
        if (handler.middleware?.length) {
          const handlerMiddlewares = flattenMiddlewares(handler.middleware);
          for (const m of handlerMiddlewares) routeMiddlewares.push(m.options.server);
        }
        if (handler.handler) routeMiddlewares.push(handlerToMiddleware(handler.handler, mayDefer));
      }
    }
  }
  routeMiddlewares.push((ctx) => executeRouter(ctx.context, matchedRoutes));
  return (await executeMiddleware(routeMiddlewares, {
    request,
    context,
    params: routeParams,
    pathname
  })).response;
}
var fetch = createStartHandler(defaultStreamHandler);
function createServerEntry(entry) {
  return { async fetch(...args) {
    return await entry.fetch(...args);
  } };
}
var server_default = createServerEntry({ fetch });
const server = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createServerEntry,
  default: server_default
}, Symbol.toStringTag, { value: "Module" }));
export {
  TSS_SERVER_FUNCTION as T,
  getServerFnById as a,
  createServerFn as c,
  getRequest as g,
  server as s
};
