import { createHash, createHmac } from "crypto";
function sigv4Sign(payload, creds, target, host, region) {
  const service = "ProductAdvertisingAPI";
  const now = /* @__PURE__ */ new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = amzDate.slice(0, 8);
  const canonicalUri = "/paapi5/searchitems";
  const canonicalQuerystring = "";
  const canonicalHeaders = `content-encoding:amz-1.0
host:${host}
x-amz-date:${amzDate}
x-amz-target:${target}
`;
  const signedHeaders = "content-encoding;host;x-amz-date;x-amz-target";
  const payloadHash = createHash("sha256").update(payload).digest("hex");
  const canonicalRequest = [
    "POST",
    canonicalUri,
    canonicalQuerystring,
    canonicalHeaders,
    signedHeaders,
    payloadHash
  ].join("\n");
  const algorithm = "AWS4-HMAC-SHA256";
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const stringToSign = [
    algorithm,
    amzDate,
    credentialScope,
    createHash("sha256").update(canonicalRequest).digest("hex")
  ].join("\n");
  const kDate = createHmac("sha256", `AWS4${creds.secret_key}`).update(dateStamp).digest();
  const kRegion = createHmac("sha256", kDate).update(region).digest();
  const kService = createHmac("sha256", kRegion).update(service).digest();
  const kSigning = createHmac("sha256", kService).update("aws4_request").digest();
  const signature = createHmac("sha256", kSigning).update(stringToSign).digest("hex");
  const authorization = `${algorithm} Credential=${creds.access_key}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  return {
    headers: {
      "content-encoding": "amz-1.0",
      "content-type": "application/json; charset=utf-8",
      host,
      "x-amz-date": amzDate,
      "x-amz-target": target,
      authorization
    }
  };
}
const amazonClient = {
  async fetchOffers(creds, filters) {
    const host = creds.host || "webservices.amazon.com.br";
    const region = creds.region || "us-east-1";
    const marketplace = creds.marketplace || "www.amazon.com.br";
    const partnerTag = creds.partner_tag;
    if (!creds.access_key || !creds.secret_key || !partnerTag) return [];
    const keyword = filters.keywords && filters.keywords.length ? filters.keywords[0] : "ofertas";
    const payload = JSON.stringify({
      Keywords: keyword,
      Resources: [
        "Images.Primary.Large",
        "ItemInfo.Title",
        "Offers.Listings.Price",
        "Offers.Listings.SavingBasis"
      ],
      PartnerTag: partnerTag,
      PartnerType: "Associates",
      Marketplace: marketplace,
      ItemCount: 10,
      MinSavingPercent: filters.minDiscountPct || 1
    });
    const target = "com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems";
    const { headers } = sigv4Sign(payload, creds, target, host, region);
    const res = await fetch(`https://${host}/paapi5/searchitems`, {
      method: "POST",
      headers,
      body: payload
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Amazon PA-API ${res.status}: ${text.slice(0, 200)}`);
    }
    const data = await res.json();
    const items = data?.SearchResult?.Items ?? [];
    return items.map((it) => {
      const listing = it?.Offers?.Listings?.[0];
      const price = listing?.Price?.Amount;
      const oldPrice = listing?.SavingBasis?.Amount;
      const discount = price && oldPrice ? Math.round((oldPrice - price) / oldPrice * 100) : null;
      return {
        store: "amazon",
        externalId: it.ASIN,
        title: it?.ItemInfo?.Title?.DisplayValue ?? "Oferta Amazon",
        price: price ?? null,
        oldPrice: oldPrice ?? null,
        discountPct: discount,
        imageUrl: it?.Images?.Primary?.Large?.URL ?? null,
        productUrl: it?.DetailPageURL ?? `https://www.amazon.com.br/dp/${it.ASIN}?tag=${partnerTag}`,
        category: null,
        raw: it
      };
    });
  },
  buildAffiliateLink(creds, productUrl, subId) {
    const tag = creds.partner_tag;
    if (!tag) return productUrl;
    const url = new URL(productUrl);
    url.searchParams.set("tag", tag);
    url.searchParams.set("ascsubtag", subId);
    return url.toString();
  },
  async fetchConversions(_creds, _since) {
    return [];
  }
};
const ENDPOINT$1 = "https://open-api.affiliate.shopee.com.br/graphql";
function sign$1(appId, secret, payload, ts) {
  const base = `${appId}${ts}${payload}${secret}`;
  return createHash("sha256").update(base).digest("hex");
}
const shopeeClient = {
  async fetchOffers(creds, filters) {
    if (!creds.app_id || !creds.secret) return [];
    const keyword = filters.keywords?.[0] ?? "";
    const query = `{
      productOfferV2(keyword: "${keyword.replace(/"/g, '\\"')}", listType: 0, sortType: 2, page: 1, limit: 20) {
        nodes { itemId productName priceMin priceMax priceDiscountRate imageUrl productLink offerLink commissionRate }
      }
    }`;
    const body = JSON.stringify({ query });
    const ts = Math.floor(Date.now() / 1e3);
    const signature = sign$1(creds.app_id, creds.secret, body, ts);
    const res = await fetch(ENDPOINT$1, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `SHA256 Credential=${creds.app_id}, Timestamp=${ts}, Signature=${signature}`
      },
      body
    });
    if (!res.ok) throw new Error(`Shopee ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    const nodes = data?.data?.productOfferV2?.nodes ?? [];
    return nodes.map((n) => {
      const price = Number(n.priceMin);
      const discount = Math.round(Number(n.priceDiscountRate ?? 0));
      const oldPrice = discount > 0 ? +(price / (1 - discount / 100)).toFixed(2) : null;
      return {
        store: "shopee",
        externalId: String(n.itemId),
        title: n.productName,
        price,
        oldPrice,
        discountPct: discount || null,
        imageUrl: n.imageUrl,
        productUrl: n.offerLink || n.productLink,
        raw: n
      };
    });
  },
  buildAffiliateLink(_creds, productUrl, subId) {
    const url = new URL(productUrl);
    url.searchParams.set("sub_id1", subId);
    return url.toString();
  },
  async fetchConversions(_creds, _since) {
    return [];
  }
};
const ENDPOINT = "https://api-sg.aliexpress.com/sync";
function sign(params, secret) {
  const keys = Object.keys(params).sort();
  const concat = secret + keys.map((k) => `${k}${params[k]}`).join("") + secret;
  return createHash("md5").update(concat).digest("hex").toUpperCase();
}
const aliexpressClient = {
  async fetchOffers(creds, filters) {
    if (!creds.app_key || !creds.app_secret || !creds.tracking_id) return [];
    const params = {
      method: "aliexpress.affiliate.product.query",
      app_key: creds.app_key,
      timestamp: (/* @__PURE__ */ new Date()).toISOString().replace(/[-T:]/g, "").slice(0, 14),
      format: "json",
      v: "2.0",
      sign_method: "md5",
      tracking_id: creds.tracking_id,
      keywords: filters.keywords?.[0] ?? "smartphone",
      page_size: "20",
      sort: "SALE_PRICE_ASC"
    };
    params.sign = sign(params, creds.app_secret);
    const res = await fetch(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(params).toString()
    });
    if (!res.ok) throw new Error(`AliExpress ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    const products = data?.aliexpress_affiliate_product_query_response?.resp_result?.result?.products?.product ?? [];
    return products.map((p) => {
      const price = Number(p.target_sale_price ?? p.sale_price ?? 0);
      const oldPrice = Number(p.target_original_price ?? p.original_price ?? 0) || null;
      const discount = p.discount ? parseInt(String(p.discount).replace(/\D/g, ""), 10) : null;
      return {
        store: "aliexpress",
        externalId: String(p.product_id),
        title: p.product_title,
        price,
        oldPrice,
        discountPct: discount,
        imageUrl: p.product_main_image_url,
        productUrl: p.promotion_link || p.product_detail_url,
        category: p.first_level_category_name ?? null,
        raw: p
      };
    });
  },
  buildAffiliateLink(_creds, productUrl, subId) {
    const url = new URL(productUrl);
    url.searchParams.set("sub_id", subId);
    return url.toString();
  },
  async fetchConversions(_creds, _since) {
    return [];
  }
};
const mercadolivreClient = {
  async fetchOffers(creds, filters) {
    const siteId = creds.site_id || "MLB";
    const q = encodeURIComponent(filters.keywords?.[0] ?? "promocao");
    const url = `https://api.mercadolibre.com/sites/${siteId}/search?q=${q}&limit=20&sort=price_asc`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Mercado Livre ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    const items = data?.results ?? [];
    return items.filter((it) => {
      const disc = it.original_price ? Math.round((it.original_price - it.price) / it.original_price * 100) : 0;
      return disc >= (filters.minDiscountPct ?? 0);
    }).map((it) => {
      const discount = it.original_price ? Math.round((it.original_price - it.price) / it.original_price * 100) : null;
      return {
        store: "mercadolivre",
        externalId: it.id,
        title: it.title,
        price: it.price,
        oldPrice: it.original_price ?? null,
        discountPct: discount,
        imageUrl: it.thumbnail?.replace("-I.jpg", "-O.jpg") ?? it.thumbnail,
        productUrl: it.permalink,
        category: it.category_id ?? null,
        raw: it
      };
    });
  },
  buildAffiliateLink(creds, productUrl, subId) {
    const aff = creds.affiliate_id;
    if (!aff) return productUrl;
    const u = new URL(productUrl);
    u.searchParams.set("matt_word", subId);
    u.searchParams.set("matt_tool", aff);
    return u.toString();
  },
  async fetchConversions(_creds, _since) {
    return [];
  }
};
function makeStub$1(qsKey) {
  return {
    async fetchOffers() {
      return [];
    },
    buildAffiliateLink(creds, productUrl, subId) {
      try {
        const url = new URL(productUrl);
        const aff = creds.aff_id || creds.affiliate_id || creds.partner_id;
        if (aff) url.searchParams.set(qsKey, aff);
        if (subId) url.searchParams.set("sub_id", subId);
        return url.toString();
      } catch {
        return productUrl;
      }
    },
    async fetchConversions() {
      return [];
    }
  };
}
const privacyClient = makeStub$1("aff");
const crakrevenueClient = makeStub$1("aff");
const awempireClient = makeStub$1("aff");
function makeStub(trackerKey) {
  return {
    async fetchOffers() {
      return [];
    },
    buildAffiliateLink(creds, productUrl, subId) {
      try {
        const url = new URL(productUrl);
        const tracker = creds.btag || creds.affiliate_id || creds.tracker_id || creds.partner_id;
        if (tracker) url.searchParams.set(trackerKey, tracker);
        if (subId) url.searchParams.set("sub_id", subId);
        return url.toString();
      } catch {
        return productUrl;
      }
    },
    async fetchConversions() {
      return [];
    }
  };
}
const bet365Client = makeStub("affid");
const betanoClient = makeStub("btag");
const blazeClient = makeStub("ref");
const ktoClient = makeStub("btag");
const sportingbetClient = makeStub("btag");
const STORE_CLIENTS = {
  amazon: amazonClient,
  shopee: shopeeClient,
  aliexpress: aliexpressClient,
  mercadolivre: mercadolivreClient,
  privacy: privacyClient,
  crakrevenue: crakrevenueClient,
  awempire: awempireClient,
  bet365: bet365Client,
  betano: betanoClient,
  blaze: blazeClient,
  kto: ktoClient,
  sportingbet: sportingbetClient
};
export {
  STORE_CLIENTS
};
