import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { u as useAuth, B as Button, C as Card } from "./router-Cw6OHOsO.js";
import { Sparkles, Send, Bot, Zap, TrendingUp, Users, Shield, Trophy, LineChart, Flame, GraduationCap, ShoppingBag } from "lucide-react";
import "@tanstack/react-query";
import "react";
import "./client-bD0og8Nx.js";
import "@supabase/supabase-js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const features = [{
  icon: Bot,
  title: "Bots inteligentes",
  desc: "Boas-vindas, follow-up e encaminhador automático para escalar atendimento sem time."
}, {
  icon: Zap,
  title: "Envios agendados",
  desc: "Sinais, prévias, lembretes e promoções disparados na hora certa, em todos os grupos."
}, {
  icon: TrendingUp,
  title: "Tracking nativo",
  desc: "Pixels, postbacks e Meta CAPI integrados para medir cada clique e conversão."
}, {
  icon: Users,
  title: "Gestão de membros",
  desc: "Controle de acesso VIP, expiração automática e fluxos de upsell prontos."
}, {
  icon: Sparkles,
  title: "Emojis Premium",
  desc: "Mensagens que se destacam com emojis premium e templates de alta conversão."
}, {
  icon: Shield,
  title: "Cloud seguro",
  desc: "Banco gerenciado, RLS e backups automáticos — sem precisar configurar servidor."
}];
const niches = [{
  icon: Trophy,
  title: "iGaming",
  desc: "Sinais de cassino, odds esportivas e afiliados de casas de aposta."
}, {
  icon: LineChart,
  title: "OB (Opportunity Bets)",
  desc: "Sinais de operações binárias com martingale, soros e gestão de banca automatizada."
}, {
  icon: Flame,
  title: "Hot",
  desc: "Funis VIP, prévias agendadas e promoções de redes adultas."
}, {
  icon: GraduationCap,
  title: "Experts",
  desc: "Aulas, lembretes e funis de venda de mentoria/curso."
}, {
  icon: ShoppingBag,
  title: "Promoções",
  desc: "Amazon, Shopee, Mercado Livre e AliExpress com link de afiliado."
}];
function LandingPage() {
  const {
    user
  } = useAuth();
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen relative overflow-hidden bg-background text-foreground", children: [
    /* @__PURE__ */ jsx("div", { className: "absolute inset-0 grid-bg opacity-40 pointer-events-none" }),
    /* @__PURE__ */ jsx("div", { className: "absolute -top-40 -left-40 size-[520px] rounded-full cyber-gradient opacity-25 blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsx("div", { className: "absolute top-1/3 -right-40 size-[560px] rounded-full cyber-gradient opacity-20 blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsxs("header", { className: "relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("img", { src: "/favicon.png", alt: "TeleSignal", className: "size-9 rounded-xl neon-glow" }),
        /* @__PURE__ */ jsx("span", { className: "font-bold tracking-tight cyber-text", children: "TeleSignal" })
      ] }),
      /* @__PURE__ */ jsxs("nav", { className: "hidden md:flex items-center gap-6 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsx("a", { href: "#recursos", className: "hover:text-foreground transition-colors", children: "Recursos" }),
        /* @__PURE__ */ jsx("a", { href: "#nichos", className: "hover:text-foreground transition-colors", children: "Nichos" }),
        /* @__PURE__ */ jsx("a", { href: "#comecar", className: "hover:text-foreground transition-colors", children: "Começar" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: user ? /* @__PURE__ */ jsx(Button, { asChild: true, className: "cyber-gradient text-primary-foreground border-0 hover:opacity-90 neon-glow", children: /* @__PURE__ */ jsx(Link, { to: "/dashboard", children: "Ir para o painel" }) }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Button, { asChild: true, variant: "ghost", children: /* @__PURE__ */ jsx(Link, { to: "/login", children: "Entrar" }) }),
        /* @__PURE__ */ jsx(Button, { asChild: true, className: "cyber-gradient text-primary-foreground border-0 hover:opacity-90 neon-glow", children: /* @__PURE__ */ jsx(Link, { to: "/signup", children: "Cadastrar-se" }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "relative z-10 mx-auto max-w-5xl px-6 pt-16 pb-24 text-center", children: [
      /* @__PURE__ */ jsxs("div", { className: "inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs text-muted-foreground backdrop-blur", children: [
        /* @__PURE__ */ jsx(Sparkles, { className: "size-3.5 text-primary" }),
        "Automação Telegram all-in-one"
      ] }),
      /* @__PURE__ */ jsxs("h1", { className: "mt-6 text-5xl md:text-7xl font-bold tracking-tight", children: [
        "Escale sua operação no ",
        /* @__PURE__ */ jsx("span", { className: "cyber-text", children: "Telegram" }),
        " no piloto automático"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto mt-6 max-w-2xl text-lg text-muted-foreground", children: "Crie bots, dispare sinais, gerencie membros VIP, rode promoções de afiliado e acompanhe cada conversão — tudo a partir de um painel único." }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 flex flex-wrap justify-center gap-3", children: [
        /* @__PURE__ */ jsx(Button, { asChild: true, size: "lg", className: "cyber-gradient text-primary-foreground border-0 hover:opacity-90 neon-glow", children: /* @__PURE__ */ jsxs(Link, { to: "/signup", children: [
          /* @__PURE__ */ jsx(Send, { className: "size-4" }),
          " Criar conta grátis"
        ] }) }),
        /* @__PURE__ */ jsx(Button, { asChild: true, size: "lg", variant: "outline", children: /* @__PURE__ */ jsx(Link, { to: "/login", children: "Já tenho conta" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("section", { id: "recursos", className: "relative z-10 mx-auto max-w-6xl px-6 pb-24 scroll-mt-24", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-12 text-center", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight", children: "Tudo que você precisa em um lugar" }),
        /* @__PURE__ */ jsx("p", { className: "mt-3 text-muted-foreground", children: "Pare de juntar 5 ferramentas. O TeleSignal faz o trabalho pesado." })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3", children: features.map((f) => /* @__PURE__ */ jsxs(Card, { className: "p-6 glass-strong cyber-border rounded-2xl border-0", children: [
        /* @__PURE__ */ jsx("div", { className: "flex size-11 items-center justify-center rounded-xl cyber-gradient neon-glow", children: /* @__PURE__ */ jsx(f.icon, { className: "size-5 text-primary-foreground" }) }),
        /* @__PURE__ */ jsx("h3", { className: "mt-4 text-lg font-semibold", children: f.title }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: f.desc })
      ] }, f.title)) })
    ] }),
    /* @__PURE__ */ jsxs("section", { id: "nichos", className: "relative z-10 mx-auto max-w-6xl px-6 pb-24 scroll-mt-24", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-12 text-center", children: [
        /* @__PURE__ */ jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight", children: "Feito para o seu nicho" }),
        /* @__PURE__ */ jsx("p", { className: "mt-3 text-muted-foreground", children: "Templates e automações prontas para cada tipo de operação." })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid gap-4 md:grid-cols-2 lg:grid-cols-5", children: niches.map((n) => /* @__PURE__ */ jsxs(Card, { className: "p-6 glass-strong cyber-border rounded-2xl border-0", children: [
        /* @__PURE__ */ jsx(n.icon, { className: "size-7 text-primary" }),
        /* @__PURE__ */ jsx("h3", { className: "mt-4 text-lg font-semibold", children: n.title }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: n.desc })
      ] }, n.title)) })
    ] }),
    /* @__PURE__ */ jsx("section", { id: "comecar", className: "relative z-10 mx-auto max-w-4xl px-6 pb-24 scroll-mt-24", children: /* @__PURE__ */ jsxs(Card, { className: "p-10 md:p-14 text-center glass-strong cyber-border neon-glow rounded-3xl border-0", children: [
      /* @__PURE__ */ jsxs("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight", children: [
        "Comece em ",
        /* @__PURE__ */ jsx("span", { className: "cyber-text", children: "minutos" })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mx-auto mt-4 max-w-xl text-muted-foreground", children: "Crie sua conta gratuita, conecte seu bot do Telegram e dispare a primeira automação ainda hoje." }),
      /* @__PURE__ */ jsxs("div", { className: "mt-8 flex flex-wrap justify-center gap-3", children: [
        /* @__PURE__ */ jsx(Button, { asChild: true, size: "lg", className: "cyber-gradient text-primary-foreground border-0 hover:opacity-90 neon-glow", children: /* @__PURE__ */ jsx(Link, { to: "/signup", children: "Cadastrar-se" }) }),
        /* @__PURE__ */ jsx(Button, { asChild: true, size: "lg", variant: "outline", children: /* @__PURE__ */ jsx(Link, { to: "/login", children: "Entrar" }) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs("footer", { className: "relative z-10 border-t border-border/50 py-8 text-center text-sm text-muted-foreground", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " TeleSignal — Automação Telegram"
    ] })
  ] });
}
export {
  LandingPage as component
};
