import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { toast } from "sonner";
import { P as POSTBACK_EVENTS_BY_MODE, c as createPostback, t as testPostback, l as listPostbacks, d as deletePostback } from "./tracking.functions-jGKb0ig9.js";
import { D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, h as DialogHeader, i as DialogTitle, L as Label, I as Input, C as Card, x as CardContent, H as Badge } from "./router-Cw6OHOsO.js";
import { Repeat, Plus, Trash2, BadgeDollarSign, CreditCard, ShoppingCart, UserPlus, DoorOpen, Megaphone, MousePointer, FileText } from "lucide-react";
import { u as usePixelFilter, P as PixelFilterBar } from "./PixelFilter-FzJuz8YB.js";
import "@tanstack/react-router";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const EVENT_META = {
  viewpage: {
    label: "ViewPage",
    icon: /* @__PURE__ */ jsx(FileText, { className: "size-6" }),
    color: "text-slate-300"
  },
  click_button: {
    label: "Clique no Botão",
    icon: /* @__PURE__ */ jsx(MousePointer, { className: "size-6" }),
    color: "text-slate-300"
  },
  channel_enter: {
    label: "Entrada no Canal",
    icon: /* @__PURE__ */ jsx(Megaphone, { className: "size-6" }),
    color: "text-pink-500"
  },
  channel_leave: {
    label: "Saída do Canal",
    icon: /* @__PURE__ */ jsx(DoorOpen, { className: "size-6" }),
    color: "text-amber-500"
  },
  lead: {
    label: "Lead",
    icon: /* @__PURE__ */ jsx(UserPlus, { className: "size-6" }),
    color: "text-blue-400"
  },
  checkout_started: {
    label: "Iniciou Checkout",
    icon: /* @__PURE__ */ jsx(ShoppingCart, { className: "size-6" }),
    color: "text-cyan-400"
  },
  payment_info: {
    label: "Dados Pagamento",
    icon: /* @__PURE__ */ jsx(CreditCard, { className: "size-6" }),
    color: "text-violet-400"
  },
  purchase: {
    label: "Compra",
    icon: /* @__PURE__ */ jsx(BadgeDollarSign, { className: "size-6" }),
    color: "text-emerald-500"
  }
};
function PostbacksPage() {
  const {
    pixelId,
    pixels,
    setPixel
  } = usePixelFilter();
  const effectiveId = pixelId ?? pixels[0]?.id ?? null;
  const currentPixel = pixels.find((p) => p.id === effectiveId);
  const mode = currentPixel?.tracking_mode ?? "telegram";
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Repeat, { className: "size-6" }),
          " Postbacks"
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground mt-1", children: [
          "Dispare webhooks customizados nos eventos do seu funil",
          currentPixel ? ` · modo ${mode === "direct_response" ? "Direct Response" : "Telegram"}` : "",
          "."
        ] })
      ] }),
      effectiveId && /* @__PURE__ */ jsx(NewPostbackDialog, { pixelId: effectiveId, mode })
    ] }),
    /* @__PURE__ */ jsx(PixelFilterBar, { pixelId: effectiveId, pixels, setPixel }),
    effectiveId ? /* @__PURE__ */ jsx(PostbacksList, { pixelId: effectiveId }) : /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Crie um pixel para configurar postbacks." })
  ] });
}
function PostbacksList({
  pixelId
}) {
  const listFn = useServerFn(listPostbacks);
  const delFn = useServerFn(deletePostback);
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["postbacks", pixelId],
    queryFn: () => listFn({
      data: {
        pixel_id: pixelId
      }
    })
  });
  const del = useMutation({
    mutationFn: (id) => delFn({
      data: {
        id
      }
    }),
    onSuccess: () => {
      qc.invalidateQueries({
        queryKey: ["postbacks", pixelId]
      });
      toast.success("Postback removido");
    }
  });
  if (!q.data || q.data.length === 0) {
    return /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsx(CardContent, { className: "p-8 text-center text-sm text-muted-foreground", children: 'Nenhum postback configurado. Clique em "Novo Postback".' }) });
  }
  return /* @__PURE__ */ jsx("div", { className: "grid gap-2", children: q.data.map((p) => {
    const meta = EVENT_META[p.event];
    return /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "p-4 flex items-center gap-3", children: [
      /* @__PURE__ */ jsx("div", { className: meta?.color, children: meta?.icon }),
      /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium truncate", children: p.name }),
          /* @__PURE__ */ jsx(Badge, { variant: "outline", className: "text-[10px]", children: meta?.label })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground font-mono truncate", children: p.url })
      ] }),
      /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => del.mutate(p.id), children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
    ] }) }, p.id);
  }) });
}
function NewPostbackDialog({
  pixelId,
  mode
}) {
  const [open, setOpen] = useState(false);
  const [event, setEvent] = useState(null);
  const allowedEvents = POSTBACK_EVENTS_BY_MODE[mode];
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const createFn = useServerFn(createPostback);
  const testFn = useServerFn(testPostback);
  const qc = useQueryClient();
  const create = useMutation({
    mutationFn: () => createFn({
      data: {
        pixel_id: pixelId,
        name,
        url,
        event,
        is_active: true
      }
    }),
    onSuccess: () => {
      qc.invalidateQueries({
        queryKey: ["postbacks", pixelId]
      });
      toast.success("Postback criado");
      setOpen(false);
      setEvent(null);
      setName("");
      setUrl("");
    },
    onError: (e) => toast.error(e?.message ?? "Erro ao salvar")
  });
  const test = useMutation({
    mutationFn: () => testFn({
      data: {
        url
      }
    }),
    onSuccess: (r) => r.ok ? toast.success(`Postback OK (HTTP ${r.status})`) : toast.error(`Falhou (HTTP ${r.status})`),
    onError: (e) => toast.error(e?.message ?? "Erro de teste")
  });
  const canSave = !!event && name.trim().length > 0 && /^https?:\/\//.test(url);
  const canTest = /^https?:\/\//.test(url);
  return /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { className: "gap-2", children: [
      /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
      " Novo Postback"
    ] }) }),
    /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-3xl", children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Novo Postback" }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsxs("div", { className: "rounded-lg border p-4 space-y-3", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Escolha o evento do Postback" }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: allowedEvents.map((ev) => {
            const m = EVENT_META[ev];
            const active = event === ev;
            return /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => setEvent(ev), className: `rounded-lg border p-4 flex flex-col items-center gap-2 text-sm transition-colors ${active ? "border-primary bg-primary/10" : "bg-muted/30 hover:bg-muted/60"}`, children: [
              /* @__PURE__ */ jsx("span", { className: m.color, children: m.icon }),
              /* @__PURE__ */ jsx("span", { children: m.label })
            ] }, ev);
          }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsx(Label, { children: "Nome" }),
            /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), placeholder: "Digite o Nome do Postback" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsx(Label, { children: "URL" }),
            /* @__PURE__ */ jsx(Input, { value: url, onChange: (e) => setUrl(e.target.value), placeholder: "www.exemplo.com" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-2", children: [
          /* @__PURE__ */ jsx(Button, { variant: "secondary", disabled: !canTest || test.isPending, onClick: () => test.mutate(), children: test.isPending ? "Testando..." : "Testar Postback" }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setOpen(false), children: "Cancelar" }),
            /* @__PURE__ */ jsx(Button, { disabled: !canSave || create.isPending, onClick: () => create.mutate(), children: create.isPending ? "Salvando..." : "Salvar" })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  PostbacksPage as component
};
