import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { createHash } from "crypto";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
function publicBaseUrl() {
  const explicit = process.env.PUBLIC_BASE_URL;
  if (explicit) return explicit.replace(/\/$/, "");
  return `https://telesignal.com.br`;
}
const ALLOWED_UPDATES = ["chat_member", "my_chat_member", "message", "channel_post"];
function webhookUrlFor(accountId) {
  return `${publicBaseUrl()}/api/public/telegram/webhook/${accountId}`;
}
function webhookSecretFor(botToken) {
  return createHash("sha256").update(`tg-tracking:${botToken}`).digest("base64url");
}
async function* drainPendingUpdates(accountId, botToken) {
  const url = webhookUrlFor(accountId);
  const secret = webhookSecretFor(botToken);
  let offset;
  let processed = 0;
  let errors = 0;
  let total = 0;
  for (let i = 0; i < 100; i++) {
    const r = await callTelegram(botToken, "getUpdates", {
      offset,
      limit: 100,
      timeout: 0,
      allowed_updates: ALLOWED_UPDATES
    });
    if (!r.ok) throw new Error(r.description ?? "getUpdates falhou");
    const batch = r.result ?? [];
    if (batch.length === 0) break;
    total += batch.length;
    yield {
      phase: "draining",
      processed,
      errors,
      total
    };
    for (const upd of batch) {
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-telegram-bot-api-secret-token": secret
          },
          body: JSON.stringify(upd)
        });
        if (resp.ok) processed++;
        else errors++;
      } catch {
        errors++;
      }
      offset = upd.update_id + 1;
    }
    yield {
      phase: "draining",
      processed,
      errors,
      total
    };
    if (batch.length < 100) break;
  }
  return {
    processed,
    errors,
    total
  };
}
const enableMemberTracking_createServerFn_handler = createServerRpc({
  id: "73562d24cd31fbd26f4cab24ac3b6e132c58ee857d20f8bbae7d26c33088d38a",
  name: "enableMemberTracking",
  filename: "src/lib/telegram-tracking.functions.ts"
}, (opts) => enableMemberTracking.__executeServer(opts));
const enableMemberTracking = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(enableMemberTracking_createServerFn_handler, async function* ({
  data,
  context
}) {
  const {
    supabase
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("id, bot_token").eq("id", data.accountId).maybeSingle();
  if (error || !acc?.bot_token) throw new Error("Conta não encontrada");
  const url = webhookUrlFor(acc.id);
  const secret = webhookSecretFor(acc.bot_token);
  yield {
    phase: "preparing",
    processed: 0,
    errors: 0,
    total: 0
  };
  await callTelegram(acc.bot_token, "deleteWebhook", {
    drop_pending_updates: false
  });
  let processed = 0;
  let errors = 0;
  let total = 0;
  try {
    for await (const p of drainPendingUpdates(acc.id, acc.bot_token)) {
      processed = p.processed;
      errors = p.errors;
      total = p.total;
      yield p;
    }
  } catch (e) {
    yield {
      phase: "drain_error",
      processed,
      errors,
      total,
      message: e instanceof Error ? e.message : String(e)
    };
  }
  yield {
    phase: "registering",
    processed,
    errors,
    total
  };
  const r = await callTelegram(acc.bot_token, "setWebhook", {
    url,
    secret_token: secret,
    allowed_updates: ALLOWED_UPDATES,
    drop_pending_updates: false
  });
  if (!r.ok) {
    await supabase.from("telegram_accounts").update({
      member_tracking_last_check: (/* @__PURE__ */ new Date()).toISOString(),
      member_tracking_last_error: r.description ?? "setWebhook falhou"
    }).eq("id", acc.id);
    throw new Error(r.description ?? "Falha ao registrar webhook");
  }
  await supabase.from("telegram_accounts").update({
    member_tracking_enabled: true,
    member_tracking_last_check: (/* @__PURE__ */ new Date()).toISOString(),
    member_tracking_last_error: null
  }).eq("id", acc.id);
  yield {
    phase: "done",
    processed,
    errors,
    total,
    url
  };
});
const disableMemberTracking_createServerFn_handler = createServerRpc({
  id: "466f3e9f548b02e4b45cb9628872cce1539e03478760d01fe3a29070c2fc5b91",
  name: "disableMemberTracking",
  filename: "src/lib/telegram-tracking.functions.ts"
}, (opts) => disableMemberTracking.__executeServer(opts));
const disableMemberTracking = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(disableMemberTracking_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: acc
  } = await supabase.from("telegram_accounts").select("bot_token").eq("id", data.accountId).maybeSingle();
  if (!acc) throw new Error("Conta não encontrada");
  const r = await callTelegram(acc.bot_token, "deleteWebhook", {});
  if (!r.ok) throw new Error(r.description ?? "Falha");
  await supabase.from("telegram_accounts").update({
    member_tracking_enabled: false,
    member_tracking_last_check: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", data.accountId);
  return {
    ok: true
  };
});
const getMemberStats_createServerFn_handler = createServerRpc({
  id: "6d56c54f8361e3f4a856af7bdd3239d6c8196c320aec96e6194653ea5841d2f9",
  name: "getMemberStats",
  filename: "src/lib/telegram-tracking.functions.ts"
}, (opts) => getMemberStats.__executeServer(opts));
const getMemberStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  from: z.string().optional(),
  to: z.string().optional()
}).optional().parse(d ?? {})).handler(getMemberStats_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const TZ = "America/Sao_Paulo";
  const dayInTZ = (d) => new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(d);
  const tzDayBoundary = (ymd, end) => {
    const time = end ? "23:59:59.999" : "00:00:00.000";
    return /* @__PURE__ */ new Date(`${ymd}T${time}-03:00`);
  };
  const todayYmd = dayInTZ(/* @__PURE__ */ new Date());
  const defaultFromYmd = dayInTZ(new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3));
  const fromYmd = data?.from || defaultFromYmd;
  const toYmd = data?.to || todayYmd;
  const since = tzDayBoundary(fromYmd, false).toISOString();
  const until = tzDayBoundary(toYmd, true).toISOString();
  const [{
    data: events
  }, {
    data: recent
  }] = await Promise.all([supabase.from("telegram_member_events").select("event_type, occurred_at, chat_id, chat_title").gte("occurred_at", since).lte("occurred_at", until).order("occurred_at", {
    ascending: false
  }).limit(5e3), supabase.from("telegram_member_events").select("id, chat_title, chat_id, tg_first_name, tg_username, event_type, occurred_at").gte("occurred_at", since).lte("occurred_at", until).order("occurred_at", {
    ascending: false
  }).limit(200)]);
  const list = events ?? [];
  let joinsToday = 0;
  let leavesToday = 0;
  let joins30 = 0;
  let leaves30 = 0;
  const byDay = /* @__PURE__ */ new Map();
  const byChat = /* @__PURE__ */ new Map();
  for (const e of list) {
    const occurred = new Date(e.occurred_at);
    const day = dayInTZ(occurred);
    const bd = byDay.get(day) ?? {
      day,
      joins: 0,
      leaves: 0
    };
    const isJoin = e.event_type === "join";
    const isLeave = e.event_type === "leave" || e.event_type === "kicked";
    if (isJoin) {
      joins30++;
      bd.joins++;
      if (day === todayYmd) joinsToday++;
    }
    if (isLeave) {
      leaves30++;
      bd.leaves++;
      if (day === todayYmd) leavesToday++;
    }
    byDay.set(day, bd);
    const bc = byChat.get(e.chat_id) ?? {
      chat_id: e.chat_id,
      chat_title: e.chat_title,
      joins: 0,
      leaves: 0
    };
    if (isJoin) bc.joins++;
    if (isLeave) bc.leaves++;
    byChat.set(e.chat_id, bc);
  }
  return {
    joinsToday,
    leavesToday,
    joins30,
    leaves30,
    net30: joins30 - leaves30,
    daily: Array.from(byDay.values()).sort((a, b) => a.day.localeCompare(b.day)),
    perChat: Array.from(byChat.values()).sort((a, b) => b.joins - a.joins),
    recent: recent ?? []
  };
});
const getCurrentMemberCounts_createServerFn_handler = createServerRpc({
  id: "636af64b9c4b9e724ed8981b4acc7661c7099eb373fab9234898005009f700e0",
  name: "getCurrentMemberCounts",
  filename: "src/lib/telegram-tracking.functions.ts"
}, (opts) => getCurrentMemberCounts.__executeServer(opts));
const getCurrentMemberCounts = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getCurrentMemberCounts_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: rooms,
    error
  } = await supabase.from("rooms").select("id, name, default_account_id, premium_account_id").eq("is_active", true).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  const roomIds = (rooms ?? []).map((room) => room.id);
  const {
    data: chats,
    error: chatsError
  } = await supabase.from("room_chats").select("room_id, chat_id, chat_title").in("room_id", roomIds.length ? roomIds : ["00000000-0000-0000-0000-000000000000"]);
  if (chatsError) throw new Error(chatsError.message);
  const chatsByRoom = /* @__PURE__ */ new Map();
  for (const chat of chats ?? []) {
    const roomChats = chatsByRoom.get(chat.room_id) ?? [];
    roomChats.push(chat);
    chatsByRoom.set(chat.room_id, roomChats);
  }
  const accountIds = Array.from(new Set((rooms ?? []).map((room) => room.default_account_id ?? room.premium_account_id).filter(Boolean)));
  const {
    data: accounts,
    error: accountsError
  } = await supabase.from("telegram_accounts").select("id, bot_token, label, bot_username").in("id", accountIds.length ? accountIds : ["00000000-0000-0000-0000-000000000000"]);
  if (accountsError) throw new Error(accountsError.message);
  const accountById = new Map((accounts ?? []).map((account) => [account.id, account]));
  const results = [];
  for (const room of rooms ?? []) {
    const accountId = room.default_account_id ?? room.premium_account_id;
    const account = accountId ? accountById.get(accountId) : null;
    for (const chat of chatsByRoom.get(room.id) ?? []) {
      if (!account?.bot_token) {
        results.push({
          roomId: room.id,
          roomName: room.name,
          chatId: chat.chat_id,
          chatTitle: chat.chat_title,
          accountLabel: account?.label ?? null,
          count: null,
          error: "Sala sem bot padrão com token.",
          chatType: "unknown"
        });
        continue;
      }
      const [response, info] = await Promise.all([callTelegram(account.bot_token, "getChatMemberCount", {
        chat_id: chat.chat_id
      }), callTelegram(account.bot_token, "getChat", {
        chat_id: chat.chat_id
      })]);
      const tgType = info.ok ? info.result?.type : void 0;
      const chatType = tgType === "channel" ? "channel" : tgType === "group" || tgType === "supergroup" ? "group" : "unknown";
      results.push({
        roomId: room.id,
        roomName: room.name,
        chatId: chat.chat_id,
        chatTitle: chat.chat_title,
        accountLabel: account.label ?? account.bot_username ?? null,
        count: response.ok ? response.result ?? 0 : null,
        error: response.ok ? null : response.description ?? "Falha ao consultar membros.",
        chatType
      });
    }
  }
  return {
    total: results.reduce((sum, row) => sum + (row.count ?? 0), 0),
    chats: results
  };
});
export {
  disableMemberTracking_createServerFn_handler,
  enableMemberTracking_createServerFn_handler,
  getCurrentMemberCounts_createServerFn_handler,
  getMemberStats_createServerFn_handler
};
