import{c as o}from"./index-BK9Ovhoc.js";const a=[["path",{d:"m15 17 5-5-5-5",key:"nf172w"}],["path",{d:"M4 18v-2a4 4 0 0 1 4-4h12",key:"jmiej9"}]],r=o("forward",a);export{r as F};
