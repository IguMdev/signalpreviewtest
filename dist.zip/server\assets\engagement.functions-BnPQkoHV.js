import { T as TSS_SERVER_FUNCTION, a as getServerFnById, c as createServerFn } from "./server-Bg62lSXL.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
var createSsrRpc = (functionId) => {
  const url = "/_serverFn/" + functionId;
  const serverFnMeta = { id: functionId };
  const fn = async (...args) => {
    return (await getServerFnById(functionId))(...args);
  };
  return Object.assign(fn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const N1PANEL_URL = "https://n1panel.com/api/v2";
const DEFAULT_N1_REACTIONS_SERVICE_ID = 3205;
const DEFAULT_N1_MEMBERS_SERVICE_ID = 3310;
function normalizeTelegramLink(input) {
  if (!input) return null;
  let raw = input.trim();
  if (!raw) return null;
  raw = raw.replace(/[\u200B-\u200D\uFEFF]/g, "");
  if (raw.startsWith("@")) raw = raw.slice(1);
  if (/^(t\.me|telegram\.me)\//i.test(raw)) raw = `https://${raw}`;
  if (!/^https?:\/\//i.test(raw) && !raw.includes("/")) {
    if (!/^[a-zA-Z0-9_]{4,64}$/.test(raw)) return null;
    return `https://t.me/${raw}`;
  }
  let url;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  const host = url.hostname.toLowerCase();
  if (host !== "t.me" && host !== "telegram.me") return null;
  const segs = url.pathname.split("/").filter(Boolean);
  if (segs.length === 0) return null;
  const first = segs[0];
  if (first.toLowerCase() === "joinchat" || first.startsWith("+")) return null;
  if (!/^[a-zA-Z0-9_]{4,64}$/.test(first)) return null;
  if (segs.length >= 2 && !/^\d+$/.test(segs[1])) return null;
  const path = segs.slice(0, 2).join("/");
  return `https://t.me/${path}`;
}
const listEngagementPlans = createServerFn({
  method: "GET"
}).handler(createSsrRpc("1bd6e0100cdd735b7b3aee9616caffc00f4cf2497c9b6ebcd94c7a0c4b68b37d"));
createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("aa876c540e70dc067f56f08c5b988573ee749cc119a305bcc78462388746fb86"));
const getMySubscriptions = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("da16a63bdab39f1e819d98d4d8e867c0a3c96df6ad7153176087ee19ffb3e0ee"));
createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("3d27619f2fab50c5cbed08145758bef45ecd8e80b09b7263a336756fb59102eb"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  autoReactEnabled: z.boolean(),
  reactionsPerSignal: z.number().int().min(1).max(1e4),
  reactEmojis: z.array(z.string().min(1).max(8)).min(1).max(20),
  delaySecondsMin: z.number().int().min(0).max(3600),
  delaySecondsMax: z.number().int().min(0).max(3600),
  autoMembersEnabled: z.boolean(),
  membersPerDay: z.number().int().min(1).max(5e4),
  welcomeBotEnabled: z.boolean().optional(),
  welcomeMessage: z.string().max(2e3).optional(),
  forwarderEnabled: z.boolean().optional(),
  forwarderSourceChatId: z.number().int().nullable().optional(),
  forwarderTargetChatIds: z.array(z.number().int()).max(50).optional()
}).parse(d)).handler(createSsrRpc("fd647e1258179beb6ef150bfd1ab4dae7b6a931b738812cda56c36a089b86185"));
const getWelcomeBotConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("9141a8c4a5d2cac0a43cd7b56801b5a30b380dd6728e462dfe5dee62bf1032e7"));
const upsertWelcomeBotConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  enabled: z.boolean(),
  message: z.string().max(4e3).nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  parseMode: z.enum(["HTML", "MarkdownV2", "Markdown"]).optional(),
  premiumEnabled: z.boolean().optional(),
  premiumAccountId: z.string().uuid().nullable().optional()
}).parse(d)).handler(createSsrRpc("eeef8403ac4754c69ca7fc9e1ae201751be1ea260d8f3df11123836fe0acecc9"));
const getForwarderConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("520161aadea83353aab9313ee81b67c26d693d76f5fb557fe23959921b3d49ce"));
const upsertForwarderConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  enabled: z.boolean(),
  sourceChatId: z.number().int().nullable().optional(),
  targetChatIds: z.array(z.number().int()).max(50).optional(),
  allowedTypes: z.array(z.string().min(1).max(32)).max(20).optional(),
  markedRecurring: z.array(z.string().uuid()).max(200).optional(),
  markedScheduled: z.array(z.string().uuid()).max(200).optional(),
  markedTemplates: z.array(z.string().min(1).max(64)).max(50).optional(),
  premiumEnabled: z.boolean().optional(),
  premiumAccountId: z.string().uuid().nullable().optional()
}).parse(d)).handler(createSsrRpc("c34908e8207ac3e6b51381875e4ad4d47cbf48ba13ce18a00b61a6c3b4b5cae7"));
const listAccountChats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("8222aea8cddd21daa30a34176c278c2ff1b0c8ffc97ccabe96fee4264ff3023d"));
const listForwarderSourceItems = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("e49642dc954ff7560817b9728dedb29fe050efa27e1ffd298454cb47b797ecc1"));
async function callSmmPanel(params) {
  const key = process.env.N1PANEL_API_KEY || process.env.SMM_PANEL_API_KEY;
  if (!key) throw new Error("Nenhuma chave de painel SMM configurada (N1PANEL_API_KEY).");
  const body = new URLSearchParams({
    key,
    ...Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)]))
  });
  const res = await fetch(N1PANEL_URL, {
    method: "POST",
    body
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`SMM panel ${res.status}: ${JSON.stringify(json)}`);
  return json;
}
const SUBSCRIPTION_REACTION_SERVICE_IDS = /* @__PURE__ */ new Set([2637, 3205, 3206, 3233, 3513, 3514, 2635, 2636, 2638]);
const MEMBERS_SERVICE_IDS = /* @__PURE__ */ new Set([3310, 3440, 7102]);
const SERVICE_MIN_QUANTITY = {
  2637: 10,
  // AUTO reactions (subscription)
  3205: 700,
  // AUTO reactions premium (subscription) — min alto
  3206: 700,
  3310: 10,
  // Members
  3440: 100,
  // Members (legado)
  3494: 100,
  // Reactions per-post
  7102: 100,
  // JAP members (legado)
  8485: 10
  // JAP reactions (legado)
};
function extractTelegramUsername(link) {
  const m = link.match(/t\.me\/([^/?#]+)/i);
  if (!m) return null;
  const u = m[1];
  if (u.startsWith("+") || u === "joinchat") return null;
  return u;
}
function buildAddOrderParams(args) {
  const min = SERVICE_MIN_QUANTITY[args.serviceId];
  if (min != null && args.quantity < min) {
    throw new Error(`Quantidade ${args.quantity} é menor que o mínimo do serviço ${args.serviceId} (mín. ${min}). Selecione um plano com quota >= ${min} ou troque o serviço SMM do plano para um que aceite ${args.quantity}.`);
  }
  if (SUBSCRIPTION_REACTION_SERVICE_IDS.has(args.serviceId)) {
    const username = extractTelegramUsername(args.link);
    if (!username) {
      throw new Error(`Link inválido para serviço de assinatura ${args.serviceId}: ${args.link}`);
    }
    return {
      action: "add",
      service: args.serviceId,
      username,
      min: args.quantity,
      max: args.quantity,
      posts: 1
    };
  }
  let link = args.link;
  if (MEMBERS_SERVICE_IDS.has(args.serviceId)) {
    const username = extractTelegramUsername(link);
    if (!username) {
      throw new Error(`Link inválido para serviço de membros ${args.serviceId}: ${args.link}`);
    }
    link = `https://t.me/${username}`;
  }
  return {
    action: "add",
    service: args.serviceId,
    link,
    quantity: args.quantity
  };
}
function mapSmmStatus(status, remains) {
  const normalized = String(status ?? "").trim().toLowerCase();
  const remaining = Number(remains ?? Number.NaN);
  if (normalized === "completed" && remaining === 0) return "completed";
  if (normalized === "completed") return "in_progress";
  if (normalized === "partial") return "partial";
  if (normalized === "canceled" || normalized === "cancelled") return "canceled";
  if (normalized === "processing" || normalized === "in progress" || normalized === "pending") return "in_progress";
  return null;
}
async function getTelegramMemberCountForOrder(order) {
  const username = normalizeTelegramLink(order.target)?.split("/").filter(Boolean).at(-1);
  if (!username || /^\d+$/.test(username)) return null;
  let accountId = null;
  if (order.room_id) {
    const {
      data: room
    } = await supabaseAdmin.from("rooms").select("default_account_id").eq("id", order.room_id).eq("user_id", order.user_id).maybeSingle();
    accountId = room?.default_account_id ?? null;
  }
  const query = supabaseAdmin.from("telegram_accounts").select("bot_token").eq("user_id", order.user_id).eq("is_active", true).not("bot_token", "is", null).limit(1);
  const {
    data: account
  } = accountId ? await query.eq("id", accountId).maybeSingle() : await query.maybeSingle();
  if (!account?.bot_token) return null;
  const resp = await callTelegram(account.bot_token, "getChatMemberCount", {
    chat_id: `@${username}`
  });
  return resp.ok && typeof resp.result === "number" ? resp.result : null;
}
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  type: z.enum(["reaction", "members"]),
  postId: z.number().int().positive().optional(),
  quantity: z.number().int().min(10).max(5e4)
}).parse(d)).handler(createSsrRpc("17eae8fd17f1c83ba64e6ae635fe6345b974fae93d39fd4813fbdff10993a575"));
const listMyEngagementOrders = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("be61ba610464f2a6ce575de6faab72ec24f462f385ee814c9812cbe96e83c542"));
async function syncOneEngagementOrder(order) {
  if (!order.smm_order_id) return null;
  try {
    const panel = await callSmmPanel({
      action: "status",
      order: order.smm_order_id
    });
    let nextStatus = mapSmmStatus(panel.status, panel.remains);
    if (!nextStatus) return null;
    const nextRaw = {
      ...order.raw_response ?? {},
      status_check: panel
    };
    if (order.type === "members") {
      const actualCount = await getTelegramMemberCountForOrder(order);
      if (actualCount != null) {
        const startCount = Number(panel.start_count ?? Number.NaN);
        const expectedCount = Number.isFinite(startCount) ? startCount + Number(order.quantity ?? 0) : null;
        nextRaw.telegram_count = {
          current: actualCount,
          expected: expectedCount,
          checked_at: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (nextStatus === "completed" && expectedCount != null && actualCount < expectedCount) {
          nextStatus = "in_progress";
        }
      }
    }
    await supabaseAdmin.from("engagement_orders").update({
      status: nextStatus,
      raw_response: nextRaw
    }).eq("id", order.id).eq("user_id", order.user_id);
    return {
      status: nextStatus,
      raw_response: nextRaw
    };
  } catch (e) {
    console.error("[syncOneEngagementOrder] failed for", order.id, e);
    return null;
  }
}
async function runEngagementOrdersSync(opts = {}) {
  const limit = Math.max(1, Math.min(200, opts.limit ?? 100));
  const {
    data,
    error
  } = await supabaseAdmin.from("engagement_orders").select("id, user_id, type, target, quantity, smm_order_id, room_id, status, raw_response").in("status", ["pending", "in_progress"]).not("smm_order_id", "is", null).order("updated_at", {
    ascending: true
  }).limit(limit);
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  let synced = 0;
  let divergent = 0;
  for (const r of rows) {
    const u = await syncOneEngagementOrder(r);
    if (u) {
      synced++;
      const tc = u.raw_response?.telegram_count;
      if (tc && typeof tc.current === "number" && typeof tc.expected === "number" && tc.current < tc.expected) {
        divergent++;
      }
    }
  }
  return {
    checked: rows.length,
    synced,
    divergent
  };
}
const listEngagementAudit = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("70ebf1cace5a6167ae9f5feba347cc6da057d22e2aa044d7f10ee81280a6b6e8"));
const listMyPaymentHistory = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("1dd1a0f1764fb9a74e32a0e6d3508bb3857bdc4b644c9440962468839e7957df"));
createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("55d5439e5566db59dd84035a91b041ab955fc04c0f4932a0c6cec3199f1712aa"));
createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("f46508554c2f0f4b657b3bc94b8f0db79f9dd6c228d9258459e231eb123d566a"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  subscriptionId: z.string().uuid(),
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("2ed761f88ef8c0e1f8ccc61181823b9d92fec2f852ec4f567df50d01e191a5fd"));
async function allocateAndAutoDispatch(opts) {
  const {
    data: sub,
    error: subErr
  } = await supabaseAdmin.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").eq("id", opts.subscriptionId).eq("user_id", opts.userId).maybeSingle();
  if (subErr) throw new Error(subErr.message);
  if (!sub) throw new Error("Assinatura não encontrada.");
  if (sub.target_room_id) {
    throw new Error("Esta assinatura já está alocada a uma sala.");
  }
  const plan = sub.plan;
  if (!plan) throw new Error("Plano não encontrado.");
  const botType = plan.bot_type;
  if (botType !== "inscritos" && botType !== "interacoes") {
    throw new Error("Apenas Inscritos/Interações precisam de canal.");
  }
  const {
    data: room
  } = await supabaseAdmin.from("rooms").select("id, user_id").eq("id", opts.roomId).eq("user_id", opts.userId).maybeSingle();
  if (!room) throw new Error("Sala inválida.");
  const {
    data: rc
  } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", opts.roomId).maybeSingle();
  if (!rc?.chat_id) throw new Error("A sala não tem canal vinculado.");
  const {
    data: chat
  } = await supabaseAdmin.from("telegram_chats").select("username").eq("chat_id", rc.chat_id).eq("user_id", opts.userId).maybeSingle();
  if (!chat?.username) {
    throw new Error("O canal da sala não é público (sem @username).");
  }
  const link = `https://t.me/${chat.username}`;
  await supabaseAdmin.from("user_engagement_subscriptions").update({
    target_room_id: opts.roomId,
    target_link: link
  }).eq("id", opts.subscriptionId);
  if (botType === "interacoes") {
    return {
      ok: true,
      mode: "saved",
      link
    };
  }
  const serviceId = plan.smm_service_id ?? DEFAULT_N1_MEMBERS_SERVICE_ID;
  const quantity = plan.smm_default_quantity ?? plan.monthly_quota ?? 0;
  if (!serviceId || !quantity) {
    throw new Error("Plano sem configuração SMM (service_id/quantity).");
  }
  const result = await placeSmmOrder({
    userId: opts.userId,
    subscriptionId: opts.subscriptionId,
    serviceId,
    link,
    quantity,
    type: "members",
    roomId: opts.roomId
  });
  if (!result.ok) {
    throw new Error(`Falha ao despachar inscritos: ${result.error}`);
  }
  await supabaseAdmin.from("user_engagement_subscriptions").update({
    units_used: quantity,
    auto_dispatched_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", opts.subscriptionId);
  return {
    ok: true,
    mode: "dispatched",
    smmOrderId: result.smmOrderId,
    quantity,
    link
  };
}
async function placeSmmOrder(opts) {
  const existing = await findReusableSmmOrder(opts);
  if (existing) {
    return {
      ok: true,
      smmOrderId: Number(existing.smm_order_id),
      orderId: existing.id
    };
  }
  const {
    data: order,
    error: orderErr
  } = await supabaseAdmin.from("engagement_orders").insert({
    user_id: opts.userId,
    room_id: opts.roomId ?? null,
    subscription_id: opts.subscriptionId,
    type: opts.type,
    target: opts.link,
    quantity: opts.quantity,
    smm_service_id: opts.serviceId
  }).select("*").single();
  if (orderErr) throw new Error(orderErr.message);
  try {
    const resp = await callSmmPanel(buildAddOrderParams({
      serviceId: opts.serviceId,
      link: opts.link,
      quantity: opts.quantity
    }));
    if (resp.error || !resp.order) {
      await supabaseAdmin.from("engagement_orders").update({
        status: "failed",
        error: resp.error ?? "no order id",
        raw_response: resp
      }).eq("id", order.id);
      return {
        ok: false,
        error: resp.error ?? "no order id"
      };
    }
    await supabaseAdmin.from("engagement_orders").update({
      status: "in_progress",
      smm_order_id: String(resp.order),
      cost_usd: resp.charge ? Number(resp.charge) : null,
      raw_response: resp
    }).eq("id", order.id);
    return {
      ok: true,
      smmOrderId: resp.order,
      orderId: order.id
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await supabaseAdmin.from("engagement_orders").update({
      status: "failed",
      error: msg
    }).eq("id", order.id);
    return {
      ok: false,
      error: msg
    };
  }
}
async function findReusableSmmOrder(opts) {
  const {
    data
  } = await supabaseAdmin.from("engagement_orders").select("id, smm_order_id, status").eq("user_id", opts.userId).eq("subscription_id", opts.subscriptionId).eq("type", opts.type).eq("target", opts.link).eq("quantity", opts.quantity).eq("smm_service_id", opts.serviceId).in("status", ["pending", "in_progress", "completed", "partial"]).not("smm_order_id", "is", null).order("created_at", {
    ascending: false
  }).limit(1).maybeSingle();
  return data;
}
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  subscriptionId: z.string().uuid(),
  targetLink: z.string().min(1).max(500)
}).parse(d)).handler(createSsrRpc("c83a0df8caf1e6a68c81136d80c86b3e2ed1ac14a5104b3fcc1210dc358776b2"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  orderId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("13d157f4f68be2d92e9ed9665cdaf03785e1a4db0f7546cc5ab12f9a724b0d84"));
async function triggerSignalReactions(opts) {
  try {
    const {
      data: claim,
      error: claimErr
    } = await supabaseAdmin.from("engagement_reaction_dispatches").insert({
      chat_id: opts.chatId,
      telegram_message_id: opts.telegramMessageId,
      user_id: opts.userId
    }).select("chat_id").maybeSingle();
    if (claimErr) {
      if (claimErr.code === "23505") return;
      console.error("[triggerSignalReactions] claim failed:", claimErr);
      return;
    }
    if (!claim) return;
    const {
      data: sub
    } = await supabaseAdmin.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").eq("user_id", opts.userId).eq("bot_type", "interacoes").eq("status", "active").order("created_at", {
      ascending: false
    }).limit(1).maybeSingle();
    if (!sub || !sub.plan) {
      await releaseReactionClaim(opts.chatId, opts.telegramMessageId);
      return;
    }
    const plan = sub.plan;
    const qty = plan.smm_default_quantity ?? plan.monthly_quota ?? 0;
    if (!qty) {
      await releaseReactionClaim(opts.chatId, opts.telegramMessageId);
      return;
    }
    const {
      data: chat
    } = await supabaseAdmin.from("telegram_chats").select("username").eq("chat_id", opts.chatId).eq("user_id", opts.userId).maybeSingle();
    if (!chat?.username) {
      await releaseReactionClaim(opts.chatId, opts.telegramMessageId);
      return;
    }
    const link = `https://t.me/${chat.username}/${opts.telegramMessageId}`;
    const serviceId = plan.smm_service_id ?? DEFAULT_N1_REACTIONS_SERVICE_ID;
    const result = await placeSmmOrder({
      userId: opts.userId,
      subscriptionId: sub.id,
      serviceId,
      link,
      quantity: qty,
      type: "reaction",
      roomId: opts.roomId ?? null
    });
    if (result.ok) {
      await supabaseAdmin.from("engagement_reaction_dispatches").update({
        subscription_id: sub.id,
        smm_order_id: result.smmOrderId ? String(result.smmOrderId) : null
      }).eq("chat_id", opts.chatId).eq("telegram_message_id", opts.telegramMessageId);
    } else {
      await releaseReactionClaim(opts.chatId, opts.telegramMessageId);
    }
  } catch (e) {
    console.error("[triggerSignalReactions] failed:", e);
    await releaseReactionClaim(opts.chatId, opts.telegramMessageId).catch(() => void 0);
  }
}
async function releaseReactionClaim(chatId, telegramMessageId) {
  await supabaseAdmin.from("engagement_reaction_dispatches").delete().eq("chat_id", chatId).eq("telegram_message_id", telegramMessageId);
}
const engagement_functions = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  allocateAndAutoDispatch,
  getForwarderConfig,
  getMySubscriptions,
  getWelcomeBotConfig,
  listAccountChats,
  listEngagementAudit,
  listEngagementPlans,
  listForwarderSourceItems,
  listMyEngagementOrders,
  listMyPaymentHistory,
  normalizeTelegramLink,
  runEngagementOrdersSync,
  syncOneEngagementOrder,
  triggerSignalReactions,
  upsertForwarderConfig,
  upsertWelcomeBotConfig
}, Symbol.toStringTag, { value: "Module" }));
export {
  allocateAndAutoDispatch as a,
  listMyPaymentHistory as b,
  createSsrRpc as c,
  listMyEngagementOrders as d,
  listEngagementAudit as e,
  listAccountChats as f,
  getMySubscriptions as g,
  getForwarderConfig as h,
  listForwarderSourceItems as i,
  getWelcomeBotConfig as j,
  upsertWelcomeBotConfig as k,
  listEngagementPlans as l,
  engagement_functions as m,
  runEngagementOrdersSync as r,
  triggerSignalReactions as t,
  upsertForwarderConfig as u
};
