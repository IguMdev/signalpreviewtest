import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { C as Card, O as CardHeader, Q as CardTitle, x as CardContent, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, N as Switch, L as Label, B as Button, l as getPremiumAccountAvatar } from "./router-Cw6OHOsO.js";
import { C as Checkbox } from "./checkbox-CU7rmJt5.js";
import { Forward, ImageIcon, RefreshCw, Sparkles, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { f as listAccountChats, h as getForwarderConfig, i as listForwarderSourceItems, u as upsertForwarderConfig } from "./engagement.functions-BnPQkoHV.js";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "./client.server-CDheR9QG.js";
import "zod";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-checkbox";
function PremiumAvatar({
  accountId,
  label
}) {
  const avatarQ = useQuery({
    queryKey: ["premium-avatar", accountId],
    queryFn: () => getPremiumAccountAvatar({
      data: {
        accountId
      }
    }),
    enabled: Boolean(accountId),
    staleTime: 1e3 * 60 * 60,
    refetchOnWindowFocus: false
  });
  const url = avatarQ.data?.dataUrl ?? null;
  const initials = label.split(/\s+/).map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return url ? /* @__PURE__ */ jsx("img", { src: url, alt: label, className: "size-7 rounded-full object-cover border border-border/60 shrink-0" }) : /* @__PURE__ */ jsx("div", { className: "size-7 rounded-full flex items-center justify-center bg-primary text-[10px] font-bold text-primary-foreground shrink-0", children: initials || "?" });
}
function ItemList({
  title,
  empty,
  items,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsx("p", { className: "text-xs font-medium text-foreground", children: title }),
    /* @__PURE__ */ jsx("div", { className: "border rounded-md p-3 max-h-48 overflow-auto space-y-2", children: items.length === 0 ? /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: empty }) : items.map((it) => {
      const checked = value.includes(it.id);
      return /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm", children: [
        /* @__PURE__ */ jsx(Checkbox, { checked, onCheckedChange: (v) => {
          onChange(v ? [...value, it.id] : value.filter((x) => x !== it.id));
        } }),
        /* @__PURE__ */ jsx("span", { className: "truncate", children: it.label })
      ] }, it.id);
    }) })
  ] });
}
function EncaminhadorPage() {
  const qc = useQueryClient();
  const get = useServerFn(getForwarderConfig);
  const upsert = useServerFn(upsertForwarderConfig);
  const listChats = useServerFn(listAccountChats);
  const listItems = useServerFn(listForwarderSourceItems);
  const roomsQ = useQuery({
    queryKey: ["rooms-pick"],
    queryFn: async () => (await supabase.from("rooms").select("id, name, photo_url").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const chatsQ = useQuery({
    queryKey: ["account-chats"],
    queryFn: () => listChats()
  });
  const [roomId, setRoomId] = useState("");
  useEffect(() => {
    if (!roomId && roomsQ.data?.[0]?.id) setRoomId(roomsQ.data[0].id);
  }, [roomsQ.data, roomId]);
  const selectedRoom = (roomsQ.data ?? []).find((r) => r.id === roomId);
  const [roomPhotoError, setRoomPhotoError] = useState(false);
  useEffect(() => {
    setRoomPhotoError(false);
  }, [roomId]);
  const roomAccountQ = useQuery({
    queryKey: ["room-forwarder-account", roomId],
    enabled: !!roomId,
    queryFn: async () => {
      const {
        data
      } = await supabase.from("rooms").select("default_account_id, telegram_accounts:default_account_id(id, label, bot_username, bot_first_name)").eq("id", roomId).maybeSingle();
      return data;
    }
  });
  const cfgQ = useQuery({
    queryKey: ["fwd-cfg", roomId],
    enabled: !!roomId,
    queryFn: () => get({
      data: {
        roomId
      }
    })
  });
  const itemsQ = useQuery({
    queryKey: ["fwd-items", roomId],
    enabled: !!roomId,
    queryFn: () => listItems({
      data: {
        roomId
      }
    })
  });
  const [enabled, setEnabled] = useState(false);
  const [source, setSource] = useState("");
  const [targets, setTargets] = useState([]);
  const [markedTemplates, setMarkedTemplates] = useState([]);
  const [markedScheduled, setMarkedScheduled] = useState([]);
  const [markedRecurring, setMarkedRecurring] = useState([]);
  const [premiumEnabled, setPremiumEnabled] = useState(false);
  const [premiumAccountId, setPremiumAccountId] = useState("");
  const premiumAccountsQ = useQuery({
    queryKey: ["premium-accounts-list"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("telegram_accounts").select("id, label, phone, is_active, tg_session").eq("account_type", "premium").order("created_at", {
        ascending: false
      });
      return data ?? [];
    }
  });
  const activePremiumAccounts = (premiumAccountsQ.data ?? []).filter((a) => a.is_active && a.tg_session);
  useEffect(() => {
    const c = cfgQ.data;
    if (!c) return;
    setEnabled(c.forwarder_enabled ?? false);
    setSource(c.forwarder_source_chat_id ? String(c.forwarder_source_chat_id) : "");
    setTargets(c.forwarder_target_chat_ids ?? []);
    setMarkedTemplates(c.forwarder_marked_templates ?? []);
    setMarkedScheduled(c.forwarder_marked_scheduled ?? []);
    setMarkedRecurring(c.forwarder_marked_recurring ?? []);
    setPremiumEnabled(c.forwarder_premium_enabled ?? false);
    setPremiumAccountId(c.forwarder_premium_account_id ?? "");
  }, [cfgQ.data]);
  const save = useMutation({
    mutationFn: () => upsert({
      data: {
        roomId,
        enabled,
        sourceChatId: source ? Number(source) : null,
        targetChatIds: targets,
        markedTemplates,
        markedScheduled,
        markedRecurring,
        premiumEnabled,
        premiumAccountId: premiumAccountId || null
      }
    }),
    onSuccess: () => {
      toast.success("Salvo");
      qc.invalidateQueries({
        queryKey: ["fwd-cfg", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const roomAccount = roomAccountQ.data?.telegram_accounts;
  const roomBotName = roomAccount?.bot_username ? `@${roomAccount.bot_username}` : roomAccount?.bot_first_name ?? roomAccount?.label ?? "bot padrão da sala";
  const chats = (chatsQ.data ?? []).filter((c) => !roomAccountQ.data?.default_account_id || c.account_id === roomAccountQ.data.default_account_id);
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-3xl", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Forward, { className: "size-6 text-primary" }),
        " BotEncaminhador"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Copia mensagens de um canal/grupo para outros automaticamente. O bot precisa estar como administrador no canal de origem." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Sala" }) }),
      /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        selectedRoom?.photo_url && !roomPhotoError ? /* @__PURE__ */ jsx("img", { src: selectedRoom.photo_url, alt: selectedRoom.name, className: "size-14 rounded-md object-cover border border-border/60 shrink-0", onError: () => setRoomPhotoError(true) }) : /* @__PURE__ */ jsx("div", { className: "size-14 rounded-md border border-border/60 bg-muted shrink-0 flex items-center justify-center", children: /* @__PURE__ */ jsx(ImageIcon, { className: "size-6 text-muted-foreground" }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
          selectedRoom && /* @__PURE__ */ jsx("p", { className: "text-sm font-medium truncate mb-1", children: selectedRoom.name }),
          /* @__PURE__ */ jsxs(Select, { value: roomId, onValueChange: setRoomId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: (roomsQ.data ?? []).map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] })
      ] }) })
    ] }),
    roomId && /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center justify-between", children: [
        "Configuração",
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
          "Ativado ",
          /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { children: "Canal de origem" }),
          /* @__PURE__ */ jsxs(Select, { value: source, onValueChange: setSource, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione o canal" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: chats.map((c) => /* @__PURE__ */ jsx(SelectItem, { value: String(c.chat_id), children: c.title ?? c.username ?? c.chat_id }, c.chat_id)) })
          ] }),
          chats.length === 0 && /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-border bg-muted/40 p-3 text-xs text-muted-foreground space-y-2", children: [
            /* @__PURE__ */ jsx("p", { children: "Nenhum chat detectado para o bot desta sala." }),
            /* @__PURE__ */ jsxs("ol", { className: "list-decimal pl-4 space-y-1", children: [
              /* @__PURE__ */ jsxs("li", { children: [
                "Use o bot da sala: ",
                /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: roomBotName }),
                "."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Na página Contas Telegram, clique em ",
                /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Ativar rastreamento" }),
                " nesse bot."
              ] }),
              /* @__PURE__ */ jsx("li", { children: "Adicione esse bot como administrador no canal/grupo e envie uma mensagem nova no canal." }),
              /* @__PURE__ */ jsx("li", { children: "Volte aqui e clique em atualizar." })
            ] }),
            /* @__PURE__ */ jsxs(Button, { type: "button", variant: "outline", size: "sm", className: "gap-2", onClick: () => chatsQ.refetch(), children: [
              /* @__PURE__ */ jsx(RefreshCw, { className: "size-3.5" }),
              " Atualizar chats"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-border bg-muted/30 p-3 space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsx(Sparkles, { className: "size-4 text-primary mt-0.5 shrink-0" }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Emojis Premium animados" }),
                /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Quando a mensagem original tiver emojis premium, reenviamos pela sua conta Telegram Premium para preservar a animação. Sem isso o Telegram remove os emojis no encaminhamento." })
              ] })
            ] }),
            /* @__PURE__ */ jsx(Switch, { checked: premiumEnabled, onCheckedChange: setPremiumEnabled })
          ] }),
          premiumEnabled && /* @__PURE__ */ jsxs("div", { className: "space-y-1.5 pl-6", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Conta Premium" }),
            activePremiumAccounts.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/5 p-2 text-xs", children: [
              /* @__PURE__ */ jsx(AlertCircle, { className: "size-4 text-destructive shrink-0 mt-0.5" }),
              /* @__PURE__ */ jsx("span", { children: "Nenhuma conta Telegram Premium conectada. Vá em Contas Telegram e conecte uma conta Premium para usar esse recurso." })
            ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsxs(Select, { value: premiumAccountId, onValueChange: setPremiumAccountId, children: [
                /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione a conta Premium" }) }),
                /* @__PURE__ */ jsx(SelectContent, { children: activePremiumAccounts.map((a) => /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
                  a.label,
                  a.phone ? ` — ${a.phone}` : ""
                ] }, a.id)) })
              ] }),
              premiumAccountId && /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1", children: [
                (() => {
                  const acc = activePremiumAccounts.find((a) => a.id === premiumAccountId);
                  return acc ? /* @__PURE__ */ jsx(PremiumAvatar, { accountId: acc.id, label: acc.label }) : null;
                })(),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400", children: [
                  /* @__PURE__ */ jsx(CheckCircle2, { className: "size-3.5" }),
                  " Conta conectada e pronta para uso."
                ] })
              ] }),
              /* @__PURE__ */ jsx("p", { className: "text-[11px] text-muted-foreground", children: "A conta Premium precisa estar nos canais/grupos de destino com permissão de postar (admin em canais)." })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { children: "Canais de destino" }),
          /* @__PURE__ */ jsx("div", { className: "space-y-2 border rounded-md p-3 max-h-72 overflow-auto", children: chats.filter((c) => String(c.chat_id) !== source).map((c) => {
            const checked = targets.includes(c.chat_id);
            return /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm", children: [
              /* @__PURE__ */ jsx(Checkbox, { checked, onCheckedChange: (v) => {
                setTargets((prev) => v ? [...prev, c.chat_id] : prev.filter((x) => x !== c.chat_id));
              } }),
              /* @__PURE__ */ jsx("span", { children: c.title ?? c.username ?? c.chat_id })
            ] }, c.chat_id);
          }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(Label, { children: "Itens da sala para encaminhar" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Marque os modelos e agendamentos que devem ser copiados para os canais de destino quando dispararem no canal de origem. O que não estiver marcado fica somente no canal de origem." })
          ] }),
          /* @__PURE__ */ jsx(ItemList, { title: "Modelos da sala", empty: "Nenhum modelo de envio rápido vinculado a esta sala. Defina a sala padrão em Modelos para que apareçam aqui.", items: (itemsQ.data?.templates ?? []).map((t) => ({
            id: t.id,
            label: t.name
          })), value: markedTemplates, onChange: setMarkedTemplates }),
          /* @__PURE__ */ jsx(ItemList, { title: "Agendamentos recorrentes", empty: "Nenhum agendamento recorrente nesta sala.", items: (itemsQ.data?.recurring ?? []).map((r) => ({
            id: r.id,
            label: `${r.title}${r.is_active ? "" : " (inativo)"}`
          })), value: markedRecurring, onChange: setMarkedRecurring }),
          /* @__PURE__ */ jsx(ItemList, { title: "Agendamentos únicos", empty: "Nenhum agendamento único nesta sala.", items: (itemsQ.data?.scheduled ?? []).map((s) => ({
            id: s.id,
            label: `${new Date(s.scheduled_at).toLocaleString("pt-BR", {
              dateStyle: "short",
              timeStyle: "short"
            })} — ${(s.content ?? "").slice(0, 60) || "(sem texto)"}`
          })), value: markedScheduled, onChange: setMarkedScheduled })
        ] }),
        /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar" })
      ] })
    ] })
  ] });
}
export {
  EncaminhadorPage as component
};
