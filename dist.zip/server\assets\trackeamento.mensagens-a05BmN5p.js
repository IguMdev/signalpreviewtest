import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { s as supabase } from "./client-bD0og8Nx.js";
import { C as Card, O as CardHeader, Q as CardTitle, D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, h as DialogHeader, i as DialogTitle, L as Label, I as Input, j as DialogFooter, x as CardContent, N as Switch, T as Textarea, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem } from "./router-Cw6OHOsO.js";
import { MessageCircle, Plus, CheckCircle2, Bot, Trash2 } from "lucide-react";
import { toast } from "sonner";
import "@supabase/supabase-js";
import "@tanstack/react-router";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function TrackingMessagesPage() {
  const qc = useQueryClient();
  const [openNew, setOpenNew] = useState(false);
  const [token, setToken] = useState("");
  const botsQ = useQuery({
    queryKey: ["tracking-bots"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("tracking_bots").select("*").order("created_at", {
        ascending: false
      });
      if (error) {
        console.error(error);
        return [];
      }
      return data;
    }
  });
  const [selectedBotId, setSelectedBotId] = useState(null);
  useEffect(() => {
    if (!selectedBotId && botsQ.data?.[0]) {
      setSelectedBotId(botsQ.data[0].id);
    }
  }, [botsQ.data, selectedBotId]);
  const selectedBot = botsQ.data?.find((b) => b.id === selectedBotId);
  const messagesQ = useQuery({
    queryKey: ["tracking-bot-messages", selectedBotId],
    enabled: !!selectedBotId,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("tracking_bot_messages").select("*").eq("tracking_bot_id", selectedBotId).order("sort_order", {
        ascending: true
      });
      if (error) throw error;
      return data;
    }
  });
  const createMut = useMutation({
    mutationFn: async () => {
      const {
        data: u
      } = await supabase.auth.getUser();
      const {
        data,
        error
      } = await supabase.from("tracking_bots").insert({
        user_id: u.user.id,
        label: "Bot " + token.substring(0, 10) + "...",
        bot_token: token
      }).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast.success("Bot validado e salvo!");
      setOpenNew(false);
      setToken("");
      setSelectedBotId(data.id);
      qc.invalidateQueries({
        queryKey: ["tracking-bots"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const deleteMut = useMutation({
    mutationFn: async (id) => {
      const {
        error
      } = await supabase.from("tracking_bots").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Bot deletado.");
      qc.invalidateQueries({
        queryKey: ["tracking-bots"]
      });
    }
  });
  const updateMut = useMutation({
    mutationFn: async (updates) => {
      if (!selectedBotId) return;
      const {
        error
      } = await supabase.from("tracking_bots").update(updates).eq("id", selectedBotId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Configurações atualizadas");
      qc.invalidateQueries({
        queryKey: ["tracking-bots"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const addMsgMut = useMutation({
    mutationFn: async () => {
      if (!selectedBotId) return;
      const {
        data: u
      } = await supabase.auth.getUser();
      const sortOrder = (messagesQ.data?.length ?? 0) + 1;
      const {
        error
      } = await supabase.from("tracking_bot_messages").insert({
        user_id: u.user.id,
        tracking_bot_id: selectedBotId,
        content: "Nova mensagem...",
        sort_order: sortOrder,
        delay_seconds: 60
      });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["tracking-bot-messages", selectedBotId]
    }),
    onError: (e) => toast.error(e.message)
  });
  const updateMsgMut = useMutation({
    mutationFn: async ({
      id,
      updates
    }) => {
      const {
        error
      } = await supabase.from("tracking_bot_messages").update(updates).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Mensagem salva");
      qc.invalidateQueries({
        queryKey: ["tracking-bot-messages", selectedBotId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const deleteMsgMut = useMutation({
    mutationFn: async (id) => {
      const {
        error
      } = await supabase.from("tracking_bot_messages").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["tracking-bot-messages", selectedBotId]
    })
  });
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-5xl mx-auto", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(MessageCircle, { className: "size-6 text-primary" }),
        "Mensagens do Trackeamento"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Configure as mensagens de entrada e o auto-aceite dos seus bots de trackeamento." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "border-border/60 shadow-none bg-card/40", children: [
      /* @__PURE__ */ jsx(CardHeader, { className: "pb-3", children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-base flex items-center justify-between", children: [
        "Bot",
        /* @__PURE__ */ jsxs(Dialog, { open: openNew, onOpenChange: setOpenNew, children: [
          /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { size: "sm", className: "gap-2", children: [
            /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
            " Adicionar Bot"
          ] }) }),
          /* @__PURE__ */ jsxs(DialogContent, { className: "sm:max-w-[500px]", children: [
            /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Editar Bot" }) }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-6 py-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-4 rounded-xl border border-border/60 p-4 bg-muted/20", children: [
                /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm font-semibold", children: [
                    /* @__PURE__ */ jsx("span", { className: "flex size-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground", children: "1" }),
                    "Obtenha o Token do seu Bot"
                  ] }),
                  /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground pl-7", children: [
                    "Use o ",
                    /* @__PURE__ */ jsx("strong", { className: "text-foreground", children: "@BotFather" }),
                    " para criar ou selecionar seu bot."
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm font-semibold", children: [
                    /* @__PURE__ */ jsx("span", { className: "flex size-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground", children: "2" }),
                    "Insira o Token"
                  ] }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground pl-7", children: "Cole o token copiado do BotFather no campo abaixo e valide-o." })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 rounded-lg border border-emerald-500/20 bg-emerald-500/10 p-3 text-sm text-emerald-500", children: [
                /* @__PURE__ */ jsx(CheckCircle2, { className: "size-5 shrink-0" }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-semibold", children: "Compatível com Manychat!" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs opacity-90", children: "Você pode utilizar seu bot no Manychat e na Track4You ao mesmo tempo." })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Token do Bot" }),
                /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                  /* @__PURE__ */ jsx(Input, { value: token, onChange: (e) => setToken(e.target.value), placeholder: "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11", className: "font-mono text-xs" }),
                  /* @__PURE__ */ jsx(Button, { onClick: () => createMut.mutate(), disabled: !token || createMut.isPending, className: "shrink-0 bg-blue-600 hover:bg-blue-700 text-white", children: createMut.isPending ? "Validando..." : "Validar Token" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs(DialogFooter, { children: [
              /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setOpenNew(false), children: "Cancelar" }),
              /* @__PURE__ */ jsx(Button, { onClick: () => setOpenNew(false), className: "bg-primary/20 text-primary hover:bg-primary/30", children: "Salvar" })
            ] })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsx("div", { className: "rounded-md border border-border/60 overflow-hidden", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsx("thead", { className: "bg-muted/50 text-xs uppercase text-muted-foreground", children: /* @__PURE__ */ jsxs("tr", { children: [
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-semibold", children: "Nome do Bot" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-left font-semibold", children: "Token" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-center font-semibold", children: "Status" }),
          /* @__PURE__ */ jsx("th", { className: "px-4 py-3 text-right font-semibold", children: "Ações" })
        ] }) }),
        /* @__PURE__ */ jsx("tbody", { className: "divide-y divide-border/60", children: botsQ.data?.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 4, className: "px-4 py-8 text-center text-muted-foreground", children: "Nenhum bot cadastrado." }) }) : botsQ.data?.map((bot) => /* @__PURE__ */ jsxs("tr", { className: `hover:bg-muted/30 transition cursor-pointer ${selectedBotId === bot.id ? "bg-primary/5" : ""}`, onClick: () => setSelectedBotId(bot.id), children: [
          /* @__PURE__ */ jsxs("td", { className: "px-4 py-3 font-medium flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Bot, { className: "size-4 text-primary" }),
            bot.label
          ] }),
          /* @__PURE__ */ jsxs("td", { className: "px-4 py-3 text-muted-foreground font-mono text-xs", children: [
            bot.bot_token.substring(0, 10),
            "..."
          ] }),
          /* @__PURE__ */ jsx("td", { className: "px-4 py-3 text-center", children: /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2 py-0.5 text-xs font-medium text-emerald-500", children: [
            /* @__PURE__ */ jsx("span", { className: "size-1.5 rounded-full bg-emerald-500" }),
            bot.status
          ] }) }),
          /* @__PURE__ */ jsxs("td", { className: "px-4 py-3 text-right space-x-2", children: [
            /* @__PURE__ */ jsx(Button, { size: "sm", className: "h-7 text-xs bg-blue-600 text-white hover:bg-blue-700", children: "Editar" }),
            /* @__PURE__ */ jsx(Button, { size: "sm", onClick: (e) => {
              e.stopPropagation();
              deleteMut.mutate(bot.id);
            }, className: "h-7 text-xs bg-red-600 text-white hover:bg-red-700", children: "Deletar" })
          ] })
        ] }, bot.id)) })
      ] }) }) })
    ] }),
    /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold pt-4", children: "Configurações Padrão" }),
    /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxs(Card, { className: "border-border/60 shadow-none bg-card/40", children: [
        /* @__PURE__ */ jsx(CardHeader, { className: "pb-3 flex flex-row justify-center items-center", children: /* @__PURE__ */ jsx(CardTitle, { className: "text-sm", children: "Mensagem de Entrada" }) }),
        /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsx("span", { className: `text-xs font-semibold ${selectedBot?.welcome_enabled ? "text-emerald-500" : "text-destructive"}`, children: selectedBot?.welcome_enabled ? "Ativo" : "Inativo" }),
            /* @__PURE__ */ jsx(Switch, { checked: selectedBot?.welcome_enabled ?? false, onCheckedChange: (v) => updateMut.mutate({
              welcome_enabled: v
            }), disabled: !selectedBot })
          ] }),
          /* @__PURE__ */ jsxs(Dialog, { children: [
            /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { className: "w-full bg-primary hover:bg-primary/90", disabled: !selectedBot, children: "Configurar" }) }),
            /* @__PURE__ */ jsxs(DialogContent, { children: [
              /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Mensagem de Entrada" }) }),
              /* @__PURE__ */ jsx("div", { className: "space-y-4 py-4", children: /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Conteúdo da mensagem" }),
                /* @__PURE__ */ jsx(Textarea, { value: selectedBot?.welcome_message ?? "", onChange: (e) => updateMut.mutate({
                  welcome_message: e.target.value
                }), placeholder: "Seja bem-vindo ao grupo!", rows: 5, disabled: !selectedBot })
              ] }) })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Card, { className: "border-border/60 shadow-none bg-card/40", children: [
        /* @__PURE__ */ jsx(CardHeader, { className: "pb-3 flex flex-row justify-center items-center", children: /* @__PURE__ */ jsx(CardTitle, { className: "text-sm", children: "Mensagem de Saída" }) }),
        /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsx("span", { className: `text-xs font-semibold ${selectedBot?.leave_enabled ? "text-emerald-500" : "text-destructive"}`, children: selectedBot?.leave_enabled ? "Ativo" : "Inativo" }),
            /* @__PURE__ */ jsx(Switch, { checked: selectedBot?.leave_enabled ?? false, onCheckedChange: (v) => updateMut.mutate({
              leave_enabled: v
            }), disabled: !selectedBot })
          ] }),
          /* @__PURE__ */ jsxs(Dialog, { children: [
            /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { className: "w-full bg-primary hover:bg-primary/90", disabled: !selectedBot, children: "Configurar" }) }),
            /* @__PURE__ */ jsxs(DialogContent, { children: [
              /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Mensagem de Saída" }) }),
              /* @__PURE__ */ jsx("div", { className: "space-y-4 py-4", children: /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Conteúdo da mensagem" }),
                /* @__PURE__ */ jsx(Textarea, { value: selectedBot?.leave_message ?? "", onChange: (e) => updateMut.mutate({
                  leave_message: e.target.value
                }), placeholder: "Até logo!", rows: 5, disabled: !selectedBot })
              ] }) })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Card, { className: "border-border/60 shadow-none bg-card/40", children: [
        /* @__PURE__ */ jsx(CardHeader, { className: "pb-3 flex flex-row justify-center items-center", children: /* @__PURE__ */ jsx(CardTitle, { className: "text-sm", children: "Auto-Aceite" }) }),
        /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsx("span", { className: `text-xs font-semibold ${selectedBot?.auto_accept_enabled ? "text-emerald-500" : "text-destructive"}`, children: selectedBot?.auto_accept_enabled ? "Ativo" : "Inativo" }),
            /* @__PURE__ */ jsx(Switch, { checked: selectedBot?.auto_accept_enabled ?? false, onCheckedChange: (v) => updateMut.mutate({
              auto_accept_enabled: v
            }), disabled: !selectedBot })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs text-muted-foreground", children: "Aceitar membro após:" }),
            /* @__PURE__ */ jsxs(Select, { value: selectedBot?.auto_accept_delay_seconds?.toString() || "0", onValueChange: (v) => updateMut.mutate({
              auto_accept_delay_seconds: parseInt(v)
            }), disabled: !selectedBot, children: [
              /* @__PURE__ */ jsx(SelectTrigger, { className: "bg-background/50", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione..." }) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "0", children: "Instantâneo" }),
                /* @__PURE__ */ jsx(SelectItem, { value: "60", children: "1 Minuto" }),
                /* @__PURE__ */ jsx(SelectItem, { value: "300", children: "5 Minutos" }),
                /* @__PURE__ */ jsx(SelectItem, { value: "600", children: "10 Minutos" })
              ] })
            ] })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-4", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Mensagens Personalizadas" }),
      /* @__PURE__ */ jsxs(Button, { size: "sm", onClick: () => addMsgMut.mutate(), className: "bg-primary text-primary-foreground hover:bg-primary/90", disabled: !selectedBot || addMsgMut.isPending, children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-2" }),
        " Nova Mensagem"
      ] })
    ] }),
    messagesQ.data?.length === 0 ? /* @__PURE__ */ jsx(Card, { className: "border-border/60 shadow-none bg-card/40 p-8 text-center text-muted-foreground", children: "Nenhuma mensagem personalizada criada para este bot." }) : /* @__PURE__ */ jsx("div", { className: "space-y-3", children: messagesQ.data?.map((msg, i) => /* @__PURE__ */ jsx(Card, { className: "border-border/60 shadow-none bg-card/40", children: /* @__PURE__ */ jsxs(CardContent, { className: "p-4 space-y-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs("span", { className: "font-semibold text-sm", children: [
          "Mensagem #",
          i + 1
        ] }),
        /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => deleteMsgMut.mutate(msg.id), className: "h-8 text-destructive hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-[1fr_200px] gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs text-muted-foreground", children: "Conteúdo da Mensagem" }),
          /* @__PURE__ */ jsx(Textarea, { defaultValue: msg.content, onBlur: (e) => updateMsgMut.mutate({
            id: msg.id,
            updates: {
              content: e.target.value
            }
          }), rows: 3 })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs text-muted-foreground", children: "Atraso após a entrada (segundos)" }),
          /* @__PURE__ */ jsx(Input, { type: "number", defaultValue: msg.delay_seconds, onBlur: (e) => updateMsgMut.mutate({
            id: msg.id,
            updates: {
              delay_seconds: parseInt(e.target.value) || 0
            }
          }) }),
          /* @__PURE__ */ jsx("p", { className: "text-[10px] text-muted-foreground mt-1", children: "Ex: 60 para enviar 1 minuto após o lead entrar." })
        ] })
      ] })
    ] }) }, msg.id)) })
  ] });
}
export {
  TrackingMessagesPage as component
};
