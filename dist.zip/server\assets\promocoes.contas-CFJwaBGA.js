import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { a as listAffiliateAccounts, u as upsertAffiliateAccount, d as deleteAffiliateAccount, t as testAffiliateAccount } from "./promo.functions-D_8o42Ut.js";
import { B as Button, C as Card, y as Table, z as TableHeader, A as TableRow, E as TableHead, F as TableBody, G as TableCell, H as Badge, D as Dialog, g as DialogContent, h as DialogHeader, i as DialogTitle, L as Label, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, I as Input, N as Switch, j as DialogFooter } from "./router-Cw6OHOsO.js";
import { Plus, Loader2, XCircle, CheckCircle2, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import "@tanstack/react-router";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const STORE_LABELS = {
  amazon: "Amazon Associates",
  shopee: "Shopee Afiliados",
  aliexpress: "AliExpress Portals",
  mercadolivre: "Mercado Livre Afiliados"
};
const STORE_FIELDS = {
  amazon: [{
    key: "access_key",
    label: "Access Key",
    help: "PA-API 5.0 Access Key"
  }, {
    key: "secret_key",
    label: "Secret Key",
    type: "password"
  }, {
    key: "partner_tag",
    label: "Associate Tag (ex: mysite-20)"
  }, {
    key: "marketplace",
    label: "Marketplace",
    help: "ex: www.amazon.com.br"
  }],
  shopee: [{
    key: "app_id",
    label: "App ID"
  }, {
    key: "app_secret",
    label: "App Secret",
    type: "password"
  }, {
    key: "sub_id",
    label: "SubID (opcional)"
  }],
  aliexpress: [{
    key: "app_key",
    label: "App Key"
  }, {
    key: "app_secret",
    label: "App Secret",
    type: "password"
  }, {
    key: "tracking_id",
    label: "Tracking ID"
  }],
  mercadolivre: [{
    key: "client_id",
    label: "Client ID"
  }, {
    key: "client_secret",
    label: "Client Secret",
    type: "password"
  }, {
    key: "site_id",
    label: "Site ID",
    help: "MLB para Brasil"
  }]
};
function AffiliateAccountsPage() {
  const qc = useQueryClient();
  const list = useServerFn(listAffiliateAccounts);
  const upsert = useServerFn(upsertAffiliateAccount);
  const del = useServerFn(deleteAffiliateAccount);
  const test = useServerFn(testAffiliateAccount);
  const accounts = useQuery({
    queryKey: ["affiliate-accounts"],
    queryFn: () => list()
  });
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [store, setStore] = useState("amazon");
  const [label, setLabel] = useState("");
  const [active, setActive] = useState(true);
  const [creds, setCreds] = useState({});
  function openNew() {
    setEditing(null);
    setStore("amazon");
    setLabel("");
    setActive(true);
    setCreds({});
    setOpen(true);
  }
  function openEdit(a) {
    setEditing(a);
    setStore(a.store);
    setLabel(a.label);
    setActive(a.is_active);
    setCreds(a.credentials ?? {});
    setOpen(true);
  }
  const saveMut = useMutation({
    mutationFn: () => upsert({
      data: {
        id: editing?.id,
        store,
        label,
        credentials: creds,
        is_active: active
      }
    }),
    onSuccess: () => {
      toast.success("Conta salva");
      setOpen(false);
      qc.invalidateQueries({
        queryKey: ["affiliate-accounts"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const delMut = useMutation({
    mutationFn: (id) => del({
      data: {
        id
      }
    }),
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["affiliate-accounts"]
    })
  });
  const testMut = useMutation({
    mutationFn: (id) => test({
      data: {
        id
      }
    }),
    onSuccess: (r) => {
      if (r.ok) toast.success(`Conexão OK — ${r.sampleCount} oferta(s) encontradas`);
      else toast.error(`Falhou: ${r.error}`);
      qc.invalidateQueries({
        queryKey: ["affiliate-accounts"]
      });
    }
  });
  const fields = STORE_FIELDS[store];
  return /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Contas de Afiliado" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Credenciais oficiais das lojas para o bot de promoções." })
      ] }),
      /* @__PURE__ */ jsxs(Button, { onClick: openNew, children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-2" }),
        "Nova conta"
      ] })
    ] }),
    /* @__PURE__ */ jsx(Card, { className: "overflow-hidden", children: accounts.data?.accounts.length === 0 ? /* @__PURE__ */ jsx("div", { className: "p-10 text-center text-sm text-muted-foreground", children: "Nenhuma conta cadastrada. Adicione suas credenciais para começar a receber promoções." }) : /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableHead, { children: "Loja" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Rótulo" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Status" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Último teste" }),
        /* @__PURE__ */ jsx(TableHead, { className: "text-right", children: "Ações" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: accounts.data?.accounts.map((a) => /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: STORE_LABELS[a.store] }) }),
        /* @__PURE__ */ jsx(TableCell, { className: "font-medium", children: a.label }),
        /* @__PURE__ */ jsxs(TableCell, { children: [
          a.is_active ? /* @__PURE__ */ jsx(Badge, { children: "Ativa" }) : /* @__PURE__ */ jsx(Badge, { variant: "outline", children: "Inativa" }),
          a.last_error && /* @__PURE__ */ jsx("div", { className: "text-xs text-destructive mt-1 max-w-xs truncate", title: a.last_error, children: a.last_error })
        ] }),
        /* @__PURE__ */ jsx(TableCell, { className: "text-xs text-muted-foreground", children: a.last_check_at ? new Date(a.last_check_at).toLocaleString("pt-BR") : "—" }),
        /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-1", children: [
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => testMut.mutate(a.id), disabled: testMut.isPending, children: testMut.isPending ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : a.last_error ? /* @__PURE__ */ jsx(XCircle, { className: "size-4 text-destructive" }) : /* @__PURE__ */ jsx(CheckCircle2, { className: "size-4 text-emerald-500" }) }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => openEdit(a), children: /* @__PURE__ */ jsx(Pencil, { className: "size-4" }) }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => {
            if (confirm("Excluir?")) delMut.mutate(a.id);
          }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
        ] }) })
      ] }, a.id)) })
    ] }) }),
    /* @__PURE__ */ jsx(Dialog, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-lg", children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: editing ? "Editar conta" : "Nova conta de afiliado" }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Loja" }),
            /* @__PURE__ */ jsxs(Select, { value: store, onValueChange: (v) => {
              setStore(v);
              setCreds({});
            }, disabled: !!editing, children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsx(SelectContent, { children: Object.keys(STORE_LABELS).map((s) => /* @__PURE__ */ jsx(SelectItem, { value: s, children: STORE_LABELS[s] }, s)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Rótulo" }),
            /* @__PURE__ */ jsx(Input, { value: label, onChange: (e) => setLabel(e.target.value), placeholder: "Ex: Conta principal" })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-2 pt-2", children: fields.map((f) => /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs", children: f.label }),
          /* @__PURE__ */ jsx(Input, { type: f.type ?? "text", value: creds[f.key] ?? "", onChange: (e) => setCreds((p) => ({
            ...p,
            [f.key]: e.target.value
          })) }),
          f.help && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-muted-foreground", children: f.help })
        ] }, f.key)) }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 pt-2", children: [
          /* @__PURE__ */ jsx(Switch, { checked: active, onCheckedChange: setActive }),
          /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Conta ativa" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setOpen(false), children: "Cancelar" }),
        /* @__PURE__ */ jsx(Button, { onClick: () => saveMut.mutate(), disabled: !label || saveMut.isPending, children: saveMut.isPending ? "Salvando..." : "Salvar" })
      ] })
    ] }) })
  ] });
}
export {
  AffiliateAccountsPage as component
};
