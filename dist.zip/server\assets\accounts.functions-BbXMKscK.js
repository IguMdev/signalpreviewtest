import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { f as getPremiumAccountConnectionStatus, a as sendTextWithPremiumEmojis, g as getUserEmojiLookup, r as renderEmojiTokens, b as renderEmojiTokensToHtml, s as sendPhotoWithPremiumEmojiCaption } from "./premium-send.server-B6I-0YLO.js";
import { r as renderTemplate } from "./signals.server-CxsfAlOW.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const verifyAccount_createServerFn_handler = createServerRpc({
  id: "4a076d7479753b932f9099c0e14826f639f88204af2dfc90155ac3cd1709f93a",
  name: "verifyAccount",
  filename: "src/lib/accounts.functions.ts"
}, (opts) => verifyAccount.__executeServer(opts));
const verifyAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(verifyAccount_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("id, bot_token, account_type").eq("id", data.accountId).maybeSingle();
  if (error || !acc) throw new Error("Conta não encontrada");
  if (acc.account_type === "premium") {
    const premium = await getPremiumAccountConnectionStatus(userId, acc.id);
    const premiumUpdate = premium.ok ? {
      status: "ok",
      last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_error: premium.isPremium ? null : "A conta conectada não tem Telegram Premium ativo.",
      bot_username: premium.username ?? null,
      bot_first_name: premium.firstName ?? null
    } : {
      status: "error",
      last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_error: premium.error
    };
    await supabase.from("telegram_accounts").update(premiumUpdate).eq("id", acc.id);
    if (!premium.ok) return {
      ok: false,
      error: premium.error
    };
    if (!premium.isPremium) return {
      ok: false,
      error: "A conta conectada não tem Telegram Premium ativo."
    };
    return {
      ok: true,
      bot: {
        id: 0,
        is_bot: false,
        first_name: premium.firstName ?? "Conta Premium",
        username: premium.username ?? void 0
      }
    };
  }
  const r = await callTelegram(acc.bot_token, "getMe");
  if (!r.ok || !r.result) {
    await supabase.from("telegram_accounts").update({
      status: "error",
      last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_error: r.description ?? "Falha desconhecida"
    }).eq("id", acc.id);
    return {
      ok: false,
      error: r.description ?? "Falha"
    };
  }
  await supabase.from("telegram_accounts").update({
    status: "ok",
    last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
    last_error: null,
    bot_username: r.result.username ?? null,
    bot_first_name: r.result.first_name ?? null
  }).eq("id", acc.id);
  return {
    ok: true,
    bot: r.result
  };
});
const sendTestMessage_createServerFn_handler = createServerRpc({
  id: "9d672f1b1145acd5f53de234dd6706a0c1e2dd86fe6670f5ad41ed73bdce3017",
  name: "sendTestMessage",
  filename: "src/lib/accounts.functions.ts"
}, (opts) => sendTestMessage.__executeServer(opts));
const sendTestMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  chatId: z.string().min(1),
  text: z.string().min(1).max(4e3)
}).parse(d)).handler(sendTestMessage_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("id, bot_token, account_type").eq("id", data.accountId).maybeSingle();
  if (error || !acc) throw new Error("Conta não encontrada");
  const premium = await sendTextWithPremiumEmojis({
    userId,
    accountId: acc.account_type === "premium" ? acc.id : void 0,
    chatId: data.chatId,
    text: data.text,
    allowPlain: acc.account_type === "premium",
    strict: acc.account_type === "premium"
  });
  if (premium.applied) {
    if (!premium.ok) return {
      ok: false,
      error: premium.error,
      reason: premium.reason
    };
    return {
      ok: true,
      messageId: premium.messageId ?? void 0
    };
  }
  if (acc.account_type === "premium") {
    return {
      ok: false,
      error: "Envio premium não aplicado.",
      reason: premium.reason
    };
  }
  const r = await callTelegram(acc.bot_token, "sendMessage", {
    chat_id: data.chatId,
    text: data.text,
    parse_mode: "HTML"
  });
  if (!r.ok) return {
    ok: false,
    error: r.description,
    reason: premium.reason
  };
  return {
    ok: true,
    messageId: r.result?.message_id
  };
});
const refreshChats_createServerFn_handler = createServerRpc({
  id: "0a01656cd747bbe876270e0d8d002d5de74fd71d2f56128cccd31ed18ee88355",
  name: "refreshChats",
  filename: "src/lib/accounts.functions.ts"
}, (opts) => refreshChats.__executeServer(opts));
const refreshChats = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(refreshChats_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: acc,
    error
  } = await supabase.from("telegram_accounts").select("id, bot_token").eq("id", data.accountId).maybeSingle();
  if (error || !acc) throw new Error("Conta não encontrada");
  const r = await callTelegram(acc.bot_token, "getUpdates", {
    limit: 100
  });
  if (!r.ok || !r.result) return {
    ok: false,
    error: r.description
  };
  const chats = /* @__PURE__ */ new Map();
  for (const u of r.result) {
    const c = u.message?.chat ?? u.channel_post?.chat ?? u.my_chat_member?.chat;
    if (c && (c.type === "group" || c.type === "supergroup" || c.type === "channel")) {
      chats.set(c.id, {
        title: c.title,
        type: c.type,
        username: c.username
      });
    }
  }
  const rows = Array.from(chats.entries()).map(([chat_id, v]) => ({
    account_id: acc.id,
    user_id: userId,
    chat_id,
    title: v.title ?? null,
    type: v.type,
    username: v.username ?? null,
    cached_at: (/* @__PURE__ */ new Date()).toISOString()
  }));
  if (rows.length > 0) {
    const {
      error: upErr
    } = await supabase.from("telegram_chats").upsert(rows, {
      onConflict: "account_id,chat_id"
    });
    if (upErr) return {
      ok: false,
      error: upErr.message
    };
  }
  return {
    ok: true,
    count: rows.length
  };
});
const sendRoomTest_createServerFn_handler = createServerRpc({
  id: "40fcf5e29c7970fea9b71db6b24426d496c10dbf59ef04683fd7842621b9abcf",
  name: "sendRoomTest",
  filename: "src/lib/accounts.functions.ts"
}, (opts) => sendRoomTest.__executeServer(opts));
const sendRoomTest = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  templateKind: z.enum(["buy_direction", "entry", "event", "gain", "loss", "sell_direction", "signal", "win", "win_martingale"]).optional(),
  text: z.string().max(4e3).optional(),
  imagePath: z.string().optional(),
  imageBucket: z.string().optional(),
  imageMime: z.string().optional(),
  imageExt: z.string().optional()
}).parse(d)).handler(sendRoomTest_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: room,
    error: roomErr
  } = await supabase.from("rooms").select("id, default_account_id").eq("id", data.roomId).maybeSingle();
  if (roomErr || !room) throw new Error("Sala não encontrada");
  if (!room.default_account_id) throw new Error("Selecione um bot padrão para a sala antes de enviar testes.");
  const {
    data: chat
  } = await supabase.from("room_chats").select("chat_id").eq("room_id", room.id).limit(1).maybeSingle();
  if (!chat) throw new Error("Vincule pelo menos um chat do Telegram à sala antes de enviar testes.");
  const {
    data: acc
  } = await supabase.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
  if (!acc) throw new Error("Bot da sala não encontrado");
  let sampleAsset = "EURUSD";
  let sampleTimeframe = "M1";
  let sampleDirection = "buy";
  let sampleEntryAt = null;
  try {
    const {
      data: lastSig
    } = await supabase.from("signal_events").select("asset_code, timeframe, direction, entry_at").eq("room_id", room.id).order("entry_at", {
      ascending: false
    }).limit(1).maybeSingle();
    if (lastSig?.asset_code) {
      sampleAsset = lastSig.asset_code;
      sampleTimeframe = lastSig.timeframe ?? sampleTimeframe;
      sampleDirection = lastSig.direction ?? sampleDirection;
      sampleEntryAt = lastSig.entry_at ? new Date(lastSig.entry_at) : null;
    } else {
      const {
        data: ra
      } = await supabase.from("room_assets").select("asset_code").eq("room_id", room.id).eq("is_open", true).limit(1).maybeSingle();
      if (ra?.asset_code) sampleAsset = ra.asset_code;
    }
  } catch {
  }
  const now = /* @__PURE__ */ new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const hhmm = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const entry = sampleEntryAt ?? new Date(Math.ceil((now.getTime() + 1) / 6e4) * 6e4);
  const rawText = data.text?.trim() || "";
  const text = rawText ? renderTemplate(rawText, {
    ATIVO: sampleAsset,
    TIMEFRAME: sampleTimeframe,
    DIRECAO: sampleDirection === "sell" ? "🔴 VENDA" : "🟢 COMPRA",
    ENTRADA: hhmm(entry),
    ENTRADAGALE1: hhmm(new Date(entry.getTime() + 6e4)),
    ENTRADAGALE2: hhmm(new Date(entry.getTime() + 12e4)),
    MARTINGALE: "2"
  }) : "";
  const emojiLookup = await getUserEmojiLookup(userId);
  const {
    data: buttons
  } = await supabase.from("room_template_buttons").select("label, url, sort_order").eq("room_id", room.id).eq("template_kind", data.templateKind || "signal").order("sort_order", {
    ascending: true
  });
  const buttonRows = (buttons ?? []).filter((b) => b.label && b.url).map((b) => [{
    text: renderEmojiTokens(b.label, emojiLookup).text,
    url: b.url
  }]);
  const replyMarkup = buttonRows.length ? {
    inline_keyboard: buttonRows
  } : void 0;
  const botText = replyMarkup ? renderEmojiTokensToHtml(text, emojiLookup).text : text;
  let r;
  if (data.imagePath) {
    const bucket = data.imageBucket || "room-images";
    const {
      data: pub
    } = supabase.storage.from(bucket).getPublicUrl(data.imagePath);
    const mime = (data.imageMime || "").toLowerCase();
    const ext = (data.imageExt || data.imagePath.split(".").pop() || "").toLowerCase();
    const isStickerByMime = mime === "image/webp" || mime === "application/x-tgsticker" || mime === "video/webm";
    const isStickerByExt = ext === "webp" || ext === "tgs" || ext === "webm";
    const isSticker = isStickerByMime || !mime && isStickerByExt;
    if (isSticker) {
      r = await callTelegram(acc.bot_token, "sendSticker", {
        chat_id: chat.chat_id,
        sticker: pub.publicUrl,
        reply_markup: replyMarkup
      });
      if (r.ok && text) {
        const premium = await sendTextWithPremiumEmojis({
          userId,
          chatId: chat.chat_id,
          text,
          buttonRows: buttonRows.length ? buttonRows : void 0
        });
        if (premium.applied) {
          if (!premium.ok) throw new Error(premium.error);
        } else await callTelegram(acc.bot_token, "sendMessage", {
          chat_id: chat.chat_id,
          text: botText,
          parse_mode: "HTML",
          reply_markup: replyMarkup
        });
      }
    } else {
      const premiumPhoto = await sendPhotoWithPremiumEmojiCaption({
        userId,
        chatId: chat.chat_id,
        photoUrl: pub.publicUrl,
        caption: text,
        buttonRows: buttonRows.length ? buttonRows : void 0
      });
      if (premiumPhoto.applied) {
        if (premiumPhoto.ok) {
          r = {
            ok: true,
            result: {
              message_id: premiumPhoto.messageId ?? void 0
            }
          };
        } else {
          r = {
            ok: false,
            description: premiumPhoto.error
          };
        }
      } else {
        r = await callTelegram(acc.bot_token, "sendPhoto", {
          chat_id: chat.chat_id,
          photo: pub.publicUrl,
          caption: botText || void 0,
          parse_mode: "HTML",
          reply_markup: replyMarkup
        });
      }
    }
  } else {
    if (!text) throw new Error("Mensagem vazia");
    const premium = await sendTextWithPremiumEmojis({
      userId,
      chatId: chat.chat_id,
      text,
      buttonRows: buttonRows.length ? buttonRows : void 0
    });
    if (premium.applied) {
      if (!premium.ok) throw new Error(premium.error);
      r = {
        ok: true,
        result: {
          message_id: premium.messageId ?? void 0
        }
      };
    } else r = await callTelegram(acc.bot_token, "sendMessage", {
      chat_id: chat.chat_id,
      text: botText,
      parse_mode: "HTML",
      reply_markup: replyMarkup
    });
  }
  if (!r.ok) throw new Error(r.description ?? "Falha ao enviar");
  if (r.result?.message_id) {
    const {
      triggerSignalReactions
    } = await import("./engagement.functions-BnPQkoHV.js").then((n) => n.m);
    await triggerSignalReactions({
      userId,
      chatId: chat.chat_id,
      telegramMessageId: r.result.message_id,
      roomId: room.id
    });
  }
  return {
    ok: true,
    messageId: r.result?.message_id
  };
});
export {
  refreshChats_createServerFn_handler,
  sendRoomTest_createServerFn_handler,
  sendTestMessage_createServerFn_handler,
  verifyAccount_createServerFn_handler
};
