import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
function hasEmojiTokens(s) {
  if (!s) return false;
  return /\{[^}]+\}/.test(s);
}
const TOKEN_RE = /\{([^{}\n]{1,80})\}/g;
function renderEmojiTokens(text, lookup) {
  const normalizedLookup = new Map(
    Array.from(lookup.entries()).map(([name, value]) => [name.trim().toUpperCase(), value])
  );
  const entities = [];
  const re = new RegExp(TOKEN_RE);
  let out = "";
  let last = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    out += text.slice(last, m.index);
    const name = m[1].trim();
    const found = lookup.get(name) ?? normalizedLookup.get(name.toUpperCase());
    if (!found) {
      out += m[0];
      last = m.index + m[0].length;
      continue;
    }
    const replacement = found.preview_char && found.preview_char.length > 0 ? found.preview_char : "⭐";
    entities.push({
      name,
      offset: out.length,
      length: replacement.length,
      documentId: found.custom_emoji_id
    });
    out += replacement;
    last = m.index + m[0].length;
  }
  out += text.slice(last);
  return { text: out, entities };
}
function renderEmojiTokensToHtml(text, lookup) {
  const normalizedLookup = new Map(
    Array.from(lookup.entries()).map(([name, value]) => [name.trim().toUpperCase(), value])
  );
  let replaced = false;
  const out = text.replace(TOKEN_RE, (token, rawName) => {
    const name = rawName.trim();
    const found = lookup.get(name) ?? normalizedLookup.get(name.toUpperCase());
    if (!found) return token;
    replaced = true;
    const fallback = found.preview_char && found.preview_char.length > 0 ? found.preview_char : "⭐";
    return `<tg-emoji emoji-id="${found.custom_emoji_id}">${fallback}</tg-emoji>`;
  });
  return { text: out, replaced };
}
function renderEmojiTokensPlain(text, lookup) {
  const normalizedLookup = new Map(
    Array.from(lookup.entries()).map(([name, value]) => [name.trim().toUpperCase(), value])
  );
  return text.replace(TOKEN_RE, (token, rawName) => {
    const name = rawName.trim();
    const found = lookup.get(name) ?? normalizedLookup.get(name.toUpperCase());
    if (!found) return token;
    return found.preview_char && found.preview_char.length > 0 ? found.preview_char : "⭐";
  });
}
const TRANSIENT_REASONS = /* @__PURE__ */ new Set([
  "flood-wait",
  "client-send-threw",
  "media-invalid",
  "slowmode",
  "peer-invalid"
]);
function isTransientReason(reason) {
  return reason ? TRANSIENT_REASONS.has(reason) : false;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function sendTextWithPremiumEmojisRetry(opts, maxAttempts = 3) {
  let last = { applied: false, reason: "not-attempted" };
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    last = await sendTextWithPremiumEmojis(opts);
    if (!last.applied) return last;
    if (last.ok) return last;
    if (!isTransientReason(last.reason)) return last;
    if (attempt < maxAttempts) {
      console.warn("[premium-send] retry text", { attempt, reason: last.reason });
      await sleep(1e3 * attempt);
    }
  }
  return last;
}
async function sendPhotoWithPremiumEmojiCaptionRetry(opts, maxAttempts = 3) {
  let last = { applied: false, reason: "not-attempted" };
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    last = await sendPhotoWithPremiumEmojiCaption(opts);
    if (!last.applied) return last;
    if (last.ok) return last;
    if (!isTransientReason(last.reason)) return last;
    if (attempt < maxAttempts) {
      console.warn("[premium-send] retry photo", { attempt, reason: last.reason });
      await sleep(1e3 * attempt);
    }
  }
  return last;
}
async function buildInlineMarkup(buttonRows) {
  if (!buttonRows || !buttonRows.length) return void 0;
  const { Api } = await import("telegram");
  const rows = buttonRows.map(
    (row) => new Api.KeyboardButtonRow({
      buttons: row.filter((b) => b.text && b.url).map((b) => new Api.KeyboardButtonUrl({ text: b.text, url: b.url }))
    })
  ).filter((r) => r.buttons.length > 0);
  if (!rows.length) return void 0;
  return new Api.ReplyInlineMarkup({ rows });
}
function logPremiumFallback(ctx, reason, extra) {
  const preview = (ctx.text ?? "").slice(0, 80).replace(/\s+/g, " ");
  console.warn("[premium-send] fallback to plain", {
    where: ctx.where,
    reason,
    userId: ctx.userId,
    accountId: ctx.accountId ?? null,
    chatId: String(ctx.chatId),
    parseMode: ctx.parseMode ?? "MTProto/customEmoji",
    entitiesCount: ctx.entitiesCount,
    textPreview: preview,
    ...extra
  });
}
function translateMtprotoError(raw) {
  const r = (raw || "").toUpperCase();
  if (r.includes("CHAT_ADMIN_REQUIRED")) {
    return {
      reason: "chat-admin-required",
      message: "A conta Premium precisa ser admin desse canal/grupo (com permissão de postar) para enviar emojis animados."
    };
  }
  if (r.includes("CHAT_WRITE_FORBIDDEN") || r.includes("CHANNEL_PRIVATE")) {
    return {
      reason: "chat-write-forbidden",
      message: "A conta Premium não tem permissão para escrever nesse chat. Adicione-a ao canal/grupo (como admin, se for canal)."
    };
  }
  if (r.includes("USER_BANNED_IN_CHANNEL") || r.includes("USER_KICKED")) {
    return {
      reason: "user-banned",
      message: "A conta Premium foi banida ou removida desse chat."
    };
  }
  if (r.includes("PEER_ID_INVALID")) {
    return {
      reason: "peer-invalid",
      message: "A conta Premium ainda não conhece esse chat. Entre no canal/grupo com a conta Premium pelo menos uma vez."
    };
  }
  if (r.includes("SLOWMODE_WAIT")) {
    return { reason: "slowmode", message: "O chat está em modo lento. Aguarde antes de enviar novamente." };
  }
  if (r.includes("FLOOD_WAIT")) {
    return { reason: "flood-wait", message: "Telegram pediu para aguardar antes de enviar (flood wait)." };
  }
  if (r.includes("AUTH_KEY") || r.includes("SESSION_REVOKED") || r.includes("SESSION_EXPIRED")) {
    return {
      reason: "session-invalid",
      message: "A sessão da conta Premium expirou. Reconecte a conta Telegram Premium."
    };
  }
  if (r.includes("MEDIA_EMPTY") || r.includes("PHOTO_INVALID")) {
    return { reason: "media-invalid", message: "A imagem enviada é inválida ou não pôde ser baixada pelo Telegram." };
  }
  return { reason: "client-send-threw", message: raw };
}
async function getUserEmojiLookup(userId) {
  const { data: emojiRows } = await supabaseAdmin.from("premium_emojis").select("name, custom_emoji_id, preview_char").eq("user_id", userId);
  return new Map(
    (emojiRows ?? []).map((r) => [
      r.name,
      { custom_emoji_id: r.custom_emoji_id, preview_char: r.preview_char }
    ])
  );
}
async function getActivePremiumAccount(userId, accountId) {
  let query = supabaseAdmin.from("telegram_accounts").select("id, tg_api_id, tg_api_hash, tg_session").eq("user_id", userId).eq("account_type", "premium").eq("is_active", true).not("tg_session", "is", null);
  query = accountId ? query.eq("id", accountId) : query.limit(1);
  const { data: acc } = await query.maybeSingle();
  if (!acc?.tg_session || !acc.tg_api_id || !acc.tg_api_hash) return null;
  return acc;
}
function resolveTelegramTarget(chatId) {
  const numeric = typeof chatId === "string" ? Number(chatId) : chatId;
  return Number.isFinite(numeric) ? numeric : chatId;
}
function resolveNormalVideoDimensions(width, height) {
  const w = Number(width);
  const h = Number(height);
  if (Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0) {
    return { width: Math.round(w), height: Math.round(h) };
  }
  return { width: 720, height: 1280 };
}
function safeTelegramThumbnail(bytes) {
  if (!bytes || bytes.byteLength > 200 * 1024) return null;
  return bytes;
}
async function createUploadFile(filename, bytes) {
  const { CustomFile } = await import("telegram/client/uploads.js");
  if (bytes.length < 20 * 1024 * 1024) {
    return { file: new CustomFile(filename, bytes.length, "", bytes), cleanup: async () => {
    } };
  }
  const { writeFile, unlink } = await import("fs/promises");
  const { join } = await import("path");
  const { randomUUID } = await import("crypto");
  const filePath = join("/tmp", `${randomUUID()}-${filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`);
  await writeFile(filePath, bytes);
  return {
    file: new CustomFile(filename, bytes.length, filePath),
    cleanup: async () => {
      await unlink(filePath).catch(() => {
      });
    }
  };
}
async function connectAndAssertPremium(acc) {
  const { TelegramClient, Api } = await import("telegram");
  const { StringSession } = await import("telegram/sessions/index.js");
  const client = new TelegramClient(
    new StringSession(acc.tg_session),
    acc.tg_api_id,
    acc.tg_api_hash,
    { connectionRetries: 2, useWSS: true }
  );
  await client.connect();
  let isPremium = false;
  let userInfo = {};
  try {
    const me = await client.invoke(
      new Api.users.GetFullUser({ id: new Api.InputUserSelf() })
    );
    const user = (me.users ?? []).find(
      (u) => u.className === "User"
    );
    isPremium = Boolean(user?.premium);
    userInfo = {
      firstName: user?.firstName ?? null,
      username: user?.username ?? null
    };
  } catch {
    isPremium = false;
  }
  return { client, isPremium, userInfo };
}
async function renderTelegramHtmlWithPremiumEmojis(text, lookup) {
  const { HTMLParser } = await import("telegram/extensions/html.js");
  const { Api } = await import("telegram");
  const { default: bigInt } = await import("big-integer");
  const html = renderEmojiTokensToHtml(text, lookup).text;
  const [parsedText, rawEntities] = HTMLParser.parse(html);
  const entities = (rawEntities ?? []).map(
    (entity) => entity.className === "MessageEntityCustomEmoji" ? new Api.MessageEntityCustomEmoji({
      offset: entity.offset,
      length: entity.length,
      documentId: bigInt(String(entity.documentId))
    }) : entity
  );
  return { text: parsedText, entities };
}
async function getPremiumAccountConnectionStatus(userId, accountId) {
  const acc = await getActivePremiumAccount(userId, accountId);
  if (!acc) return { ok: false, error: "Conecte a conta Telegram Premium novamente." };
  const { client, isPremium, userInfo } = await connectAndAssertPremium({
    tg_api_id: acc.tg_api_id,
    tg_api_hash: acc.tg_api_hash,
    tg_session: acc.tg_session
  });
  await client.disconnect().catch(() => {
  });
  return { ok: true, isPremium, ...userInfo };
}
async function sendTextWithPremiumEmojis(opts) {
  if (!hasEmojiTokens(opts.text)) {
    if (opts.allowPlain) {
      const acc2 = await getActivePremiumAccount(opts.userId, opts.accountId);
      if (!acc2) {
        logPremiumFallback(
          { where: "sendText.allowPlain", userId: opts.userId, accountId: opts.accountId, chatId: opts.chatId, text: opts.text, entitiesCount: 0 },
          "no-active-premium-account"
        );
        return { applied: true, ok: false, error: "Conecte a conta Telegram Premium novamente.", reason: "no-active-premium-account" };
      }
      const { client: client2 } = await connectAndAssertPremium({
        tg_api_id: acc2.tg_api_id,
        tg_api_hash: acc2.tg_api_hash,
        tg_session: acc2.tg_session
      });
      try {
        const buttons = await buildInlineMarkup(opts.buttonRows);
        const formatted = await renderTelegramHtmlWithPremiumEmojis(opts.text, /* @__PURE__ */ new Map());
        const msg = await client2.sendMessage(resolveTelegramTarget(opts.chatId), {
          message: formatted.text,
          formattingEntities: formatted.entities,
          replyTo: opts.replyToMessageId,
          linkPreview: false,
          ...buttons ? { buttons } : {}
        });
        return { applied: true, ok: true, messageId: Number(msg.id) };
      } catch (e) {
        const raw = e instanceof Error ? e.message : String(e);
        const { message: error, reason } = translateMtprotoError(raw);
        logPremiumFallback(
          { where: "sendText.allowPlain", userId: opts.userId, accountId: acc2.id, chatId: opts.chatId, text: opts.text, entitiesCount: 0 },
          reason,
          { rawError: raw }
        );
        return { applied: true, ok: false, error, reason };
      } finally {
        await client2.disconnect().catch(() => {
        });
      }
    }
    logPremiumFallback(
      { where: "sendText", userId: opts.userId, accountId: opts.accountId, chatId: opts.chatId, text: opts.text, entitiesCount: 0 },
      "no-tokens"
    );
    return { applied: false, reason: "no-tokens" };
  }
  const lookup = await getUserEmojiLookup(opts.userId);
  const rendered = renderEmojiTokens(opts.text, lookup);
  if (!rendered.entities.length) {
    logPremiumFallback(
      { where: "sendText", userId: opts.userId, accountId: opts.accountId, chatId: opts.chatId, text: opts.text, entitiesCount: 0 },
      "no-known-emojis",
      { lookupSize: lookup.size }
    );
    if (opts.strict) {
      return { applied: true, ok: false, error: "Nenhum emoji premium salvo corresponde aos tokens da mensagem.", reason: "no-known-emojis" };
    }
    return { applied: false, reason: "no-known-emojis" };
  }
  const acc = await getActivePremiumAccount(opts.userId, opts.accountId);
  if (!acc) {
    logPremiumFallback(
      { where: "sendText", userId: opts.userId, accountId: opts.accountId, chatId: opts.chatId, text: opts.text, entitiesCount: rendered.entities.length },
      "no-premium-account"
    );
    if (opts.strict) {
      return { applied: true, ok: false, error: "Conecte uma conta Telegram Premium ativa para enviar emojis premium animados.", reason: "no-premium-account" };
    }
    return { applied: false, reason: "no-premium-account" };
  }
  const { client, isPremium } = await connectAndAssertPremium({
    tg_api_id: acc.tg_api_id,
    tg_api_hash: acc.tg_api_hash,
    tg_session: acc.tg_session
  });
  if (!isPremium) {
    await client.disconnect().catch(() => {
    });
    logPremiumFallback(
      { where: "sendText", userId: opts.userId, accountId: acc.id, chatId: opts.chatId, text: opts.text, entitiesCount: rendered.entities.length },
      "account-not-premium"
    );
    return {
      applied: true,
      ok: false,
      error: "A conta Telegram conectada não tem assinatura Premium ativa. Sem Premium o Telegram remove os emojis animados antes de entregar a mensagem.",
      reason: "account-not-premium"
    };
  }
  try {
    const formatted = await renderTelegramHtmlWithPremiumEmojis(opts.text, lookup);
    const target = resolveTelegramTarget(opts.chatId);
    const buttons = await buildInlineMarkup(opts.buttonRows);
    console.log("[premium-send] sending text", {
      userId: opts.userId,
      accountId: acc.id,
      chatId: String(opts.chatId),
      entitiesCount: formatted.entities.length,
      docIds: rendered.entities.map((e) => e.documentId),
      buttonRows: opts.buttonRows?.length ?? 0
    });
    const msg = await client.sendMessage(target, {
      message: formatted.text,
      formattingEntities: formatted.entities,
      replyTo: opts.replyToMessageId,
      linkPreview: false,
      ...buttons ? { buttons } : {}
    });
    return { applied: true, ok: true, messageId: Number(msg.id) };
  } catch (e) {
    const raw = e instanceof Error ? e.message : String(e);
    const { message: error, reason } = translateMtprotoError(raw);
    logPremiumFallback(
      { where: "sendText", userId: opts.userId, accountId: acc.id, chatId: opts.chatId, text: opts.text, entitiesCount: rendered.entities.length },
      reason,
      { rawError: raw }
    );
    return {
      applied: true,
      ok: false,
      error,
      reason
    };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
}
async function sendVideoWithPremiumEmojiCaption(opts) {
  if (!opts.caption || !hasEmojiTokens(opts.caption)) {
    return { applied: false, reason: "no-tokens" };
  }
  const lookup = await getUserEmojiLookup(opts.userId);
  const rendered = renderEmojiTokens(opts.caption, lookup);
  if (!rendered.entities.length) {
    if (opts.strict) {
      return { applied: true, ok: false, error: "Nenhum emoji premium salvo corresponde aos tokens da legenda.", reason: "no-known-emojis" };
    }
    return { applied: false, reason: "no-known-emojis" };
  }
  const acc = await getActivePremiumAccount(opts.userId, opts.accountId);
  if (!acc) {
    if (opts.strict) {
      return { applied: true, ok: false, error: "Conecte uma conta Telegram Premium ativa para enviar emojis premium animados.", reason: "no-premium-account" };
    }
    return { applied: false, reason: "no-premium-account" };
  }
  const { Api } = await import("telegram");
  const { client, isPremium } = await connectAndAssertPremium({
    tg_api_id: acc.tg_api_id,
    tg_api_hash: acc.tg_api_hash,
    tg_session: acc.tg_session
  });
  if (!isPremium) {
    await client.disconnect().catch(() => {
    });
    return {
      applied: true,
      ok: false,
      error: "A conta Telegram conectada não tem assinatura Premium ativa. Sem Premium o Telegram remove os emojis animados da legenda antes de entregar.",
      reason: "account-not-premium"
    };
  }
  try {
    const formatted = await renderTelegramHtmlWithPremiumEmojis(opts.caption, lookup);
    const target = resolveTelegramTarget(opts.chatId);
    const buttons = await buildInlineMarkup(opts.buttonRows);
    const buf = Buffer.from(opts.videoBytes);
    const upload = await createUploadFile(opts.filename, buf);
    const thumbBytes = safeTelegramThumbnail(opts.thumbnailBytes);
    const thumbBuffer = thumbBytes ? Buffer.from(thumbBytes) : null;
    const dimensions = resolveNormalVideoDimensions(opts.width, opts.height);
    const attributes = [
      new Api.DocumentAttributeVideo({
        duration: Math.max(1, Math.round(opts.duration ?? 1)),
        w: dimensions.width,
        h: dimensions.height
      }),
      new Api.DocumentAttributeFilename({ fileName: opts.filename })
    ];
    try {
      const msg = await client.sendFile(target, {
        file: upload.file,
        caption: formatted.text,
        formattingEntities: formatted.entities,
        attributes,
        ...thumbBuffer ? { thumb: thumbBuffer } : {},
        forceDocument: false,
        replyTo: opts.replyToMessageId,
        ...buttons ? { buttons } : {}
      });
      return { applied: true, ok: true, messageId: Number(msg.id) };
    } finally {
      await upload.cleanup();
    }
  } catch (e) {
    const raw = e instanceof Error ? e.message : String(e);
    const { message: error, reason } = translateMtprotoError(raw);
    return { applied: true, ok: false, error, reason };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
}
async function sendPhotoWithPremiumEmojiCaption(opts) {
  if (!opts.caption || !hasEmojiTokens(opts.caption)) {
    return { applied: false, reason: "no-tokens" };
  }
  const lookup = await getUserEmojiLookup(opts.userId);
  const rendered = renderEmojiTokens(opts.caption, lookup);
  if (!rendered.entities.length) {
    logPremiumFallback(
      { where: "sendPhoto", userId: opts.userId, accountId: opts.accountId, chatId: opts.chatId, text: opts.caption ?? "", entitiesCount: 0 },
      "no-known-emojis",
      { lookupSize: lookup.size }
    );
    if (opts.strict) {
      return { applied: true, ok: false, error: "Nenhum emoji premium salvo corresponde aos tokens da legenda.", reason: "no-known-emojis" };
    }
    return { applied: false, reason: "no-known-emojis" };
  }
  const acc = await getActivePremiumAccount(opts.userId, opts.accountId);
  if (!acc) {
    logPremiumFallback(
      { where: "sendPhoto", userId: opts.userId, accountId: opts.accountId, chatId: opts.chatId, text: opts.caption ?? "", entitiesCount: rendered.entities.length },
      "no-premium-account"
    );
    if (opts.strict) {
      return { applied: true, ok: false, error: "Conecte uma conta Telegram Premium ativa para enviar emojis premium animados.", reason: "no-premium-account" };
    }
    return { applied: false, reason: "no-premium-account" };
  }
  const { Api } = await import("telegram");
  const { default: bigInt } = await import("big-integer");
  const { client, isPremium } = await connectAndAssertPremium({
    tg_api_id: acc.tg_api_id,
    tg_api_hash: acc.tg_api_hash,
    tg_session: acc.tg_session
  });
  if (!isPremium) {
    await client.disconnect().catch(() => {
    });
    logPremiumFallback(
      { where: "sendPhoto", userId: opts.userId, accountId: acc.id, chatId: opts.chatId, text: opts.caption ?? "", entitiesCount: rendered.entities.length },
      "account-not-premium"
    );
    return {
      applied: true,
      ok: false,
      error: "A conta Telegram conectada não tem assinatura Premium ativa. Sem Premium o Telegram remove os emojis animados da legenda antes de entregar.",
      reason: "account-not-premium"
    };
  }
  try {
    const formatted = await renderTelegramHtmlWithPremiumEmojis(opts.caption, lookup);
    const target = resolveTelegramTarget(opts.chatId);
    const buttons = await buildInlineMarkup(opts.buttonRows);
    console.log("[premium-send] sending photo", {
      userId: opts.userId,
      accountId: acc.id,
      chatId: String(opts.chatId),
      entitiesCount: formatted.entities.length,
      docIds: rendered.entities.map((e) => e.documentId),
      buttonRows: opts.buttonRows?.length ?? 0
    });
    let upload = null;
    let fileArg = opts.photoUrl;
    if (typeof opts.photoUrl === "string" && /^https?:\/\//i.test(opts.photoUrl)) {
      const r = await fetch(opts.photoUrl);
      if (!r.ok) throw new Error(`Falha ao baixar foto (${r.status})`);
      const ab = await r.arrayBuffer();
      const buf = Buffer.from(ab);
      if (!buf.length) throw new Error("Foto vazia ao baixar URL");
      const name = opts.photoUrl.split("/").pop()?.split("?")[0] || "photo.jpg";
      upload = await createUploadFile(name, buf);
      fileArg = upload.file;
    } else if (!opts.photoUrl) {
      throw new Error("photoUrl ausente para envio premium");
    }
    try {
      const msg = await client.sendFile(target, {
        file: fileArg,
        caption: formatted.text,
        formattingEntities: formatted.entities,
        replyTo: opts.replyToMessageId,
        ...buttons ? { buttons } : {}
      });
      return { applied: true, ok: true, messageId: Number(msg.id) };
    } finally {
      await upload?.cleanup();
    }
  } catch (e) {
    const raw = e instanceof Error ? e.message : String(e);
    const { message: error, reason } = translateMtprotoError(raw);
    logPremiumFallback(
      { where: "sendPhoto", userId: opts.userId, accountId: acc.id, chatId: opts.chatId, text: opts.caption ?? "", entitiesCount: rendered.entities.length },
      reason,
      { rawError: raw }
    );
    return {
      applied: true,
      ok: false,
      error,
      reason
    };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
}
export {
  sendTextWithPremiumEmojis as a,
  renderEmojiTokensToHtml as b,
  sendPhotoWithPremiumEmojiCaptionRetry as c,
  sendTextWithPremiumEmojisRetry as d,
  sendVideoWithPremiumEmojiCaption as e,
  getPremiumAccountConnectionStatus as f,
  getUserEmojiLookup as g,
  hasEmojiTokens as h,
  renderEmojiTokensPlain as i,
  renderEmojiTokens as r,
  sendPhotoWithPremiumEmojiCaption as s
};
