import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { n as listOffers, o as createOffer, p as deleteOffer, i as getMyRedirectBase, q as listDomains } from "./tracking.functions-jGKb0ig9.js";
import { C as Card, O as CardHeader, Q as CardTitle, W as CardDescription, D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, x as CardContent, H as Badge, h as DialogHeader, i as DialogTitle, L as Label, I as Input, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, N as Switch, j as DialogFooter } from "./router-Cw6OHOsO.js";
import { T as TooltipProvider, a as Tooltip, b as TooltipTrigger, c as TooltipContent } from "./tooltip-DPQMaJsn.js";
import { Funnel, Plus, Trash2, Copy, HelpCircle, X, AlertTriangle } from "lucide-react";
import { u as usePixelFilter, P as PixelFilterBar } from "./PixelFilter-FzJuz8YB.js";
import "@tanstack/react-router";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-tooltip";
function FunisPage() {
  const {
    pixelId,
    pixels,
    setPixel
  } = usePixelFilter();
  const effectiveId = pixelId ?? pixels[0]?.id ?? null;
  const currentPixel = pixels.find((p) => p.id === effectiveId);
  const mode = currentPixel?.tracking_mode ?? "telegram";
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-5xl", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Funnel, { className: "size-6" }),
        " Funis"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1 max-w-2xl", children: mode === "direct_response" ? "Para pixels Direct Response, o funil é a sua própria página de vendas → checkout. Configure a URL e o snippet em Trackeamento → Canal." : /* @__PURE__ */ jsxs(Fragment, { children: [
        "Cadastre as ofertas (links de afiliado) de cada pixel. Geramos um redirector único por clique para injetar o ",
        /* @__PURE__ */ jsx("code", { children: "subid" }),
        " e disparar eventos Meta."
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(PixelFilterBar, { pixelId: effectiveId, pixels, setPixel }),
    effectiveId && mode === "telegram" && /* @__PURE__ */ jsx(OffersList, { pixelId: effectiveId }),
    effectiveId && mode === "direct_response" && /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardHeader, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: "Modo Direct Response" }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        "Esse pixel rastreia o fluxo Meta → página de vendas → checkout → compra. Não há ofertas/redirect a cadastrar aqui — basta colar o snippet JS na sua página (aba ",
        /* @__PURE__ */ jsx("strong", { children: "Canal" }),
        ") e disparar ",
        /* @__PURE__ */ jsxs("code", { children: [
          "lvTrack('purchase', ",
          `{ value, email }`,
          ")"
        ] }),
        " na página de obrigado."
      ] })
    ] }) })
  ] });
}
function OffersList({
  pixelId
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listOffers);
  useServerFn(createOffer);
  const delFn = useServerFn(deleteOffer);
  const baseFn = useServerFn(getMyRedirectBase);
  const domainsFn = useServerFn(listDomains);
  const offers = useQuery({
    queryKey: ["offers", pixelId],
    queryFn: () => listFn({
      data: {
        pixel_id: pixelId
      }
    })
  });
  const base = useQuery({
    queryKey: ["redirect-base"],
    queryFn: () => baseFn()
  });
  const domains = useQuery({
    queryKey: ["tracking-domains"],
    queryFn: () => domainsFn()
  });
  const [open, setOpen] = useState(false);
  const [instructions, setInstructions] = useState(null);
  const remove = useMutation({
    mutationFn: (id) => delFn({
      data: {
        id
      }
    }),
    onSuccess: () => {
      toast.success("Removida");
      qc.invalidateQueries({
        queryKey: ["offers", pixelId]
      });
    }
  });
  const baseHost = base.data?.domain ? `https://${base.data.domain}` : typeof window !== "undefined" ? window.location.origin : "";
  return /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange: setOpen, children: [
      /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
        " Novo funil"
      ] }) }),
      /* @__PURE__ */ jsx(DialogContent, { className: "max-w-2xl", children: /* @__PURE__ */ jsx(NewFunnelDialog, { pixelId, domains: (domains.data ?? []).filter((d) => d.verified_at), onDone: (created) => {
        setOpen(false);
        qc.invalidateQueries({
          queryKey: ["offers", pixelId]
        });
        if (created) setInstructions(created);
      } }) })
    ] }) }),
    /* @__PURE__ */ jsx(Dialog, { open: !!instructions, onOpenChange: (o) => !o && setInstructions(null), children: /* @__PURE__ */ jsx(DialogContent, { className: "max-w-2xl", children: instructions && /* @__PURE__ */ jsx(InstructionsDialog, { offer: instructions.offer, domain: instructions.domain, onClose: () => setInstructions(null) }) }) }),
    offers.isLoading ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Carregando..." }) : offers.data && offers.data.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid gap-3", children: offers.data.map((o) => {
      const exampleUrl = `${baseHost}/api/public/track/g/<click_id>/${o.slug}`;
      return /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "p-4 space-y-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 flex-wrap", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("p", { className: "font-semibold", children: o.name }),
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1 flex-wrap", children: [
              /* @__PURE__ */ jsxs(Badge, { variant: "secondary", children: [
                "/",
                o.slug
              ] }),
              /* @__PURE__ */ jsx(Badge, { variant: "outline", children: o.default_event }),
              /* @__PURE__ */ jsxs(Badge, { variant: "outline", children: [
                "subid: ",
                o.subid_param
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => {
            if (confirm("Remover oferta?")) remove.mutate(o.id);
          }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground break-all", children: [
          "Destino: ",
          o.destination_url
        ] }),
        /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => {
          navigator.clipboard.writeText(exampleUrl);
          toast.success("Copiado");
        }, className: "w-full text-left text-xs font-mono bg-muted/50 hover:bg-muted rounded p-2 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Copy, { className: "size-3 shrink-0" }),
          " ",
          /* @__PURE__ */ jsx("span", { className: "truncate", children: exampleUrl })
        ] })
      ] }) }, o.id);
    }) }) : /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardHeader, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: "Nenhuma oferta ainda" }),
      /* @__PURE__ */ jsx(CardDescription, { children: "Crie a primeira oferta para gerar links de redirect com tracking." })
    ] }) })
  ] });
}
function InstructionsDialog({
  offer,
  domain,
  onClose
}) {
  const scriptTag = `<script src="https://${domain}/${offer.id}.js"><\/script>`;
  const inviteLink = `https://${domain}/t/${offer.id}`;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Instruções de Configuração" }) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-lg border bg-background/40 p-4 space-y-2", children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: "Adicione esse código ao Head do seu site:" }),
        /* @__PURE__ */ jsx(CopyRow, { value: scriptTag, mono: true })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-lg border bg-background/40 p-4 space-y-2", children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: "Utilize esse link para entrada no seu Grupo do Telegram:" }),
        /* @__PURE__ */ jsx(CopyRow, { value: inviteLink })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive", children: [
        /* @__PURE__ */ jsx(AlertTriangle, { className: "size-4 shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsxs("span", { children: [
          "Siga às instruções com atenção. Apenas entradas em páginas com o ",
          /* @__PURE__ */ jsx("strong", { children: "código configurado" }),
          " no head e feitas através do ",
          /* @__PURE__ */ jsx("strong", { children: "link correto" }),
          " serão contabilizadas."
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(DialogFooter, { className: "justify-center sm:justify-center", children: /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: onClose, children: "Fechar" }) })
  ] });
}
function CopyRow({
  value,
  mono
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-stretch gap-2", children: [
    /* @__PURE__ */ jsx("div", { className: `flex-1 min-w-0 rounded-md border bg-muted/40 px-3 py-2 text-xs overflow-x-auto whitespace-nowrap ${mono ? "font-mono" : ""}`, children: value }),
    /* @__PURE__ */ jsxs(Button, { type: "button", onClick: () => {
      navigator.clipboard.writeText(value);
      toast.success("Copiado");
    }, className: "shrink-0", children: [
      /* @__PURE__ */ jsx(Copy, { className: "size-4" }),
      " Copiar"
    ] })
  ] });
}
function NewFunnelDialog({
  pixelId,
  domains,
  onDone
}) {
  const {
    pixels
  } = usePixelFilter();
  const createFn = useServerFn(createOffer);
  const [name, setName] = useState("");
  const [selectedPixel, setSelectedPixel] = useState(pixelId);
  const [domain, setDomain] = useState("");
  const [requireEntry, setRequireEntry] = useState(false);
  const [urls, setUrls] = useState([]);
  const [draftUrl, setDraftUrl] = useState("");
  function slugify(s) {
    return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "funil";
  }
  function addUrl() {
    if (!draftUrl.trim() || urls.length >= 5) return;
    try {
      new URL(draftUrl);
    } catch {
      toast.error("URL inválida");
      return;
    }
    setUrls([...urls, draftUrl.trim()]);
    setDraftUrl("");
  }
  const create = useMutation({
    mutationFn: () => createFn({
      data: {
        pixel_id: selectedPixel,
        slug: slugify(name),
        name,
        destination_url: urls[0],
        subid_param: "sub1",
        default_event: "InitiateCheckout",
        default_currency: "BRL"
      }
    }),
    onSuccess: (offer) => {
      toast.success("Funil criado");
      onDone({
        offer,
        domain
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const canSave = name.trim() && selectedPixel && domain && urls.length > 0;
  return /* @__PURE__ */ jsxs(TooltipProvider, { delayDuration: 150, children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Novo Funil" }) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Nome" }),
          /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), placeholder: "Digite o Nome do Funil" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Pixel" }),
          /* @__PURE__ */ jsxs(Select, { value: selectedPixel, onValueChange: setSelectedPixel, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione um Pixel" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: pixels.map((p) => /* @__PURE__ */ jsx(SelectItem, { value: p.id, children: p.name }, p.id)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4 items-end", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Domínio" }),
          /* @__PURE__ */ jsxs(Select, { value: domain, onValueChange: setDomain, disabled: domains.length === 0, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: domains.length === 0 ? "Nenhum domínio verificado" : "Selecione o Domínio" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: domains.map((d) => /* @__PURE__ */ jsx(SelectItem, { value: d.domain, children: d.domain }, d.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Tooltip, { children: [
          /* @__PURE__ */ jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 h-10", children: [
            /* @__PURE__ */ jsx(Switch, { checked: requireEntry, onCheckedChange: setRequireEntry, disabled: true }),
            /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Ativar Solicitação de Entrada" }),
            /* @__PURE__ */ jsx(HelpCircle, { className: "size-3.5 text-muted-foreground" })
          ] }) }),
          /* @__PURE__ */ jsx(TooltipContent, { className: "max-w-xs", children: "A solicitação de entrada está disponível apenas para canais privados." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Adicionar URLs (máximo 5)" }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx(Input, { value: draftUrl, onChange: (e) => setDraftUrl(e.target.value), onKeyDown: (e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addUrl();
            }
          }, placeholder: domain ? "https://corretora.com/?ref=123" : "Selecione um domínio primeiro", disabled: !domain || urls.length >= 5 }),
          /* @__PURE__ */ jsx(Button, { type: "button", variant: "secondary", onClick: addUrl, disabled: !domain || !draftUrl || urls.length >= 5, children: "Adicionar" })
        ] }),
        urls.length > 0 && /* @__PURE__ */ jsx("ul", { className: "space-y-1.5 pt-1", children: urls.map((u, i) => /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2 rounded-md border bg-muted/30 px-2.5 py-1.5 text-xs", children: [
          /* @__PURE__ */ jsx("span", { className: "flex-1 truncate font-mono", children: u }),
          /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setUrls(urls.filter((_, idx) => idx !== i)), className: "text-muted-foreground hover:text-destructive", children: /* @__PURE__ */ jsx(X, { className: "size-3.5" }) })
        ] }, i)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { className: "gap-2 items-center justify-between sm:justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-2.5 py-1.5 text-xs text-destructive", children: [
        /* @__PURE__ */ jsx(AlertTriangle, { className: "size-3.5" }),
        " Este bloco não poderá ser alterado."
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => onDone(), disabled: create.isPending, children: "Cancelar" }),
        /* @__PURE__ */ jsx(Button, { onClick: () => create.mutate(), disabled: !canSave || create.isPending, children: create.isPending ? "Salvando..." : "Salvar" })
      ] })
    ] })
  ] });
}
export {
  FunisPage as component
};
