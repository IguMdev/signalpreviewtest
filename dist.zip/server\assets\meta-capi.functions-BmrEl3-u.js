import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as sendMetaEvent } from "./meta-capi.server-BrVcTWbs.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "crypto";
import "./client.server-CDheR9QG.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const META_EVENT_OPTIONS = ["off", "Lead", "CompleteRegistration", "Subscribe", "ViewContent", "Contact", "AddToWishlist", "InitiateCheckout", "StartTrial", "Purchase", "AddToCart", "AddPaymentInfo", "Search", "FindLocation", "Schedule", "SubmitApplication", "Donate", "CustomizeProduct", "PageView", "AdImpression", "AdClick", "Rate", "SpentCredits", "AchievementUnlocked", "ActivateApp", "CompleteTutorial", "LevelAchieved", "UnlockAchievement"];
const eventMappingsSchema = z.object({
  join: z.enum(META_EVENT_OPTIONS).default("CompleteRegistration"),
  leave: z.enum(META_EVENT_OPTIONS).default("off"),
  kicked: z.enum(META_EVENT_OPTIONS).default("off")
});
const getMetaIntegration_createServerFn_handler = createServerRpc({
  id: "30ce60d49560fcf320a3a093acb10d55e657cdf4c528a23f700015448776354f",
  name: "getMetaIntegration",
  filename: "src/lib/meta-capi.functions.ts"
}, (opts) => getMetaIntegration.__executeServer(opts));
const getMetaIntegration = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMetaIntegration_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("meta_integrations").select("id, pixel_id, access_token, test_event_code, is_active, event_mappings, updated_at").maybeSingle();
  if (error) throw new Error(error.message);
  return data;
});
const upsertMetaIntegration_createServerFn_handler = createServerRpc({
  id: "9d460463a69d1d09a9ecdf7507943a909f8e8353acc22ca2f63749a4dc1c9511",
  name: "upsertMetaIntegration",
  filename: "src/lib/meta-capi.functions.ts"
}, (opts) => upsertMetaIntegration.__executeServer(opts));
const upsertMetaIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixelId: z.string().min(5).max(64).regex(/^\d+$/, "Pixel ID deve ser numérico"),
  accessToken: z.string().min(20).max(500),
  testEventCode: z.string().max(64).optional().nullable(),
  isActive: z.boolean().default(true),
  eventMappings: eventMappingsSchema
}).parse(d)).handler(upsertMetaIntegration_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    error
  } = await supabase.from("meta_integrations").upsert({
    user_id: userId,
    pixel_id: data.pixelId,
    access_token: data.accessToken,
    test_event_code: data.testEventCode || null,
    is_active: data.isActive,
    event_mappings: data.eventMappings
  }, {
    onConflict: "user_id"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const deleteMetaIntegration_createServerFn_handler = createServerRpc({
  id: "f5b8d4937c62913dcb9bf1b20173daa211b68e17bb379a9742e0090a20b9b26a",
  name: "deleteMetaIntegration",
  filename: "src/lib/meta-capi.functions.ts"
}, (opts) => deleteMetaIntegration.__executeServer(opts));
const deleteMetaIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(deleteMetaIntegration_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    error
  } = await supabase.from("meta_integrations").delete().eq("user_id", userId);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const sendMetaTestEvent_createServerFn_handler = createServerRpc({
  id: "f577b17f42b4ffc5eced72efbef6329ff0c4c1541605a624ec6066a450ae6cfe",
  name: "sendMetaTestEvent",
  filename: "src/lib/meta-capi.functions.ts"
}, (opts) => sendMetaTestEvent.__executeServer(opts));
const sendMetaTestEvent = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(sendMetaTestEvent_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: integ
  } = await supabase.from("meta_integrations").select("event_mappings").eq("user_id", userId).maybeSingle();
  const mappings = integ?.event_mappings ?? {};
  const mapped = mappings.join && mappings.join !== "off" ? mappings.join : "Lead";
  const result = await sendMetaEvent({
    userId,
    eventName: mapped,
    eventId: `test-${Date.now()}`,
    actionSource: "system_generated",
    userData: {
      externalId: userId
    },
    customData: {
      content_name: `Teste de conexão TeleSignal (${mapped})`,
      value: 0,
      currency: "BRL"
    }
  });
  if (!result.ok) throw new Error(result.error || "Falha ao enviar evento");
  return {
    ok: true,
    eventName: mapped
  };
});
const listMetaEventLogs_createServerFn_handler = createServerRpc({
  id: "cdd38ff44aee3057891b299148a5f45f2fbc3bfea5efb820f335a626c82ea503",
  name: "listMetaEventLogs",
  filename: "src/lib/meta-capi.functions.ts"
}, (opts) => listMetaEventLogs.__executeServer(opts));
const listMetaEventLogs = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listMetaEventLogs_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("meta_event_logs").select("id, event_name, event_id, ok, error, created_at").order("created_at", {
    ascending: false
  }).limit(30);
  if (error) throw new Error(error.message);
  return data ?? [];
});
export {
  deleteMetaIntegration_createServerFn_handler,
  getMetaIntegration_createServerFn_handler,
  listMetaEventLogs_createServerFn_handler,
  sendMetaTestEvent_createServerFn_handler,
  upsertMetaIntegration_createServerFn_handler
};
