import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const N1PANEL_URL = "https://n1panel.com/api/v2";
const DEFAULT_N1_REACTIONS_SERVICE_ID = 3205;
const DEFAULT_N1_MEMBERS_SERVICE_ID = 3310;
function normalizeTelegramLink(input) {
  if (!input) return null;
  let raw = input.trim();
  if (!raw) return null;
  raw = raw.replace(/[\u200B-\u200D\uFEFF]/g, "");
  if (raw.startsWith("@")) raw = raw.slice(1);
  if (/^(t\.me|telegram\.me)\//i.test(raw)) raw = `https://${raw}`;
  if (!/^https?:\/\//i.test(raw) && !raw.includes("/")) {
    if (!/^[a-zA-Z0-9_]{4,64}$/.test(raw)) return null;
    return `https://t.me/${raw}`;
  }
  let url;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  const host = url.hostname.toLowerCase();
  if (host !== "t.me" && host !== "telegram.me") return null;
  const segs = url.pathname.split("/").filter(Boolean);
  if (segs.length === 0) return null;
  const first = segs[0];
  if (first.toLowerCase() === "joinchat" || first.startsWith("+")) return null;
  if (!/^[a-zA-Z0-9_]{4,64}$/.test(first)) return null;
  if (segs.length >= 2 && !/^\d+$/.test(segs[1])) return null;
  const path = segs.slice(0, 2).join("/");
  return `https://t.me/${path}`;
}
const listEngagementPlans_createServerFn_handler = createServerRpc({
  id: "1bd6e0100cdd735b7b3aee9616caffc00f4cf2497c9b6ebcd94c7a0c4b68b37d",
  name: "listEngagementPlans",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listEngagementPlans.__executeServer(opts));
const listEngagementPlans = createServerFn({
  method: "GET"
}).handler(listEngagementPlans_createServerFn_handler, async () => {
  const {
    data,
    error
  } = await supabaseAdmin.from("engagement_plans").select("*").eq("is_active", true).order("sort_order", {
    ascending: true
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const getMySubscription_createServerFn_handler = createServerRpc({
  id: "aa876c540e70dc067f56f08c5b988573ee749cc119a305bcc78462388746fb86",
  name: "getMySubscription",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => getMySubscription.__executeServer(opts));
const getMySubscription = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMySubscription_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").in("status", ["pending", "active"]).order("created_at", {
    ascending: false
  }).limit(1).maybeSingle();
  if (error) throw new Error(error.message);
  return data;
});
const getMySubscriptions_createServerFn_handler = createServerRpc({
  id: "da16a63bdab39f1e819d98d4d8e867c0a3c96df6ad7153176087ee19ffb3e0ee",
  name: "getMySubscriptions",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => getMySubscriptions.__executeServer(opts));
const getMySubscriptions = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(getMySubscriptions_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").in("status", ["pending", "active"]).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const getRoomEngagementSettings_createServerFn_handler = createServerRpc({
  id: "3d27619f2fab50c5cbed08145758bef45ecd8e80b09b7263a336756fb59102eb",
  name: "getRoomEngagementSettings",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => getRoomEngagementSettings.__executeServer(opts));
const getRoomEngagementSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(getRoomEngagementSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: row,
    error
  } = await supabase.from("room_engagement_settings").select("*").eq("room_id", data.roomId).maybeSingle();
  if (error) throw new Error(error.message);
  return row;
});
const upsertRoomEngagementSettings_createServerFn_handler = createServerRpc({
  id: "fd647e1258179beb6ef150bfd1ab4dae7b6a931b738812cda56c36a089b86185",
  name: "upsertRoomEngagementSettings",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => upsertRoomEngagementSettings.__executeServer(opts));
const upsertRoomEngagementSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  autoReactEnabled: z.boolean(),
  reactionsPerSignal: z.number().int().min(1).max(1e4),
  reactEmojis: z.array(z.string().min(1).max(8)).min(1).max(20),
  delaySecondsMin: z.number().int().min(0).max(3600),
  delaySecondsMax: z.number().int().min(0).max(3600),
  autoMembersEnabled: z.boolean(),
  membersPerDay: z.number().int().min(1).max(5e4),
  welcomeBotEnabled: z.boolean().optional(),
  welcomeMessage: z.string().max(2e3).optional(),
  forwarderEnabled: z.boolean().optional(),
  forwarderSourceChatId: z.number().int().nullable().optional(),
  forwarderTargetChatIds: z.array(z.number().int()).max(50).optional()
}).parse(d)).handler(upsertRoomEngagementSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  if (data.welcomeBotEnabled) {
    await assertActiveBotSub(userId, "boasvindas");
  }
  if (data.forwarderEnabled) {
    await assertActiveBotSub(userId, "encaminhador");
  }
  const {
    error
  } = await supabase.from("room_engagement_settings").upsert({
    room_id: data.roomId,
    user_id: userId,
    auto_react_enabled: data.autoReactEnabled,
    reactions_per_signal: data.reactionsPerSignal,
    react_emojis: data.reactEmojis,
    delay_seconds_min: data.delaySecondsMin,
    delay_seconds_max: data.delaySecondsMax,
    auto_members_enabled: data.autoMembersEnabled,
    members_per_day: data.membersPerDay,
    welcome_bot_enabled: data.welcomeBotEnabled ?? false,
    welcome_message: data.welcomeMessage ?? null,
    forwarder_enabled: data.forwarderEnabled ?? false,
    forwarder_source_chat_id: data.forwarderSourceChatId ?? null,
    forwarder_target_chat_ids: data.forwarderTargetChatIds ?? []
  }, {
    onConflict: "room_id"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
async function assertActiveBotSub(userId, botType) {
  const {
    data: unlimitedData
  } = await supabaseAdmin.from("user_engagement_subscriptions").select("id, plan:engagement_plans!inner(slug)").eq("user_id", userId).eq("status", "active").eq("engagement_plans.slug", "salas-unlimited").limit(1).maybeSingle();
  if (unlimitedData) return;
  const {
    data
  } = await supabaseAdmin.from("user_engagement_subscriptions").select("id").eq("user_id", userId).eq("bot_type", botType).eq("status", "active").limit(1).maybeSingle();
  if (!data) {
    const label = botType === "boasvindas" ? "BotBoasVindas" : "BotEncaminhador";
    throw new Error(`Você não tem assinatura ativa de ${label}. Adquira na aba Recarga.`);
  }
}
const getWelcomeBotConfig_createServerFn_handler = createServerRpc({
  id: "9141a8c4a5d2cac0a43cd7b56801b5a30b380dd6728e462dfe5dee62bf1032e7",
  name: "getWelcomeBotConfig",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => getWelcomeBotConfig.__executeServer(opts));
const getWelcomeBotConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(getWelcomeBotConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: row
  } = await supabase.from("room_engagement_settings").select("welcome_bot_enabled, welcome_message, welcome_image_path, welcome_image_mime, welcome_video_id, welcome_parse_mode, welcome_premium_enabled, welcome_premium_account_id").eq("room_id", data.roomId).maybeSingle();
  return row;
});
const upsertWelcomeBotConfig_createServerFn_handler = createServerRpc({
  id: "eeef8403ac4754c69ca7fc9e1ae201751be1ea260d8f3df11123836fe0acecc9",
  name: "upsertWelcomeBotConfig",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => upsertWelcomeBotConfig.__executeServer(opts));
const upsertWelcomeBotConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  enabled: z.boolean(),
  message: z.string().max(4e3).nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  parseMode: z.enum(["HTML", "MarkdownV2", "Markdown"]).optional(),
  premiumEnabled: z.boolean().optional(),
  premiumAccountId: z.string().uuid().nullable().optional()
}).parse(d)).handler(upsertWelcomeBotConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  if (data.enabled) await assertActiveBotSub(userId, "boasvindas");
  const {
    data: existing
  } = await supabaseAdmin.from("room_engagement_settings").select("room_id").eq("room_id", data.roomId).eq("user_id", userId).maybeSingle();
  let error;
  if (existing) {
    ({
      error
    } = await supabaseAdmin.from("room_engagement_settings").update({
      welcome_bot_enabled: data.enabled,
      welcome_message: data.message ?? null,
      welcome_image_path: data.imagePath ?? null,
      welcome_image_mime: data.imageMime ?? null,
      welcome_video_id: data.videoId ?? null,
      welcome_parse_mode: data.parseMode ?? "HTML",
      welcome_premium_enabled: data.premiumEnabled ?? false,
      welcome_premium_account_id: data.premiumAccountId ?? null
    }).eq("room_id", data.roomId).eq("user_id", userId));
  } else {
    ({
      error
    } = await supabaseAdmin.from("room_engagement_settings").insert({
      room_id: data.roomId,
      user_id: userId,
      welcome_bot_enabled: data.enabled,
      welcome_message: data.message ?? null,
      welcome_image_path: data.imagePath ?? null,
      welcome_image_mime: data.imageMime ?? null,
      welcome_video_id: data.videoId ?? null,
      welcome_parse_mode: data.parseMode ?? "HTML",
      welcome_premium_enabled: data.premiumEnabled ?? false,
      welcome_premium_account_id: data.premiumAccountId ?? null
    }));
  }
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const getForwarderConfig_createServerFn_handler = createServerRpc({
  id: "520161aadea83353aab9313ee81b67c26d693d76f5fb557fe23959921b3d49ce",
  name: "getForwarderConfig",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => getForwarderConfig.__executeServer(opts));
const getForwarderConfig = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(getForwarderConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: row
  } = await supabase.from("room_engagement_settings").select("forwarder_enabled, forwarder_source_chat_id, forwarder_target_chat_ids, forwarder_allowed_types, forwarder_marked_recurring, forwarder_marked_scheduled, forwarder_marked_templates, forwarder_premium_enabled, forwarder_premium_account_id").eq("room_id", data.roomId).maybeSingle();
  return row;
});
const upsertForwarderConfig_createServerFn_handler = createServerRpc({
  id: "c34908e8207ac3e6b51381875e4ad4d47cbf48ba13ce18a00b61a6c3b4b5cae7",
  name: "upsertForwarderConfig",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => upsertForwarderConfig.__executeServer(opts));
const upsertForwarderConfig = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  enabled: z.boolean(),
  sourceChatId: z.number().int().nullable().optional(),
  targetChatIds: z.array(z.number().int()).max(50).optional(),
  allowedTypes: z.array(z.string().min(1).max(32)).max(20).optional(),
  markedRecurring: z.array(z.string().uuid()).max(200).optional(),
  markedScheduled: z.array(z.string().uuid()).max(200).optional(),
  markedTemplates: z.array(z.string().min(1).max(64)).max(50).optional(),
  premiumEnabled: z.boolean().optional(),
  premiumAccountId: z.string().uuid().nullable().optional()
}).parse(d)).handler(upsertForwarderConfig_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  if (data.enabled) await assertActiveBotSub(userId, "encaminhador");
  const {
    error
  } = await supabase.from("room_engagement_settings").upsert({
    room_id: data.roomId,
    user_id: userId,
    forwarder_enabled: data.enabled,
    forwarder_source_chat_id: data.sourceChatId ?? null,
    forwarder_target_chat_ids: data.targetChatIds ?? [],
    forwarder_allowed_types: data.allowedTypes ?? [],
    forwarder_marked_recurring: data.markedRecurring ?? [],
    forwarder_marked_scheduled: data.markedScheduled ?? [],
    forwarder_marked_templates: data.markedTemplates ?? [],
    forwarder_premium_enabled: data.premiumEnabled ?? false,
    forwarder_premium_account_id: data.premiumAccountId ?? null
  }, {
    onConflict: "room_id"
  });
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listAccountChats_createServerFn_handler = createServerRpc({
  id: "8222aea8cddd21daa30a34176c278c2ff1b0c8ffc97ccabe96fee4264ff3023d",
  name: "listAccountChats",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listAccountChats.__executeServer(opts));
const listAccountChats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listAccountChats_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("telegram_chats").select("account_id, chat_id, title, username, type").order("title", {
    ascending: true
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const listForwarderSourceItems_createServerFn_handler = createServerRpc({
  id: "e49642dc954ff7560817b9728dedb29fe050efa27e1ffd298454cb47b797ecc1",
  name: "listForwarderSourceItems",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listForwarderSourceItems.__executeServer(opts));
const listForwarderSourceItems = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(listForwarderSourceItems_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const [tpls, scheds, recs] = await Promise.all([supabase.from("quick_send_templates").select("id, name, sort_order").eq("default_room_id", data.roomId).order("sort_order", {
    ascending: true
  }), supabase.from("scheduled_messages").select("id, content, scheduled_at, status").eq("room_id", data.roomId).in("status", ["pending", "sent"]).order("scheduled_at", {
    ascending: true
  }).limit(100), supabase.from("recurring_schedules").select("id, title, is_active").eq("room_id", data.roomId).order("title", {
    ascending: true
  })]);
  return {
    templates: tpls.data ?? [],
    scheduled: scheds.data ?? [],
    recurring: recs.data ?? []
  };
});
async function callSmmPanel(params) {
  const key = process.env.N1PANEL_API_KEY || process.env.SMM_PANEL_API_KEY;
  if (!key) throw new Error("Nenhuma chave de painel SMM configurada (N1PANEL_API_KEY).");
  const body = new URLSearchParams({
    key,
    ...Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)]))
  });
  const res = await fetch(N1PANEL_URL, {
    method: "POST",
    body
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`SMM panel ${res.status}: ${JSON.stringify(json)}`);
  return json;
}
const SUBSCRIPTION_REACTION_SERVICE_IDS = /* @__PURE__ */ new Set([2637, 3205, 3206, 3233, 3513, 3514, 2635, 2636, 2638]);
const MEMBERS_SERVICE_IDS = /* @__PURE__ */ new Set([3310, 3440, 7102]);
const SERVICE_MIN_QUANTITY = {
  2637: 10,
  // AUTO reactions (subscription)
  3205: 700,
  // AUTO reactions premium (subscription) — min alto
  3206: 700,
  3310: 10,
  // Members
  3440: 100,
  // Members (legado)
  3494: 100,
  // Reactions per-post
  7102: 100,
  // JAP members (legado)
  8485: 10
  // JAP reactions (legado)
};
function extractTelegramUsername(link) {
  const m = link.match(/t\.me\/([^/?#]+)/i);
  if (!m) return null;
  const u = m[1];
  if (u.startsWith("+") || u === "joinchat") return null;
  return u;
}
function buildAddOrderParams(args) {
  const min = SERVICE_MIN_QUANTITY[args.serviceId];
  if (min != null && args.quantity < min) {
    throw new Error(`Quantidade ${args.quantity} é menor que o mínimo do serviço ${args.serviceId} (mín. ${min}). Selecione um plano com quota >= ${min} ou troque o serviço SMM do plano para um que aceite ${args.quantity}.`);
  }
  if (SUBSCRIPTION_REACTION_SERVICE_IDS.has(args.serviceId)) {
    const username = extractTelegramUsername(args.link);
    if (!username) {
      throw new Error(`Link inválido para serviço de assinatura ${args.serviceId}: ${args.link}`);
    }
    return {
      action: "add",
      service: args.serviceId,
      username,
      min: args.quantity,
      max: args.quantity,
      posts: 1
    };
  }
  let link = args.link;
  if (MEMBERS_SERVICE_IDS.has(args.serviceId)) {
    const username = extractTelegramUsername(link);
    if (!username) {
      throw new Error(`Link inválido para serviço de membros ${args.serviceId}: ${args.link}`);
    }
    link = `https://t.me/${username}`;
  }
  return {
    action: "add",
    service: args.serviceId,
    link,
    quantity: args.quantity
  };
}
function mapSmmStatus(status, remains) {
  const normalized = String(status ?? "").trim().toLowerCase();
  const remaining = Number(remains ?? Number.NaN);
  if (normalized === "completed" && remaining === 0) return "completed";
  if (normalized === "completed") return "in_progress";
  if (normalized === "partial") return "partial";
  if (normalized === "canceled" || normalized === "cancelled") return "canceled";
  if (normalized === "processing" || normalized === "in progress" || normalized === "pending") return "in_progress";
  return null;
}
async function getTelegramMemberCountForOrder(order) {
  const username = normalizeTelegramLink(order.target)?.split("/").filter(Boolean).at(-1);
  if (!username || /^\d+$/.test(username)) return null;
  let accountId = null;
  if (order.room_id) {
    const {
      data: room
    } = await supabaseAdmin.from("rooms").select("default_account_id").eq("id", order.room_id).eq("user_id", order.user_id).maybeSingle();
    accountId = room?.default_account_id ?? null;
  }
  const query = supabaseAdmin.from("telegram_accounts").select("bot_token").eq("user_id", order.user_id).eq("is_active", true).not("bot_token", "is", null).limit(1);
  const {
    data: account
  } = accountId ? await query.eq("id", accountId).maybeSingle() : await query.maybeSingle();
  if (!account?.bot_token) return null;
  const resp = await callTelegram(account.bot_token, "getChatMemberCount", {
    chat_id: `@${username}`
  });
  return resp.ok && typeof resp.result === "number" ? resp.result : null;
}
const dispatchEngagementBoost_createServerFn_handler = createServerRpc({
  id: "17eae8fd17f1c83ba64e6ae635fe6345b974fae93d39fd4813fbdff10993a575",
  name: "dispatchEngagementBoost",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => dispatchEngagementBoost.__executeServer(opts));
const dispatchEngagementBoost = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  type: z.enum(["reaction", "members"]),
  postId: z.number().int().positive().optional(),
  quantity: z.number().int().min(10).max(5e4)
}).parse(d)).handler(dispatchEngagementBoost_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: room
  } = await supabase.from("rooms").select("id, name, default_account_id").eq("id", data.roomId).maybeSingle();
  if (!room) throw new Error("Sala não encontrada (ou sem permissão).");
  const {
    data: roomChat
  } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", data.roomId).maybeSingle();
  if (!roomChat?.chat_id) {
    throw new Error("Esta sala não tem um canal Telegram vinculado. Vincule um chat primeiro.");
  }
  const {
    data: chat
  } = await supabaseAdmin.from("telegram_chats").select("username, type, title").eq("chat_id", roomChat.chat_id).eq("user_id", userId).maybeSingle();
  if (!chat?.username) {
    throw new Error("O canal desta sala não é público (não tem @username). O painel SMM precisa de canal público para entregar.");
  }
  const target = data.type === "reaction" && data.postId != null ? `https://t.me/${chat.username}/${data.postId}` : `https://t.me/${chat.username}`;
  if (data.type === "reaction" && data.postId == null) {
    throw new Error("Para reações é necessário informar o número do post (postId).");
  }
  const botType = data.type === "reaction" ? "interacoes" : "inscritos";
  const {
    data: sub
  } = await supabase.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").eq("status", "active").eq("bot_type", botType).order("created_at", {
    ascending: false
  }).limit(1).maybeSingle();
  if (!sub) throw new Error(`Você não tem uma assinatura ativa de Bot${botType === "interacoes" ? "Interações" : "Inscritos"}.`);
  const plan = sub.plan;
  const remaining = (plan?.monthly_quota ?? 0) - (sub.units_used ?? 0);
  if (remaining < data.quantity) {
    throw new Error(`Cota insuficiente. Restam ${remaining}.`);
  }
  const serviceId = data.type === "reaction" ? plan?.smm_service_id ?? DEFAULT_N1_REACTIONS_SERVICE_ID : plan?.smm_service_id ?? DEFAULT_N1_MEMBERS_SERVICE_ID;
  const {
    data: order,
    error: orderErr
  } = await supabaseAdmin.from("engagement_orders").insert({
    user_id: userId,
    room_id: data.roomId,
    subscription_id: sub.id,
    type: data.type,
    target,
    quantity: data.quantity,
    smm_service_id: serviceId
  }).select("*").single();
  if (orderErr) throw new Error(orderErr.message);
  try {
    const resp = await callSmmPanel(buildAddOrderParams({
      serviceId,
      link: target,
      quantity: data.quantity
    }));
    if (resp.error || !resp.order) {
      await supabaseAdmin.from("engagement_orders").update({
        status: "failed",
        error: resp.error ?? "no order id",
        raw_response: resp
      }).eq("id", order.id);
      throw new Error(resp.error ?? "Falha ao despachar pedido");
    }
    await supabaseAdmin.from("engagement_orders").update({
      status: "in_progress",
      smm_order_id: String(resp.order),
      cost_usd: resp.charge ? Number(resp.charge) : null,
      raw_response: resp
    }).eq("id", order.id);
    const newUsed = (sub.units_used ?? 0) + data.quantity;
    await supabaseAdmin.from("user_engagement_subscriptions").update({
      units_used: newUsed
    }).eq("id", sub.id);
    return {
      ok: true,
      orderId: order.id,
      smmOrderId: resp.order
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await supabaseAdmin.from("engagement_orders").update({
      status: "failed",
      error: msg
    }).eq("id", order.id);
    throw err;
  }
});
const listMyEngagementOrders_createServerFn_handler = createServerRpc({
  id: "be61ba610464f2a6ce575de6faab72ec24f462f385ee814c9812cbe96e83c542",
  name: "listMyEngagementOrders",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listMyEngagementOrders.__executeServer(opts));
const listMyEngagementOrders = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listMyEngagementOrders_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data,
    error
  } = await supabase.from("engagement_orders").select("*").order("created_at", {
    ascending: false
  }).limit(50);
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  const syncable = rows.filter((r) => r.smm_order_id && ["pending", "in_progress"].includes(r.status));
  if (syncable.length > 0) {
    await Promise.all(syncable.slice(0, 10).map(async (order) => {
      const updated = await syncOneEngagementOrder(order);
      if (updated) {
        order.status = updated.status;
        order.raw_response = updated.raw_response;
      }
    }));
  }
  return rows;
});
async function syncOneEngagementOrder(order) {
  if (!order.smm_order_id) return null;
  try {
    const panel = await callSmmPanel({
      action: "status",
      order: order.smm_order_id
    });
    let nextStatus = mapSmmStatus(panel.status, panel.remains);
    if (!nextStatus) return null;
    const nextRaw = {
      ...order.raw_response ?? {},
      status_check: panel
    };
    if (order.type === "members") {
      const actualCount = await getTelegramMemberCountForOrder(order);
      if (actualCount != null) {
        const startCount = Number(panel.start_count ?? Number.NaN);
        const expectedCount = Number.isFinite(startCount) ? startCount + Number(order.quantity ?? 0) : null;
        nextRaw.telegram_count = {
          current: actualCount,
          expected: expectedCount,
          checked_at: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (nextStatus === "completed" && expectedCount != null && actualCount < expectedCount) {
          nextStatus = "in_progress";
        }
      }
    }
    await supabaseAdmin.from("engagement_orders").update({
      status: nextStatus,
      raw_response: nextRaw
    }).eq("id", order.id).eq("user_id", order.user_id);
    return {
      status: nextStatus,
      raw_response: nextRaw
    };
  } catch (e) {
    console.error("[syncOneEngagementOrder] failed for", order.id, e);
    return null;
  }
}
const listEngagementAudit_createServerFn_handler = createServerRpc({
  id: "70ebf1cace5a6167ae9f5feba347cc6da057d22e2aa044d7f10ee81280a6b6e8",
  name: "listEngagementAudit",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listEngagementAudit.__executeServer(opts));
const listEngagementAudit = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listEngagementAudit_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data,
    error
  } = await supabase.from("engagement_orders").select("*").eq("type", "members").in("status", ["completed", "partial", "in_progress"]).order("created_at", {
    ascending: false
  }).limit(30);
  if (error) throw new Error(error.message);
  const rows = data ?? [];
  const enriched = await Promise.all(rows.map(async (r) => {
    const rawStatus = r.raw_response?.status_check ?? {};
    const startCount = Number(rawStatus.start_count ?? Number.NaN);
    const expected = Number.isFinite(startCount) ? startCount + Number(r.quantity ?? 0) : null;
    const liveCount = await getTelegramMemberCountForOrder({
      ...r,
      user_id: userId
    }).catch(() => null);
    const stored = r.raw_response?.telegram_count?.current ?? null;
    const current = liveCount ?? stored ?? null;
    const divergent = expected != null && current != null && current < expected;
    return {
      id: r.id,
      target: r.target,
      quantity: r.quantity,
      status: r.status,
      smm_order_id: r.smm_order_id,
      created_at: r.created_at,
      start_count: Number.isFinite(startCount) ? startCount : null,
      expected_count: expected,
      current_count: current,
      missing: divergent && expected != null && current != null ? expected - current : 0,
      divergent,
      panel_status: rawStatus.status ?? null
    };
  }));
  return enriched.filter((e) => e.divergent);
});
const listMyPaymentHistory_createServerFn_handler = createServerRpc({
  id: "1dd1a0f1764fb9a74e32a0e6d3508bb3857bdc4b644c9440962468839e7957df",
  name: "listMyPaymentHistory",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listMyPaymentHistory.__executeServer(opts));
const listMyPaymentHistory = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listMyPaymentHistory_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("user_engagement_subscriptions").select("*, plan:engagement_plans(name, price_brl, bot_type)").order("created_at", {
    ascending: false
  }).limit(50);
  if (error) throw new Error(error.message);
  return data ?? [];
});
const listPendingBoostAllocations_createServerFn_handler = createServerRpc({
  id: "55d5439e5566db59dd84035a91b041ab955fc04c0f4932a0c6cec3199f1712aa",
  name: "listPendingBoostAllocations",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listPendingBoostAllocations.__executeServer(opts));
const listPendingBoostAllocations = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listPendingBoostAllocations_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data,
    error
  } = await supabase.from("user_engagement_subscriptions").select("id, bot_type, current_period_end, plan:engagement_plans(name, monthly_quota, smm_service_id, smm_default_quantity, bot_type)").eq("status", "active").in("bot_type", ["inscritos", "interacoes"]).is("target_room_id", null).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  return data ?? [];
});
const listEligibleBoostRooms_createServerFn_handler = createServerRpc({
  id: "f46508554c2f0f4b657b3bc94b8f0db79f9dd6c228d9258459e231eb123d566a",
  name: "listEligibleBoostRooms",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => listEligibleBoostRooms.__executeServer(opts));
const listEligibleBoostRooms = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(listEligibleBoostRooms_createServerFn_handler, async ({
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: rooms,
    error
  } = await supabase.from("rooms").select("id, name, photo_url").eq("is_active", true).order("created_at", {
    ascending: false
  });
  if (error) throw new Error(error.message);
  if (!rooms?.length) return [];
  const ids = rooms.map((r) => r.id);
  const {
    data: chats
  } = await supabaseAdmin.from("room_chats").select("room_id, chat_id").in("room_id", ids);
  const chatIds = (chats ?? []).map((c) => c.chat_id);
  const {
    data: tchats
  } = await supabaseAdmin.from("telegram_chats").select("chat_id, username, title, type").in("chat_id", chatIds.length ? chatIds : [0]).eq("user_id", userId);
  const byChat = new Map((tchats ?? []).map((t) => [String(t.chat_id), t]));
  const byRoom = new Map((chats ?? []).map((c) => [c.room_id, byChat.get(String(c.chat_id))]));
  return rooms.map((r) => {
    const tc = byRoom.get(r.id);
    return {
      id: r.id,
      name: r.name,
      photoUrl: r.photo_url,
      username: tc?.username ?? null,
      channelTitle: tc?.title ?? null,
      hasPublicChannel: !!tc?.username
    };
  }).filter((r) => r.hasPublicChannel);
});
const allocateSubscriptionToRoom_createServerFn_handler = createServerRpc({
  id: "2ed761f88ef8c0e1f8ccc61181823b9d92fec2f852ec4f567df50d01e191a5fd",
  name: "allocateSubscriptionToRoom",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => allocateSubscriptionToRoom.__executeServer(opts));
const allocateSubscriptionToRoom = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  subscriptionId: z.string().uuid(),
  roomId: z.string().uuid()
}).parse(d)).handler(allocateSubscriptionToRoom_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  return await allocateAndAutoDispatch({
    userId,
    subscriptionId: data.subscriptionId,
    roomId: data.roomId
  });
});
async function allocateAndAutoDispatch(opts) {
  const {
    data: sub,
    error: subErr
  } = await supabaseAdmin.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").eq("id", opts.subscriptionId).eq("user_id", opts.userId).maybeSingle();
  if (subErr) throw new Error(subErr.message);
  if (!sub) throw new Error("Assinatura não encontrada.");
  if (sub.target_room_id) {
    throw new Error("Esta assinatura já está alocada a uma sala.");
  }
  const plan = sub.plan;
  if (!plan) throw new Error("Plano não encontrado.");
  const botType = plan.bot_type;
  if (botType !== "inscritos" && botType !== "interacoes") {
    throw new Error("Apenas Inscritos/Interações precisam de canal.");
  }
  const {
    data: room
  } = await supabaseAdmin.from("rooms").select("id, user_id").eq("id", opts.roomId).eq("user_id", opts.userId).maybeSingle();
  if (!room) throw new Error("Sala inválida.");
  const {
    data: rc
  } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", opts.roomId).maybeSingle();
  if (!rc?.chat_id) throw new Error("A sala não tem canal vinculado.");
  const {
    data: chat
  } = await supabaseAdmin.from("telegram_chats").select("username").eq("chat_id", rc.chat_id).eq("user_id", opts.userId).maybeSingle();
  if (!chat?.username) {
    throw new Error("O canal da sala não é público (sem @username).");
  }
  const link = `https://t.me/${chat.username}`;
  await supabaseAdmin.from("user_engagement_subscriptions").update({
    target_room_id: opts.roomId,
    target_link: link
  }).eq("id", opts.subscriptionId);
  if (botType === "interacoes") {
    return {
      ok: true,
      mode: "saved",
      link
    };
  }
  const serviceId = plan.smm_service_id ?? DEFAULT_N1_MEMBERS_SERVICE_ID;
  const quantity = plan.smm_default_quantity ?? plan.monthly_quota ?? 0;
  if (!serviceId || !quantity) {
    throw new Error("Plano sem configuração SMM (service_id/quantity).");
  }
  const result = await placeSmmOrder({
    userId: opts.userId,
    subscriptionId: opts.subscriptionId,
    serviceId,
    link,
    quantity,
    type: "members",
    roomId: opts.roomId
  });
  if (!result.ok) {
    throw new Error(`Falha ao despachar inscritos: ${result.error}`);
  }
  await supabaseAdmin.from("user_engagement_subscriptions").update({
    units_used: quantity,
    auto_dispatched_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", opts.subscriptionId);
  return {
    ok: true,
    mode: "dispatched",
    smmOrderId: result.smmOrderId,
    quantity,
    link
  };
}
async function placeSmmOrder(opts) {
  const existing = await findReusableSmmOrder(opts);
  if (existing) {
    return {
      ok: true,
      smmOrderId: Number(existing.smm_order_id),
      orderId: existing.id
    };
  }
  const {
    data: order,
    error: orderErr
  } = await supabaseAdmin.from("engagement_orders").insert({
    user_id: opts.userId,
    room_id: opts.roomId ?? null,
    subscription_id: opts.subscriptionId,
    type: opts.type,
    target: opts.link,
    quantity: opts.quantity,
    smm_service_id: opts.serviceId
  }).select("*").single();
  if (orderErr) throw new Error(orderErr.message);
  try {
    const resp = await callSmmPanel(buildAddOrderParams({
      serviceId: opts.serviceId,
      link: opts.link,
      quantity: opts.quantity
    }));
    if (resp.error || !resp.order) {
      await supabaseAdmin.from("engagement_orders").update({
        status: "failed",
        error: resp.error ?? "no order id",
        raw_response: resp
      }).eq("id", order.id);
      return {
        ok: false,
        error: resp.error ?? "no order id"
      };
    }
    await supabaseAdmin.from("engagement_orders").update({
      status: "in_progress",
      smm_order_id: String(resp.order),
      cost_usd: resp.charge ? Number(resp.charge) : null,
      raw_response: resp
    }).eq("id", order.id);
    return {
      ok: true,
      smmOrderId: resp.order,
      orderId: order.id
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await supabaseAdmin.from("engagement_orders").update({
      status: "failed",
      error: msg
    }).eq("id", order.id);
    return {
      ok: false,
      error: msg
    };
  }
}
async function findReusableSmmOrder(opts) {
  const {
    data
  } = await supabaseAdmin.from("engagement_orders").select("id, smm_order_id, status").eq("user_id", opts.userId).eq("subscription_id", opts.subscriptionId).eq("type", opts.type).eq("target", opts.link).eq("quantity", opts.quantity).eq("smm_service_id", opts.serviceId).in("status", ["pending", "in_progress", "completed", "partial"]).not("smm_order_id", "is", null).order("created_at", {
    ascending: false
  }).limit(1).maybeSingle();
  return data;
}
const setSubscriptionTarget_createServerFn_handler = createServerRpc({
  id: "c83a0df8caf1e6a68c81136d80c86b3e2ed1ac14a5104b3fcc1210dc358776b2",
  name: "setSubscriptionTarget",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => setSubscriptionTarget.__executeServer(opts));
const setSubscriptionTarget = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  subscriptionId: z.string().uuid(),
  targetLink: z.string().min(1).max(500)
}).parse(d)).handler(setSubscriptionTarget_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  const normalized = normalizeTelegramLink(data.targetLink);
  if (!normalized) {
    throw new Error("Link inválido. Use um canal/grupo público do Telegram (ex: https://t.me/seucanal). Convites privados (joinchat/+hash) não são aceitos.");
  }
  const {
    data: sub,
    error: subErr
  } = await supabaseAdmin.from("user_engagement_subscriptions").select("*, plan:engagement_plans(*)").eq("id", data.subscriptionId).eq("user_id", userId).maybeSingle();
  if (subErr) throw new Error(subErr.message);
  if (!sub) throw new Error("Assinatura não encontrada.");
  if (sub.target_link) throw new Error("Esta assinatura já tem um canal definido.");
  const plan = sub.plan;
  if (!plan || plan.bot_type !== "inscritos") {
    throw new Error("Apenas assinaturas de inscritos precisam de canal.");
  }
  const serviceId = plan.smm_service_id ?? DEFAULT_N1_MEMBERS_SERVICE_ID;
  const quantity = plan.smm_default_quantity ?? plan.monthly_quota ?? 0;
  if (!serviceId || !quantity) throw new Error("Plano sem configuração SMM.");
  await supabaseAdmin.from("user_engagement_subscriptions").update({
    target_link: normalized
  }).eq("id", sub.id);
  const result = await placeSmmOrder({
    userId,
    subscriptionId: sub.id,
    serviceId,
    link: normalized,
    quantity,
    type: "members"
  });
  if (!result.ok) {
    throw new Error(`Falha ao despachar inscritos: ${result.error}`);
  }
  await supabaseAdmin.from("user_engagement_subscriptions").update({
    units_used: quantity
  }).eq("id", sub.id);
  return {
    ok: true,
    smmOrderId: result.smmOrderId
  };
});
const retryEngagementOrder_createServerFn_handler = createServerRpc({
  id: "13d157f4f68be2d92e9ed9665cdaf03785e1a4db0f7546cc5ab12f9a724b0d84",
  name: "retryEngagementOrder",
  filename: "src/lib/engagement.functions.ts"
}, (opts) => retryEngagementOrder.__executeServer(opts));
const retryEngagementOrder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  orderId: z.string().uuid()
}).parse(d)).handler(retryEngagementOrder_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  const {
    data: order,
    error
  } = await supabaseAdmin.from("engagement_orders").select("*").eq("id", data.orderId).eq("user_id", userId).maybeSingle();
  if (error) throw new Error(error.message);
  if (!order) throw new Error("Pedido não encontrado.");
  if (order.status !== "failed") {
    throw new Error("Apenas pedidos com falha podem ser re-tentados.");
  }
  const normalized = normalizeTelegramLink(order.target) ?? order.target;
  const serviceId = order.smm_service_id ?? (order.type === "reaction" ? DEFAULT_N1_REACTIONS_SERVICE_ID : DEFAULT_N1_MEMBERS_SERVICE_ID);
  await supabaseAdmin.from("engagement_orders").update({
    status: "pending",
    error: null,
    raw_response: null
  }).eq("id", order.id);
  try {
    const resp = await callSmmPanel(buildAddOrderParams({
      serviceId,
      link: normalized,
      quantity: order.quantity
    }));
    if (resp.error || !resp.order) {
      await supabaseAdmin.from("engagement_orders").update({
        status: "failed",
        error: resp.error ?? "no order id",
        raw_response: resp
      }).eq("id", order.id);
      throw new Error(resp.error ?? "Falha ao re-despachar pedido");
    }
    await supabaseAdmin.from("engagement_orders").update({
      status: "in_progress",
      smm_order_id: String(resp.order),
      cost_usd: resp.charge ? Number(resp.charge) : null,
      raw_response: resp,
      target: normalized
    }).eq("id", order.id);
    return {
      ok: true,
      smmOrderId: resp.order
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await supabaseAdmin.from("engagement_orders").update({
      status: "failed",
      error: msg
    }).eq("id", order.id);
    throw err;
  }
});
export {
  allocateSubscriptionToRoom_createServerFn_handler,
  dispatchEngagementBoost_createServerFn_handler,
  getForwarderConfig_createServerFn_handler,
  getMySubscription_createServerFn_handler,
  getMySubscriptions_createServerFn_handler,
  getRoomEngagementSettings_createServerFn_handler,
  getWelcomeBotConfig_createServerFn_handler,
  listAccountChats_createServerFn_handler,
  listEligibleBoostRooms_createServerFn_handler,
  listEngagementAudit_createServerFn_handler,
  listEngagementPlans_createServerFn_handler,
  listForwarderSourceItems_createServerFn_handler,
  listMyEngagementOrders_createServerFn_handler,
  listMyPaymentHistory_createServerFn_handler,
  listPendingBoostAllocations_createServerFn_handler,
  retryEngagementOrder_createServerFn_handler,
  setSubscriptionTarget_createServerFn_handler,
  upsertForwarderConfig_createServerFn_handler,
  upsertRoomEngagementSettings_createServerFn_handler,
  upsertWelcomeBotConfig_createServerFn_handler
};
