import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
async function sendVoiceToChat(opts) {
  if (!opts.botToken) {
    return {
      ok: false,
      description: "Conta sem bot_token"
    };
  }
  const form = new FormData();
  form.append("chat_id", String(opts.chatId));
  if (opts.duration) form.append("duration", String(opts.duration));
  if (opts.caption) form.append("caption", opts.caption);
  form.append("voice", new Blob([opts.fileBytes], {
    type: opts.mimeType
  }), opts.filename);
  const res = await fetch(`https://api.telegram.org/bot${opts.botToken}/sendVoice`, {
    method: "POST",
    body: form
  });
  return await res.json();
}
const sendAudioNow_createServerFn_handler = createServerRpc({
  id: "7d6d81fc49c7fc84551bd929bf5a67d4d916f804fdf846fb012c69b9e6ba41a9",
  name: "sendAudioNow",
  filename: "src/lib/audios.functions.ts"
}, (opts) => sendAudioNow.__executeServer(opts));
const sendAudioNow = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((data) => data).handler(sendAudioNow_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const {
      userId
    } = context;
    const {
      data: audio
    } = await supabaseAdmin.from("audios").select("*").eq("id", data.audioId).maybeSingle();
    if (!audio || audio.user_id !== userId) throw new Error("Áudio não encontrado ou sem permissão");
    const {
      data: account
    } = await supabaseAdmin.from("telegram_accounts").select("bot_token, user_id").eq("id", data.accountId).maybeSingle();
    if (!account?.bot_token || account.user_id !== userId) throw new Error("Conta de Telegram inválida ou sem permissão");
    const {
      data: fileData,
      error: fileErr
    } = await supabaseAdmin.storage.from("audio-files").download(audio.storage_path);
    if (fileErr || !fileData) throw new Error("Erro ao baixar arquivo do Storage: " + (fileErr?.message || ""));
    const fileBytes = await fileData.arrayBuffer();
    const results = [];
    for (const chatId of data.chatIds) {
      const result = await sendVoiceToChat({
        botToken: account.bot_token,
        chatId,
        fileBytes,
        filename: audio.storage_path.split("/").pop() || "audio.ogg",
        mimeType: audio.mime_type || "audio/ogg",
        duration: audio.duration_seconds
      });
      results.push({
        chatId,
        ok: result.ok,
        error: result.description
      });
    }
    const allOk = results.every((r) => r.ok);
    if (!allOk) {
      const errors = results.filter((r) => !r.ok).map((r) => `Chat ${r.chatId}: ${r.error}`).join(", ");
      throw new Error(`Alguns envios falharam: ${errors}`);
    }
    return {
      ok: true
    };
  } catch (err) {
    console.error("[sendAudioNow]", err);
    throw new Error(err.message || "Erro desconhecido ao enviar áudio");
  }
});
const deleteAudio_createServerFn_handler = createServerRpc({
  id: "8a7527746586e344d6ed82b12250cdb4270db02a4d02289b4eb367cb65a8215f",
  name: "deleteAudio",
  filename: "src/lib/audios.functions.ts"
}, (opts) => deleteAudio.__executeServer(opts));
const deleteAudio = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((id) => id).handler(deleteAudio_createServerFn_handler, async ({
  data: id,
  context
}) => {
  try {
    const {
      userId
    } = context;
    const {
      data: audio
    } = await supabaseAdmin.from("audios").select("storage_path, user_id").eq("id", id).maybeSingle();
    if (!audio || audio.user_id !== userId) throw new Error("Áudio não encontrado ou sem permissão");
    if (audio?.storage_path) {
      await supabaseAdmin.storage.from("audio-files").remove([audio.storage_path]);
    }
    await supabaseAdmin.from("audios").delete().eq("id", id);
    return {
      ok: true
    };
  } catch (err) {
    throw new Error(err.message);
  }
});
export {
  deleteAudio_createServerFn_handler,
  sendAudioNow_createServerFn_handler
};
