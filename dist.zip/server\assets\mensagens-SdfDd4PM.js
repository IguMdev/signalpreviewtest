import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useEffect, useMemo, useRef } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import { t as thumbnailPathForVideoPath, c as createVideoThumbnailBlob } from "./video-thumbnail-fuRi0AXJ.js";
import { D as Dialog, g as DialogContent, h as DialogHeader, i as DialogTitle, t as DialogDescription, L as Label, I as Input, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, T as Textarea, N as Switch, j as DialogFooter, B as Button, C as Card, H as Badge } from "./router-Cw6OHOsO.js";
import { toast } from "sonner";
import { Bookmark, Video, Pencil, Trash2, Plus, X, Loader2, ImageIcon, Sparkles, Send, Calendar, CheckCircle2, Users, FolderOpen, Folder, FolderPlus, Search, Link2, Clock, Copy } from "lucide-react";
import { P as PremiumEmojiPicker } from "./PremiumEmojiPicker-KRfbHKuL.js";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const TimeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
const FollowUpInput = z.object({
  delayMinutes: z.number().int().min(1).max(1440),
  delaySeconds: z.number().int().min(1).max(86400).nullable().optional(),
  content: z.string().max(4e3).nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  audioId: z.string().uuid().nullable().optional(),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional()
});
const ScheduleInput = z.object({
  id: z.string().uuid().optional(),
  roomId: z.string().uuid(),
  accountId: z.string().uuid().nullable().optional(),
  title: z.string().min(1).max(120),
  content: z.string().max(4e3).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  audioId: z.string().uuid().nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  times: z.array(z.string().regex(TimeRe)).min(1).max(24),
  weekdays: z.array(z.number().int().min(1).max(7)).min(1).max(7),
  weekdayOverrides: z.record(z.string().regex(/^[1-7]$/), z.array(z.string().regex(TimeRe)).max(24)).default({}),
  scheduleType: z.enum(["weekly", "monthly"]).default("weekly"),
  monthDays: z.array(z.number().int().min(1).max(31)).default([]),
  followUps: z.array(FollowUpInput).max(10).default([]),
  isPremium: z.boolean().default(false),
  isActive: z.boolean().default(true),
  timezone: z.string().default("America/Sao_Paulo"),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional(),
  folderId: z.string().uuid().nullable().optional()
});
const upsertSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ScheduleInput.parse(d)).handler(createSsrRpc("557a3bb959592512346d395daec1e205af9872cf293cc245cb8edf0c9dfa42b6"));
const toggleSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  isActive: z.boolean()
}).parse(d)).handler(createSsrRpc("ede179f930977d4129f87a568ea5835e8ed726860a04033e7d1e2c366ef1ada1"));
const deleteSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("f010fecd0eae223fea7e6b9faba5094a2b823de23e6ba7de800826723cc7fd01"));
const testSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("cda58577c6df6b3babc9e9f22ba663807cc2836d974d3f733910922dc91aa8e0"));
const TestMessageInput = z.object({
  roomId: z.string().uuid(),
  accountId: z.string().uuid().nullable().optional(),
  content: z.string().max(4e3).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  audioId: z.string().uuid().nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  isPremium: z.boolean().default(false),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional()
});
const testMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => TestMessageInput.parse(d)).handler(createSsrRpc("e9cfdb4483e73620518a22b85d5af41f696ed908522b5a2b91558a187c530439"));
const FolderInput = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(60),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#6366f1"),
  sortOrder: z.number().int().min(0).max(9999).default(0)
});
const upsertFolder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => FolderInput.parse(d)).handler(createSsrRpc("cf9fb7d494ca0dc248c68827ebce13e7b58a3849c2b47f8d8c7bbae511326c12"));
const deleteFolder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("61862fba5b5b90c901af2a948eb0b0dacbcc29b7531291ee094eb7eb5b12d6cb"));
const moveScheduleToFolder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  folderId: z.string().uuid().nullable()
}).parse(d)).handler(createSsrRpc("7ddac3775442677f15be4eb2baf7b48fb9a762abcb3f88759782abe845d23c8c"));
const BulkReplaceInput = z.object({
  oldLink: z.string().min(1),
  newLink: z.string().min(1)
});
const bulkReplaceLinks = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => BulkReplaceInput.parse(d)).handler(createSsrRpc("b9ff1a6bc1d5c7403ffc0951cb8843216e98d11123f4a3455fb6f287af1a8f87"));
const syncRoomPhoto = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("caab0abaa72a33b59460709845e7aec17500521150d731dc3ac8e2d4a6450b92"));
const UpsertInput = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(80),
  content: z.string().max(4e3).default(""),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  imageExt: z.string().max(20).nullable().optional(),
  defaultRoomId: z.string().uuid().nullable().optional(),
  defaultAccountId: z.string().uuid().nullable().optional(),
  sortOrder: z.number().int().min(0).max(9999).default(0),
  isPremium: z.boolean().default(false),
  isMeetButton: z.boolean().default(false)
});
const upsertQuickTemplate = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => UpsertInput.parse(d)).handler(createSsrRpc("b392229ab5a6014b011ceea3c1c702258afd9b7b2a619034946329703eba5c01"));
const deleteQuickTemplate = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("716d17b8e661d753397d1e51ded83da886a463c2294a1ca686ce8e05f356c907"));
const SendInput = z.object({
  id: z.string().uuid(),
  roomId: z.string().uuid(),
  accountId: z.string().uuid(),
  content: z.string().max(4e3),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  premium: z.boolean().default(false),
  imagePathOverride: z.string().max(500).nullable().optional(),
  removeImage: z.boolean().default(false)
});
const sendQuickTemplate = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => SendInput.parse(d)).handler(createSsrRpc("0116fb79c44cd0c53b7ca426a1052f443a6a8715978f67ad804186a95b4a0855"));
function QuickTemplatesBar({
  rooms,
  accounts
}) {
  const qc = useQueryClient();
  const upsertFn = useServerFn(upsertQuickTemplate);
  const deleteFn = useServerFn(deleteQuickTemplate);
  const sendFn = useServerFn(sendQuickTemplate);
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);
  const [sending, setSending] = useState(null);
  const [meetSending, setMeetSending] = useState(null);
  const list = useQuery({
    queryKey: ["quick-send-templates"],
    queryFn: async () => {
      const { data } = await supabase.from("quick_send_templates").select(
        "id, name, content, parse_mode, image_path, image_mime, default_room_id, default_account_id, sort_order, is_premium, is_meet_button"
      ).order("sort_order", { ascending: true }).order("created_at", { ascending: true });
      return data ?? [];
    }
  });
  const delMut = useMutation({
    mutationFn: async (id) => {
      await deleteFn({ data: { id } });
    },
    onSuccess: () => {
      toast.success("Modelo removido");
      qc.invalidateQueries({ queryKey: ["quick-send-templates"] });
    },
    onError: (e) => toast.error(e.message)
  });
  const items = list.data ?? [];
  return /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs text-muted-foreground", children: [
      /* @__PURE__ */ jsx(Bookmark, { className: "size-3.5" }),
      "Envio rápido (modelos pré-salvos)"
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
      items.map((t) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "group inline-flex items-center rounded-full bg-secondary/60 hover:bg-secondary border border-border/60 pl-3 pr-1 py-1 text-sm gap-1",
          children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                className: "font-medium pr-1 text-foreground/90 hover:text-foreground",
                onClick: () => t.is_meet_button ? setMeetSending(t) : setSending(t),
                title: t.is_meet_button ? "Enviar com link do Meet" : "Abrir modelo para envio rápido",
                children: [
                  t.is_meet_button && /* @__PURE__ */ jsx(Video, { className: "inline size-3.5 mr-1 text-primary" }),
                  t.name
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "size-6 rounded-full grid place-items-center text-muted-foreground hover:text-foreground hover:bg-background/60 opacity-0 group-hover:opacity-100 transition",
                onClick: (e) => {
                  e.stopPropagation();
                  setEditing(t);
                },
                title: "Editar modelo",
                children: /* @__PURE__ */ jsx(Pencil, { className: "size-3.5" })
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "size-6 rounded-full grid place-items-center text-muted-foreground hover:text-destructive hover:bg-background/60 opacity-0 group-hover:opacity-100 transition",
                onClick: (e) => {
                  e.stopPropagation();
                  if (confirm(`Excluir o modelo "${t.name}"?`)) delMut.mutate(t.id);
                },
                title: "Excluir modelo",
                children: /* @__PURE__ */ jsx(Trash2, { className: "size-3.5" })
              }
            )
          ]
        },
        t.id
      )),
      /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => setCreating(true),
          className: "inline-flex items-center gap-1 rounded-full border border-dashed border-border/70 px-3 py-1 text-sm text-muted-foreground hover:text-foreground hover:border-foreground/40",
          children: [
            /* @__PURE__ */ jsx(Plus, { className: "size-3.5" }),
            "Novo modelo"
          ]
        }
      )
    ] }),
    (creating || editing) && /* @__PURE__ */ jsx(
      QuickTemplateDialog,
      {
        rooms,
        accounts,
        initial: editing ?? null,
        onClose: () => {
          setCreating(false);
          setEditing(null);
        },
        onSave: async (payload) => {
          try {
            await upsertFn({ data: payload });
            toast.success(payload.id ? "Modelo atualizado" : "Modelo criado");
            setCreating(false);
            setEditing(null);
            qc.invalidateQueries({ queryKey: ["quick-send-templates"] });
          } catch (e) {
            toast.error(e.message);
          }
        }
      }
    ),
    sending && /* @__PURE__ */ jsx(
      QuickSendDialog,
      {
        tpl: sending,
        rooms,
        accounts,
        onClose: () => setSending(null),
        onSend: async (payload) => {
          try {
            const r = await sendFn({ data: payload });
            if (r.ok) {
              toast.success(`Enviado (${r.sent} grupo${r.sent === 1 ? "" : "s"})`);
              setSending(null);
            } else {
              toast.error(r.error ?? "Falha ao enviar");
            }
          } catch (e) {
            toast.error(e.message);
          }
        }
      }
    ),
    meetSending && /* @__PURE__ */ jsx(
      MeetSendDialog,
      {
        tpl: meetSending,
        rooms,
        accounts,
        onClose: () => setMeetSending(null),
        onSend: async (payload) => {
          try {
            const r = await sendFn({ data: payload });
            if (r.ok) {
              toast.success(`Enviado (${r.sent} grupo${r.sent === 1 ? "" : "s"})`);
              setMeetSending(null);
            } else {
              toast.error(r.error ?? "Falha ao enviar");
            }
          } catch (e) {
            toast.error(e.message);
          }
        }
      }
    )
  ] });
}
function QuickTemplateDialog({
  initial,
  rooms,
  accounts,
  onClose,
  onSave
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [content, setContent] = useState(initial?.content ?? "");
  const [roomId, setRoomId] = useState(initial?.default_room_id ?? "");
  const [accountId, setAccountId] = useState(initial?.default_account_id ?? "");
  const [imagePath, setImagePath] = useState(initial?.image_path ?? null);
  const [imageMime, setImageMime] = useState(initial?.image_mime ?? null);
  const [uploading, setUploading] = useState(false);
  const [isPremium, setIsPremium] = useState(initial?.is_premium ?? false);
  const [isMeetButton, setIsMeetButton] = useState(initial?.is_meet_button ?? false);
  useEffect(() => {
    if (!roomId) return;
    const r = rooms.find((x) => x.id === roomId);
    if (r?.default_account_id && !accountId) setAccountId(r.default_account_id);
  }, [roomId, rooms, accountId]);
  const previewUrl = useMemo(() => {
    if (!imagePath) return null;
    return supabase.storage.from("room-images").getPublicUrl(imagePath).data.publicUrl;
  }, [imagePath]);
  async function handleUpload(file) {
    setUploading(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const uid = u.user?.id;
      if (!uid) throw new Error("Sessão expirada");
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${uid}/quick/${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("room-images").upload(path, file, { contentType: file.type, upsert: false });
      if (error) throw error;
      setImagePath(path);
      setImageMime(file.type);
      toast.success("Imagem carregada");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  }
  return /* @__PURE__ */ jsx(Dialog, { open: true, onOpenChange: (o) => !o && onClose(), children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-xl", children: [
    /* @__PURE__ */ jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsx(DialogTitle, { children: initial ? "Editar modelo" : "Novo modelo de envio rápido" }),
      /* @__PURE__ */ jsxs(DialogDescription, { children: [
        "Modelos aparecem como botões abaixo da busca. Você pode usar variáveis como",
        " ",
        /* @__PURE__ */ jsx("code", { children: "{DATA}" }),
        " ou ",
        /* @__PURE__ */ jsx("code", { children: "{HORA}" }),
        " e editar tudo no momento do envio."
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Nome do botão" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            value: name,
            onChange: (e) => setName(e.target.value),
            placeholder: "Ex.: Pré-save Diário",
            maxLength: 80
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Sala (padrão)" }),
          /* @__PURE__ */ jsxs(Select, { value: roomId || void 0, onValueChange: setRoomId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: rooms.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Bot (padrão)" }),
          /* @__PURE__ */ jsxs(Select, { value: accountId || void 0, onValueChange: setAccountId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: accounts.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Conteúdo (HTML)" }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: content, onChange: setContent }) }),
        /* @__PURE__ */ jsx(
          Textarea,
          {
            value: content,
            onChange: (e) => setContent(e.target.value),
            placeholder: "Olá! Pré-save de hoje: {LINK}\nValor: {VALOR}",
            rows: 6,
            maxLength: 4e3
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Imagem (opcional)" }),
        previewUrl ? /* @__PURE__ */ jsxs("div", { className: "relative inline-block", children: [
          /* @__PURE__ */ jsx("img", { src: previewUrl, alt: "", className: "rounded-md max-h-40 border border-border" }),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => {
                setImagePath(null);
                setImageMime(null);
              },
              className: "absolute -top-2 -right-2 bg-background border border-border rounded-full p-1",
              title: "Remover imagem",
              children: /* @__PURE__ */ jsx(X, { className: "size-3" })
            }
          )
        ] }) : /* @__PURE__ */ jsxs("label", { className: "inline-flex items-center gap-2 px-3 py-2 rounded-md border border-dashed border-border/70 text-sm cursor-pointer hover:bg-secondary/40", children: [
          uploading ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(ImageIcon, { className: "size-4" }),
          /* @__PURE__ */ jsx("span", { children: uploading ? "Enviando..." : "Selecionar imagem" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "file",
              accept: "image/*",
              className: "hidden",
              onChange: (e) => {
                const f = e.target.files?.[0];
                if (f) handleUpload(f);
              }
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-md border border-border/60 px-3 py-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm", children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "size-4 text-primary" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("div", { className: "font-medium", children: "Usar conta Premium por padrão" }),
            /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
              "Quando OFF: tokens ",
              "{EMOJI}",
              " são enviados como texto puro (preview), sem usar a conta Premium."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: isPremium, onCheckedChange: setIsPremium })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-md border border-border/60 px-3 py-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm", children: [
          /* @__PURE__ */ jsx(Video, { className: "size-4 text-primary" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("div", { className: "font-medium", children: "Botão MEET" }),
            /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground", children: [
              "Ao clicar no modelo, abre um modal pedindo o link do Meet e envia automaticamente. Use",
              " ",
              /* @__PURE__ */ jsx("code", { children: "{MEET_LINK}" }),
              " no conteúdo onde o link deve aparecer."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: isMeetButton, onCheckedChange: setIsMeetButton })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { children: [
      /* @__PURE__ */ jsx(Button, { variant: "outline", onClick: onClose, children: "Cancelar" }),
      /* @__PURE__ */ jsx(
        Button,
        {
          onClick: () => {
            if (!name.trim()) return toast.error("Informe um nome");
            onSave({
              id: initial?.id,
              name: name.trim(),
              content,
              parseMode: "HTML",
              imagePath,
              imageMime,
              defaultRoomId: roomId || null,
              defaultAccountId: accountId || null,
              sortOrder: initial?.sort_order ?? 0,
              isPremium,
              isMeetButton
            });
          },
          children: "Salvar modelo"
        }
      )
    ] })
  ] }) });
}
function MeetSendDialog({
  tpl,
  rooms,
  accounts,
  onClose,
  onSend
}) {
  const [meetUrl, setMeetUrl] = useState("");
  const [roomId, setRoomId] = useState(tpl.default_room_id ?? "");
  const [accountId, setAccountId] = useState(tpl.default_account_id ?? "");
  const [submitting, setSubmitting] = useState(false);
  useEffect(() => {
    if (!roomId) return;
    const r = rooms.find((x) => x.id === roomId);
    if (r?.default_account_id && !accountId) setAccountId(r.default_account_id);
  }, [roomId, rooms, accountId]);
  const hasToken = tpl.content.includes("{MEET_LINK}");
  const preview = hasToken ? tpl.content.replaceAll("{MEET_LINK}", meetUrl || "{MEET_LINK}") : `${tpl.content}
${meetUrl}`.trim();
  return /* @__PURE__ */ jsx(Dialog, { open: true, onOpenChange: (o) => !o && onClose(), children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-lg", children: [
    /* @__PURE__ */ jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Video, { className: "size-4 text-primary" }),
        tpl.name,
        " — Link do Meet"
      ] }),
      /* @__PURE__ */ jsx(DialogDescription, { children: "Cole o link do Google Meet abaixo. O modelo será enviado automaticamente com o link substituído." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Link do Meet" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            autoFocus: true,
            value: meetUrl,
            onChange: (e) => setMeetUrl(e.target.value),
            placeholder: "https://meet.google.com/xxx-xxxx-xxx"
          }
        ),
        !hasToken && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
          "Dica: inclua ",
          /* @__PURE__ */ jsx("code", { children: "{MEET_LINK}" }),
          " no modelo para escolher onde o link aparece. Por enquanto ele será adicionado ao final."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Sala" }),
          /* @__PURE__ */ jsxs(Select, { value: roomId || void 0, onValueChange: setRoomId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: rooms.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Bot" }),
          /* @__PURE__ */ jsxs(Select, { value: accountId || void 0, onValueChange: setAccountId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: accounts.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Pré-visualização" }),
        /* @__PURE__ */ jsx("div", { className: "rounded-md border border-border/60 bg-secondary/30 p-3 text-sm whitespace-pre-wrap max-h-48 overflow-auto", children: preview })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { children: [
      /* @__PURE__ */ jsx(Button, { variant: "outline", onClick: onClose, disabled: submitting, children: "Cancelar" }),
      /* @__PURE__ */ jsxs(
        Button,
        {
          disabled: submitting || !roomId || !accountId || !meetUrl.trim(),
          onClick: async () => {
            if (!meetUrl.trim()) return toast.error("Cole o link do Meet");
            setSubmitting(true);
            try {
              await onSend({
                id: tpl.id,
                roomId,
                accountId,
                content: preview,
                parseMode: tpl.parse_mode || "HTML",
                premium: Boolean(tpl.is_premium),
                imagePathOverride: tpl.image_path,
                removeImage: false
              });
            } finally {
              setSubmitting(false);
            }
          },
          children: [
            submitting ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Send, { className: "size-4" }),
            "Enviar agora"
          ]
        }
      )
    ] })
  ] }) });
}
function QuickSendDialog({
  tpl,
  rooms,
  accounts,
  onClose,
  onSend
}) {
  const [content, setContent] = useState(tpl.content);
  const [roomId, setRoomId] = useState(tpl.default_room_id ?? "");
  const [accountId, setAccountId] = useState(tpl.default_account_id ?? "");
  const [submitting, setSubmitting] = useState(false);
  const premiumKey = `qst:premium:${tpl.id}`;
  const [premium, setPremiumState] = useState(() => {
    if (typeof window === "undefined") return false;
    const ls = window.localStorage.getItem(premiumKey);
    if (ls === "1") return true;
    if (ls === "0") return false;
    return Boolean(tpl.is_premium);
  });
  const setPremium = (v) => {
    setPremiumState(v);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(premiumKey, v ? "1" : "0");
    }
  };
  const [imagePath, setImagePath] = useState(tpl.image_path);
  const [uploading, setUploading] = useState(false);
  const removed = imagePath === null && tpl.image_path !== null;
  useEffect(() => {
    if (!roomId) return;
    const r = rooms.find((x) => x.id === roomId);
    if (r?.default_account_id && !accountId) setAccountId(r.default_account_id);
  }, [roomId, rooms, accountId]);
  const previewUrl = imagePath ? supabase.storage.from("room-images").getPublicUrl(imagePath).data.publicUrl : null;
  async function handleUpload(file) {
    setUploading(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const uid = u.user?.id;
      if (!uid) throw new Error("Sessão expirada");
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${uid}/quick/${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from("room-images").upload(path, file, { contentType: file.type, upsert: false });
      if (error) throw error;
      setImagePath(path);
      toast.success("Imagem carregada");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  }
  return /* @__PURE__ */ jsx(Dialog, { open: true, onOpenChange: (o) => !o && onClose(), children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-xl", children: [
    /* @__PURE__ */ jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsxs(DialogTitle, { children: [
        "Enviar agora — ",
        tpl.name
      ] }),
      /* @__PURE__ */ jsx(DialogDescription, { children: "Edite as informações do dia e dispare. O envio é imediato." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Sala" }),
          /* @__PURE__ */ jsxs(Select, { value: roomId || void 0, onValueChange: setRoomId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: rooms.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(Label, { children: "Bot" }),
          /* @__PURE__ */ jsxs(Select, { value: accountId || void 0, onValueChange: setAccountId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione…" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: accounts.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Imagem" }),
        previewUrl ? /* @__PURE__ */ jsxs("div", { className: "relative inline-block mt-1", children: [
          /* @__PURE__ */ jsx(
            "img",
            {
              src: previewUrl,
              alt: "",
              className: "rounded-md max-h-40 border border-border"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => setImagePath(null),
              className: "absolute -top-2 -right-2 bg-background border border-border rounded-full p-1",
              title: "Remover imagem deste envio",
              children: /* @__PURE__ */ jsx(X, { className: "size-3" })
            }
          )
        ] }) : /* @__PURE__ */ jsxs("label", { className: "inline-flex items-center gap-2 px-3 py-2 rounded-md border border-dashed border-border/70 text-sm cursor-pointer hover:bg-secondary/40 mt-1", children: [
          uploading ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(ImageIcon, { className: "size-4" }),
          /* @__PURE__ */ jsx("span", { children: uploading ? "Enviando..." : "Selecionar imagem" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "file",
              accept: "image/*",
              className: "hidden",
              onChange: (e) => {
                const f = e.target.files?.[0];
                if (f) handleUpload(f);
              }
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-md border border-border/60 px-3 py-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm", children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "size-4 text-primary" }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("div", { className: "font-medium", children: "Emojis premium" }),
            /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground", children: "Renderiza emojis premium via conta MTProto (se configurada)." })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: premium, onCheckedChange: setPremium })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Label, { children: "Conteúdo" }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: content, onChange: setContent }) }),
        /* @__PURE__ */ jsx(
          Textarea,
          {
            value: content,
            onChange: (e) => setContent(e.target.value),
            rows: 8,
            maxLength: 4e3
          }
        ),
        /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
          "Suporta HTML do Telegram (",
          /* @__PURE__ */ jsx("code", { children: "<b>" }),
          ", ",
          /* @__PURE__ */ jsx("code", { children: "<i>" }),
          ", links)."
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { children: [
      /* @__PURE__ */ jsx(Button, { variant: "outline", onClick: onClose, disabled: submitting, children: "Cancelar" }),
      /* @__PURE__ */ jsxs(
        Button,
        {
          disabled: submitting || !roomId || !accountId,
          onClick: async () => {
            if (!roomId) return toast.error("Selecione a sala");
            if (!accountId) return toast.error("Selecione o bot");
            setSubmitting(true);
            try {
              await onSend({
                id: tpl.id,
                roomId,
                accountId,
                content,
                parseMode: tpl.parse_mode || "HTML",
                premium,
                imagePathOverride: imagePath,
                removeImage: removed
              });
            } finally {
              setSubmitting(false);
            }
          },
          children: [
            submitting ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Send, { className: "size-4" }),
            "Enviar agora"
          ]
        }
      )
    ] })
  ] }) });
}
const WEEKDAYS = [{
  value: 1,
  label: "Segunda",
  short: "Seg"
}, {
  value: 2,
  label: "Terça",
  short: "Ter"
}, {
  value: 3,
  label: "Quarta",
  short: "Qua"
}, {
  value: 4,
  label: "Quinta",
  short: "Qui"
}, {
  value: 5,
  label: "Sexta",
  short: "Sex"
}, {
  value: 6,
  label: "Sábado",
  short: "Sáb"
}, {
  value: 7,
  label: "Domingo",
  short: "Dom"
}];
function MensagensPage() {
  const qc = useQueryClient();
  const upsertFn = useServerFn(upsertSchedule);
  const toggleFn = useServerFn(toggleSchedule);
  const delFn = useServerFn(deleteSchedule);
  const testFn = useServerFn(testSchedule);
  const syncPhotoFn = useServerFn(syncRoomPhoto);
  const upsertFolderFn = useServerFn(upsertFolder);
  const deleteFolderFn = useServerFn(deleteFolder);
  const moveFolderFn = useServerFn(moveScheduleToFolder);
  const bulkReplaceFn = useServerFn(bulkReplaceLinks);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);
  const [presetRoomId, setPresetRoomId] = useState(null);
  const [activeFolder, setActiveFolder] = useState("all");
  const [manageOpen, setManageOpen] = useState(false);
  const [bulkReplaceOpen, setBulkReplaceOpen] = useState(false);
  const folders = useQuery({
    queryKey: ["schedule-folders"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("schedule_folders").select("id, name, color, sort_order").order("sort_order", {
        ascending: true
      }).order("created_at", {
        ascending: true
      });
      return data ?? [];
    }
  });
  const rooms = useQuery({
    queryKey: ["rooms-min"],
    queryFn: async () => (await supabase.from("rooms").select("id, name, default_account_id, photo_url")).data ?? []
  });
  const accounts = useQuery({
    queryKey: ["accounts-min"],
    queryFn: async () => (await supabase.from("telegram_accounts").select("id, label")).data ?? []
  });
  const videos = useQuery({
    queryKey: ["videos-min"],
    queryFn: async () => (await supabase.from("videos").select("id, title, kind, storage_path")).data ?? []
  });
  const audios = useQuery({
    queryKey: ["audios-min"],
    queryFn: async () => (await supabase.from("audios").select("id, title, storage_path")).data ?? []
  });
  const list = useQuery({
    queryKey: ["recurring-schedules"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("recurring_schedules").select("*").order("created_at", {
        ascending: false
      });
      return data ?? [];
    }
  });
  const all = list.data ?? [];
  const folderFiltered = useMemo(() => {
    if (activeFolder === "all") return all;
    if (activeFolder === "none") return all.filter((s) => !s.folder_id);
    return all.filter((s) => s.folder_id === activeFolder);
  }, [all, activeFolder]);
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return folderFiltered;
    const terms = q.split(/\s+/);
    return folderFiltered.filter((s) => {
      let lastSentCustom = "";
      if (s.last_sent_at) {
        const d = new Date(s.last_sent_at);
        const dd = String(d.getDate()).padStart(2, "0");
        const mm = String(d.getMonth() + 1).padStart(2, "0");
        const yyyy = d.getFullYear();
        const hh = String(d.getHours()).padStart(2, "0");
        const mins = String(d.getMinutes()).padStart(2, "0");
        lastSentCustom = `${dd}/${mm}/${yyyy} ${hh}:${mins}`;
      }
      const lastSentStr = s.last_sent_at ? new Date(s.last_sent_at).toLocaleString("pt-BR").toLowerCase() : "";
      const lastSentIso = s.last_sent_at ? s.last_sent_at.toLowerCase() : "";
      const timesStr = s.times ? s.times.join(" ").toLowerCase() : "";
      const wdStr = (s.weekdays || []).map((w) => WEEKDAYS.find((x) => x.value === w)?.label).join(" ").toLowerCase();
      return terms.every((term) => s.title.toLowerCase().includes(term) || (s.content ?? "").toLowerCase().includes(term) || lastSentStr.includes(term) || lastSentCustom.includes(term) || lastSentIso.includes(term) || timesStr.includes(term) || wdStr.includes(term) || (s.follow_ups ?? []).some((f) => (f.content ?? "").toLowerCase().includes(term)));
    });
  }, [folderFiltered, search]);
  const grouped = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const s of filtered) {
      const arr = map.get(s.room_id) ?? [];
      arr.push(s);
      map.set(s.room_id, arr);
    }
    return map;
  }, [filtered]);
  const stats = useMemo(() => {
    const total = all.length;
    const active = all.filter((s) => s.is_active).length;
    const roomsWithSchedules = new Set(all.map((s) => s.room_id)).size;
    return {
      total,
      active,
      rooms: roomsWithSchedules
    };
  }, [all]);
  const toggleMut = useMutation({
    mutationFn: async (vars) => {
      await toggleFn({
        data: vars
      });
    },
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["recurring-schedules"]
    }),
    onError: (e) => toast.error(e.message)
  });
  const delMut = useMutation({
    mutationFn: async (id) => {
      await delFn({
        data: {
          id
        }
      });
    },
    onSuccess: () => {
      toast.success("Agendamento removido");
      qc.invalidateQueries({
        queryKey: ["recurring-schedules"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const moveMut = useMutation({
    mutationFn: async (vars) => {
      await moveFolderFn({
        data: vars
      });
    },
    onSuccess: () => qc.invalidateQueries({
      queryKey: ["recurring-schedules"]
    }),
    onError: (e) => toast.error(e.message)
  });
  useMutation({
    mutationFn: async (roomId) => {
      const res = await syncPhotoFn({
        data: {
          roomId
        }
      });
      if (!res.ok) throw new Error(res.message ?? "Falha ao sincronizar foto");
      return res;
    },
    onSuccess: () => {
      toast.success("Foto atualizada");
      qc.invalidateQueries({
        queryKey: ["rooms-min"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const testMut = useMutation({
    mutationFn: async (id) => {
      return await testFn({
        data: {
          id
        }
      });
    },
    onSuccess: (res) => {
      if (res.ok) toast.success(`Teste enviado (${res.sent} grupo${res.sent === 1 ? "" : "s"})`);
      else toast.error(res.error ?? "Falha ao enviar teste");
    },
    onError: (e) => toast.error(e.message)
  });
  const ensureVideoThumbnail = async (videoIdToFix) => {
    const video = videos.data?.find((v) => v.id === videoIdToFix);
    if (!video || video.kind !== "normal" || !video.storage_path) return;
    const thumbPath = thumbnailPathForVideoPath(video.storage_path);
    const existing = await supabase.storage.from("videos").download(thumbPath);
    if (existing.data) return;
    const signed = await supabase.storage.from("videos").createSignedUrl(video.storage_path, 300);
    if (!signed.data?.signedUrl) return;
    const res = await fetch(signed.data.signedUrl);
    if (!res.ok) return;
    const thumb = await createVideoThumbnailBlob(await res.blob());
    await supabase.storage.from("videos").upload(thumbPath, thumb, {
      contentType: "image/jpeg",
      upsert: true
    });
  };
  const triedRef = useRef(/* @__PURE__ */ new Set());
  useEffect(() => {
    const list2 = rooms.data ?? [];
    for (const r of list2) {
      if (!r.photo_url && !triedRef.current.has(r.id)) {
        triedRef.current.add(r.id);
        syncPhotoFn({
          data: {
            roomId: r.id
          }
        }).then(() => qc.invalidateQueries({
          queryKey: ["rooms-min"]
        })).catch(() => {
        });
      }
    }
  }, [rooms.data, syncPhotoFn, qc]);
  const openNew = (roomId) => {
    setPresetRoomId(roomId ?? null);
    setEditing({
      id: "",
      user_id: "",
      room_id: roomId ?? "",
      account_id: roomId ? rooms.data?.find((r) => r.id === roomId)?.default_account_id ?? null : null,
      title: "",
      content: "",
      video_id: null,
      audio_id: null,
      image_path: null,
      image_mime: null,
      parse_mode: "HTML",
      times: ["08:00"],
      weekdays: [1, 2, 3, 4, 5, 6, 7],
      schedule_type: "weekly",
      month_days: [],
      weekday_overrides: {},
      follow_ups: [],
      is_premium: false,
      is_active: true,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString(),
      timezone: "America/Sao_Paulo",
      last_sent_at: null,
      last_fire_key: null,
      button_text: "",
      button_url: ""
    });
  };
  const openDuplicate = (s) => {
    setPresetRoomId(s.room_id);
    setEditing({
      ...s,
      id: "",
      title: `${s.title} (cópia)`,
      is_active: true,
      last_sent_at: null
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-5 sm:space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight", children: "Mensagens Agendadas" }),
      /* @__PURE__ */ jsx("p", { className: "text-xs sm:text-sm text-muted-foreground", children: "Gerencie mensagens automáticas enviadas nos horários e dias que você definir." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4", children: [
      /* @__PURE__ */ jsx(StatCard, { icon: /* @__PURE__ */ jsx(Calendar, { className: "size-5" }), value: stats.total, label: "Total", tone: "primary" }),
      /* @__PURE__ */ jsx(StatCard, { icon: /* @__PURE__ */ jsx(CheckCircle2, { className: "size-5" }), value: stats.active, label: "Ativas", tone: "success" }),
      /* @__PURE__ */ jsx(StatCard, { icon: /* @__PURE__ */ jsx(Users, { className: "size-5" }), value: stats.rooms, label: "Salas", tone: "info" }),
      /* @__PURE__ */ jsx(Card, { className: "p-4 sm:p-5 flex items-center text-xs sm:text-sm text-muted-foreground col-span-2 lg:col-span-1", children: "Execução automática a cada minuto pelo sistema" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 flex-wrap -mx-1 px-1 overflow-x-auto sm:overflow-visible", children: [
      /* @__PURE__ */ jsx(FolderChip, { active: activeFolder === "all", onClick: () => setActiveFolder("all"), icon: /* @__PURE__ */ jsx(FolderOpen, { className: "size-4" }), label: "Todas", count: all.length }),
      /* @__PURE__ */ jsx(FolderChip, { active: activeFolder === "none", onClick: () => setActiveFolder("none"), icon: /* @__PURE__ */ jsx(Folder, { className: "size-4" }), label: "Sem pasta", count: all.filter((s) => !s.folder_id).length }),
      (folders.data ?? []).map((f) => /* @__PURE__ */ jsx(FolderChip, { active: activeFolder === f.id, onClick: () => setActiveFolder(f.id), icon: /* @__PURE__ */ jsx(Folder, { className: "size-4", style: {
        color: f.color
      } }), label: f.name, count: all.filter((s) => s.folder_id === f.id).length, color: f.color }, f.id)),
      /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: () => setManageOpen(true), className: "shrink-0", children: [
        /* @__PURE__ */ jsx(FolderPlus, { className: "size-4" }),
        /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Gerenciar pastas" }),
        /* @__PURE__ */ jsx("span", { className: "sm:hidden", children: "Pastas" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative w-full sm:max-w-md", children: [
      /* @__PURE__ */ jsx(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" }),
      /* @__PURE__ */ jsx(Input, { placeholder: "Buscar por título, conteúdo, data ou hora…", value: search, onChange: (e) => setSearch(e.target.value), className: "pl-9" })
    ] }),
    /* @__PURE__ */ jsx(QuickTemplatesBar, { rooms: (rooms.data ?? []).map((r) => ({
      id: r.id,
      name: r.name,
      default_account_id: r.default_account_id
    })), accounts: accounts.data ?? [] }),
    (rooms.data ?? []).length === 0 && /* @__PURE__ */ jsx(Card, { className: "p-10 text-center text-muted-foreground text-sm", children: "Crie um grupo (sala) primeiro para poder agendar mensagens." }),
    /* @__PURE__ */ jsx("div", { className: "space-y-4", children: (rooms.data ?? []).map((room) => {
      const items = grouped.get(room.id) ?? [];
      if (search && items.length === 0) return null;
      return /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 flex-wrap", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
            room.photo_url ? /* @__PURE__ */ jsx("img", { src: room.photo_url, alt: room.name, className: "size-10 rounded-full object-cover shrink-0 bg-muted" }) : /* @__PURE__ */ jsx("div", { className: "size-10 rounded-full bg-primary/10 text-primary grid place-items-center shrink-0", children: /* @__PURE__ */ jsx(Users, { className: "size-5" }) }),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "font-semibold truncate text-sm sm:text-base", children: room.name }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs text-muted-foreground", children: [
                /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-emerald-500/15 text-emerald-400 px-2 py-0.5", children: [
                  /* @__PURE__ */ jsx("span", { className: "size-1.5 rounded-full bg-emerald-400" }),
                  " Ativa"
                ] }),
                /* @__PURE__ */ jsxs("span", { className: "truncate", children: [
                  items.length,
                  " ",
                  items.length === 1 ? "mensagem agendada" : "mensagens agendadas"
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: () => setBulkReplaceOpen(true), title: "Substituir links em todos os agendamentos", className: "flex-1 sm:flex-none", children: [
              /* @__PURE__ */ jsx(Link2, { className: "size-4" }),
              "Substituir Links"
            ] }),
            /* @__PURE__ */ jsxs(Button, { size: "sm", onClick: () => openNew(room.id), "data-tour": "add-schedule", className: "flex-1 sm:flex-none", children: [
              /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
              "Adicionar"
            ] })
          ] })
        ] }),
        items.length === 0 ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhum agendamento nesta sala ainda." }) : /* @__PURE__ */ jsx("div", { className: "space-y-6", children: [...WEEKDAYS, {
          value: -1,
          label: "Sem dia definido",
          short: ""
        }].map((wd) => {
          const dayItems = items.filter((s) => wd.value === -1 ? !s.weekdays || s.weekdays.length === 0 : s.weekdays?.[0] === wd.value);
          if (dayItems.length === 0) return null;
          return /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxs("h3", { className: "font-medium text-sm text-muted-foreground border-b border-border/60 pb-1 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Calendar, { className: "size-4" }),
              " ",
              wd.label
            ] }),
            /* @__PURE__ */ jsx("div", { className: "divide-y divide-border/60 rounded-md border border-border/60 bg-card", children: dayItems.map((s) => /* @__PURE__ */ jsxs("div", { className: "py-3 flex flex-col sm:flex-row sm:items-start gap-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 flex-1 min-w-0", children: [
                /* @__PURE__ */ jsx("span", { className: `mt-1.5 size-2 rounded-full shrink-0 ${s.is_active ? "bg-emerald-400" : "bg-muted-foreground/40"}` }),
                /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsx("p", { className: "font-medium text-sm sm:text-base break-words", children: s.title }),
                  /* @__PURE__ */ jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-1.5 text-xs", children: [
                    s.times.map((t) => /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 text-muted-foreground", children: [
                      /* @__PURE__ */ jsx(Clock, { className: "size-3" }),
                      t
                    ] }, t)),
                    s.schedule_type === "monthly" ? s.month_days?.map((d) => /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "bg-sky-500/15 text-sky-300 border-0 font-normal", children: [
                      "Dia ",
                      d
                    ] }, d)) : s.weekdays.map((w) => {
                      const wd2 = WEEKDAYS.find((x) => x.value === w);
                      return /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "bg-sky-500/15 text-sky-300 border-0 font-normal", children: [
                        /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: wd2?.label }),
                        /* @__PURE__ */ jsx("span", { className: "sm:hidden", children: wd2?.short })
                      ] }, w);
                    }),
                    s.is_premium && /* @__PURE__ */ jsxs(Badge, { className: "bg-amber-500/15 text-amber-400 border-0 font-normal", children: [
                      /* @__PURE__ */ jsx(Sparkles, { className: "size-3 mr-1" }),
                      "Premium"
                    ] }),
                    (() => {
                      const f = (folders.data ?? []).find((x) => x.id === s.folder_id);
                      return f ? /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "border-0 font-normal", style: {
                        backgroundColor: `${f.color}26`,
                        color: f.color
                      }, children: [
                        /* @__PURE__ */ jsx(Folder, { className: "size-3 mr-1" }),
                        f.name
                      ] }) : null;
                    })()
                  ] }),
                  s.last_sent_at && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground mt-1", children: [
                    "Último envio: ",
                    new Date(s.last_sent_at).toLocaleString("pt-BR")
                  ] }),
                  search.trim() && (s.follow_ups ?? []).some((f) => (f.content ?? "").toLowerCase().includes(search.trim().toLowerCase())) && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground mt-2 bg-muted/50 px-2 py-1 rounded inline-flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsx(Search, { className: "size-3" }),
                    " Correspondência encontrada na mensagem em sequência"
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 flex-wrap sm:flex-nowrap justify-end pl-5 sm:pl-0", children: [
                /* @__PURE__ */ jsx(Switch, { checked: s.is_active, onCheckedChange: (v) => toggleMut.mutate({
                  id: s.id,
                  isActive: v
                }) }),
                /* @__PURE__ */ jsxs(Select, { value: s.folder_id ?? "__none__", onValueChange: (v) => moveMut.mutate({
                  id: s.id,
                  folderId: v === "__none__" ? null : v
                }), children: [
                  /* @__PURE__ */ jsx(SelectTrigger, { className: "h-8 w-[110px] sm:w-[140px] text-xs sm:text-sm", title: "Mover para pasta", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Pasta" }) }),
                  /* @__PURE__ */ jsxs(SelectContent, { children: [
                    /* @__PURE__ */ jsx(SelectItem, { value: "__none__", children: "Sem pasta" }),
                    (folders.data ?? []).map((f) => /* @__PURE__ */ jsx(SelectItem, { value: f.id, children: f.name }, f.id))
                  ] })
                ] }),
                /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", title: "Enviar teste agora", onClick: () => testMut.mutate(s.id), disabled: testMut.isPending && testMut.variables === s.id, className: "h-8", children: [
                  testMut.isPending && testMut.variables === s.id ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Send, { className: "size-4" }),
                  /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Testar" })
                ] }),
                /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", title: "Duplicar agendamento", onClick: () => openDuplicate(s), className: "h-8", children: [
                  /* @__PURE__ */ jsx(Copy, { className: "size-4" }),
                  /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Duplicar" })
                ] }),
                /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => setEditing(s), children: /* @__PURE__ */ jsx(Pencil, { className: "size-4" }) }),
                /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => {
                  if (confirm("Excluir este agendamento?")) delMut.mutate(s.id);
                }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
              ] })
            ] }, s.id)) })
          ] }, wd.value);
        }) })
      ] }, room.id);
    }) }),
    /* @__PURE__ */ jsx(ScheduleDialog, { editing, rooms: rooms.data ?? [], accounts: accounts.data ?? [], videos: videos.data ?? [], audios: audios.data ?? [], folders: folders.data ?? [], presetRoomId, ensureVideoThumbnail, onClose: () => setEditing(null), onSave: async (payload) => {
      try {
        await upsertFn({
          data: payload
        });
        toast.success(payload.id ? "Agendamento atualizado" : "Agendamento criado");
        setEditing(null);
        qc.invalidateQueries({
          queryKey: ["recurring-schedules"]
        });
      } catch (e) {
        toast.error(e.message);
      }
    } }),
    /* @__PURE__ */ jsx(ManageFoldersDialog, { open: manageOpen, onClose: () => setManageOpen(false), folders: folders.data ?? [], onCreate: async (name, color) => {
      await upsertFolderFn({
        data: {
          name,
          color,
          sortOrder: folders.data?.length ?? 0
        }
      });
      await qc.invalidateQueries({
        queryKey: ["schedule-folders"]
      });
    }, onRename: async (id, name, color) => {
      await upsertFolderFn({
        data: {
          id,
          name,
          color,
          sortOrder: 0
        }
      });
      await qc.invalidateQueries({
        queryKey: ["schedule-folders"]
      });
    }, onDelete: async (id) => {
      await deleteFolderFn({
        data: {
          id
        }
      });
      await qc.invalidateQueries({
        queryKey: ["schedule-folders"]
      });
      await qc.invalidateQueries({
        queryKey: ["recurring-schedules"]
      });
      if (activeFolder === id) setActiveFolder("all");
    } }),
    /* @__PURE__ */ jsx(BulkReplaceDialog, { open: bulkReplaceOpen, onClose: () => setBulkReplaceOpen(false), onSubmit: async (oldLink, newLink) => {
      const res = await bulkReplaceFn({
        data: {
          oldLink,
          newLink
        }
      });
      await qc.invalidateQueries({
        queryKey: ["recurring-schedules"]
      });
      toast.success(`Atualizados ${res.recurringUpdated} agendamentos recorrentes e ${res.scheduledUpdated} únicos.`);
    } })
  ] });
}
function FolderChip({
  active,
  onClick,
  icon,
  label,
  count,
  color
}) {
  return /* @__PURE__ */ jsxs("button", { type: "button", onClick, className: `inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm border transition-colors ${active ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-muted border-border"}`, style: active && color ? {
    backgroundColor: color,
    borderColor: color,
    color: "#fff"
  } : void 0, children: [
    icon,
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsx("span", { className: `text-xs ${active ? "opacity-80" : "text-muted-foreground"}`, children: count })
  ] });
}
function ManageFoldersDialog({
  open,
  onClose,
  folders,
  onCreate,
  onRename,
  onDelete
}) {
  const [name, setName] = useState("");
  const [color, setColor] = useState("#6366f1");
  const [busy, setBusy] = useState(false);
  return /* @__PURE__ */ jsx(Dialog, { open, onOpenChange: (v) => !v && onClose(), children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-md w-[calc(100vw-1rem)] sm:w-auto p-4 sm:p-6", children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Pastas de agendamentos" }) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-end gap-2 flex-wrap sm:flex-nowrap", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-[60%] space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { children: "Nova pasta" }),
          /* @__PURE__ */ jsx(Input, { placeholder: "Ex: Manhã, Sinais, Promo…", value: name, onChange: (e) => setName(e.target.value) })
        ] }),
        /* @__PURE__ */ jsx("input", { type: "color", value: color, onChange: (e) => setColor(e.target.value), className: "h-10 w-12 rounded border border-border bg-transparent shrink-0" }),
        /* @__PURE__ */ jsx(Button, { className: "shrink-0", disabled: !name.trim() || busy, onClick: async () => {
          setBusy(true);
          try {
            await onCreate(name.trim(), color);
            setName("");
            toast.success("Pasta criada");
          } catch (e) {
            toast.error(e.message);
          } finally {
            setBusy(false);
          }
        }, children: /* @__PURE__ */ jsx(Plus, { className: "size-4" }) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "space-y-2 max-h-72 overflow-auto", children: folders.length === 0 ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhuma pasta criada." }) : folders.map((f) => /* @__PURE__ */ jsx(FolderRow, { folder: f, onRename, onDelete }, f.id)) })
    ] }),
    /* @__PURE__ */ jsx(DialogFooter, { children: /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: onClose, children: "Fechar" }) })
  ] }) });
}
function FolderRow({
  folder,
  onRename,
  onDelete
}) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(folder.name);
  const [color, setColor] = useState(folder.color);
  return /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2 rounded-md border border-border p-2", children: editing ? /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("input", { type: "color", value: color, onChange: (e) => setColor(e.target.value), className: "h-8 w-10 rounded border border-border bg-transparent" }),
    /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), className: "h-8" }),
    /* @__PURE__ */ jsx(Button, { size: "sm", onClick: async () => {
      try {
        await onRename(folder.id, name.trim(), color);
        setEditing(false);
        toast.success("Pasta atualizada");
      } catch (e) {
        toast.error(e.message);
      }
    }, children: "OK" }),
    /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => {
      setEditing(false);
      setName(folder.name);
      setColor(folder.color);
    }, children: /* @__PURE__ */ jsx(X, { className: "size-4" }) })
  ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("span", { className: "size-4 rounded-full", style: {
      backgroundColor: folder.color
    } }),
    /* @__PURE__ */ jsx("span", { className: "flex-1 truncate", children: folder.name }),
    /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => setEditing(true), children: /* @__PURE__ */ jsx(Pencil, { className: "size-4" }) }),
    /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: async () => {
      if (!confirm(`Excluir pasta "${folder.name}"? Os agendamentos não serão excluídos.`)) return;
      try {
        await onDelete(folder.id);
        toast.success("Pasta removida");
      } catch (e) {
        toast.error(e.message);
      }
    }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
  ] }) });
}
function StatCard({
  icon,
  value,
  label,
  tone
}) {
  const toneCls = tone === "success" ? "bg-emerald-500/15 text-emerald-400" : tone === "info" ? "bg-sky-500/15 text-sky-400" : "bg-primary/15 text-primary";
  return /* @__PURE__ */ jsxs(Card, { className: "p-3 sm:p-5 flex items-center gap-3 sm:gap-4", children: [
    /* @__PURE__ */ jsx("div", { className: `size-9 sm:size-11 rounded-xl grid place-items-center shrink-0 ${toneCls}`, children: icon }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("p", { className: "text-xl sm:text-2xl font-bold leading-none", children: value }),
      /* @__PURE__ */ jsx("p", { className: "text-xs sm:text-sm text-muted-foreground mt-1", children: label })
    ] })
  ] });
}
function ScheduleDialog({
  editing,
  rooms,
  accounts,
  videos,
  audios,
  folders,
  presetRoomId,
  ensureVideoThumbnail,
  onClose,
  onSave
}) {
  const [title, setTitle] = useState("");
  const testMsgFn = useServerFn(testMessage);
  const [testingPart, setTestingPart] = useState(null);
  const [roomId, setRoomId] = useState("");
  const [accountId, setAccountId] = useState("");
  const [content, setContent] = useState("");
  const [videoId, setVideoId] = useState("");
  const [audioId, setAudioId] = useState("");
  const [imagePath, setImagePath] = useState("");
  const [imageMime, setImageMime] = useState("");
  const [uploading, setUploading] = useState(false);
  const [times, setTimes] = useState([]);
  const [weekdays, setWeekdays] = useState([]);
  const [scheduleType, setScheduleType] = useState("weekly");
  const [monthDays, setMonthDays] = useState([]);
  const [weekdayOverrides, setWeekdayOverrides] = useState({});
  const [overrideInputs, setOverrideInputs] = useState({});
  const [followUps, setFollowUps] = useState([]);
  const [followUpUploading, setFollowUpUploading] = useState(null);
  const [isPremium, setIsPremium] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [newTime, setNewTime] = useState("");
  const [buttonText, setButtonText] = useState("");
  const [buttonUrl, setButtonUrl] = useState("");
  const [folderId, setFolderId] = useState("");
  const open = !!editing;
  const videoKindById = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const v of videos) m.set(v.id, v.kind ?? "round");
    return m;
  }, [videos]);
  const isRoundVideo = (vid) => !!vid && (videoKindById.get(vid) ?? "round") === "round";
  useMemo(() => {
    if (editing) {
      setTitle(editing.title);
      setRoomId(editing.room_id || presetRoomId || "");
      setAccountId(editing.account_id ?? "");
      setContent(editing.content ?? "");
      setVideoId(editing.video_id ?? "");
      setAudioId(editing.audio_id ?? "");
      setImagePath(editing.image_path ?? "");
      setImageMime(editing.image_mime ?? "");
      setTimes(editing.times);
      setWeekdays(editing.weekdays);
      setScheduleType(editing.schedule_type ?? "weekly");
      setMonthDays(editing.month_days ?? []);
      setWeekdayOverrides(editing.weekday_overrides ?? {});
      setOverrideInputs({});
      setFollowUps((editing.follow_ups ?? []).map((f) => ({
        delayValue: f.delay_seconds && f.delay_seconds > 0 ? f.delay_seconds : f.delay_minutes,
        delayUnit: f.delay_seconds && f.delay_seconds > 0 ? "seconds" : "minutes",
        content: f.content ?? "",
        imagePath: f.image_path ?? "",
        imageMime: f.image_mime ?? "",
        videoId: f.video_id ?? "",
        audioId: f.audio_id ?? "",
        buttonText: f.button_text ?? "",
        buttonUrl: f.button_url ?? ""
      })));
      setIsPremium(editing.is_premium);
      setIsActive(editing.is_active);
      setNewTime("");
      setButtonText(editing.button_text ?? "");
      setButtonUrl(editing.button_url ?? "");
      setFolderId(editing.folder_id ?? "");
    } else {
      setButtonText("");
      setButtonUrl("");
      setFolderId("");
    }
  }, [editing, presetRoomId]);
  const imagePublicUrl = useMemo(() => {
    if (!imagePath) return "";
    const {
      data
    } = supabase.storage.from("room-images").getPublicUrl(imagePath);
    return data.publicUrl;
  }, [imagePath]);
  async function handleImageUpload(file) {
    setUploading(true);
    try {
      const {
        data: u
      } = await supabase.auth.getUser();
      const uid = u.user?.id;
      if (!uid) throw new Error("Sessão expirada");
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `messages/${uid}/${Date.now()}.${ext}`;
      const {
        error
      } = await supabase.storage.from("room-images").upload(path, file, {
        contentType: file.type,
        upsert: false
      });
      if (error) throw error;
      setImagePath(path);
      setImageMime(file.type);
      setVideoId("");
      setAudioId("");
      toast.success("Imagem carregada");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  }
  const addTime = () => {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(newTime)) return;
    if (times.includes(newTime)) return;
    setTimes([...times, newTime].sort());
    setNewTime("");
  };
  const toggleWeekday = (v) => {
    setWeekdays((cur) => cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v].sort((a, b) => a - b));
  };
  const toggleMonthDay = (v) => {
    setMonthDays((cur) => cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v].sort((a, b) => a - b));
  };
  const canSave = title.trim() && roomId && times.length > 0 && (scheduleType === "weekly" ? weekdays.length > 0 : monthDays.length > 0);
  async function runPartTest(key, payload) {
    if (!roomId) {
      toast.error("Selecione uma sala antes de testar");
      return;
    }
    setTestingPart(key);
    try {
      if (payload.videoId) await ensureVideoThumbnail(payload.videoId);
      const res = await testMsgFn({
        data: {
          roomId,
          accountId: accountId || null,
          content: payload.content || null,
          videoId: payload.videoId || null,
          audioId: payload.audioId || null,
          imagePath: payload.videoId || payload.audioId ? null : payload.imagePath || null,
          imageMime: payload.videoId || payload.audioId ? null : payload.imageMime || null,
          parseMode: "HTML",
          isPremium,
          buttonText: payload.buttonText?.trim() || null,
          buttonUrl: payload.buttonUrl?.trim() || null
        }
      });
      if (res.ok) toast.success(`Teste enviado (${res.sent} grupo${res.sent === 1 ? "" : "s"})`);
      else toast.error(res.error ?? "Falha ao enviar teste");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTestingPart(null);
    }
  }
  return /* @__PURE__ */ jsx(Dialog, { open, onOpenChange: (o) => !o && onClose(), children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-6xl max-h-[92vh] overflow-y-auto p-4 sm:p-6 w-[calc(100vw-1rem)] sm:w-auto", children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: editing?.id ? "Editar mensagem" : "Nova mensagem" }) }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-4", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-semibold", children: "Identificação" }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxs(Label, { children: [
              "Título ",
              /* @__PURE__ */ jsx("span", { className: "text-destructive", children: "*" })
            ] }),
            /* @__PURE__ */ jsx(Input, { value: title, onChange: (e) => setTitle(e.target.value), placeholder: "Ex: Bom dia traders!" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxs(Label, { children: [
                "Sala ",
                /* @__PURE__ */ jsx("span", { className: "text-destructive", children: "*" })
              ] }),
              /* @__PURE__ */ jsxs(Select, { value: roomId, onValueChange: (v) => {
                setRoomId(v);
                if (!accountId) {
                  const r = rooms.find((x) => x.id === v);
                  if (r?.default_account_id) setAccountId(r.default_account_id);
                }
              }, children: [
                /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
                /* @__PURE__ */ jsx(SelectContent, { children: rooms.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Conta Telegram" }),
              /* @__PURE__ */ jsxs(Select, { value: accountId, onValueChange: setAccountId, children: [
                /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Padrão da sala" }) }),
                /* @__PURE__ */ jsx(SelectContent, { children: accounts.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Pasta" }),
            /* @__PURE__ */ jsxs(Select, { value: folderId || "__none__", onValueChange: (v) => setFolderId(v === "__none__" ? "" : v), children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Sem pasta" }) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "__none__", children: "Sem pasta" }),
                folders.map((f) => /* @__PURE__ */ jsx(SelectItem, { value: f.id, children: f.name }, f.id))
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-6 pt-1", children: [
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer", children: [
              /* @__PURE__ */ jsx("input", { type: "checkbox", checked: isActive, onChange: (e) => setIsActive(e.target.checked), className: "size-4 rounded accent-primary" }),
              /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: "Ativo" })
            ] }),
            /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer", children: [
              /* @__PURE__ */ jsx("input", { type: "checkbox", checked: isPremium, onChange: (e) => setIsPremium(e.target.checked), className: "size-4 rounded accent-primary" }),
              /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: "Usar emoji premium" })
            ] })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground -mt-2", children: "Processa emojis premium da sala antes do envio" })
        ] }),
        /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-4", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-semibold", children: "Conteúdo" }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxs(Label, { children: [
              "Mensagem ",
              /* @__PURE__ */ jsx("span", { className: "text-destructive", children: "*" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: content, onChange: setContent }) }),
            /* @__PURE__ */ jsx(Textarea, { value: content, onChange: (e) => setContent(e.target.value), rows: 6, placeholder: imagePath ? "Legenda da imagem (opcional)" : videoId ? isRoundVideo(videoId) ? "Vídeos redondos não suportam texto" : "Legenda do vídeo (opcional)" : "Texto da mensagem. Use {NOME} para emojis premium.", disabled: !!videoId && isRoundVideo(videoId) }),
            /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
              "Suporta HTML do Telegram: <b>, <i>, <u>, <code>. Para emojis premium, use",
              " ",
              /* @__PURE__ */ jsx("code", { className: "px-1 py-0.5 rounded bg-muted", children: "{NOME}" }),
              "."
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Imagem (opcional — texto vira legenda)" }),
            imagePath ? /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx("img", { src: imagePublicUrl, alt: "Preview", className: "size-24 rounded-md object-cover border border-border" }),
              /* @__PURE__ */ jsxs(Button, { type: "button", size: "sm", variant: "outline", onClick: () => {
                setImagePath("");
                setImageMime("");
              }, children: [
                /* @__PURE__ */ jsx(X, { className: "size-4" }),
                " Remover imagem"
              ] })
            ] }) : /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-2 px-3 py-2 rounded-md border border-dashed cursor-pointer hover:bg-muted/40 text-sm ${videoId || audioId ? "opacity-50 pointer-events-none" : ""}`, children: [
              uploading ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(ImageIcon, { className: "size-4" }),
              /* @__PURE__ */ jsx("span", { children: uploading ? "Enviando..." : "Selecionar imagem" }),
              /* @__PURE__ */ jsx("input", { type: "file", accept: "image/*", className: "hidden", onChange: (e) => {
                const f = e.target.files?.[0];
                if (f) handleImageUpload(f);
                e.target.value = "";
              } })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Vídeo da biblioteca (opcional — substitui texto/imagem)" }),
            /* @__PURE__ */ jsxs(Select, { value: videoId || "none", onValueChange: (v) => {
              const next = v === "none" ? "" : v;
              setVideoId(next);
              if (next) {
                setAudioId("");
                setImagePath("");
                setImageMime("");
                void ensureVideoThumbnail(next);
              }
            }, children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhum (enviar texto)" }) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum (enviar texto)" }),
                videos.map((v) => /* @__PURE__ */ jsx(SelectItem, { value: v.id, children: v.title }, v.id))
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { children: "Áudio da biblioteca (opcional — substitui texto/imagem/vídeo)" }),
            /* @__PURE__ */ jsxs(Select, { value: audioId || "none", onValueChange: (v) => {
              const next = v === "none" ? "" : v;
              setAudioId(next);
              if (next) {
                setVideoId("");
                setImagePath("");
                setImageMime("");
              }
            }, children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhum (enviar texto)" }) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum (enviar texto)" }),
                audios.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.title }, a.id))
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-1", children: /* @__PURE__ */ jsxs(Button, { type: "button", size: "sm", variant: "outline", disabled: testingPart === "main" || !roomId, onClick: () => runPartTest("main", {
            content,
            videoId,
            audioId,
            imagePath,
            imageMime,
            buttonText,
            buttonUrl
          }), children: [
            testingPart === "main" ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Send, { className: "size-4" }),
            "Testar esta mensagem"
          ] }) })
        ] }),
        /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-start sm:items-center justify-between gap-2 flex-wrap", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h3", { className: "font-semibold", children: "Mensagens em sequência" }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-0.5", children: "Envie mais mensagens após a primeira, com um intervalo em minutos." })
            ] }),
            /* @__PURE__ */ jsxs(Button, { type: "button", size: "sm", variant: "outline", disabled: followUps.length >= 10, className: "shrink-0", onClick: () => setFollowUps([...followUps, {
              delayValue: 1,
              delayUnit: "minutes",
              content: "",
              imagePath: "",
              imageMime: "",
              videoId: "",
              audioId: "",
              buttonText: "",
              buttonUrl: ""
            }]), children: [
              /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
              /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Adicionar conteúdo" }),
              /* @__PURE__ */ jsx("span", { className: "sm:hidden", children: "Adicionar" })
            ] })
          ] }),
          followUps.length === 0 ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhuma mensagem em sequência." }) : /* @__PURE__ */ jsx("div", { className: "space-y-3", children: followUps.map((f, idx) => {
            const update = (patch) => {
              const next = [...followUps];
              next[idx] = {
                ...next[idx],
                ...patch
              };
              setFollowUps(next);
            };
            const remove = () => setFollowUps(followUps.filter((_, i) => i !== idx));
            const previewUrl = f.imagePath ? supabase.storage.from("room-images").getPublicUrl(f.imagePath).data.publicUrl : "";
            return /* @__PURE__ */ jsxs("div", { className: "rounded-md border p-3 space-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxs("span", { className: "text-sm font-medium", children: [
                  "Mensagem #",
                  idx + 2
                ] }),
                /* @__PURE__ */ jsx(Button, { type: "button", size: "icon", variant: "ghost", onClick: remove, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
                /* @__PURE__ */ jsx(Label, { className: "text-xs whitespace-nowrap", children: "Após:" }),
                /* @__PURE__ */ jsx(Input, { type: "number", min: 1, max: f.delayUnit === "seconds" ? 86400 : 1440, value: f.delayValue, onChange: (e) => {
                  const max = f.delayUnit === "seconds" ? 86400 : 1440;
                  update({
                    delayValue: Math.max(1, Math.min(max, Number(e.target.value) || 1))
                  });
                }, className: "max-w-[100px]" }),
                /* @__PURE__ */ jsxs(Select, { value: f.delayUnit, onValueChange: (v) => {
                  const max = v === "seconds" ? 86400 : 1440;
                  update({
                    delayUnit: v,
                    delayValue: Math.max(1, Math.min(max, f.delayValue))
                  });
                }, children: [
                  /* @__PURE__ */ jsx(SelectTrigger, { className: "max-w-[130px]", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                  /* @__PURE__ */ jsxs(SelectContent, { children: [
                    /* @__PURE__ */ jsx(SelectItem, { value: "seconds", children: "segundos" }),
                    /* @__PURE__ */ jsx(SelectItem, { value: "minutes", children: "minutos" })
                  ] })
                ] }),
                /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: "depois da mensagem anterior" })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: f.content, onChange: (v) => update({
                content: v
              }) }) }),
              /* @__PURE__ */ jsx(Textarea, { rows: 3, value: f.content, onChange: (e) => update({
                content: e.target.value
              }), placeholder: f.videoId ? isRoundVideo(f.videoId) ? "Vídeos redondos não suportam texto" : "Legenda do vídeo (opcional)" : "Texto desta mensagem (ou legenda da imagem)", disabled: !!f.videoId && isRoundVideo(f.videoId) }),
              f.imagePath ? /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsx("img", { src: previewUrl, alt: "Preview", className: "size-20 rounded-md object-cover border border-border" }),
                /* @__PURE__ */ jsxs(Button, { type: "button", size: "sm", variant: "outline", onClick: () => update({
                  imagePath: "",
                  imageMime: ""
                }), children: [
                  /* @__PURE__ */ jsx(X, { className: "size-4" }),
                  " Remover imagem"
                ] })
              ] }) : /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-2 px-3 py-2 rounded-md border border-dashed cursor-pointer hover:bg-muted/40 text-sm w-fit ${f.videoId || f.audioId ? "opacity-50 pointer-events-none" : ""}`, children: [
                followUpUploading === idx ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(ImageIcon, { className: "size-4" }),
                /* @__PURE__ */ jsx("span", { children: followUpUploading === idx ? "Enviando..." : "Imagem (opcional)" }),
                /* @__PURE__ */ jsx("input", { type: "file", accept: "image/*", className: "hidden", onChange: async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (!file) return;
                  setFollowUpUploading(idx);
                  try {
                    const {
                      data: u
                    } = await supabase.auth.getUser();
                    const uid = u.user?.id;
                    if (!uid) throw new Error("Sessão expirada");
                    const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
                    const path = `messages/${uid}/${Date.now()}-fu.${ext}`;
                    const {
                      error
                    } = await supabase.storage.from("room-images").upload(path, file, {
                      contentType: file.type,
                      upsert: false
                    });
                    if (error) throw error;
                    update({
                      imagePath: path,
                      imageMime: file.type,
                      videoId: "",
                      audioId: ""
                    });
                    toast.success("Imagem carregada");
                  } catch (err) {
                    toast.error(err.message);
                  } finally {
                    setFollowUpUploading(null);
                  }
                } })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Vídeo da biblioteca (opcional)" }),
                /* @__PURE__ */ jsxs(Select, { value: f.videoId || "none", onValueChange: (v) => {
                  const next = v === "none" ? "" : v;
                  if (next) {
                    update({
                      videoId: next,
                      audioId: "",
                      imagePath: "",
                      imageMime: ""
                    });
                    void ensureVideoThumbnail(next);
                  } else {
                    update({
                      videoId: ""
                    });
                  }
                }, children: [
                  /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhum (enviar texto/imagem)" }) }),
                  /* @__PURE__ */ jsxs(SelectContent, { children: [
                    /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum (enviar texto/imagem)" }),
                    videos.map((v) => /* @__PURE__ */ jsx(SelectItem, { value: v.id, children: v.title }, v.id))
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Áudio da biblioteca (opcional)" }),
                /* @__PURE__ */ jsxs(Select, { value: f.audioId || "none", onValueChange: (v) => {
                  const next = v === "none" ? "" : v;
                  if (next) {
                    update({
                      audioId: next,
                      videoId: "",
                      imagePath: "",
                      imageMime: ""
                    });
                  } else {
                    update({
                      audioId: ""
                    });
                  }
                }, children: [
                  /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Nenhum (enviar texto/imagem)" }) }),
                  /* @__PURE__ */ jsxs(SelectContent, { children: [
                    /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum (enviar texto/imagem)" }),
                    audios.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.title }, a.id))
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxs(Button, { type: "button", size: "sm", variant: "outline", disabled: testingPart === `fu-${idx}` || !roomId, onClick: () => runPartTest(`fu-${idx}`, {
                content: f.content,
                videoId: f.videoId,
                audioId: f.audioId,
                imagePath: f.imagePath,
                imageMime: f.imageMime,
                buttonText: f.buttonText,
                buttonUrl: f.buttonUrl
              }), children: [
                testingPart === `fu-${idx}` ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Send, { className: "size-4" }),
                "Testar esta mensagem"
              ] }) })
            ] }, idx);
          }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxs("h3", { className: "font-semibold", children: [
              "Dias de envio ",
              /* @__PURE__ */ jsx("span", { className: "text-destructive", children: "*" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex bg-muted p-1 rounded-md w-fit", children: [
              /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setScheduleType("weekly"), className: `px-3 py-1.5 rounded text-sm font-medium transition ${scheduleType === "weekly" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`, children: "Dias da Semana" }),
              /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setScheduleType("monthly"), className: `px-3 py-1.5 rounded text-sm font-medium transition ${scheduleType === "monthly" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`, children: "Dias do Mês" })
            ] })
          ] }),
          scheduleType === "weekly" ? /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2", children: WEEKDAYS.map((d) => {
            const on = weekdays.includes(d.value);
            return /* @__PURE__ */ jsxs("label", { className: `flex items-center gap-2 px-3 py-2.5 rounded-md border cursor-pointer transition ${on ? "border-primary bg-primary/10" : "border-border hover:bg-muted/50"}`, children: [
              /* @__PURE__ */ jsx("input", { type: "checkbox", checked: on, onChange: () => toggleWeekday(d.value), className: "size-4 rounded accent-primary" }),
              /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: d.label })
            ] }, d.value);
          }) }) : /* @__PURE__ */ jsxs("div", { className: "space-y-3 mt-2", children: [
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Selecione os dias do mês em que a mensagem será enviada de forma recorrente (todo mês)." }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-7 gap-1.5 sm:gap-2", children: Array.from({
              length: 31
            }, (_, i) => i + 1).map((day) => {
              const on = monthDays.includes(day);
              return /* @__PURE__ */ jsx("button", { type: "button", onClick: () => toggleMonthDay(day), className: `h-9 sm:h-10 rounded-md border text-sm font-medium transition flex items-center justify-center ${on ? "border-primary bg-primary text-primary-foreground shadow-sm" : "border-border bg-card hover:bg-muted/50 text-foreground"}`, children: day }, day);
            }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-3", children: [
          /* @__PURE__ */ jsxs("h3", { className: "font-semibold", children: [
            "Horários ",
            /* @__PURE__ */ jsx("span", { className: "text-destructive", children: "*" })
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Adicione um ou mais horários de envio. A mensagem será enviada a cada horário marcado nos dias configurados." }),
          times.length === 0 ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhum horário adicionado." }) : /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-1.5", children: times.map((t) => /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "gap-1 pr-1", children: [
            /* @__PURE__ */ jsx(Clock, { className: "size-3" }),
            t,
            /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setTimes(times.filter((x) => x !== t)), className: "ml-1 hover:bg-background/40 rounded p-0.5", children: /* @__PURE__ */ jsx(X, { className: "size-3" }) })
          ] }, t)) }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx(Input, { type: "time", value: newTime, onChange: (e) => setNewTime(e.target.value), className: "max-w-[140px]" }),
            /* @__PURE__ */ jsxs(Button, { type: "button", onClick: addTime, children: [
              /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
              "Adicionar"
            ] })
          ] })
        ] }),
        scheduleType === "weekly" && weekdays.length > 0 && /* @__PURE__ */ jsxs(Card, { className: "p-4 sm:p-5 space-y-3", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-semibold", children: "Horários específicos por dia (opcional)" }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
            "Defina horários diferentes para um dia da semana. Quando houver horários aqui, o horário padrão acima ",
            /* @__PURE__ */ jsx("strong", { children: "não" }),
            " será enviado nesse dia."
          ] }),
          /* @__PURE__ */ jsx("div", { className: "space-y-2", children: WEEKDAYS.filter((d) => weekdays.includes(d.value)).map((d) => {
            const key = String(d.value);
            const list = weekdayOverrides[key] ?? [];
            const input = overrideInputs[key] ?? "";
            const addOverride = () => {
              if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(input)) return;
              if (list.includes(input)) return;
              setWeekdayOverrides({
                ...weekdayOverrides,
                [key]: [...list, input].sort()
              });
              setOverrideInputs({
                ...overrideInputs,
                [key]: ""
              });
            };
            return /* @__PURE__ */ jsxs("div", { className: "rounded-md border p-3 space-y-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx("span", { className: "text-sm font-medium", children: d.label }),
                list.length === 0 ? /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: "usa padrão" }) : /* @__PURE__ */ jsx("button", { type: "button", onClick: () => {
                  const next = {
                    ...weekdayOverrides
                  };
                  delete next[key];
                  setWeekdayOverrides(next);
                }, className: "text-xs text-destructive hover:underline", children: "limpar" })
              ] }),
              list.length > 0 && /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-1.5", children: list.map((t) => /* @__PURE__ */ jsxs(Badge, { variant: "secondary", className: "gap-1 pr-1", children: [
                /* @__PURE__ */ jsx(Clock, { className: "size-3" }),
                t,
                /* @__PURE__ */ jsx("button", { type: "button", onClick: () => {
                  const next = list.filter((x) => x !== t);
                  const copy = {
                    ...weekdayOverrides
                  };
                  if (next.length === 0) delete copy[key];
                  else copy[key] = next;
                  setWeekdayOverrides(copy);
                }, className: "ml-1 hover:bg-background/40 rounded p-0.5", children: /* @__PURE__ */ jsx(X, { className: "size-3" }) })
              ] }, t)) }),
              /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsx(Input, { type: "time", value: input, onChange: (e) => setOverrideInputs({
                  ...overrideInputs,
                  [key]: e.target.value
                }), className: "max-w-[140px]" }),
                /* @__PURE__ */ jsxs(Button, { type: "button", size: "sm", variant: "secondary", onClick: addOverride, children: [
                  /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
                  "Adicionar"
                ] })
              ] })
            ] }, key);
          }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(DialogFooter, { className: "gap-2 flex-col-reverse sm:flex-row", children: [
      /* @__PURE__ */ jsx(Button, { className: "w-full sm:w-auto", disabled: !canSave, onClick: async () => {
        const ids = [videoId, ...followUps.map((f) => f.videoId)].filter(Boolean);
        await Promise.all(ids.map((id) => ensureVideoThumbnail(id)));
        onSave({
          id: editing?.id || void 0,
          roomId,
          accountId: accountId || null,
          title: title.trim(),
          content: content || null,
          videoId: videoId || null,
          audioId: audioId || null,
          imagePath: videoId || audioId ? null : imagePath || null,
          imageMime: videoId || audioId ? null : imageMime || null,
          parseMode: "HTML",
          times,
          weekdays,
          scheduleType,
          monthDays,
          weekdayOverrides,
          followUps: followUps.map((f) => ({
            delayMinutes: f.delayUnit === "seconds" ? Math.max(1, Math.ceil(f.delayValue / 60)) : f.delayValue,
            delaySeconds: f.delayUnit === "seconds" ? f.delayValue : null,
            content: f.content || null,
            imagePath: f.imagePath || null,
            imageMime: f.imageMime || null,
            videoId: f.videoId || null,
            audioId: f.audioId || null,
            buttonText: f.buttonText?.trim() || null,
            buttonUrl: f.buttonUrl?.trim() || null
          })),
          isPremium,
          isActive,
          timezone: "America/Sao_Paulo",
          buttonText: buttonText.trim() || null,
          buttonUrl: buttonUrl.trim() || null,
          folderId: folderId || null
        });
      }, children: editing?.id ? "Salvar alterações" : "Criar mensagem" }),
      /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: onClose, className: "w-full sm:w-auto", children: "Cancelar" })
    ] })
  ] }) });
}
function BulkReplaceDialog({
  open,
  onClose,
  onSubmit
}) {
  const [oldLink, setOldLink] = useState("");
  const [newLink, setNewLink] = useState("");
  const [busy, setBusy] = useState(false);
  return /* @__PURE__ */ jsx(Dialog, { open, onOpenChange: (v) => !v && onClose(), children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-md w-[calc(100vw-1rem)] sm:w-auto p-4 sm:p-6", children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Substituir Links em Massa" }) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Encontre e substitua um link (ou texto) em todos os seus agendamentos recorrentes e mensagens pendentes únicas." }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { children: "Link ou texto antigo" }),
          /* @__PURE__ */ jsx(Input, { placeholder: "Ex: https://t.me/suporte_velho", value: oldLink, onChange: (e) => setOldLink(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsx(Label, { children: "Novo link ou texto" }),
          /* @__PURE__ */ jsx(Input, { placeholder: "Ex: https://t.me/suporte_novo", value: newLink, onChange: (e) => setNewLink(e.target.value) })
        ] })
      ] }),
      /* @__PURE__ */ jsx(DialogFooter, { className: "mt-4", children: /* @__PURE__ */ jsx(Button, { disabled: !oldLink.trim() || !newLink.trim() || busy, onClick: async () => {
        setBusy(true);
        try {
          await onSubmit(oldLink.trim(), newLink.trim());
          setOldLink("");
          setNewLink("");
          onClose();
        } catch (e) {
          toast.error(e.message);
        } finally {
          setBusy(false);
        }
      }, children: busy ? "Substituindo..." : "Substituir em todos" }) })
    ] })
  ] }) });
}
export {
  MensagensPage as component
};
