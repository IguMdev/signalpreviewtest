import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
function resolveNormalVideoDimensions(width, height) {
  const w = Number(width);
  const h = Number(height);
  if (Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0) {
    return {
      width: Math.round(w),
      height: Math.round(h)
    };
  }
  return {
    width: 720,
    height: 1280
  };
}
function thumbnailPathForVideoPath(storagePath) {
  const parts = storagePath.split("/");
  const file = parts.pop() || "video.mp4";
  const base = file.replace(/\.[^.]+$/, "") || "video";
  return [...parts, "thumbs", `${base}.jpg`].filter(Boolean).join("/");
}
async function sendVideoNoteToChat(opts) {
  if (!opts.botToken) {
    return {
      ok: false,
      description: "Conta sem bot_token"
    };
  }
  const form = new FormData();
  form.append("chat_id", String(opts.chatId));
  if (opts.duration) form.append("duration", String(opts.duration));
  form.append("video_note", new Blob([opts.fileBytes], {
    type: opts.mimeType || "video/mp4"
  }), opts.filename);
  const res = await fetch(`https://api.telegram.org/bot${opts.botToken}/sendVideoNote`, {
    method: "POST",
    body: form
  });
  return await res.json();
}
async function sendVideoToChat(opts) {
  if (!opts.botToken) {
    return {
      ok: false,
      description: "Conta sem bot_token"
    };
  }
  const form = new FormData();
  const dimensions = resolveNormalVideoDimensions(opts.width, opts.height);
  form.append("chat_id", String(opts.chatId));
  if (opts.caption && opts.caption.trim()) {
    form.append("caption", opts.caption);
    if (opts.parseMode) form.append("parse_mode", opts.parseMode);
  }
  if (opts.duration) form.append("duration", String(Math.round(opts.duration)));
  form.append("width", String(dimensions.width));
  form.append("height", String(dimensions.height));
  if (opts.thumbnailBytes && opts.thumbnailBytes.byteLength <= 200 * 1024) {
    form.append("thumbnail", new Blob([opts.thumbnailBytes], {
      type: "image/jpeg"
    }), "thumbnail.jpg");
  }
  if (opts.replyMarkup) form.append("reply_markup", JSON.stringify(opts.replyMarkup));
  form.append("video", new Blob([opts.fileBytes], {
    type: opts.mimeType || "video/mp4"
  }), opts.filename);
  const res = await fetch(`https://api.telegram.org/bot${opts.botToken}/sendVideo`, {
    method: "POST",
    body: form
  });
  return await res.json();
}
async function loadVideoThumbnail(storagePath) {
  const {
    data: thumb
  } = await supabaseAdmin.storage.from("videos").download(thumbnailPathForVideoPath(storagePath));
  if (!thumb) return null;
  const bytes = await thumb.arrayBuffer();
  return bytes.byteLength <= 200 * 1024 ? bytes : null;
}
const sendVideoNoteNow = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  videoId: z.string().uuid(),
  accountId: z.string().uuid(),
  chatIds: z.array(z.union([z.number(), z.string()])).min(1)
}).parse(d)).handler(createSsrRpc("bdd37fe8aa26d3bad1eb29e3a757bbf04c7a3d08ba659057e6302f09cc264909"));
const deleteVideo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(createSsrRpc("3fcd159205240d6926126acac1e16e0b826c923dfac07b14dd13822331355611"));
async function dispatchVideoNote(opts) {
  const {
    data: file,
    error
  } = await supabaseAdmin.storage.from("videos").download(opts.storagePath);
  if (error || !file) {
    return {
      ok: false,
      description: "Falha ao baixar vídeo"
    };
  }
  const bytes = await file.arrayBuffer();
  return sendVideoNoteToChat({
    botToken: opts.botToken,
    chatId: opts.chatId,
    fileBytes: bytes,
    filename: opts.filename ?? "video.mp4",
    mimeType: opts.mimeType ?? "video/mp4",
    duration: opts.duration
  });
}
async function dispatchVideo(opts) {
  const {
    data: file,
    error
  } = await supabaseAdmin.storage.from("videos").download(opts.storagePath);
  if (error || !file) {
    return {
      ok: false,
      description: "Falha ao baixar vídeo"
    };
  }
  const bytes = await file.arrayBuffer();
  const thumbnailBytes = await loadVideoThumbnail(opts.storagePath);
  return sendVideoToChat({
    botToken: opts.botToken,
    chatId: opts.chatId,
    fileBytes: bytes,
    filename: opts.filename ?? "video.mp4",
    mimeType: opts.mimeType ?? "video/mp4",
    duration: opts.duration,
    width: opts.width,
    height: opts.height,
    thumbnailBytes,
    caption: opts.caption,
    parseMode: opts.parseMode,
    replyMarkup: opts.replyMarkup
  });
}
export {
  dispatchVideoNote as a,
  deleteVideo as b,
  dispatchVideo as d,
  loadVideoThumbnail as l,
  sendVideoNoteNow as s
};
