import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState, useRef, useCallback, useEffect, useMemo } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { u as useAuth, D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, h as DialogHeader, i as DialogTitle, L as Label, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, I as Input, j as DialogFooter, T as Textarea, v as verifyAccount, l as getPremiumAccountAvatar, s as syncPremiumEmojis, r as refreshChats, m as sendTestMessage, n as requestPremiumCode, o as confirmPremiumCode } from "./router-Cw6OHOsO.js";
import { e as enableMemberTracking } from "./telegram-tracking.functions-CF7nyJdP.js";
import { P as PremiumEmojiPicker } from "./PremiumEmojiPicker-KRfbHKuL.js";
import { T as TooltipProvider, a as Tooltip, b as TooltipTrigger, c as TooltipContent } from "./tooltip-DPQMaJsn.js";
import { toast } from "sonner";
import { GraduationCap, ChevronDown, Bot, Sparkles, Plus, KeyRound, Send, UserCircle, Check, RefreshCw, Users, MessageSquare, Activity, Trash2 } from "lucide-react";
import { C as Collapsible, a as CollapsibleTrigger, b as CollapsibleContent } from "./collapsible-DUtqt5i7.js";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-tooltip";
import "@radix-ui/react-collapsible";
const premiumStrings = {
  steps: {
    title: "Como conectar sua conta Telegram",
    subtitle: "Passo a passo:",
    items: [
      "Acesse <a>my.telegram.org</a> e faça login",
      'Vá em "API Development Tools" e crie uma aplicação',
      "Copie o <b>API ID</b> e o <b>API Hash</b>",
      "Preencha todos os campos abaixo",
      'Clique em "Solicitar código" — ele chega no <b>app do Telegram</b> (não por SMS)',
      'Digite o código recebido no app e clique em "Conectar"'
    ],
    tip: "Você precisa das credenciais de API para conectar sua conta pessoal."
  },
  fields: {
    accountName: "Nome da Conta",
    accountNamePlaceholder: "Ex: Minha Conta Premium",
    accountNameHint: "Nome para identificar esta conta no sistema",
    phone: "Número do Telefone",
    phonePlaceholder: "+5511999999999",
    phoneHint: "Número completo com código do país (ex: +55)",
    apiId: "API ID",
    apiIdHint: "API ID obtido em my.telegram.org",
    apiHash: "API Hash",
    apiHashHint: "API Hash obtido em my.telegram.org",
    code: "Código",
    twoFa: "Senha 2FA (verificação em duas etapas)"
  },
  codeStep: {
    heading: "Digite o código recebido no app do Telegram",
    subheading: 'Abra o app do Telegram e veja a conversa oficial "Telegram". O código não é enviado por SMS e expira em ~5 minutos.'
  },
  buttons: {
    cancel: "Cancelar",
    requestCode: "Solicitar código",
    sendingCode: "Enviando...",
    connect: "Conectar",
    connecting: "Conectando...",
    resend: "Reenviar código",
    resendIn: (s) => `Reenviar em ${s}s`
  },
  toasts: {
    fillAll: "Preencha todos os campos",
    invalidApiId: "API ID inválido",
    codeSent: "Código enviado pelo Telegram",
    codeResent: "Novo código enviado pelo Telegram",
    needs2fa: "Esta conta tem 2FA — informe a senha de nuvem",
    connected: "Conta conectada!",
    emojisSynced: (n) => `${n} emojis premium sincronizados`,
    genericFail: "Falha na operação. Tente novamente."
  },
  errors: {
    timeout: "O Telegram demorou demais para responder. Verifique sua conexão e tente novamente.",
    invalidCode: "Código inválido. Confira o número que chegou no app do Telegram e tente de novo.",
    expiredCode: "Esse código expirou. Clique em “Reenviar código” para receber um novo no app do Telegram.".replace(
      /\u201c|\u201d/g,
      '"'
    ),
    floodWait: (s) => `Muitas tentativas. Aguarde ${s}s antes de pedir um novo código.`,
    invalid2fa: "Senha 2FA incorreta. Verifique sua senha de nuvem do Telegram.",
    phoneInvalid: "Número de telefone inválido. Use o formato internacional (+55...).",
    apiInvalid: "API ID ou API Hash inválidos. Gere novamente em my.telegram.org.",
    notConfigured: "Serviço de userbot não configurado. Configure os secrets USERBOT_API_URL e USERBOT_TOKEN."
  }
};
function translatePremiumError(raw) {
  const msg = raw instanceof Error ? raw.message : String(raw ?? "");
  const m = msg.toUpperCase();
  if (/PHONE_CODE_INVALID/.test(m)) return premiumStrings.errors.invalidCode;
  if (/PHONE_CODE_EXPIRED/.test(m)) return premiumStrings.errors.expiredCode;
  if (/PHONE_NUMBER_INVALID/.test(m)) return premiumStrings.errors.phoneInvalid;
  if (/API_ID_INVALID|API_HASH_INVALID/.test(m)) return premiumStrings.errors.apiInvalid;
  if (/PASSWORD_HASH_INVALID|PASSWORD_INVALID/.test(m)) return premiumStrings.errors.invalid2fa;
  const flood = m.match(/FLOOD_WAIT_(\d+)/);
  if (flood) return premiumStrings.errors.floodWait(Number(flood[1]));
  if (/TIMEOUT|ETIMEDOUT|FETCH FAILED|NETWORK/.test(m)) return premiumStrings.errors.timeout;
  if (/USERBOT_API_URL|USERBOT_TOKEN/.test(msg)) return premiumStrings.errors.notConfigured;
  return msg || premiumStrings.toasts.genericFail;
}
function useResendCooldown(seconds = 60) {
  const [remaining, setRemaining] = useState(0);
  const intervalRef = useRef(null);
  const clear = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);
  const start = useCallback(() => {
    clear();
    setRemaining(seconds);
    intervalRef.current = setInterval(() => {
      setRemaining((s) => {
        if (s <= 1) {
          clear();
          return 0;
        }
        return s - 1;
      });
    }, 1e3);
  }, [clear, seconds]);
  useEffect(() => clear, [clear]);
  return { remaining, start, canResend: remaining === 0 };
}
const PREMIUM_REASON_LABELS = {
  "no-tokens": "A mensagem não contém tokens {NOME} para envio premium.",
  "no-known-emojis": "Nenhum emoji premium salvo corresponde aos tokens.",
  "no-premium-account": "Nenhuma conta Premium ativa conectada.",
  "no-active-premium-account": "Conecte a conta Premium novamente.",
  "account-not-premium": "A conta Telegram conectada não tem assinatura Premium ativa.",
  "client-send-threw": "O cliente MTProto rejeitou o envio.",
  "premium-send-failed": "Envio premium falhou."
};
function reasonLabel(reason) {
  if (!reason) return null;
  return PREMIUM_REASON_LABELS[reason] ?? reason;
}
const HAS_TOKEN_RE = /\{[^{}\n]{1,80}\}/;
function TelegramAccountsPage() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const verify = useServerFn(verifyAccount);
  const sendTest = useServerFn(sendTestMessage);
  const refresh = useServerFn(refreshChats);
  const enableTrack = useServerFn(enableMemberTracking);
  const reqCode = useServerFn(requestPremiumCode);
  const confirmCode = useServerFn(confirmPremiumCode);
  const syncEmojis = useServerFn(syncPremiumEmojis);
  const accounts = useQuery({
    queryKey: ["telegram-accounts"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("telegram_accounts").select("*").order("created_at", {
        ascending: false
      });
      if (error) throw error;
      return data;
    }
  });
  const [openNew, setOpenNew] = useState(false);
  const [label, setLabel] = useState("");
  const [token, setToken] = useState("");
  const [accountType, setAccountType] = useState("bot");
  const [phone, setPhone] = useState("");
  const [apiId, setApiId] = useState("");
  const [apiHash, setApiHash] = useState("");
  const [premiumStep, setPremiumStep] = useState("form");
  const [pendingAccountId, setPendingAccountId] = useState(null);
  const [telegramCode, setTelegramCode] = useState("");
  const [twoFa, setTwoFa] = useState("");
  const [needs2fa, setNeeds2fa] = useState(false);
  const [loadingPremium, setLoadingPremium] = useState(false);
  const resend = useResendCooldown(60);
  const createMut = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("telegram_accounts").insert({
        user_id: user.id,
        label,
        bot_token: token || "premium-no-token",
        account_type: accountType,
        phone: accountType === "premium" ? phone : null
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Conta adicionada");
      setOpenNew(false);
      setLabel("");
      setToken("");
      setPhone("");
      setAccountType("bot");
      qc.invalidateQueries({
        queryKey: ["telegram-accounts"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  function resetDialog() {
    setLabel("");
    setToken("");
    setPhone("");
    setApiId("");
    setApiHash("");
    setTelegramCode("");
    setTwoFa("");
    setNeeds2fa(false);
    setPremiumStep("form");
    setPendingAccountId(null);
    setAccountType("bot");
  }
  async function handleRequestCode() {
    if (!label || !phone || !apiId || !apiHash) {
      toast.error(premiumStrings.toasts.fillAll);
      return;
    }
    const idNum = Number(apiId);
    if (!Number.isInteger(idNum) || idNum <= 0) {
      toast.error(premiumStrings.toasts.invalidApiId);
      return;
    }
    setLoadingPremium(true);
    try {
      const {
        data: row,
        error
      } = await supabase.from("telegram_accounts").insert({
        user_id: user.id,
        label,
        bot_token: null,
        account_type: "premium",
        phone,
        tg_api_id: idNum,
        tg_api_hash: apiHash
      }).select("id").single();
      if (error) throw error;
      await reqCode({
        data: {
          accountId: row.id,
          apiId: idNum,
          apiHash,
          phone
        }
      });
      setPendingAccountId(row.id);
      setPremiumStep("code");
      toast.success(premiumStrings.toasts.codeSent);
      resend.start();
      qc.invalidateQueries({
        queryKey: ["telegram-accounts"]
      });
    } catch (e) {
      toast.error(translatePremiumError(e));
    } finally {
      setLoadingPremium(false);
    }
  }
  async function handleResendCode() {
    if (!pendingAccountId || !resend.canResend) return;
    const idNum = Number(apiId);
    setLoadingPremium(true);
    try {
      await reqCode({
        data: {
          accountId: pendingAccountId,
          apiId: idNum,
          apiHash,
          phone
        }
      });
      toast.success(premiumStrings.toasts.codeResent);
      resend.start();
    } catch (e) {
      toast.error(translatePremiumError(e));
    } finally {
      setLoadingPremium(false);
    }
  }
  async function handleConfirmCode() {
    if (!pendingAccountId || !telegramCode) return;
    setLoadingPremium(true);
    try {
      const r = await confirmCode({
        data: {
          accountId: pendingAccountId,
          code: telegramCode,
          password: twoFa || void 0
        }
      });
      if (r.needsPassword) {
        setNeeds2fa(true);
        toast.message(premiumStrings.toasts.needs2fa);
        return;
      }
      toast.success(premiumStrings.toasts.connected);
      syncEmojis({
        data: {
          accountId: pendingAccountId
        }
      }).then((s) => toast.success(premiumStrings.toasts.emojisSynced(s.count))).catch(() => {
      });
      setOpenNew(false);
      resetDialog();
      qc.invalidateQueries({
        queryKey: ["telegram-accounts"]
      });
    } catch (e) {
      toast.error(translatePremiumError(e));
    } finally {
      setLoadingPremium(false);
    }
  }
  const deleteMut = useMutation({
    mutationFn: async (id) => {
      const {
        error
      } = await supabase.from("telegram_accounts").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Conta removida");
      qc.invalidateQueries({
        queryKey: ["telegram-accounts"]
      });
    }
  });
  const [testFor, setTestFor] = useState(null);
  const [testChat, setTestChat] = useState("");
  const [testText, setTestText] = useState("Mensagem de teste do TeleSignal - Automação Telegram 🚀");
  const autoCheckMin = 5;
  const premiumAccountIds = useMemo(() => (accounts.data ?? []).filter((a) => a.account_type === "premium").map((a) => a.id), [accounts.data]);
  useEffect(() => {
    if (!premiumAccountIds.length || autoCheckMin <= 0) return;
    let cancelled = false;
    const run = async () => {
      for (const id of premiumAccountIds) {
        if (cancelled) return;
        try {
          await verify({
            data: {
              accountId: id
            }
          });
        } catch {
        }
      }
      if (!cancelled) qc.invalidateQueries({
        queryKey: ["telegram-accounts"]
      });
    };
    const handle = window.setInterval(run, autoCheckMin * 6e4);
    return () => {
      cancelled = true;
      window.clearInterval(handle);
    };
  }, [premiumAccountIds, autoCheckMin, verify, qc]);
  const testAccount = useMemo(() => testFor ? accounts.data?.find((a) => a.id === testFor) : void 0, [testFor, accounts.data]);
  const testHasTokens = HAS_TOKEN_RE.test(testText);
  const testIsPremium = testAccount?.account_type === "premium";
  const testPremiumBlocked = Boolean(testIsPremium) && testHasTokens && (testAccount?.status !== "ok" || Boolean(testAccount?.last_error));
  const testBlockMessage = testPremiumBlocked ? testAccount?.last_error ?? "Status Premium não está OK. Clique em Verificar antes de enviar." : null;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsx(Collapsible, { defaultOpen: true, children: /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-primary/30 bg-primary/5", children: [
      /* @__PURE__ */ jsxs(CollapsibleTrigger, { className: "w-full flex items-center justify-between gap-3 px-4 py-3 text-left", children: [
        /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2 text-sm font-semibold", children: [
          /* @__PURE__ */ jsx(GraduationCap, { className: "size-4 text-primary" }),
          "Como cadastrar sua conta Telegram"
        ] }),
        /* @__PURE__ */ jsx(ChevronDown, { className: "size-4 text-muted-foreground transition-transform data-[state=open]:rotate-180" })
      ] }),
      /* @__PURE__ */ jsx(CollapsibleContent, { className: "px-4 pb-4", children: /* @__PURE__ */ jsxs("div", { className: "space-y-3 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsxs("p", { children: [
          "Siga os passos abaixo para conectar um ",
          /* @__PURE__ */ jsx("strong", { className: "text-foreground", children: "Bot" }),
          " ou uma ",
          /* @__PURE__ */ jsx("strong", { className: "text-foreground", children: "Conta Premium" }),
          ":"
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid gap-3 md:grid-cols-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-border/60 bg-background/40 p-3 space-y-2", children: [
            /* @__PURE__ */ jsxs("p", { className: "font-semibold text-foreground flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Bot, { className: "size-4 text-primary" }),
              " Conta Bot"
            ] }),
            /* @__PURE__ */ jsxs("ol", { className: "list-decimal list-inside space-y-1 text-xs", children: [
              /* @__PURE__ */ jsxs("li", { children: [
                "No Telegram, abra ",
                /* @__PURE__ */ jsx("code", { className: "text-primary", children: "@BotFather" }),
                " e use ",
                /* @__PURE__ */ jsx("code", { children: "/newbot" }),
                "."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Defina o nome e o username do bot e copie o ",
                /* @__PURE__ */ jsx("strong", { children: "token" }),
                " gerado."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Clique em ",
                /* @__PURE__ */ jsx("strong", { children: "Adicionar Conta" }),
                ", escolha ",
                /* @__PURE__ */ jsx("strong", { children: "Bot" }),
                " e cole o token."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Adicione o bot como ",
                /* @__PURE__ */ jsx("strong", { children: "administrador" }),
                " nos seus grupos/canais."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Clique em ",
                /* @__PURE__ */ jsx("strong", { children: "Atualizar chats" }),
                " para listar os grupos disponíveis."
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-border/60 bg-background/40 p-3 space-y-2", children: [
            /* @__PURE__ */ jsxs("p", { className: "font-semibold text-foreground flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(Sparkles, { className: "size-4 text-primary" }),
              " Conta Premium"
            ] }),
            /* @__PURE__ */ jsxs("ol", { className: "list-decimal list-inside space-y-1 text-xs", children: [
              /* @__PURE__ */ jsxs("li", { children: [
                "Em ",
                /* @__PURE__ */ jsx("a", { className: "text-primary underline", href: "https://my.telegram.org", target: "_blank", rel: "noreferrer", children: "my.telegram.org" }),
                ", gere ",
                /* @__PURE__ */ jsx("strong", { children: "API ID" }),
                " e ",
                /* @__PURE__ */ jsx("strong", { children: "API Hash" }),
                "."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Clique em ",
                /* @__PURE__ */ jsx("strong", { children: "Adicionar Conta" }),
                " e selecione ",
                /* @__PURE__ */ jsx("strong", { children: "Premium" }),
                "."
              ] }),
              /* @__PURE__ */ jsx("li", { children: "Informe telefone, API ID e API Hash e solicite o código." }),
              /* @__PURE__ */ jsx("li", { children: "Digite o código recebido no app oficial do Telegram." }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Use ",
                /* @__PURE__ */ jsx("strong", { children: "Sincronizar emojis" }),
                " para importar seus emojis premium."
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "text-xs", children: [
          "Dica: ative o ",
          /* @__PURE__ */ jsx("strong", { className: "text-foreground", children: "rastreamento de membros" }),
          " nas contas Bot para contabilizar entradas e saídas automaticamente."
        ] })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Contas Telegram" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Gerencie seus bots e contas pessoais premium do Telegram." })
      ] }),
      /* @__PURE__ */ jsxs(Dialog, { open: openNew, onOpenChange: setOpenNew, children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { className: "gap-2", "data-tour": "add-account", children: [
          /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
          "Adicionar Conta"
        ] }) }),
        /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-3xl max-h-[90vh] overflow-y-auto", children: [
          /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: accountType === "premium" ? "Adicionar Conta Premium" : "Adicionar conta Telegram" }) }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Tipo da conta" }),
              /* @__PURE__ */ jsxs(Select, { value: accountType, onValueChange: (v) => {
                setAccountType(v);
                setPremiumStep("form");
                setPendingAccountId(null);
              }, children: [
                /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "bot", children: "🤖 Bot (Básico)" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "premium", children: "✨ Conta Premium" })
                ] })
              ] })
            ] }),
            accountType === "bot" && /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Rótulo / Nome do bot" }),
                /* @__PURE__ */ jsx(Input, { value: label, onChange: (e) => setLabel(e.target.value), placeholder: "Ex: Bot principal" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Bot Token" }),
                /* @__PURE__ */ jsx(Input, { value: token, onChange: (e) => setToken(e.target.value), placeholder: "123456:ABC-...", type: "password" }),
                /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Crie um bot com o @BotFather no Telegram para obter o token." })
              ] })
            ] }),
            accountType === "premium" && premiumStep === "form" && /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-primary/30 bg-primary/10 p-4 text-sm space-y-2", children: [
                /* @__PURE__ */ jsx("p", { className: "font-semibold", children: premiumStrings.steps.title }),
                /* @__PURE__ */ jsxs("p", { className: "font-medium", children: [
                  "📱 ",
                  premiumStrings.steps.subtitle
                ] }),
                /* @__PURE__ */ jsxs("ol", { className: "list-decimal pl-5 space-y-1 text-muted-foreground", children: [
                  /* @__PURE__ */ jsxs("li", { children: [
                    "Acesse",
                    " ",
                    /* @__PURE__ */ jsx("a", { href: "https://my.telegram.org", target: "_blank", rel: "noreferrer", className: "underline", children: "my.telegram.org" }),
                    " ",
                    "e faça login"
                  ] }),
                  /* @__PURE__ */ jsx("li", { children: 'Vá em "API Development Tools" e crie uma aplicação' }),
                  /* @__PURE__ */ jsxs("li", { children: [
                    "Copie o ",
                    /* @__PURE__ */ jsx("b", { children: "API ID" }),
                    " e o ",
                    /* @__PURE__ */ jsx("b", { children: "API Hash" })
                  ] }),
                  /* @__PURE__ */ jsx("li", { children: "Preencha todos os campos abaixo" }),
                  /* @__PURE__ */ jsxs("li", { children: [
                    'Clique em "',
                    premiumStrings.buttons.requestCode,
                    '" — ele chega no ',
                    /* @__PURE__ */ jsx("b", { children: "app do Telegram" }),
                    " (não por SMS)"
                  ] }),
                  /* @__PURE__ */ jsxs("li", { children: [
                    'Digite o código recebido no app e clique em "',
                    premiumStrings.buttons.connect,
                    '"'
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "rounded-md bg-primary/20 px-3 py-2 text-xs", children: [
                  "💡 ",
                  /* @__PURE__ */ jsx("b", { children: "Dica:" }),
                  " ",
                  premiumStrings.steps.tip
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx(Label, { children: "Nome da Conta" }),
                  /* @__PURE__ */ jsx(Input, { value: label, onChange: (e) => setLabel(e.target.value), placeholder: "Ex: Minha Conta Premium" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Nome para identificar esta conta no sistema" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx(Label, { children: "Número do Telefone" }),
                  /* @__PURE__ */ jsx(Input, { value: phone, onChange: (e) => setPhone(e.target.value), placeholder: "+5511999999999" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Número completo com código do país (ex: +55)" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx(Label, { children: "API ID" }),
                  /* @__PURE__ */ jsx(Input, { value: apiId, onChange: (e) => setApiId(e.target.value), placeholder: "12345678", inputMode: "numeric" }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "API ID obtido em my.telegram.org" })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsx(Label, { children: "API Hash" }),
                  /* @__PURE__ */ jsx(Input, { value: apiHash, onChange: (e) => setApiHash(e.target.value), placeholder: "abcdef1234567890..." }),
                  /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "API Hash obtido em my.telegram.org" })
                ] })
              ] })
            ] }),
            accountType === "premium" && premiumStep === "code" && /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-primary/30 bg-primary/10 p-4 text-sm flex items-start gap-3", children: [
                /* @__PURE__ */ jsx(KeyRound, { className: "size-5 mt-0.5" }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("p", { className: "font-semibold", children: premiumStrings.codeStep.heading }),
                  /* @__PURE__ */ jsx("p", { className: "text-muted-foreground text-xs mt-1", children: premiumStrings.codeStep.subheading })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: premiumStrings.fields.code }),
                /* @__PURE__ */ jsx(Input, { value: telegramCode, onChange: (e) => setTelegramCode(e.target.value.replace(/\D/g, "")), placeholder: "12345", inputMode: "numeric", maxLength: 6, autoFocus: true, "aria-label": premiumStrings.fields.code })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: handleResendCode, disabled: !resend.canResend || loadingPremium, children: !resend.canResend ? premiumStrings.buttons.resendIn(resend.remaining) : premiumStrings.buttons.resend }) }),
              needs2fa && /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: premiumStrings.fields.twoFa }),
                /* @__PURE__ */ jsx(Input, { type: "password", value: twoFa, onChange: (e) => setTwoFa(e.target.value) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs(DialogFooter, { children: [
            /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => {
              setOpenNew(false);
              resetDialog();
            }, children: premiumStrings.buttons.cancel }),
            accountType === "bot" && /* @__PURE__ */ jsx(Button, { onClick: () => createMut.mutate(), disabled: !label || !token || createMut.isPending, children: createMut.isPending ? "Salvando..." : "Salvar" }),
            accountType === "premium" && premiumStep === "form" && /* @__PURE__ */ jsx(Button, { onClick: handleRequestCode, disabled: loadingPremium, children: loadingPremium ? premiumStrings.buttons.sendingCode : premiumStrings.buttons.requestCode }),
            accountType === "premium" && premiumStep === "code" && /* @__PURE__ */ jsx(Button, { onClick: handleConfirmCode, disabled: loadingPremium || !telegramCode, children: loadingPremium ? premiumStrings.buttons.connecting : premiumStrings.buttons.connect })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-primary/20 bg-primary/5 p-5", children: [
      /* @__PURE__ */ jsx("h3", { className: "font-semibold mb-3", children: "Tipos de Conta:" }),
      /* @__PURE__ */ jsxs("div", { className: "grid sm:grid-cols-2 gap-4 text-sm", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-medium mb-2", children: [
            /* @__PURE__ */ jsx(Bot, { className: "size-4" }),
            " Bot (Básico)"
          ] }),
          /* @__PURE__ */ jsxs("ul", { className: "space-y-1 text-muted-foreground pl-1", children: [
            /* @__PURE__ */ jsx("li", { children: "• Mensagens automáticas" }),
            /* @__PURE__ */ jsx("li", { children: "• Emojis padrão" }),
            /* @__PURE__ */ jsx("li", { children: "• API oficial do Telegram" }),
            /* @__PURE__ */ jsx("li", { children: "• Gratuito e simples" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 font-medium mb-2 text-amber-500", children: [
            /* @__PURE__ */ jsx(Sparkles, { className: "size-4" }),
            " Conta Premium"
          ] }),
          /* @__PURE__ */ jsxs("ul", { className: "space-y-1 text-muted-foreground pl-1", children: [
            /* @__PURE__ */ jsx("li", { children: "• Emojis premium exclusivos" }),
            /* @__PURE__ */ jsx("li", { children: "• Envio como usuário pessoal" }),
            /* @__PURE__ */ jsx("li", { children: "• Maior personalização" }),
            /* @__PURE__ */ jsx("li", { children: "• Recursos avançados" })
          ] })
        ] })
      ] })
    ] }),
    accounts.data?.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm", children: [
      /* @__PURE__ */ jsx(Send, { className: "size-8 mx-auto mb-2 opacity-50" }),
      "Nenhuma conta cadastrada ainda."
    ] }) : /* @__PURE__ */ jsx("div", { className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3", children: accounts.data?.map((a) => /* @__PURE__ */ jsx(AccountCard, { account: a, onVerify: async () => {
      const r = await verify({
        data: {
          accountId: a.id
        }
      });
      if (r.ok) toast.success("Conta verificada");
      else toast.error(r.error ?? "Falha");
      qc.invalidateQueries({
        queryKey: ["telegram-accounts"]
      });
    }, onRefresh: async () => {
      const r = await refresh({
        data: {
          accountId: a.id
        }
      });
      if (r.ok) toast.success(`${r.count} chats sincronizados`);
      else toast.error(r.error ?? "Falha");
    }, onTest: () => setTestFor(a.id), onDelete: () => {
      if (confirm("Remover esta conta?")) deleteMut.mutate(a.id);
    }, onEnableTracking: async () => {
      const tId = toast.loading("Reativando webhook…");
      try {
        const stream = await enableTrack({
          data: {
            accountId: a.id
          }
        });
        let last = {
          processed: 0,
          errors: 0,
          total: 0,
          phase: "preparing"
        };
        for await (const ev of stream) {
          last = ev;
          const label2 = ev.phase === "preparing" ? "Verificando webhook…" : ev.phase === "draining" ? `Reprocessando pendentes: ${ev.processed}/${ev.total}${ev.errors ? ` (${ev.errors} erros)` : ""}` : ev.phase === "registering" ? "Registrando webhook…" : ev.phase === "done" ? `Webhook ativo • ${ev.processed} reprocessados${ev.errors ? `, ${ev.errors} erros` : ""}` : `Aviso: ${ev.message ?? "drain falhou"}`;
          toast.loading(label2, {
            id: tId
          });
        }
        toast.success(`Rastreamento ativo. ${last.processed} updates reprocessados${last.errors ? `, ${last.errors} erros` : ""}. Adicione o bot como admin do grupo.`, {
          id: tId
        });
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Falha", {
          id: tId
        });
      }
    }, onSyncEmojis: async () => {
      try {
        const r = await syncEmojis({
          data: {
            accountId: a.id
          }
        });
        toast.success(`${r.count} emojis premium sincronizados`);
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Falha");
      }
    } }, a.id)) }),
    /* @__PURE__ */ jsx(Dialog, { open: !!testFor, onOpenChange: (o) => !o && setTestFor(null), children: /* @__PURE__ */ jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Enviar mensagem de teste" }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Chat ID" }),
          /* @__PURE__ */ jsx(Input, { value: testChat, onChange: (e) => setTestChat(e.target.value), placeholder: "-1001234567890" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Mensagem" }),
          /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: testText, onChange: setTestText }) }),
          /* @__PURE__ */ jsx(Textarea, { value: testText, onChange: (e) => setTestText(e.target.value), rows: 4 })
        ] }),
        testPremiumBlocked && /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive", children: [
          /* @__PURE__ */ jsx("p", { className: "font-semibold", children: "Envio premium bloqueado" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs mt-0.5", children: testBlockMessage }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs mt-1 opacity-80", children: [
            "Status atual: ",
            testAccount?.status ?? "—",
            ". Verifique a conta antes de enviar emojis premium."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setTestFor(null), children: "Cancelar" }),
        /* @__PURE__ */ jsx(Button, { onClick: async () => {
          if (!testFor) return;
          const r = await sendTest({
            data: {
              accountId: testFor,
              chatId: testChat,
              text: testText
            }
          });
          if (r.ok) {
            toast.success("Mensagem enviada");
            setTestFor(null);
          } else {
            const reason = r.reason;
            toast.error(r.error ?? "Falha", {
              description: reason ? `Motivo: ${reason} — ${reasonLabel(reason)}` : void 0
            });
          }
        }, disabled: !testChat || !testText || testPremiumBlocked, children: "Enviar" })
      ] })
    ] }) })
  ] });
}
function AccountCard({
  account: a,
  onVerify,
  onRefresh,
  onTest,
  onDelete,
  onEnableTracking,
  onSyncEmojis
}) {
  const isPremium = a.account_type === "premium";
  const today = useQuery({
    queryKey: ["account-today", a.id],
    queryFn: async () => {
      const start = /* @__PURE__ */ new Date();
      start.setHours(0, 0, 0, 0);
      const {
        count
      } = await supabase.from("message_logs").select("id", {
        count: "exact",
        head: true
      }).eq("account_id", a.id).eq("ok", true).gte("created_at", start.toISOString());
      return count ?? 0;
    },
    refetchInterval: 3e4
  });
  const used = today.data ?? 0;
  const limit = a.daily_limit || 1e3;
  const pct = Math.min(100, used / limit * 100);
  const avatarQ = useQuery({
    queryKey: ["premium-avatar", a.id],
    queryFn: () => getPremiumAccountAvatar({
      data: {
        accountId: a.id
      }
    }),
    enabled: isPremium && a.status === "ok",
    staleTime: 1e3 * 60 * 60,
    refetchOnWindowFocus: false
  });
  const avatarUrl = avatarQ.data?.dataUrl ?? null;
  const botRoomPhotoQ = useQuery({
    queryKey: ["bot-room-photo", a.id],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("rooms").select("photo_url").eq("default_account_id", a.id).not("photo_url", "is", null).order("created_at", {
        ascending: false
      }).limit(1).maybeSingle();
      return data?.photo_url ?? null;
    },
    enabled: !isPremium,
    staleTime: 1e3 * 60 * 5
  });
  const botRoomPhoto = botRoomPhotoQ.data ?? null;
  return /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-border bg-card p-5 space-y-4 hover:border-primary/40 transition", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        isPremium && avatarUrl ? /* @__PURE__ */ jsx("img", { src: avatarUrl, alt: a.label, className: "size-10 rounded-xl object-cover border border-amber-500/30" }) : !isPremium && botRoomPhoto ? /* @__PURE__ */ jsx("img", { src: botRoomPhoto, alt: a.label, className: "size-10 rounded-xl object-cover border border-primary/30" }) : /* @__PURE__ */ jsx("div", { className: `size-10 rounded-xl grid place-items-center ${isPremium ? "bg-amber-500/10 text-amber-500" : "bg-primary/10 text-primary"}`, children: isPremium ? /* @__PURE__ */ jsx(UserCircle, { className: "size-5" }) : /* @__PURE__ */ jsx(Bot, { className: "size-5" }) }),
        /* @__PURE__ */ jsx("span", { className: `text-xs font-medium px-2 py-0.5 rounded-full ${isPremium ? "bg-gradient-to-r from-amber-500/20 to-pink-500/20 text-amber-500" : "bg-muted text-foreground"}`, children: isPremium ? "✨ Premium" : "Bot" })
      ] }),
      /* @__PURE__ */ jsx(TooltipProvider, { delayDuration: 150, children: /* @__PURE__ */ jsxs(Tooltip, { children: [
        /* @__PURE__ */ jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxs("span", { className: `text-xs px-2 py-0.5 rounded-full inline-flex items-center gap-1 cursor-help ${a.status === "ok" ? "bg-emerald-500/10 text-emerald-500" : a.status === "error" ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"}`, children: [
          /* @__PURE__ */ jsx("span", { className: "size-1.5 rounded-full bg-current" }),
          a.status === "ok" ? isPremium ? "Premium ativo" : "Ativo" : a.status === "error" ? "Erro" : "Aguardando"
        ] }) }),
        /* @__PURE__ */ jsxs(TooltipContent, { side: "left", className: "max-w-xs space-y-1", children: [
          /* @__PURE__ */ jsx("p", { className: "font-semibold", children: isPremium ? "Status da conta Premium" : "Status da conta" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs", children: a.status === "ok" ? isPremium ? "Telegram Premium verificado — emojis animados serão entregues." : "Conta verificada e pronta para enviar." : a.status === "error" ? a.last_error ?? "Erro desconhecido na última verificação." : "Ainda não verificada. Clique em Verificar para testar a conexão." }),
          /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-muted-foreground", children: [
            "Última checagem: ",
            a.last_check_at ? new Date(a.last_check_at).toLocaleString("pt-BR") : "nunca"
          ] })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h3", { className: "font-bold text-lg leading-tight", children: a.label }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-0.5", children: isPremium ? a.phone || "—" : a.bot_username ? `@${a.bot_username}` : "—" })
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("p", { className: "text-[11px] font-semibold text-muted-foreground tracking-wider mb-1.5", children: "RECURSOS" }),
      /* @__PURE__ */ jsx("ul", { className: "space-y-1 text-sm", children: isPremium ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Check, { className: "size-3.5 text-emerald-500" }),
          " Mensagens como usuário pessoal"
        ] }),
        /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "size-3.5 text-amber-500" }),
          " Emojis Premium"
        ] }),
        /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Check, { className: "size-3.5 text-emerald-500" }),
          " Recursos Premium"
        ] })
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Check, { className: "size-3.5 text-emerald-500" }),
          " Mensagens básicas"
        ] }),
        /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Check, { className: "size-3.5 text-emerald-500" }),
          " Emojis padrão"
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-xs text-muted-foreground mb-1.5", children: [
        /* @__PURE__ */ jsx("span", { children: "Mensagens hoje:" }),
        /* @__PURE__ */ jsxs("span", { className: "font-medium text-foreground", children: [
          used,
          "/",
          limit
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "h-1.5 rounded-full bg-muted overflow-hidden", children: /* @__PURE__ */ jsx("div", { className: "h-full bg-gradient-to-r from-primary to-primary/70 transition-all", style: {
        width: `${pct}%`
      } }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: a.last_check_at ? `Verificado: ${new Date(a.last_check_at).toLocaleString("pt-BR")}` : "Nunca usado" }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-0.5", children: [
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", className: "size-8", onClick: onVerify, title: isPremium ? "Verificar status Premium" : "Verificar", children: /* @__PURE__ */ jsx(RefreshCw, { className: "size-3.5" }) }),
        !isPremium && /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", className: "size-8", onClick: onRefresh, title: "Sincronizar grupos", children: /* @__PURE__ */ jsx(Users, { className: "size-3.5" }) }),
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", className: "size-8", onClick: onTest, title: "Enviar teste", children: /* @__PURE__ */ jsx(MessageSquare, { className: "size-3.5" }) }),
        !isPremium && /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", className: "size-8", onClick: onEnableTracking, title: "Ativar rastreamento de membros", children: /* @__PURE__ */ jsx(Activity, { className: "size-3.5" }) }),
        isPremium && /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", className: "size-8", onClick: onSyncEmojis, title: "Sincronizar emojis premium", children: /* @__PURE__ */ jsx(Sparkles, { className: "size-3.5" }) }),
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", className: "size-8 text-destructive hover:text-destructive", onClick: onDelete, title: "Remover", children: /* @__PURE__ */ jsx(Trash2, { className: "size-3.5" }) })
      ] })
    ] })
  ] });
}
export {
  TelegramAccountsPage as component
};
