import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { l as loadVideoThumbnail, d as dispatchVideo, a as dispatchVideoNote } from "./videos.functions-DCpzn6E3.js";
import { h as hasEmojiTokens, g as getUserEmojiLookup, b as renderEmojiTokensToHtml, a as sendTextWithPremiumEmojis, s as sendPhotoWithPremiumEmojiCaption, e as sendVideoWithPremiumEmojiCaption } from "./premium-send.server-B6I-0YLO.js";
import { t as triggerSignalReactions } from "./engagement.functions-BnPQkoHV.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const TimeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
async function withCompanionButton(primary, botToken, chatId, replyMarkup) {
  if (!primary.ok || true) return primary;
}
const FollowUpInput = z.object({
  delayMinutes: z.number().int().min(1).max(1440),
  delaySeconds: z.number().int().min(1).max(86400).nullable().optional(),
  content: z.string().max(4e3).nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  audioId: z.string().uuid().nullable().optional(),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional()
});
const ScheduleInput = z.object({
  id: z.string().uuid().optional(),
  roomId: z.string().uuid(),
  accountId: z.string().uuid().nullable().optional(),
  title: z.string().min(1).max(120),
  content: z.string().max(4e3).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  audioId: z.string().uuid().nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  times: z.array(z.string().regex(TimeRe)).min(1).max(24),
  weekdays: z.array(z.number().int().min(1).max(7)).min(1).max(7),
  weekdayOverrides: z.record(z.string().regex(/^[1-7]$/), z.array(z.string().regex(TimeRe)).max(24)).default({}),
  scheduleType: z.enum(["weekly", "monthly"]).default("weekly"),
  monthDays: z.array(z.number().int().min(1).max(31)).default([]),
  followUps: z.array(FollowUpInput).max(10).default([]),
  isPremium: z.boolean().default(false),
  isActive: z.boolean().default(true),
  timezone: z.string().default("America/Sao_Paulo"),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional(),
  folderId: z.string().uuid().nullable().optional()
});
const upsertSchedule_createServerFn_handler = createServerRpc({
  id: "557a3bb959592512346d395daec1e205af9872cf293cc245cb8edf0c9dfa42b6",
  name: "upsertSchedule",
  filename: "src/lib/recurring-schedules.functions.ts"
}, (opts) => upsertSchedule.__executeServer(opts));
const upsertSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => ScheduleInput.parse(d)).handler(upsertSchedule_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const row = {
    user_id: userId,
    room_id: data.roomId,
    account_id: data.accountId ?? null,
    title: data.title.trim(),
    content: data.content ?? null,
    video_id: data.videoId ?? null,
    audio_id: data.audioId ?? null,
    image_path: data.imagePath ?? null,
    image_mime: data.imageMime ?? null,
    parse_mode: data.parseMode,
    times: Array.from(new Set(data.times)).sort(),
    weekdays: Array.from(new Set(data.weekdays)).sort(),
    weekday_overrides: Object.fromEntries(Object.entries(data.weekdayOverrides ?? {}).map(([k, v]) => [k, Array.from(new Set(v)).sort()]).filter(([, v]) => v.length > 0)),
    schedule_type: data.scheduleType,
    month_days: Array.from(new Set(data.monthDays)).sort((a, b) => a - b),
    follow_ups: (data.followUps ?? []).map((f) => ({
      delay_minutes: f.delayMinutes,
      delay_seconds: f.delaySeconds ?? null,
      content: f.content ?? null,
      image_path: f.imagePath ?? null,
      image_mime: f.imageMime ?? null,
      video_id: f.videoId ?? null,
      audio_id: f.audioId ?? null,
      button_text: f.buttonText ?? null,
      button_url: f.buttonUrl ?? null
    })),
    is_premium: data.isPremium,
    is_active: data.isActive,
    timezone: data.timezone,
    button_text: data.buttonText ?? null,
    button_url: data.buttonUrl ?? null,
    folder_id: data.folderId ?? null
  };
  if (data.id) {
    const {
      error: error2
    } = await supabase.from("recurring_schedules").update(row).eq("id", data.id);
    if (error2) throw new Error(error2.message);
    return {
      id: data.id
    };
  }
  const {
    data: ins,
    error
  } = await supabase.from("recurring_schedules").insert(row).select("id").single();
  if (error) throw new Error(error.message);
  return {
    id: ins.id
  };
});
const toggleSchedule_createServerFn_handler = createServerRpc({
  id: "ede179f930977d4129f87a568ea5835e8ed726860a04033e7d1e2c366ef1ada1",
  name: "toggleSchedule",
  filename: "src/lib/recurring-schedules.functions.ts"
}, (opts) => toggleSchedule.__executeServer(opts));
const toggleSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  isActive: z.boolean()
}).parse(d)).handler(toggleSchedule_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("recurring_schedules").update({
    is_active: data.isActive
  }).eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const deleteSchedule_createServerFn_handler = createServerRpc({
  id: "f010fecd0eae223fea7e6b9faba5094a2b823de23e6ba7de800826723cc7fd01",
  name: "deleteSchedule",
  filename: "src/lib/recurring-schedules.functions.ts"
}, (opts) => deleteSchedule.__executeServer(opts));
const deleteSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteSchedule_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("recurring_schedules").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const testSchedule_createServerFn_handler = createServerRpc({
  id: "cda58577c6df6b3babc9e9f22ba663807cc2836d974d3f733910922dc91aa8e0",
  name: "testSchedule",
  filename: "src/lib/recurring-schedules.functions.ts"
}, (opts) => testSchedule.__executeServer(opts));
const testSchedule = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(testSchedule_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  const {
    data: s,
    error
  } = await supabaseAdmin.from("recurring_schedules").select("id, user_id, room_id, account_id, content, video_id, audio_id, image_path, image_mime, parse_mode, is_premium, button_text, button_url, follow_ups").eq("id", data.id).maybeSingle();
  if (error) throw new Error(error.message);
  if (!s || s.user_id !== userId) throw new Error("Agendamento não encontrado");
  let accountId = s.account_id;
  if (!accountId) {
    const {
      data: room
    } = await supabaseAdmin.from("rooms").select("default_account_id, is_active").eq("id", s.room_id).maybeSingle();
    if (!room?.is_active) throw new Error("Sala inativa (is_active=false). Ignorando envio.");
    accountId = room?.default_account_id ?? null;
  } else {
    const {
      data: room
    } = await supabaseAdmin.from("rooms").select("is_active").eq("id", s.room_id).maybeSingle();
    if (!room?.is_active) throw new Error("Sala inativa (is_active=false). Ignorando envio.");
  }
  if (!accountId) throw new Error("Nenhuma conta de bot configurada");
  const {
    data: acc
  } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", accountId).maybeSingle();
  const {
    data: chats
  } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", s.room_id);
  if (!acc) throw new Error("Bot não encontrado");
  if (!chats?.length) throw new Error("Nenhum grupo vinculado a esta sala");
  const loadVideo = async (videoId) => {
    if (!videoId) return null;
    const {
      data: v
    } = await supabaseAdmin.from("videos").select("storage_path, mime_type, duration_seconds, title, kind, width, height").eq("id", videoId).maybeSingle();
    return v ?? null;
  };
  const loadAudio = async (audioId) => {
    if (!audioId) return null;
    const {
      data: a
    } = await supabaseAdmin.from("audios").select("storage_path, duration_seconds, title").eq("id", audioId).maybeSingle();
    return a ?? null;
  };
  const sendPayload = async (p) => {
    let sent2 = 0;
    let failed2 = 0;
    let lastError2 = null;
    const video = p.video;
    const audio = p.audio;
    const isNormalVideo = video && video.kind === "normal";
    for (const c of chats) {
      let r = {
        ok: false,
        description: "no-op"
      };
      const replyMarkup = void 0;
      const premium = p.is_premium && !p.image_path && !video && p.content ? await sendTextWithPremiumEmojis({
        userId: s.user_id,
        chatId: c.chat_id,
        text: p.content,
        strict: true
      }) : {
        applied: false
      };
      if (premium.applied) {
        r = await withCompanionButton(premium.ok ? {
          ok: true,
          result: {
            message_id: premium.messageId ?? void 0
          }
        } : {
          ok: false,
          description: premium.error
        }, acc.bot_token, c.chat_id);
      } else r = p.image_path ? await (async () => {
        const {
          data: pub
        } = supabaseAdmin.storage.from("room-images").getPublicUrl(p.image_path);
        if (p.is_premium) {
          const premiumPhoto = await sendPhotoWithPremiumEmojiCaption({
            userId: s.user_id,
            chatId: c.chat_id,
            photoUrl: pub.publicUrl,
            caption: p.content,
            strict: true
          });
          if (premiumPhoto.applied) {
            return await withCompanionButton(premiumPhoto.ok ? {
              ok: true,
              result: {
                message_id: premiumPhoto.messageId ?? void 0
              }
            } : {
              ok: false,
              description: premiumPhoto.error
            }, acc.bot_token, c.chat_id);
          }
        }
        return await callTelegram(acc.bot_token, "sendPhoto", {
          chat_id: c.chat_id,
          photo: pub.publicUrl,
          caption: p.content ?? void 0,
          parse_mode: p.content ? p.parse_mode : void 0,
          reply_markup: replyMarkup
        });
      })() : video ? isNormalVideo ? await (async () => {
        if (p.is_premium && p.content && hasEmojiTokens(p.content)) {
          const {
            data: file
          } = await supabaseAdmin.storage.from("videos").download(video.storage_path);
          if (file) {
            const bytes = await file.arrayBuffer();
            const pv = await sendVideoWithPremiumEmojiCaption({
              userId: s.user_id,
              chatId: c.chat_id,
              videoBytes: bytes,
              thumbnailBytes: await loadVideoThumbnail(video.storage_path),
              filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
              mimeType: video.mime_type ?? "video/mp4",
              duration: video.duration_seconds,
              width: video.width,
              height: video.height,
              caption: p.content,
              strict: true
            });
            if (pv.applied) {
              return await withCompanionButton(pv.ok ? {
                ok: true,
                result: {
                  message_id: pv.messageId ?? void 0
                }
              } : {
                ok: false,
                description: pv.error
              }, acc.bot_token, c.chat_id);
            }
          }
        }
        return await dispatchVideo({
          botToken: acc.bot_token,
          storagePath: video.storage_path,
          chatId: c.chat_id,
          duration: video.duration_seconds,
          width: video.width,
          height: video.height,
          mimeType: video.mime_type,
          filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
          caption: p.content,
          parseMode: p.parse_mode,
          replyMarkup
        });
      })() : await dispatchVideoNote({
        botToken: acc.bot_token,
        storagePath: video.storage_path,
        chatId: c.chat_id,
        duration: video.duration_seconds,
        mimeType: video.mime_type,
        filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
      }) : audio ? await (async () => {
        const {
          data: fileData,
          error: error2
        } = await supabaseAdmin.storage.from("audio-files").download(audio.storage_path);
        if (error2 || !fileData) return {
          ok: false,
          description: "Falha ao baixar áudio"
        };
        const bytes = await fileData.arrayBuffer();
        const {
          sendVoiceToChat
        } = await import("./audios.functions-DUKTM5eK.js");
        return await sendVoiceToChat({
          botToken: acc.bot_token,
          chatId: c.chat_id,
          fileBytes: bytes,
          filename: audio.title + ".ogg",
          mimeType: "audio/ogg",
          duration: audio.duration_seconds,
          caption: p.content
        });
      })() : await callTelegram(acc.bot_token, "sendMessage", {
        chat_id: c.chat_id,
        text: p.content ?? "",
        parse_mode: p.parse_mode,
        reply_markup: replyMarkup,
        link_preview_options: {
          is_disabled: true
        }
      });
      await supabaseAdmin.from("message_logs").insert({
        user_id: userId,
        account_id: accountId,
        chat_id: c.chat_id,
        ok: r.ok,
        telegram_message_id: r.result?.message_id ?? null,
        error: r.ok ? null : r.description ?? "erro"
      });
      if (r.ok) sent2++;
      else {
        failed2++;
        lastError2 = r.description ?? "erro";
      }
      if (r.ok && r.result?.message_id) {
        await triggerSignalReactions({
          userId,
          chatId: c.chat_id,
          telegramMessageId: r.result.message_id,
          roomId: s.room_id
        });
      }
    }
    return {
      sent: sent2,
      failed: failed2,
      lastError: lastError2
    };
  };
  const mainVideo = await loadVideo(s.video_id);
  const mainAudio = await loadAudio(s.audio_id);
  const mainRes = await sendPayload({
    content: s.content ?? null,
    image_path: s.image_path ?? null,
    video: mainVideo,
    audio: mainAudio,
    parse_mode: s.parse_mode,
    is_premium: !!s.is_premium
  });
  let sent = mainRes.sent;
  let failed = mainRes.failed;
  let lastError = mainRes.lastError;
  const fups = Array.isArray(s.follow_ups) ? s.follow_ups : [];
  for (const f of fups) {
    const fVideo = await loadVideo(f.video_id ?? null);
    const fAudio = await loadAudio(f.audio_id ?? null);
    const fr = await sendPayload({
      content: f.content ?? null,
      image_path: f.image_path ?? null,
      video: fVideo,
      audio: fAudio,
      parse_mode: s.parse_mode,
      is_premium: !!s.is_premium
    });
    sent += fr.sent;
    failed += fr.failed;
    if (fr.lastError) lastError = fr.lastError;
  }
  return {
    ok: sent > 0,
    sent,
    failed,
    error: lastError
  };
});
const TestMessageInput = z.object({
  roomId: z.string().uuid(),
  accountId: z.string().uuid().nullable().optional(),
  content: z.string().max(4e3).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  audioId: z.string().uuid().nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  isPremium: z.boolean().default(false),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional()
});
const testMessage_createServerFn_handler = createServerRpc({
  id: "e9cfdb4483e73620518a22b85d5af41f696ed908522b5a2b91558a187c530439",
  name: "testMessage",
  filename: "src/lib/recurring-schedules.functions.ts"
}, (opts) => testMessage.__executeServer(opts));
const testMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => TestMessageInput.parse(d)).handler(testMessage_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  let accountId = data.accountId ?? null;
  if (!accountId) {
    const {
      data: room
    } = await supabaseAdmin.from("rooms").select("default_account_id, user_id").eq("id", data.roomId).maybeSingle();
    if (!room || room.user_id !== userId) throw new Error("Sala não encontrada");
    accountId = room.default_account_id ?? null;
  }
  if (!accountId) throw new Error("Nenhuma conta de bot configurada");
  const {
    data: acc
  } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", accountId).maybeSingle();
  const {
    data: chats
  } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", data.roomId);
  if (!acc) throw new Error("Bot não encontrado");
  if (!chats?.length) throw new Error("Nenhum grupo vinculado a esta sala");
  let video = null;
  if (data.videoId) {
    const {
      data: v
    } = await supabaseAdmin.from("videos").select("storage_path, mime_type, duration_seconds, title, kind, width, height").eq("id", data.videoId).maybeSingle();
    video = v ?? null;
  }
  let mainAudio = null;
  if (data.audioId) {
    const {
      data: a
    } = await supabaseAdmin.from("audios").select("storage_path, duration_seconds, title").eq("id", data.audioId).maybeSingle();
    mainAudio = a ?? null;
  }
  const replyMarkup = void 0;
  const isNormalVideo = video && video.kind === "normal";
  const wantsPremium = data.isPremium || hasEmojiTokens(data.content ?? "");
  let captionForMedia = data.content ?? null;
  let captionParseMode = data.parseMode;
  if (captionForMedia && hasEmojiTokens(captionForMedia)) {
    const lookup = await getUserEmojiLookup(userId);
    const rendered = renderEmojiTokensToHtml(captionForMedia, lookup);
    if (rendered.replaced) {
      captionForMedia = rendered.text;
      captionParseMode = "HTML";
    }
  }
  let sent = 0;
  let failed = 0;
  let lastError = null;
  for (const c of chats) {
    let r = {
      ok: false,
      description: "no-op"
    };
    const premium = wantsPremium && !data.imagePath && !video && data.content ? await sendTextWithPremiumEmojis({
      userId,
      chatId: c.chat_id,
      text: data.content,
      strict: true
    }) : {
      applied: false
    };
    if (premium.applied) {
      r = await withCompanionButton(premium.ok ? {
        ok: true,
        result: {
          message_id: premium.messageId ?? void 0
        }
      } : {
        ok: false,
        description: premium.error
      }, acc.bot_token, c.chat_id);
    } else if (data.imagePath) {
      const {
        data: pub
      } = supabaseAdmin.storage.from("room-images").getPublicUrl(data.imagePath);
      if (wantsPremium) {
        const premiumPhoto = await sendPhotoWithPremiumEmojiCaption({
          userId,
          chatId: c.chat_id,
          photoUrl: pub.publicUrl,
          caption: data.content ?? null,
          strict: true
        });
        if (premiumPhoto.applied) {
          r = await withCompanionButton(premiumPhoto.ok ? {
            ok: true,
            result: {
              message_id: premiumPhoto.messageId ?? void 0
            }
          } : {
            ok: false,
            description: premiumPhoto.error
          }, acc.bot_token, c.chat_id);
        } else {
          r = await callTelegram(acc.bot_token, "sendPhoto", {
            chat_id: c.chat_id,
            photo: pub.publicUrl,
            caption: captionForMedia ?? void 0,
            parse_mode: captionForMedia ? captionParseMode : void 0,
            reply_markup: replyMarkup
          });
        }
      } else {
        r = await callTelegram(acc.bot_token, "sendPhoto", {
          chat_id: c.chat_id,
          photo: pub.publicUrl,
          caption: captionForMedia ?? void 0,
          parse_mode: captionForMedia ? captionParseMode : void 0,
          reply_markup: replyMarkup
        });
      }
    } else if (video) {
      if (isNormalVideo) {
        let premiumVideoOk = false;
        if (wantsPremium && data.content && hasEmojiTokens(data.content)) {
          const {
            data: file
          } = await supabaseAdmin.storage.from("videos").download(video.storage_path);
          if (file) {
            const bytes = await file.arrayBuffer();
            const pv = await sendVideoWithPremiumEmojiCaption({
              userId,
              chatId: c.chat_id,
              videoBytes: bytes,
              thumbnailBytes: await loadVideoThumbnail(video.storage_path),
              filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
              mimeType: video.mime_type ?? "video/mp4",
              duration: video.duration_seconds,
              width: video.width,
              height: video.height,
              caption: data.content,
              strict: true
            });
            if (pv.applied) {
              r = await withCompanionButton(pv.ok ? {
                ok: true,
                result: {
                  message_id: pv.messageId ?? void 0
                }
              } : {
                ok: false,
                description: pv.error
              }, acc.bot_token, c.chat_id);
              premiumVideoOk = true;
            }
          }
        }
        if (!premiumVideoOk) {
          r = await dispatchVideo({
            botToken: acc.bot_token,
            storagePath: video.storage_path,
            chatId: c.chat_id,
            duration: video.duration_seconds,
            width: video.width,
            height: video.height,
            mimeType: video.mime_type,
            filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
            caption: captionForMedia,
            parseMode: captionParseMode,
            replyMarkup
          });
        }
      } else {
        r = await dispatchVideoNote({
          botToken: acc.bot_token,
          storagePath: video.storage_path,
          chatId: c.chat_id,
          duration: video.duration_seconds,
          mimeType: video.mime_type,
          filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
        });
      }
    } else if (mainAudio) {
      const {
        data: fileData,
        error
      } = await supabaseAdmin.storage.from("audio-files").download(mainAudio.storage_path);
      if (error || !fileData) {
        r = {
          ok: false,
          description: "Falha ao baixar áudio"
        };
      } else {
        const bytes = await fileData.arrayBuffer();
        const {
          sendVoiceToChat
        } = await import("./audios.functions-DUKTM5eK.js");
        r = await sendVoiceToChat({
          botToken: acc.bot_token,
          chatId: c.chat_id,
          fileBytes: bytes,
          filename: mainAudio.title + ".ogg",
          mimeType: "audio/ogg",
          duration: mainAudio.duration_seconds,
          caption: data.content
        });
      }
    } else {
      r = await callTelegram(acc.bot_token, "sendMessage", {
        chat_id: c.chat_id,
        text: data.content ?? "",
        parse_mode: data.parseMode,
        reply_markup: replyMarkup,
        link_preview_options: {
          is_disabled: true
        }
      });
    }
    await supabaseAdmin.from("message_logs").insert({
      user_id: userId,
      account_id: accountId,
      chat_id: c.chat_id,
      ok: r.ok,
      telegram_message_id: r.result?.message_id ?? null,
      error: r.ok ? null : r.description ?? "erro"
    });
    if (r.ok) sent++;
    else {
      failed++;
      lastError = r.description ?? "erro";
    }
    if (r.ok && r.result?.message_id) {
      await triggerSignalReactions({
        userId,
        chatId: c.chat_id,
        telegramMessageId: r.result.message_id,
        roomId: data.roomId
      });
    }
  }
  return {
    ok: sent > 0,
    sent,
    failed,
    error: lastError
  };
});
export {
  deleteSchedule_createServerFn_handler,
  testMessage_createServerFn_handler,
  testSchedule_createServerFn_handler,
  toggleSchedule_createServerFn_handler,
  upsertSchedule_createServerFn_handler
};
