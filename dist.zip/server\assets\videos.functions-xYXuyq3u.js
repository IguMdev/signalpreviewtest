import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
function resolveNormalVideoDimensions(width, height) {
  const w = Number(width);
  const h = Number(height);
  if (Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0) {
    return {
      width: Math.round(w),
      height: Math.round(h)
    };
  }
  return {
    width: 720,
    height: 1280
  };
}
function thumbnailPathForVideoPath(storagePath) {
  const parts = storagePath.split("/");
  const file = parts.pop() || "video.mp4";
  const base = file.replace(/\.[^.]+$/, "") || "video";
  return [...parts, "thumbs", `${base}.jpg`].filter(Boolean).join("/");
}
async function sendVideoNoteToChat(opts) {
  if (!opts.botToken) {
    return {
      ok: false,
      description: "Conta sem bot_token"
    };
  }
  const form = new FormData();
  form.append("chat_id", String(opts.chatId));
  if (opts.duration) form.append("duration", String(opts.duration));
  form.append("video_note", new Blob([opts.fileBytes], {
    type: opts.mimeType || "video/mp4"
  }), opts.filename);
  const res = await fetch(`https://api.telegram.org/bot${opts.botToken}/sendVideoNote`, {
    method: "POST",
    body: form
  });
  return await res.json();
}
async function sendVideoToChat(opts) {
  if (!opts.botToken) {
    return {
      ok: false,
      description: "Conta sem bot_token"
    };
  }
  const form = new FormData();
  const dimensions = resolveNormalVideoDimensions(opts.width, opts.height);
  form.append("chat_id", String(opts.chatId));
  if (opts.caption && opts.caption.trim()) {
    form.append("caption", opts.caption);
    if (opts.parseMode) form.append("parse_mode", opts.parseMode);
  }
  if (opts.duration) form.append("duration", String(Math.round(opts.duration)));
  form.append("width", String(dimensions.width));
  form.append("height", String(dimensions.height));
  if (opts.thumbnailBytes && opts.thumbnailBytes.byteLength <= 200 * 1024) {
    form.append("thumbnail", new Blob([opts.thumbnailBytes], {
      type: "image/jpeg"
    }), "thumbnail.jpg");
  }
  if (opts.replyMarkup) form.append("reply_markup", JSON.stringify(opts.replyMarkup));
  form.append("video", new Blob([opts.fileBytes], {
    type: opts.mimeType || "video/mp4"
  }), opts.filename);
  const res = await fetch(`https://api.telegram.org/bot${opts.botToken}/sendVideo`, {
    method: "POST",
    body: form
  });
  return await res.json();
}
async function loadVideoThumbnail(storagePath) {
  const {
    data: thumb
  } = await supabaseAdmin.storage.from("videos").download(thumbnailPathForVideoPath(storagePath));
  if (!thumb) return null;
  const bytes = await thumb.arrayBuffer();
  return bytes.byteLength <= 200 * 1024 ? bytes : null;
}
const sendVideoNoteNow_createServerFn_handler = createServerRpc({
  id: "bdd37fe8aa26d3bad1eb29e3a757bbf04c7a3d08ba659057e6302f09cc264909",
  name: "sendVideoNoteNow",
  filename: "src/lib/videos.functions.ts"
}, (opts) => sendVideoNoteNow.__executeServer(opts));
const sendVideoNoteNow = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  videoId: z.string().uuid(),
  accountId: z.string().uuid(),
  chatIds: z.array(z.union([z.number(), z.string()])).min(1)
}).parse(d)).handler(sendVideoNoteNow_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    data: video,
    error: vErr
  } = await supabase.from("videos").select("id, storage_path, mime_type, duration_seconds, title, kind, width, height").eq("id", data.videoId).maybeSingle();
  if (vErr || !video) throw new Error("Vídeo não encontrado");
  const {
    data: acc,
    error: aErr
  } = await supabase.from("telegram_accounts").select("id, bot_token").eq("id", data.accountId).maybeSingle();
  if (aErr || !acc) throw new Error("Conta Telegram não encontrada");
  const {
    data: file,
    error: dErr
  } = await supabaseAdmin.storage.from("videos").download(video.storage_path);
  if (dErr || !file) throw new Error("Falha ao baixar vídeo: " + (dErr?.message ?? ""));
  const bytes = await file.arrayBuffer();
  const thumbnailBytes = await loadVideoThumbnail(video.storage_path);
  const results = [];
  for (const chatId of data.chatIds) {
    const filename = video.title.replace(/[^\w.-]+/g, "_") + ".mp4";
    const r = video.kind === "normal" ? await sendVideoToChat({
      botToken: acc.bot_token,
      chatId,
      fileBytes: bytes,
      filename,
      mimeType: video.mime_type ?? "video/mp4",
      duration: video.duration_seconds,
      width: video.width,
      height: video.height,
      thumbnailBytes
    }) : await sendVideoNoteToChat({
      botToken: acc.bot_token,
      chatId,
      fileBytes: bytes,
      filename,
      mimeType: video.mime_type ?? "video/mp4",
      duration: video.duration_seconds
    });
    await supabaseAdmin.from("message_logs").insert({
      user_id: userId,
      account_id: data.accountId,
      chat_id: typeof chatId === "string" ? Number(chatId) : chatId,
      ok: r.ok,
      telegram_message_id: r.result?.message_id ?? null,
      error: r.ok ? null : r.description ?? "erro"
    });
    results.push({
      chatId,
      ok: r.ok,
      error: r.ok ? void 0 : r.description
    });
  }
  return {
    results
  };
});
const deleteVideo_createServerFn_handler = createServerRpc({
  id: "3fcd159205240d6926126acac1e16e0b826c923dfac07b14dd13822331355611",
  name: "deleteVideo",
  filename: "src/lib/videos.functions.ts"
}, (opts) => deleteVideo.__executeServer(opts));
const deleteVideo = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteVideo_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: v
  } = await supabase.from("videos").select("storage_path").eq("id", data.id).maybeSingle();
  if (v?.storage_path) {
    await supabaseAdmin.storage.from("videos").remove([v.storage_path, thumbnailPathForVideoPath(v.storage_path)]);
  }
  const {
    error
  } = await supabase.from("videos").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
export {
  deleteVideo_createServerFn_handler,
  sendVideoNoteNow_createServerFn_handler
};
