import { jsxs, jsx } from "react/jsx-runtime";
import { useRef, useState } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { u as useAuth, B as Button, C as Card, L as Label, I as Input, D as Dialog, g as DialogContent, h as DialogHeader, i as DialogTitle, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, j as DialogFooter } from "./router-Cw6OHOsO.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { deleteAudio, sendAudioNow } from "./audios.functions-DUKTM5eK.js";
import { toast } from "sonner";
import { HelpCircle, Loader2, Upload, Mic, Send, Trash2 } from "lucide-react";
import "@tanstack/react-router";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function AudioPreview({
  path
}) {
  const {
    data: url
  } = useQuery({
    queryKey: ["audio-signed", path],
    queryFn: async () => {
      const {
        data
      } = await supabase.storage.from("audio-files").createSignedUrl(path, 3600);
      return data?.signedUrl ?? null;
    },
    staleTime: 50 * 60 * 1e3
  });
  return /* @__PURE__ */ jsx("div", { className: "w-full h-12 bg-muted/50 rounded-md flex items-center px-3", children: url ? /* @__PURE__ */ jsx("audio", { src: url, className: "w-full h-8", controls: true, preload: "metadata" }) : /* @__PURE__ */ jsx(Loader2, { className: "size-5 animate-spin text-muted-foreground mx-auto" }) });
}
const MAX_BYTES_AUDIO = 50 * 1024 * 1024;
async function validateAudioFile(file) {
  if (file.size > MAX_BYTES_AUDIO) {
    throw new Error("O áudio deve ter no máximo 50 MB.");
  }
  if (!file.name.toLowerCase().endsWith(".ogg")) {
    throw new Error("O áudio deve estar no formato .ogg para ser enviado como nota de voz no Telegram.");
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const a = new Audio();
    a.preload = "metadata";
    a.src = url;
    a.onloadedmetadata = () => {
      const dur = a.duration;
      URL.revokeObjectURL(url);
      resolve({
        duration: Math.round(dur)
      });
    };
    a.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Não foi possível ler o arquivo de áudio. Certifique-se de que é um formato válido."));
    };
  });
}
function AudiosPage() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const sendNow = useServerFn(sendAudioNow);
  const delFn = useServerFn(deleteAudio);
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState("");
  const [pendingFile, setPendingFile] = useState(null);
  const [sendDialog, setSendDialog] = useState(null);
  const [accountId, setAccountId] = useState("");
  const [roomId, setRoomId] = useState("");
  const [sending, setSending] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const audios = useQuery({
    queryKey: ["audios"],
    queryFn: async () => (await supabase.from("audios").select("id, title, storage_path, file_size, duration_seconds, created_at").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const accounts = useQuery({
    queryKey: ["accounts-min"],
    queryFn: async () => (await supabase.from("telegram_accounts").select("id, label")).data ?? []
  });
  const rooms = useQuery({
    queryKey: ["rooms-min"],
    queryFn: async () => (await supabase.from("rooms").select("id, name, default_account_id")).data ?? []
  });
  const onPickFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const {
        duration
      } = await validateAudioFile(f);
      setPendingFile({
        file: f,
        duration
      });
      setTitle(f.name.replace(/\.[^/.]+$/, ""));
    } catch (err) {
      toast.error(err.message);
      if (fileRef.current) fileRef.current.value = "";
    }
  };
  const upload = async () => {
    if (!pendingFile || !user) return;
    setUploading(true);
    try {
      const mimeType = pendingFile.file.type || "audio/ogg";
      const path = `${user.id}/${crypto.randomUUID()}.ogg`;
      const {
        error: upErr
      } = await supabase.storage.from("audio-files").upload(path, pendingFile.file, {
        contentType: mimeType,
        upsert: false
      });
      if (upErr) throw upErr;
      const {
        error: insErr
      } = await supabase.from("audios").insert({
        user_id: user.id,
        title: title.trim() || "Áudio",
        storage_path: path,
        file_size: pendingFile.file.size,
        duration_seconds: pendingFile.duration,
        mime_type: mimeType
      });
      if (insErr) throw insErr;
      toast.success("Áudio enviado com sucesso!");
      setPendingFile(null);
      setTitle("");
      if (fileRef.current) fileRef.current.value = "";
      qc.invalidateQueries({
        queryKey: ["audios"]
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  };
  const delMut = useMutation({
    mutationFn: async (id) => {
      await delFn({
        data: id
      });
    },
    onSuccess: () => {
      toast.success("Áudio removido");
      qc.invalidateQueries({
        queryKey: ["audios"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const submitSend = async () => {
    if (!sendDialog || !accountId || !roomId) return;
    setSending(true);
    try {
      const {
        data: chats
      } = await supabase.from("room_chats").select("chat_id").eq("room_id", roomId);
      const chatIds = (chats ?? []).map((c) => String(c.chat_id));
      if (!chatIds.length) {
        toast.error("Esse grupo não tem chats vinculados.");
        return;
      }
      const res = await sendNow({
        data: {
          audioId: sendDialog.audioId,
          accountId,
          chatIds
        }
      });
      if (res.ok) {
        toast.success(`Enviado com sucesso!`);
      }
      setSendDialog(null);
      setAccountId("");
      setRoomId("");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Áudios" }),
        /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", onClick: () => setHelpOpen(true), children: [
          /* @__PURE__ */ jsx(HelpCircle, { className: "size-4" }),
          "Como criar um arquivo .ogg"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground", children: [
        "Envie áudios para o Telegram que aparecerão como ",
        /* @__PURE__ */ jsx("b", { children: "Mensagens de Voz" }),
        " (Voice Notes gravadas na hora)."
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-5 space-y-4", "data-tour": "audio-upload", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row gap-3 sm:items-end", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex-1 space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Áudio em formato .ogg (com codec OPUS)" }),
          /* @__PURE__ */ jsx(Input, { ref: fileRef, type: "file", accept: ".ogg,audio/ogg", onChange: onPickFile })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Título" }),
          /* @__PURE__ */ jsx(Input, { value: title, onChange: (e) => setTitle(e.target.value), placeholder: "Nome do áudio" })
        ] }),
        /* @__PURE__ */ jsxs(Button, { onClick: upload, disabled: !pendingFile || uploading, children: [
          uploading ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Upload, { className: "size-4" }),
          "Enviar"
        ] })
      ] }),
      pendingFile && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
        "Pronto: ",
        pendingFile.file.name,
        " · ",
        pendingFile.duration,
        "s ·",
        " ",
        (pendingFile.file.size / 1024 / 1024).toFixed(2),
        " MB"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-3", children: [
      audios.data?.length === 0 && /* @__PURE__ */ jsxs(Card, { className: "p-10 text-center text-muted-foreground text-sm md:col-span-2 lg:col-span-3", children: [
        /* @__PURE__ */ jsx(Mic, { className: "size-8 mx-auto mb-2 opacity-50" }),
        "Nenhum áudio enviado ainda."
      ] }),
      audios.data?.map((a) => /* @__PURE__ */ jsxs(Card, { className: "p-4 flex flex-col justify-between space-y-4", children: [
        /* @__PURE__ */ jsx(AudioPreview, { path: a.storage_path }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium truncate", children: a.title }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
            "Nota de Voz · ",
            a.duration_seconds ?? "?",
            "s ·",
            " ",
            a.file_size ? (a.file_size / 1024 / 1024).toFixed(2) + " MB" : "—"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: new Date(a.created_at).toLocaleString("pt-BR") })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxs(Button, { size: "sm", className: "flex-1", onClick: () => setSendDialog({
            audioId: a.id,
            title: a.title
          }), children: [
            /* @__PURE__ */ jsx(Send, { className: "size-4" }),
            "Enviar agora"
          ] }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => {
            if (confirm("Excluir este áudio?")) delMut.mutate(a.id);
          }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
        ] })
      ] }, a.id))
    ] }),
    /* @__PURE__ */ jsx(Dialog, { open: !!sendDialog, onOpenChange: (o) => !o && setSendDialog(null), children: /* @__PURE__ */ jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsxs(DialogTitle, { children: [
        'Enviar "',
        sendDialog?.title,
        '"'
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Grupo" }),
          /* @__PURE__ */ jsxs(Select, { value: roomId, onValueChange: (v) => {
            setRoomId(v);
            const r = rooms.data?.find((x) => x.id === v);
            if (r?.default_account_id) setAccountId(r.default_account_id);
          }, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: rooms.data?.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Conta Telegram" }),
          /* @__PURE__ */ jsxs(Select, { value: accountId, onValueChange: setAccountId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: accounts.data?.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setSendDialog(null), children: "Cancelar" }),
        /* @__PURE__ */ jsxs(Button, { onClick: submitSend, disabled: !accountId || !roomId || sending, children: [
          sending && /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }),
          "Enviar"
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(Dialog, { open: helpOpen, onOpenChange: setHelpOpen, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-lg", children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Como preparar um áudio (Voice Note)" }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4 text-sm", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium mb-1", children: "Por que formato .ogg?" }),
          /* @__PURE__ */ jsxs("p", { className: "text-muted-foreground", children: [
            "O Telegram exige que mensagens de voz sejam enviadas no formato ",
            /* @__PURE__ */ jsx("b", { children: ".ogg" }),
            " codificado com ",
            /* @__PURE__ */ jsx("b", { children: "OPUS" }),
            '. Se você enviar mp3 ou wav, o Telegram exibirá como um "arquivo de música" ou "documento", e não como uma gravação de voz.'
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium mb-1", children: "Como converter seu áudio gratuitamente" }),
          /* @__PURE__ */ jsxs("ol", { className: "list-decimal pl-5 text-muted-foreground space-y-1", children: [
            /* @__PURE__ */ jsxs("li", { children: [
              "Acesse um site de conversão grátis, como ",
              /* @__PURE__ */ jsx("b", { children: "Convertio" }),
              " ou ",
              /* @__PURE__ */ jsx("b", { children: "Online-Audio-Converter" }),
              "."
            ] }),
            /* @__PURE__ */ jsx("li", { children: "Faça o upload do seu áudio (MP3, M4A, WAV, etc)." }),
            /* @__PURE__ */ jsxs("li", { children: [
              "Selecione o formato de saída como ",
              /* @__PURE__ */ jsx("b", { children: "OGG" }),
              "."
            ] }),
            /* @__PURE__ */ jsx("li", { children: "Clique em Converter e baixe o arquivo resultante." }),
            /* @__PURE__ */ jsx("li", { children: "Faça o upload do arquivo .ogg aqui nesta tela." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-blue-500/30 bg-blue-500/10 p-3 text-xs", children: [
          "💡 ",
          /* @__PURE__ */ jsx("b", { children: "Dica:" }),
          " Áudios muito longos podem demorar a enviar. Recomendamos enviar áudios curtos e diretos, iguais aos que você envia normalmente conversando no Telegram."
        ] })
      ] }),
      /* @__PURE__ */ jsx(DialogFooter, { children: /* @__PURE__ */ jsx(Button, { onClick: () => setHelpOpen(false), children: "Entendi" }) })
    ] }) })
  ] });
}
export {
  AudiosPage as component
};
