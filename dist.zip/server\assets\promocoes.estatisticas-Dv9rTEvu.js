import { jsxs, jsx } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { g as getPromoStats, l as listPromoDispatches } from "./promo.functions-D_8o42Ut.js";
import { C as Card, H as Badge, y as Table, z as TableHeader, A as TableRow, E as TableHead, F as TableBody, G as TableCell } from "./router-Cw6OHOsO.js";
import { ShoppingBag, MousePointerClick, TrendingUp, DollarSign } from "lucide-react";
import "react";
import "@tanstack/react-router";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "./client-bD0og8Nx.js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function PromoStatsPage() {
  const stats = useServerFn(getPromoStats);
  const list = useServerFn(listPromoDispatches);
  const statsQ = useQuery({
    queryKey: ["promo-stats"],
    queryFn: () => stats({
      data: {
        days: 30
      }
    })
  });
  const listQ = useQuery({
    queryKey: ["promo-dispatches"],
    queryFn: () => list({
      data: {
        limit: 50
      }
    })
  });
  const s = statsQ.data;
  return /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Estatísticas de Promoções" }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Últimos 30 dias." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-3", children: [
      /* @__PURE__ */ jsx(Stat, { icon: /* @__PURE__ */ jsx(ShoppingBag, { className: "size-5" }), label: "Enviados", value: s?.sent ?? 0 }),
      /* @__PURE__ */ jsx(Stat, { icon: /* @__PURE__ */ jsx(MousePointerClick, { className: "size-5" }), label: "Cliques", value: s?.clicks ?? 0 }),
      /* @__PURE__ */ jsx(Stat, { icon: /* @__PURE__ */ jsx(TrendingUp, { className: "size-5" }), label: "Conversões", value: s?.conversions ?? 0 }),
      /* @__PURE__ */ jsx(Stat, { icon: /* @__PURE__ */ jsx(DollarSign, { className: "size-5" }), label: "Comissão (R$)", value: (s?.commissionTotal ?? 0).toFixed(2) })
    ] }),
    s && /* @__PURE__ */ jsxs(Card, { className: "p-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-sm font-medium mb-2", children: "Envios por loja" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
        Object.entries(s.byStore).map(([k, v]) => /* @__PURE__ */ jsxs(Badge, { variant: "secondary", children: [
          k,
          ": ",
          v
        ] }, k)),
        Object.keys(s.byStore).length === 0 && /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: "Nenhum envio ainda." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "overflow-hidden", children: [
      /* @__PURE__ */ jsx("div", { className: "p-4 text-sm font-medium border-b", children: "Últimos envios" }),
      /* @__PURE__ */ jsxs(Table, { children: [
        /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
          /* @__PURE__ */ jsx(TableHead, { children: "Quando" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Loja" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Produto" }),
          /* @__PURE__ */ jsx(TableHead, { children: "Status" })
        ] }) }),
        /* @__PURE__ */ jsxs(TableBody, { children: [
          (listQ.data?.dispatches ?? []).map((d) => /* @__PURE__ */ jsxs(TableRow, { children: [
            /* @__PURE__ */ jsx(TableCell, { className: "text-xs", children: new Date(d.sent_at).toLocaleString("pt-BR") }),
            /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: d.store }) }),
            /* @__PURE__ */ jsx(TableCell, { className: "font-mono text-xs truncate max-w-md", children: d.external_id }),
            /* @__PURE__ */ jsx(TableCell, { children: d.ok ? /* @__PURE__ */ jsx(Badge, { children: "OK" }) : /* @__PURE__ */ jsx(Badge, { variant: "destructive", children: "Erro" }) })
          ] }, d.id)),
          listQ.data?.dispatches.length === 0 && /* @__PURE__ */ jsx(TableRow, { children: /* @__PURE__ */ jsx(TableCell, { colSpan: 4, className: "text-center text-xs text-muted-foreground py-8", children: "Sem envios ainda." }) })
        ] })
      ] })
    ] })
  ] });
}
function Stat({
  icon,
  label,
  value
}) {
  return /* @__PURE__ */ jsxs(Card, { className: "p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground flex items-center gap-2", children: [
      icon,
      label
    ] }),
    /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold mt-1", children: value })
  ] });
}
export {
  PromoStatsPage as component
};
