import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { s as supabase } from "./client-bD0og8Nx.js";
import { a as listPixels, b as deletePixel, e as createPixel, T as TRACKING_MODES, M as MODE_PRESETS, V as VERTICALS, u as updatePixel, E as EVENT_OPTIONS } from "./tracking.functions-jGKb0ig9.js";
import { D as Dialog, k as DialogTrigger, B as Button, g as DialogContent, C as Card, x as CardContent, H as Badge, O as CardHeader, Q as CardTitle, W as CardDescription, h as DialogHeader, i as DialogTitle, L as Label, I as Input, T as Textarea, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, j as DialogFooter, N as Switch } from "./router-Cw6OHOsO.js";
import { T as TooltipProvider, a as Tooltip, b as TooltipTrigger, c as TooltipContent } from "./tooltip-DPQMaJsn.js";
import { Code2, Plus, Settings2, Trash2, Bot, Send, Globe, AlertTriangle, ExternalLink, HelpCircle, Check } from "lucide-react";
import "@supabase/supabase-js";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-tooltip";
const VERTICAL_LABEL = {
  bet: "Apostas / Bet",
  igaming: "iGaming / Cassino",
  hot: "Nicho Hot / +18",
  promo: "Promoções e descontos",
  outro: "Outro"
};
const MODE_LABEL = {
  telegram: "Telegram",
  direct_response: "Direct Response"
};
function PixelsPage() {
  const qc = useQueryClient();
  const listFn = useServerFn(listPixels);
  useServerFn(createPixel);
  const delFn = useServerFn(deletePixel);
  const pixels = useQuery({
    queryKey: ["tracking-pixels"],
    queryFn: () => listFn()
  });
  const accounts = useQuery({
    queryKey: ["telegram-accounts-mini"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("telegram_accounts").select("id,bot_username").order("created_at", {
        ascending: false
      });
      return data ?? [];
    }
  });
  const [open, setOpen] = useState(false);
  const remove = useMutation({
    mutationFn: (id) => delFn({
      data: {
        id
      }
    }),
    onSuccess: () => {
      toast.success("Removido");
      qc.invalidateQueries({
        queryKey: ["tracking-pixels"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const [editing, setEditing] = useState(null);
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-5xl", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Code2, { className: "size-6" }),
          " Pixels"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1 max-w-2xl", children: "Cada pixel representa uma campanha ou funil. Vincule um bot, ofertas e Meta CAPI para medir o caminho completo: clique → bot → cadastro → depósito." })
      ] }),
      /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange: setOpen, children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { children: [
          /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
          " Novo pixel"
        ] }) }),
        /* @__PURE__ */ jsx(DialogContent, { className: "max-w-2xl", children: /* @__PURE__ */ jsx(NewPixelWizard, { accounts: accounts.data ?? [], onDone: () => {
          setOpen(false);
          qc.invalidateQueries({
            queryKey: ["tracking-pixels"]
          });
        } }) })
      ] })
    ] }),
    pixels.isLoading ? /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Carregando..." }) : pixels.data && pixels.data.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid gap-3", children: pixels.data.map((p) => /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "flex items-center justify-between gap-3 py-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsx("p", { className: "font-semibold truncate", children: p.name }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1 flex-wrap", children: [
          /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: MODE_LABEL[p.tracking_mode ?? "telegram"] }),
          /* @__PURE__ */ jsx(Badge, { variant: "secondary", children: VERTICAL_LABEL[p.vertical] ?? p.vertical }),
          p.is_active ? /* @__PURE__ */ jsx(Badge, { children: "Ativo" }) : /* @__PURE__ */ jsx(Badge, { variant: "outline", children: "Inativo" }),
          p.bot_username && /* @__PURE__ */ jsxs(Badge, { variant: "outline", children: [
            "@",
            p.bot_username
          ] }),
          /* @__PURE__ */ jsx(Badge, { variant: "outline", className: "font-mono text-xs", children: p.id.slice(0, 8) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Link, { to: "/trackeamento/metricas", search: {
          pixel: p.id
        }, children: /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", children: "Ver métricas" }) }),
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => setEditing(p), children: /* @__PURE__ */ jsx(Settings2, { className: "size-4" }) }),
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => {
          if (confirm(`Remover pixel "${p.name}"? Os cliques serão perdidos.`)) remove.mutate(p.id);
        }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
      ] })
    ] }) }, p.id)) }) : /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardHeader, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: "Nenhum pixel ainda" }),
      /* @__PURE__ */ jsx(CardDescription, { children: "Crie o primeiro pixel para começar a rastrear seu funil." })
    ] }) }),
    /* @__PURE__ */ jsx(EditPixelDialog, { pixel: editing, onClose: () => setEditing(null) })
  ] });
}
function NewPixelWizard({
  accounts,
  onDone
}) {
  const createFn = useServerFn(createPixel);
  const [step, setStep] = useState(1);
  const [trackingMode, setTrackingMode] = useState("telegram");
  const [name, setName] = useState("");
  const [metaPixelId, setMetaPixelId] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [testEventCode, setTestEventCode] = useState("");
  const [vertical, setVertical] = useState("bet");
  const [accountId, setAccountId] = useState("");
  const [salesPageUrl, setSalesPageUrl] = useState("");
  const create = useMutation({
    mutationFn: () => createFn({
      data: {
        name,
        vertical,
        tracking_mode: trackingMode,
        account_id: trackingMode === "telegram" ? accountId || null : null,
        sales_page_url: trackingMode === "direct_response" ? salesPageUrl || null : null,
        is_active: true,
        event_on_join: "Lead",
        event_on_offer_click: "InitiateCheckout",
        event_on_register: "CompleteRegistration",
        event_on_deposit: "Purchase",
        event_on_view: "ViewContent",
        event_on_lead: "Lead",
        event_on_checkout: "InitiateCheckout",
        event_on_payment_info: "AddPaymentInfo",
        event_on_purchase: "Purchase",
        meta_pixel_id: metaPixelId || null,
        meta_access_token: accessToken || null,
        meta_test_event_code: testEventCode || null
      }
    }),
    onSuccess: () => {
      toast.success("Pixel criado");
      onDone();
    },
    onError: (e) => toast.error(e.message)
  });
  const canNext = name.trim().length > 0 && metaPixelId.trim().length > 0 && accessToken.trim().length > 0;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Novo Pixel" }) }),
    /* @__PURE__ */ jsx(Stepper, { step }),
    step === 1 ? /* @__PURE__ */ jsx(TooltipProvider, { delayDuration: 150, children: /* @__PURE__ */ jsxs("div", { className: "space-y-5 max-h-[70vh] overflow-y-auto pr-2 -mr-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Modo de trackeamento" }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: TRACKING_MODES.map((m) => {
          const preset = MODE_PRESETS[m];
          const active = trackingMode === m;
          const Icon = m === "telegram" ? Bot : Send;
          return /* @__PURE__ */ jsxs("button", { type: "button", onClick: () => setTrackingMode(m), className: `text-left rounded-xl border p-3 transition ${active ? "border-primary bg-primary/5 ring-1 ring-primary/30" : "border-border hover:bg-muted/30"}`, children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
              /* @__PURE__ */ jsx(Icon, { className: "size-4 text-primary" }),
              /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: preset.label })
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: preset.description }),
            /* @__PURE__ */ jsx("ul", { className: "mt-2 space-y-0.5", children: preset.stages.map((s) => /* @__PURE__ */ jsxs("li", { className: "text-[11px] text-muted-foreground flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx("span", { className: "inline-block size-1 rounded-full bg-primary/60" }),
              /* @__PURE__ */ jsx("span", { children: s.label }),
              /* @__PURE__ */ jsx("code", { className: "ml-1 text-[10px] rounded bg-background border px-1", children: s.defaultEvent })
            ] }, s.key)) })
          ] }, m);
        }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-xl border bg-muted/30 p-4 space-y-3", children: [
        /* @__PURE__ */ jsx(InstructionRow, { index: 1, title: "Colete Pixel e Token no Facebook", description: "Localize e copie seu ID e Token de Integração.", tip: "Em business.facebook.com → Gerenciador de Eventos → seu Pixel → Configurações → Conversions API → Gerar token." }),
        /* @__PURE__ */ jsx(InstructionRow, { index: 2, title: "Preencha o Nome, ID e Token", description: "Preencha corretamente os campos abaixo.", tip: "O Nome é só pra você identificar internamente. ID e Token vêm direto do Meta." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Nome" }),
          /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), placeholder: "Digite o Nome do Pixel" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "ID" }),
          /* @__PURE__ */ jsx(Input, { value: metaPixelId, onChange: (e) => setMetaPixelId(e.target.value), placeholder: "Digite o ID do Pixel" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Token de Integração" }),
        /* @__PURE__ */ jsx(Textarea, { value: accessToken, onChange: (e) => setAccessToken(e.target.value), placeholder: "Digite o Token de Integração do Pixel", rows: 3, className: "font-mono text-xs" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Vertical" }),
          /* @__PURE__ */ jsxs(Select, { value: vertical, onValueChange: (v) => setVertical(v), children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsx(SelectContent, { children: VERTICALS.map((v) => /* @__PURE__ */ jsx(SelectItem, { value: v, children: VERTICAL_LABEL[v] }, v)) })
          ] })
        ] }),
        trackingMode === "telegram" ? /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs(Label, { children: [
            "Bot do Telegram ",
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs", children: "(opcional)" })
          ] }),
          /* @__PURE__ */ jsxs(Select, { value: accountId || "none", onValueChange: (v) => setAccountId(v === "none" ? "" : v), children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "none", children: "Nenhum (escolher depois)" }),
              accounts.map((a) => /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
                "@",
                a.bot_username ?? "(sem username)"
              ] }, a.id))
            ] })
          ] })
        ] }) : /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs(Label, { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(Globe, { className: "size-3.5" }),
            " URL da página de vendas ",
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs", children: "(opcional)" })
          ] }),
          /* @__PURE__ */ jsx(Input, { value: salesPageUrl, onChange: (e) => setSalesPageUrl(e.target.value), placeholder: "https://seusite.com/oferta" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm", children: [
        /* @__PURE__ */ jsx(AlertTriangle, { className: "size-5 text-destructive shrink-0 mt-0.5" }),
        /* @__PURE__ */ jsx("p", { className: "text-destructive", children: "Se você gerar um novo token de integração no Facebook após configurar o pixel, o token atual será invalidado e a automação deixará de funcionar." })
      ] })
    ] }) }) : /* @__PURE__ */ jsx(TooltipProvider, { delayDuration: 150, children: /* @__PURE__ */ jsxs("div", { className: "space-y-5 max-h-[70vh] overflow-y-auto pr-2 -mr-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-xl border bg-muted/30 p-4 space-y-3", children: [
        /* @__PURE__ */ jsx(InstructionRow, { index: 1, title: "Acesse o Gerenciador de Eventos", description: "Localize o pixel que você deseja configurar.", tip: "business.facebook.com/events_manager → seu Pixel → aba Testar Eventos." }),
        /* @__PURE__ */ jsx(InstructionRow, { index: 2, title: "Preencha o Código de Teste e envie", description: 'Copie o código da seção "Confirme os eventos do seu Servidor".', tip: "O código começa com TEST e identifica esta sessão de teste." }),
        /* @__PURE__ */ jsx(InstructionRow, { index: 3, title: "Aguarde e aceite os Eventos", description: "Aceite os eventos para otimização de campanhas. Os eventos enviados serão:", tip: "Após aceitar, o Meta passa a contar esses eventos para otimização de campanhas." }),
        /* @__PURE__ */ jsxs("ul", { className: "pl-9 space-y-1 text-xs text-muted-foreground", children: [
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("code", { className: "rounded bg-background border px-1.5 py-0.5 text-[11px]", children: "enter_channel" }),
            /* @__PURE__ */ jsx("span", { children: ": Disparado quando um usuário entra no canal." })
          ] }),
          /* @__PURE__ */ jsxs("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx("code", { className: "rounded bg-background border px-1.5 py-0.5 text-[11px]", children: "left_channel" }),
            /* @__PURE__ */ jsx("span", { children: ": Disparado quando um usuário sai do canal." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "ID do Pixel" }),
          /* @__PURE__ */ jsx(Input, { value: metaPixelId, readOnly: true, className: "bg-muted/40" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Código de Teste" }),
          /* @__PURE__ */ jsx(Input, { value: testEventCode, onChange: (e) => setTestEventCode(e.target.value), placeholder: "Digite o Código de Teste" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Token de Integração" }),
        /* @__PURE__ */ jsx(Textarea, { value: accessToken, readOnly: true, rows: 3, className: "font-mono text-xs bg-muted/40 break-all" })
      ] }),
      /* @__PURE__ */ jsxs("a", { href: "https://business.facebook.com/events_manager", target: "_blank", rel: "noreferrer", className: "inline-flex items-center gap-1 text-xs text-primary hover:underline", children: [
        "Abrir Events Manager ",
        /* @__PURE__ */ jsx(ExternalLink, { className: "size-3" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs(DialogFooter, { className: "gap-2", children: [
      step === 2 && /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setStep(1), disabled: create.isPending, children: "Voltar" }),
      /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: onDone, disabled: create.isPending, children: "Cancelar" }),
      step === 1 ? /* @__PURE__ */ jsx(Button, { onClick: () => setStep(2), disabled: !canNext, children: "Próximo" }) : /* @__PURE__ */ jsx(Button, { onClick: () => create.mutate(), disabled: create.isPending, children: create.isPending ? "Enviando..." : "Enviar Evento Teste" })
    ] })
  ] });
}
function Stepper({
  step
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-3 py-3", children: [
    /* @__PURE__ */ jsx(StepDot, { n: 1, active: step >= 1, done: step > 1, label: "Configuração" }),
    /* @__PURE__ */ jsx("div", { className: `h-px w-24 ${step > 1 ? "bg-primary" : "bg-border"}` }),
    /* @__PURE__ */ jsx(StepDot, { n: 2, active: step >= 2, done: false, label: "Evento Teste" })
  ] });
}
function StepDot({
  n,
  active,
  done,
  label
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-1", children: [
    /* @__PURE__ */ jsx("div", { className: `size-8 rounded-full flex items-center justify-center text-sm font-semibold border ${active ? "bg-primary text-primary-foreground border-primary" : "bg-muted text-muted-foreground border-border"}`, children: done ? /* @__PURE__ */ jsx(Check, { className: "size-4" }) : n }),
    /* @__PURE__ */ jsx("span", { className: `text-xs ${active ? "text-foreground" : "text-muted-foreground"}`, children: label })
  ] });
}
function InstructionRow({
  index,
  title,
  description,
  tip
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
    /* @__PURE__ */ jsx("div", { className: "size-6 rounded-full bg-primary/20 text-primary text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5", children: index }),
    /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: title }),
        /* @__PURE__ */ jsxs(Tooltip, { children: [
          /* @__PURE__ */ jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsx(HelpCircle, { className: "size-3.5 text-muted-foreground cursor-help" }) }),
          /* @__PURE__ */ jsx(TooltipContent, { className: "max-w-xs", children: tip })
        ] })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: description })
    ] })
  ] });
}
function EditPixelDialog({
  pixel,
  onClose
}) {
  return /* @__PURE__ */ jsx(Dialog, { open: !!pixel, onOpenChange: (o) => {
    if (!o) onClose();
  }, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-2xl", children: [
    /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Editar pixel" }) }),
    pixel && /* @__PURE__ */ jsx(EditPixelForm, { pixel, onClose }, pixel.id)
  ] }) });
}
function EditPixelForm({
  pixel,
  onClose
}) {
  const qc = useQueryClient();
  const updFn = useServerFn(updatePixel);
  const [name, setName] = useState(pixel.name);
  const [vertical, setVertical] = useState(pixel.vertical);
  const [isActive, setIsActive] = useState(pixel.is_active);
  const [trackingMode, setTrackingMode] = useState(pixel.tracking_mode ?? "telegram");
  const [salesPageUrl, setSalesPageUrl] = useState(pixel.sales_page_url ?? "");
  const [evJoin, setEvJoin] = useState(pixel.event_on_join);
  const [evOffer, setEvOffer] = useState(pixel.event_on_offer_click);
  const [evReg, setEvReg] = useState(pixel.event_on_register);
  const [evDep, setEvDep] = useState(pixel.event_on_deposit);
  const [evView, setEvView] = useState(pixel.event_on_view ?? "ViewContent");
  const [evLead, setEvLead] = useState(pixel.event_on_lead ?? "Lead");
  const [evCheckout, setEvCheckout] = useState(pixel.event_on_checkout ?? "InitiateCheckout");
  const [evPayInfo, setEvPayInfo] = useState(pixel.event_on_payment_info ?? "AddPaymentInfo");
  const [evPurchase, setEvPurchase] = useState(pixel.event_on_purchase ?? "Purchase");
  const [metaPixelId, setMetaPixelId] = useState(pixel.meta_pixel_id ?? "");
  const [accessToken, setAccessToken] = useState(pixel.meta_access_token ?? "");
  const [testEventCode, setTestEventCode] = useState(pixel.meta_test_event_code ?? "");
  const [drConfig, setDrConfig] = useState(pixel.dr_config ?? {
    enable_lead: false,
    enable_add_to_cart: false,
    enable_initiate_checkout: true,
    initiate_checkout_url_contains: "",
    purchase_approval_only: true,
    purchase_value_mode: "Valor da venda",
    purchase_product: "Qualquer",
    ipv6_enabled: true
  });
  const save = useMutation({
    mutationFn: () => updFn({
      data: {
        id: pixel.id,
        name,
        vertical,
        is_active: isActive,
        tracking_mode: trackingMode,
        sales_page_url: trackingMode === "direct_response" ? salesPageUrl || null : null,
        event_on_join: evJoin,
        event_on_offer_click: evOffer,
        event_on_register: evReg,
        event_on_deposit: evDep,
        event_on_view: evView,
        event_on_lead: evLead,
        event_on_checkout: evCheckout,
        event_on_payment_info: evPayInfo,
        event_on_purchase: evPurchase,
        meta_pixel_id: metaPixelId || null,
        meta_access_token: accessToken || null,
        meta_test_event_code: testEventCode || null,
        dr_config: drConfig
      }
    }),
    onSuccess: () => {
      toast.success("Salvo");
      qc.invalidateQueries({
        queryKey: ["tracking-pixels"]
      });
      onClose();
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "space-y-4 max-h-[70vh] overflow-y-auto pr-2 -mr-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Nome" }),
        /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Modo de trackeamento" }),
        /* @__PURE__ */ jsxs(Select, { value: trackingMode, onValueChange: (v) => setTrackingMode(v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "telegram", children: MODE_PRESETS.telegram.label }),
            /* @__PURE__ */ jsx(SelectItem, { value: "direct_response", children: MODE_PRESETS.direct_response.label })
          ] })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: MODE_PRESETS[trackingMode].description })
      ] }),
      trackingMode === "direct_response" && /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Código do Pixel" }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx(Input, { readOnly: true, value: `<script> window.pixelId = "${pixel.id}"; var a = document.createElement("script"); a.setAttribute("async", ""); a.setAttribute("defer", ""); a.setAttribute("src", "${window.location.origin}/api/public/track/script.js"); document.head.appendChild(a); <\/script>`, className: "font-mono text-xs text-muted-foreground bg-muted/30" }),
            /* @__PURE__ */ jsx(Button, { variant: "outline", size: "icon", onClick: () => {
              navigator.clipboard.writeText(`<script> window.pixelId = "${pixel.id}"; var a = document.createElement("script"); a.setAttribute("async", ""); a.setAttribute("defer", ""); a.setAttribute("src", "${window.location.origin}/api/public/track/script.js"); document.head.appendChild(a); <\/script>`);
              toast.success("Código copiado!");
            }, children: /* @__PURE__ */ jsx(Code2, { className: "size-4" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-3 pt-2 border-t", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: "Regras Avançadas" }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2 bg-muted/20 p-3 rounded-lg border", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Regra de Lead (Envio de Lead)" }),
            /* @__PURE__ */ jsxs(Select, { value: drConfig.enable_lead ? "true" : "false", onValueChange: (v) => setDrConfig({
              ...drConfig,
              enable_lead: v === "true"
            }), children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "true", children: "Habilitado" }),
                /* @__PURE__ */ jsx(SelectItem, { value: "false", children: "Desabilitado" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2 bg-muted/20 p-3 rounded-lg border", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Regra de Add To Cart" }),
            /* @__PURE__ */ jsxs(Select, { value: drConfig.enable_add_to_cart ? "true" : "false", onValueChange: (v) => setDrConfig({
              ...drConfig,
              enable_add_to_cart: v === "true"
            }), children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "true", children: "Habilitado" }),
                /* @__PURE__ */ jsx(SelectItem, { value: "false", children: "Desabilitado" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-4 bg-muted/20 p-3 rounded-lg border", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs font-semibold", children: "Regra de Initiate Checkout" }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { className: "text-[10px]", children: "Envio de Initiate Checkout" }),
              /* @__PURE__ */ jsxs(Select, { value: drConfig.enable_initiate_checkout ? "true" : "false", onValueChange: (v) => setDrConfig({
                ...drConfig,
                enable_initiate_checkout: v === "true"
              }), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "true", children: "Habilitado" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "false", children: "Desabilitado" })
                ] })
              ] })
            ] }),
            drConfig.enable_initiate_checkout && /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { className: "text-[10px]", children: "Regra de Detecção / Marcar se o botão de compra contém a URL do checkout" }),
              /* @__PURE__ */ jsx(Input, { placeholder: "https://pay.cakto.com.br/", value: drConfig.initiate_checkout_url_contains, onChange: (e) => setDrConfig({
                ...drConfig,
                initiate_checkout_url_contains: e.target.value
              }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-4 bg-muted/20 p-3 rounded-lg border", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs font-semibold", children: "Regra de Purchase" }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx(Label, { className: "text-[10px]", children: "Configuração de envio" }),
              /* @__PURE__ */ jsxs(Select, { value: drConfig.purchase_approval_only ? "true" : "false", onValueChange: (v) => setDrConfig({
                ...drConfig,
                purchase_approval_only: v === "true"
              }), children: [
                /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
                /* @__PURE__ */ jsxs(SelectContent, { children: [
                  /* @__PURE__ */ jsx(SelectItem, { value: "true", children: "Apenas vendas aprovadas" }),
                  /* @__PURE__ */ jsx(SelectItem, { value: "false", children: "Todas as vendas" })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2 bg-muted/20 p-3 rounded-lg border", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Envio de IP nos eventos" }),
            /* @__PURE__ */ jsxs(Select, { value: drConfig.ipv6_enabled ? "true" : "false", onValueChange: (v) => setDrConfig({
              ...drConfig,
              ipv6_enabled: v === "true"
            }), children: [
              /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
              /* @__PURE__ */ jsxs(SelectContent, { children: [
                /* @__PURE__ */ jsx(SelectItem, { value: "true", children: "Enviar IPv6 se houver. Enviar IPv4 se não houver IPv6" }),
                /* @__PURE__ */ jsx(SelectItem, { value: "false", children: "Apenas IPv4" })
              ] })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx(Label, { children: "Vertical" }),
        /* @__PURE__ */ jsxs(Select, { value: vertical, onValueChange: setVertical, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsx(SelectContent, { children: VERTICALS.map((v) => /* @__PURE__ */ jsx(SelectItem, { value: v, children: VERTICAL_LABEL[v] }, v)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-lg border p-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Ativo" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Desligado: nenhum evento é registrado." })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: isActive, onCheckedChange: setIsActive })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3 pt-2 border-t", children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: "Eventos Meta por etapa" }),
        trackingMode === "telegram" ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(EventRow, { label: "Entrada no bot", value: evJoin, onChange: setEvJoin }),
          /* @__PURE__ */ jsx(EventRow, { label: "Clique na oferta", value: evOffer, onChange: setEvOffer }),
          /* @__PURE__ */ jsx(EventRow, { label: "Cadastro", value: evReg, onChange: setEvReg }),
          /* @__PURE__ */ jsx(EventRow, { label: "Depósito", value: evDep, onChange: setEvDep })
        ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(EventRow, { label: "Visualização da página", value: evView, onChange: setEvView }),
          /* @__PURE__ */ jsx(EventRow, { label: "Lead qualificado", value: evLead, onChange: setEvLead }),
          /* @__PURE__ */ jsx(EventRow, { label: "Iniciou checkout", value: evCheckout, onChange: setEvCheckout }),
          /* @__PURE__ */ jsx(EventRow, { label: "Dados de pagamento", value: evPayInfo, onChange: setEvPayInfo }),
          /* @__PURE__ */ jsx(EventRow, { label: "Compra confirmada", value: evPurchase, onChange: setEvPurchase })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-3 pt-2 border-t", children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold", children: "Credenciais Meta (CAPI)" }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "ID do Pixel" }),
            /* @__PURE__ */ jsx(Input, { value: metaPixelId, onChange: (e) => setMetaPixelId(e.target.value), placeholder: "123456789012345" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Test Event Code" }),
            /* @__PURE__ */ jsx(Input, { value: testEventCode, onChange: (e) => setTestEventCode(e.target.value), placeholder: "TEST12345" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Token de Integração" }),
          /* @__PURE__ */ jsx(Textarea, { value: accessToken, onChange: (e) => setAccessToken(e.target.value), rows: 2, className: "font-mono text-xs", placeholder: "EAAB..." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(DialogFooter, { className: "mt-4", children: /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: "Salvar" }) })
  ] });
}
function EventRow({
  label,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
    /* @__PURE__ */ jsx(Label, { className: "text-sm", children: label }),
    /* @__PURE__ */ jsxs(Select, { value, onValueChange: onChange, children: [
      /* @__PURE__ */ jsx(SelectTrigger, { className: "w-56", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
      /* @__PURE__ */ jsx(SelectContent, { children: EVENT_OPTIONS.map((o) => /* @__PURE__ */ jsx(SelectItem, { value: o, children: o === "off" ? "Desativado" : o }, o)) })
    ] })
  ] });
}
export {
  PixelsPage as component
};
