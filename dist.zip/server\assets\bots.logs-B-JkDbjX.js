import { jsxs, jsx } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { s as supabase } from "./client-bD0og8Nx.js";
import { S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, B as Button, C as Card, O as CardHeader, Q as CardTitle, x as CardContent, H as Badge } from "./router-Cw6OHOsO.js";
import { ScrollText, RefreshCw } from "lucide-react";
import { useState } from "react";
import "@supabase/supabase-js";
import "@tanstack/react-router";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const eventColor = {
  received: "bg-blue-500/15 text-blue-500 border-blue-500/30",
  sent: "bg-emerald-500/15 text-emerald-500 border-emerald-500/30",
  skipped: "bg-amber-500/15 text-amber-500 border-amber-500/30",
  failed: "bg-rose-500/15 text-rose-500 border-rose-500/30"
};
function BotLogsPage() {
  const [bot, setBot] = useState("all");
  const [event, setEvent] = useState("all");
  const q = useQuery({
    queryKey: ["bot-logs", bot, event],
    queryFn: async () => {
      let query = supabase.from("bot_execution_logs").select("*").order("created_at", {
        ascending: false
      }).limit(200);
      if (bot !== "all") query = query.eq("bot_type", bot);
      if (event !== "all") query = query.eq("event", event);
      const {
        data,
        error
      } = await query;
      if (error) throw error;
      return data ?? [];
    },
    refetchInterval: 8e3
  });
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(ScrollText, { className: "size-6 text-primary" }),
          " Logs dos Bots"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Eventos recebidos e envios feitos por BoasVindas e Encaminhador." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxs(Select, { value: bot, onValueChange: setBot, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-44", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos os bots" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "boasvindas", children: "BotBoasVindas" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "encaminhador", children: "BotEncaminhador" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Select, { value: event, onValueChange: setEvent, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-44", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos eventos" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "received", children: "Recebidos" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "sent", children: "Enviados" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "skipped", children: "Ignorados" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "failed", children: "Falhas" })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "icon", onClick: () => q.refetch(), children: /* @__PURE__ */ jsx(RefreshCw, { className: "size-4" }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Últimos 200 eventos" }) }),
      /* @__PURE__ */ jsx(CardContent, { className: "p-0", children: /* @__PURE__ */ jsxs("div", { className: "divide-y divide-border/60", children: [
        (q.data ?? []).map((row) => /* @__PURE__ */ jsxs("div", { className: "px-4 py-3 grid gap-1 text-sm", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
            /* @__PURE__ */ jsx(Badge, { variant: "outline", className: eventColor[row.event] ?? "", children: row.event }),
            /* @__PURE__ */ jsx(Badge, { variant: "outline", children: row.bot_type }),
            /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: new Date(row.created_at).toLocaleString("pt-BR") }),
            row.chat_id && /* @__PURE__ */ jsxs("span", { className: "text-xs text-muted-foreground", children: [
              "chat: ",
              /* @__PURE__ */ jsx("code", { children: row.chat_id })
            ] }),
            row.target_chat_id && /* @__PURE__ */ jsxs("span", { className: "text-xs text-muted-foreground", children: [
              "→ ",
              /* @__PURE__ */ jsx("code", { children: row.target_chat_id })
            ] }),
            row.tg_first_name && /* @__PURE__ */ jsxs("span", { className: "text-xs", children: [
              "👤 ",
              row.tg_first_name,
              row.tg_username ? ` (@${row.tg_username})` : ""
            ] })
          ] }),
          row.message && /* @__PURE__ */ jsx("div", { className: "text-xs text-foreground/80 line-clamp-2 whitespace-pre-wrap", children: row.message }),
          row.error && /* @__PURE__ */ jsxs("div", { className: "text-xs text-rose-500", children: [
            "erro: ",
            row.error
          ] })
        ] }, row.id)),
        q.data?.length === 0 && /* @__PURE__ */ jsx("div", { className: "px-4 py-10 text-center text-sm text-muted-foreground", children: "Nenhum evento ainda. Adicione o bot a um canal/grupo e aguarde." })
      ] }) })
    ] })
  ] });
}
export {
  BotLogsPage as component
};
