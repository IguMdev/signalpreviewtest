import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useRef, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { P as Popover, J as PopoverTrigger, B as Button, K as PopoverContent, I as Input, M as getPremiumEmojiThumbs } from "./router-Cw6OHOsO.js";
import { Sparkles, Search } from "lucide-react";
const DB_NAME = "premium-emoji-cache";
const STORE = "thumbs";
const VERSION = 1;
let dbPromise = null;
function openDb() {
  if (typeof indexedDB === "undefined") {
    return Promise.reject(new Error("IndexedDB indisponível"));
  }
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: "custom_emoji_id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}
async function getCachedEmojis(ids) {
  const result = /* @__PURE__ */ new Map();
  if (!ids.length) return result;
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const store = tx.objectStore(STORE);
      let pending = ids.length;
      for (const id of ids) {
        const req = store.get(id);
        req.onsuccess = () => {
          if (req.result) result.set(id, req.result);
          if (--pending === 0) resolve();
        };
        req.onerror = () => {
          if (--pending === 0) resolve();
        };
      }
      tx.onerror = () => reject(tx.error);
    });
  } catch {
  }
  return result;
}
async function putCachedEmojis(items) {
  if (!items.length) return;
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      const store = tx.objectStore(STORE);
      const now = Date.now();
      for (const it of items) {
        store.put({ ...it, cached_at: now });
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
  }
}
function insertAtCursor(el, current, insert, onChange) {
  if (!el) {
    onChange(current + insert);
    return;
  }
  const start = el.selectionStart ?? current.length;
  const end = el.selectionEnd ?? current.length;
  const next = current.slice(0, start) + insert + current.slice(end);
  onChange(next);
  requestAnimationFrame(() => {
    el.focus();
    const pos = start + insert.length;
    el.setSelectionRange(pos, pos);
  });
}
async function decodeTgsDataUrl(dataUrl) {
  const base64 = dataUrl.split(",")[1] ?? "";
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  const win = window;
  if (!win.DecompressionStream) return null;
  const stream = new Blob([bytes]).stream().pipeThrough(new win.DecompressionStream("gzip"));
  return JSON.parse(await new Response(stream).text());
}
function EmojiFallback({ fallback }) {
  return /* @__PURE__ */ jsx("span", { className: "text-xl leading-none", children: fallback ?? "✨" });
}
function TgsEmojiMedia({ src, className, animate, fallback }) {
  const ref = useRef(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    let destroyed = false;
    let animation = null;
    decodeTgsDataUrl(src).then(async (animationData) => {
      if (!animationData || destroyed || !ref.current) return setFailed(true);
      const lottie = await import("lottie-web");
      if (destroyed || !ref.current) return;
      animation = lottie.default.loadAnimation({
        container: ref.current,
        renderer: "svg",
        loop: animate,
        autoplay: animate,
        animationData
      });
      if (!animate) animation.goToAndStop(0, true);
    }).catch(() => setFailed(true));
    return () => {
      destroyed = true;
      animation?.destroy();
    };
  }, [src, animate]);
  if (failed) return /* @__PURE__ */ jsx(EmojiFallback, { fallback });
  return /* @__PURE__ */ jsx("div", { ref, className: `${className} [&_svg]:!block` });
}
function PremiumEmojiMedia({ cached, fallback, className = "size-7", animate = false }) {
  if (cached?.thumb_data_url) {
    if (cached.thumb_mime === "video/webm") {
      return /* @__PURE__ */ jsx("video", { src: cached.thumb_data_url, autoPlay: animate, loop: animate, muted: true, playsInline: true, preload: "metadata", className: `${className} object-contain`, onLoadedMetadata: (e) => {
        if (!animate) {
          e.currentTarget.currentTime = 0;
          e.currentTarget.pause();
        }
      } });
    }
    if (cached.thumb_mime?.startsWith("image/")) {
      return /* @__PURE__ */ jsx("img", { src: cached.thumb_data_url, alt: "", className: `${className} object-contain` });
    }
    if (cached.thumb_mime === "application/x-tgsticker") {
      return /* @__PURE__ */ jsx(TgsEmojiMedia, { src: cached.thumb_data_url, className, animate, fallback });
    }
  }
  return /* @__PURE__ */ jsx(EmojiFallback, { fallback });
}
function isTextControl(el) {
  return el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement;
}
function isPickerTextControl(el) {
  return !!el.closest("[data-premium-emoji-picker]");
}
function setTextControlCursor(el, pos) {
  const prevScrollTop = el.scrollTop;
  const prevScrollLeft = el.scrollLeft;
  try {
    el.focus({ preventScroll: true });
    el.setSelectionRange(pos, pos);
  } catch {
    try {
      el.focus({ preventScroll: true });
    } catch {
      el.focus();
    }
  }
  el.scrollTop = prevScrollTop;
  el.scrollLeft = prevScrollLeft;
}
function PremiumEmojiPicker({ value, onChange, targetRef, size = "sm", className }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [thumbs, setThumbs] = useState(/* @__PURE__ */ new Map());
  const fetchThumbs = useServerFn(getPremiumEmojiThumbs);
  const internalRef = useRef(null);
  const ref = targetRef ?? internalRef;
  const savedSelection = useRef(null);
  const captureSelection = (candidate) => {
    let el = null;
    if (isTextControl(candidate)) {
      el = candidate;
    } else if (ref.current) {
      el = ref.current;
    } else if (isTextControl(document.activeElement)) {
      el = document.activeElement;
    }
    if (!el || isPickerTextControl(el) || typeof el.selectionStart !== "number" || typeof el.selectionEnd !== "number") {
      return;
    }
    savedSelection.current = {
      el,
      start: el.selectionStart ?? el.value.length,
      end: el.selectionEnd ?? el.value.length
    };
  };
  useEffect(() => {
    const rememberSelection = (event) => captureSelection(event.target);
    document.addEventListener("focusin", rememberSelection);
    document.addEventListener("selectionchange", rememberSelection);
    document.addEventListener("mouseup", rememberSelection);
    document.addEventListener("keyup", rememberSelection);
    document.addEventListener("input", rememberSelection);
    return () => {
      document.removeEventListener("focusin", rememberSelection);
      document.removeEventListener("selectionchange", rememberSelection);
      document.removeEventListener("mouseup", rememberSelection);
      document.removeEventListener("keyup", rememberSelection);
      document.removeEventListener("input", rememberSelection);
    };
  }, [ref]);
  const list = useQuery({
    queryKey: ["emojis", "picker"],
    enabled: open,
    queryFn: async () => {
      const { data, error } = await supabase.from("premium_emojis").select("id, name, custom_emoji_id, preview_char").order("name");
      if (error) throw error;
      return data;
    }
  });
  useEffect(() => {
    if (!list.data?.length) return;
    const ids = list.data.map((e) => e.custom_emoji_id);
    getCachedEmojis(ids).then(async (cached) => {
      setThumbs(cached);
      const missing = ids.filter((id) => {
        const item = cached.get(id);
        return !item?.thumb_data_url || item.thumb_mime === "application/x-tgsticker";
      });
      if (!missing.length) return;
      const previewById = new Map(list.data.map((e) => [e.custom_emoji_id, e.preview_char]));
      for (let i = 0; i < missing.length; i += 24) {
        const fresh = await fetchThumbs({ data: { ids: missing.slice(i, i + 24) } }).catch(() => null);
        if (!fresh?.ok || !fresh.items.length) continue;
        await putCachedEmojis(fresh.items.map((it) => ({ custom_emoji_id: it.custom_emoji_id, preview_char: previewById.get(it.custom_emoji_id) ?? null, thumb_data_url: it.thumb_data_url, thumb_mime: it.thumb_mime })));
        setThumbs((prev) => new Map([...prev, ...fresh.items.map((it) => [it.custom_emoji_id, { ...it, preview_char: previewById.get(it.custom_emoji_id) ?? null, cached_at: Date.now() }])]));
      }
    });
  }, [list.data, fetchThumbs]);
  const filtered = useMemo(() => {
    const items = list.data ?? [];
    const term = q.trim().toLowerCase();
    if (!term) return items;
    return items.filter((e) => e.name.toLowerCase().includes(term));
  }, [list.data, q]);
  const insert = (name) => {
    const token = `{${name}}`;
    const saved = savedSelection.current;
    if (saved) {
      const start = Math.min(saved.start, value.length);
      const end = Math.min(Math.max(saved.end, start), value.length);
      const next = value.slice(0, start) + token + value.slice(end);
      onChange(next);
      const pos = start + token.length;
      requestAnimationFrame(() => {
        setTextControlCursor(saved.el, pos);
      });
    } else {
      insertAtCursor(ref.current, value, token, onChange);
    }
    setOpen(false);
  };
  return /* @__PURE__ */ jsxs(Popover, { open, onOpenChange: (next) => {
    if (next) captureSelection();
    setOpen(next);
  }, children: [
    /* @__PURE__ */ jsx(PopoverTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
      Button,
      {
        type: "button",
        variant: "outline",
        size: size === "sm" ? "sm" : "default",
        className,
        onPointerDown: () => captureSelection(),
        title: "Inserir emoji premium",
        children: [
          /* @__PURE__ */ jsx(Sparkles, { className: "size-4 text-amber-400" }),
          size !== "sm" && /* @__PURE__ */ jsx("span", { className: "ml-1", children: "Emoji premium" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsx(PopoverContent, { className: "w-80 p-3", align: "end", "data-premium-emoji-picker": true, children: /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsx(Search, { className: "size-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsx(
          Input,
          {
            placeholder: "Buscar emoji premium...",
            value: q,
            onChange: (e) => setQ(e.target.value),
            className: "pl-8 h-8 text-sm",
            autoFocus: true
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { className: "max-h-64 overflow-y-auto -mx-1 px-1", children: list.isLoading ? /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground py-6 text-center", children: "Carregando..." }) : filtered.length === 0 ? /* @__PURE__ */ jsx("div", { className: "text-xs text-muted-foreground py-6 text-center", children: list.data?.length ? "Nenhum emoji corresponde." : "Nenhum emoji premium salvo ainda." }) : /* @__PURE__ */ jsx("div", { className: "grid grid-cols-6 gap-1", children: filtered.map((e) => /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => insert(e.name),
          className: "flex flex-col items-center justify-center gap-0.5 rounded-md p-1.5 hover:bg-accent transition",
          title: `{${e.name}}`,
          children: [
            /* @__PURE__ */ jsx(PremiumEmojiMedia, { cached: thumbs.get(e.custom_emoji_id), fallback: e.preview_char }),
            /* @__PURE__ */ jsx("span", { className: "text-[9px] font-mono uppercase truncate w-full text-center text-muted-foreground", children: e.name })
          ]
        },
        e.id
      )) }) }),
      /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-muted-foreground text-center pt-1 border-t", children: [
        "Insere ",
        /* @__PURE__ */ jsx("code", { className: "font-mono", children: "{NOME}" }),
        " na posição do cursor."
      ] })
    ] }) })
  ] });
}
export {
  PremiumEmojiPicker as P,
  PremiumEmojiMedia as a,
  getCachedEmojis as g,
  putCachedEmojis as p
};
