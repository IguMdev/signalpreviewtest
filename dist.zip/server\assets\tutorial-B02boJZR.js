import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { C as Card, B as Button } from "./router-Cw6OHOsO.js";
import { u as useTour } from "./TourProvider-BQMn7Vcx.js";
import { PlayCircle, LayoutDashboard, Send, Sparkles, Users, UserPlus, CalendarClock, Video, Wallet, UserCircle } from "lucide-react";
import "@tanstack/react-query";
import "@tanstack/react-router";
import "react";
import "./client-bD0og8Nx.js";
import "@supabase/supabase-js";
import "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "react-dom";
const steps = [{
  id: "welcome",
  title: "Bem-vindo ao tour guiado",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Vamos passar por cada ferramenta da plataforma. Use os botões ",
    /* @__PURE__ */ jsx("b", { children: "Próximo" }),
    " e",
    /* @__PURE__ */ jsx("b", { children: " Anterior" }),
    " (ou as setas do teclado) para navegar. Pressione ",
    /* @__PURE__ */ jsx("b", { children: "Esc" }),
    " para sair a qualquer momento."
  ] }),
  placement: "center",
  route: "/tutorial"
}, {
  id: "dashboard",
  title: "Dashboard",
  description: "Visão geral da operação: créditos disponíveis, contas Telegram conectadas, bots ativos, salas, planos ativos e a evolução de membros por grupo / canal.",
  selector: '[data-tour="nav-dashboard"]',
  route: "/dashboard",
  placement: "right"
}, {
  id: "telegram-accounts",
  title: "Contas Telegram",
  description: "Conecte e gerencie seus bots do Telegram aqui. Cada conta usa um token do BotFather e é o que de fato envia mensagens, vídeos e mídias para os grupos e canais.",
  selector: '[data-tour="nav-telegram-accounts"]',
  route: "/telegram-accounts",
  placement: "right"
}, {
  id: "add-account",
  title: "Como cadastrar uma conta",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Clique em ",
    /* @__PURE__ */ jsx("b", { children: "Adicionar Conta" }),
    " para abrir o formulário. Você vai precisar do",
    " ",
    /* @__PURE__ */ jsx("b", { children: "token do bot" }),
    ' (gerado no @BotFather do Telegram) e de um rótulo para identificá-lo. Para contas premium, escolha o tipo "Premium" e siga os passos de autenticação.'
  ] }),
  selector: '[data-tour="add-account"]',
  route: "/telegram-accounts",
  placement: "left"
}, {
  id: "premium-emojis",
  title: "Emojis Premium",
  description: "Cadastre e organize seus emojis premium personalizados para deixar as mensagens dos canais com identidade visual única.",
  selector: '[data-tour="nav-premium-emojis"]',
  route: "/premium-emojis",
  placement: "right"
}, {
  id: "rooms",
  title: "Salas",
  description: "Uma sala agrupa um conjunto de chats (grupos / canais) e a corretora vinculada. É a partir das salas que você dispara conteúdos, mensagens agendadas e vídeos.",
  selector: '[data-tour="nav-rooms"]',
  route: "/rooms",
  placement: "right"
}, {
  id: "add-room",
  title: "Como criar uma sala",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Clique em ",
    /* @__PURE__ */ jsx("b", { children: "Adicionar sala" }),
    " e preencha: ",
    /* @__PURE__ */ jsx("b", { children: "ID do grupo / canal" }),
    " do Telegram, nome, corretora vinculada e a conta Telegram padrão que vai operar essa sala. Depois de criada você pode adicionar mais chats à mesma sala."
  ] }),
  selector: '[data-tour="add-room"]',
  route: "/rooms",
  placement: "left"
}, {
  id: "membros",
  title: "Membros",
  description: "Acompanhe entradas, saídas e o saldo de membros em cada grupo ou canal. Use os filtros para isolar uma sala específica e ver o histórico de eventos.",
  selector: '[data-tour="nav-membros"]',
  route: "/membros",
  placement: "right"
}, {
  id: "mensagens",
  title: "Agendamentos",
  description: "Programe mensagens recorrentes ou pontuais para seus canais. Defina conteúdo, horário e qual sala / bot vai enviar — o sistema dispara automaticamente.",
  selector: '[data-tour="nav-mensagens"]',
  route: "/mensagens",
  placement: "right"
}, {
  id: "add-schedule",
  title: "Como criar um agendamento",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Em cada sala, clique em ",
    /* @__PURE__ */ jsx("b", { children: "Adicionar" }),
    ". No formulário você define: ",
    /* @__PURE__ */ jsx("b", { children: "título" }),
    ",",
    /* @__PURE__ */ jsx("b", { children: " conteúdo" }),
    " da mensagem (texto, mídia ou vídeo já cadastrado), ",
    /* @__PURE__ */ jsx("b", { children: "conta" }),
    " que vai enviar e os ",
    /* @__PURE__ */ jsx("b", { children: "horários" }),
    " de disparo. Pode adicionar vários horários para o mesmo agendamento."
  ] }),
  selector: '[data-tour="add-schedule"]',
  route: "/mensagens",
  placement: "left"
}, {
  id: "videos",
  title: "Vídeos",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Faça upload de vídeos para enviar ao Telegram em dois formatos:",
    " ",
    /* @__PURE__ */ jsx("b", { children: "redondo" }),
    " (video note quadrado, até 60s) ou ",
    /* @__PURE__ */ jsx("b", { children: "normal" }),
    " (vídeo comum, até 50 MB). Selecione o tipo antes de subir o arquivo."
  ] }),
  selector: '[data-tour="nav-videos"]',
  route: "/videos",
  placement: "right"
}, {
  id: "video-upload",
  title: "Como enviar um vídeo",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Escolha o ",
    /* @__PURE__ */ jsx("b", { children: "Tipo" }),
    " (redondo ou normal), selecione o arquivo MP4, dê um ",
    /* @__PURE__ */ jsx("b", { children: "título" }),
    " e clique em ",
    /* @__PURE__ */ jsx("b", { children: "Enviar" }),
    ". Depois de salvo, use o botão ",
    /* @__PURE__ */ jsx("b", { children: "Enviar agora" }),
    " no card do vídeo para disparar para uma sala específica."
  ] }),
  selector: '[data-tour="video-upload"]',
  route: "/videos",
  placement: "top"
}, {
  id: "recarga",
  title: "Recarga",
  description: "Adicione créditos à sua conta e gerencie seus planos ativos. Os créditos são consumidos por envios e funcionalidades premium.",
  selector: '[data-tour="nav-recarga"]',
  route: "/recarga",
  placement: "right"
}, {
  id: "recharge-plans",
  title: "Como fazer a recarga",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "Escolha um ",
    /* @__PURE__ */ jsx("b", { children: "plano de sala" }),
    " ou um pacote de bot (Inscritos, Interações, Boas-vindas ou Encaminhador) e clique no botão de ",
    /* @__PURE__ */ jsx("b", { children: "Comprar" }),
    ". Você é redirecionado ao checkout seguro e os créditos / planos são liberados automaticamente após o pagamento."
  ] }),
  selector: '[data-tour="recharge-plans"]',
  route: "/recarga",
  placement: "top"
}, {
  id: "perfil",
  title: "Minha conta",
  description: "Atualize seus dados pessoais, foto de perfil e preferências. Aqui também ficam as opções de segurança da conta.",
  selector: '[data-tour="nav-perfil"]',
  route: "/perfil",
  placement: "right"
}, {
  id: "tutorial-footer",
  title: "Sempre disponível",
  description: /* @__PURE__ */ jsxs(Fragment, { children: [
    "O ",
    /* @__PURE__ */ jsx("b", { children: "Tutorial" }),
    " fica fixo no rodapé do menu lateral. Volte aqui sempre que quiser revisar uma ferramenta ou clicar em ",
    /* @__PURE__ */ jsx("b", { children: "Reiniciar tutorial" }),
    " para começar do zero."
  ] }),
  selector: '[data-tour="nav-tutorial"]',
  route: "/tutorial",
  placement: "right"
}, {
  id: "done",
  title: "Tudo pronto!",
  description: "Você concluiu o tour. Pode rodar de novo a qualquer momento clicando em 'Iniciar tour' nesta página. Bons sinais!",
  placement: "center",
  route: "/tutorial"
}];
const features = [{
  icon: LayoutDashboard,
  label: "Dashboard",
  text: "Visão geral da sua operação."
}, {
  icon: Send,
  label: "Contas Telegram",
  text: "Conecte os bots que enviam mensagens."
}, {
  icon: Sparkles,
  label: "Emojis Premium",
  text: "Personalize a identidade visual."
}, {
  icon: Users,
  label: "Salas",
  text: "Agrupe chats e corretora."
}, {
  icon: UserPlus,
  label: "Membros",
  text: "Entradas, saídas e saldo."
}, {
  icon: CalendarClock,
  label: "Agendamentos",
  text: "Mensagens programadas."
}, {
  icon: Video,
  label: "Vídeos",
  text: "Redondos ou normais para o Telegram."
}, {
  icon: Wallet,
  label: "Recarga",
  text: "Créditos e planos ativos."
}, {
  icon: UserCircle,
  label: "Minha conta",
  text: "Perfil e segurança."
}];
function TutorialPage() {
  const {
    start
  } = useTour();
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Tutorial" }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Faça um tour guiado pela plataforma. Vamos destacar cada ferramenta no menu e explicar o que ela faz." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "font-semibold", children: "Tour interativo" }),
        /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground", children: [
          steps.length,
          " passos · cerca de 3 minutos. Vamos te mostrar como cadastrar conta, criar agendamento, enviar vídeo e fazer a recarga."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Button, { onClick: () => start(steps), size: "lg", children: [
        /* @__PURE__ */ jsx(PlayCircle, { className: "size-5" }),
        "Iniciar tour"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h2", { className: "font-semibold mb-3", children: "O que você vai aprender" }),
      /* @__PURE__ */ jsx("div", { className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3", children: features.map(({
        icon: Icon,
        label,
        text
      }) => /* @__PURE__ */ jsxs(Card, { className: "p-4 flex gap-3 items-start", children: [
        /* @__PURE__ */ jsx("div", { className: "size-9 rounded-lg bg-primary/10 text-primary grid place-items-center shrink-0", children: /* @__PURE__ */ jsx(Icon, { className: "size-4" }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium text-sm", children: label }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: text })
        ] })
      ] }, label)) })
    ] })
  ] });
}
export {
  TutorialPage as component
};
