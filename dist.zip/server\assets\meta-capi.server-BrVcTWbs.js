import { createHash } from "crypto";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
const GRAPH_VERSION = "v21.0";
function sha256(value) {
  if (!value) return void 0;
  const v = value.trim().toLowerCase();
  if (!v) return void 0;
  return createHash("sha256").update(v).digest("hex");
}
const META_EVENT_SPECS = {
  // Conversão de valor — value+currency são OBRIGATÓRIOS
  Purchase: { required: ["value", "currency"], recommended: ["content_ids", "content_type", "num_items"], monetary: true },
  Subscribe: { required: ["value", "currency"], recommended: ["predicted_ltv"], monetary: true },
  StartTrial: { required: ["value", "currency"], recommended: ["predicted_ltv"], monetary: true },
  // Eventos com value/currency RECOMENDADOS (não falham se ausentes, mas perdem otimização)
  AddPaymentInfo: { required: [], recommended: ["value", "currency", "content_ids", "content_category"] },
  AddToCart: { required: [], recommended: ["value", "currency", "content_ids", "content_type", "content_name"] },
  AddToWishlist: { required: [], recommended: ["value", "currency", "content_name", "content_category"] },
  InitiateCheckout: { required: [], recommended: ["value", "currency", "content_ids", "num_items"] },
  Donate: { required: [], recommended: ["value", "currency"] },
  // Conteúdo / leads
  ViewContent: { required: [], recommended: ["content_ids", "content_type", "content_name", "value", "currency"] },
  Search: { required: [], recommended: ["search_string", "content_ids", "content_category"] },
  Lead: { required: [], recommended: ["content_name", "content_category", "value", "currency"] },
  CompleteRegistration: { required: [], recommended: ["content_name", "status", "value", "currency"] },
  Contact: { required: [], recommended: [] },
  CustomizeProduct: { required: [], recommended: [] },
  FindLocation: { required: [], recommended: [] },
  Schedule: { required: [], recommended: [] },
  SubmitApplication: { required: [], recommended: [] },
  // App / engajamento
  Rate: { required: [], recommended: [] },
  SpentCredits: { required: [], recommended: ["value"] },
  AchievementUnlocked: { required: [], recommended: [] },
  ActivateApp: { required: [], recommended: [] },
  CompleteTutorial: { required: [], recommended: [] },
  LevelAchieved: { required: [], recommended: [] },
  UnlockAchievement: { required: [], recommended: [] },
  // Pixel-equivalentes
  PageView: { required: [], recommended: [] },
  AdImpression: { required: [], recommended: [] },
  AdClick: { required: [], recommended: [] }
};
function applyMetaEventDefaults(eventName, customData) {
  const spec = META_EVENT_SPECS[eventName];
  const data = { ...customData ?? {} };
  if (spec?.monetary) {
    if (data.value == null || Number.isNaN(Number(data.value))) data.value = 0;
    if (!data.currency) data.currency = "BRL";
  }
  const missingRequired = [];
  const warnings = [];
  if (spec) {
    for (const f of spec.required) {
      const v = data[f];
      if (v == null || v === "") missingRequired.push(f);
    }
    for (const f of spec.recommended) {
      const v = data[f];
      if (v == null || v === "") warnings.push(`missing recommended field: ${f}`);
    }
  } else {
    warnings.push(`unknown event "${eventName}" — sending as custom event`);
  }
  return { customData: data, missingRequired, warnings };
}
async function sendMetaEvent(opts) {
  try {
    const { customData: finalCustomData, missingRequired, warnings } = applyMetaEventDefaults(
      opts.eventName,
      opts.customData
    );
    if (missingRequired.length > 0) {
      const err = `Evento "${opts.eventName}" inválido: campos obrigatórios ausentes em custom_data: ${missingRequired.join(", ")}`;
      try {
        await supabaseAdmin.from("meta_event_logs").insert({
          user_id: opts.userId,
          event_name: opts.eventName,
          event_id: opts.eventId ?? null,
          ok: false,
          error: err
        });
      } catch {
      }
      return { ok: false, error: err };
    }
    if (warnings.length > 0) {
      console.warn("[meta-capi]", opts.eventName, warnings.join("; "));
    }
    const { data: integ } = await supabaseAdmin.from("meta_integrations").select("pixel_id, access_token, test_event_code, is_active").eq("user_id", opts.userId).maybeSingle();
    if (!integ || !integ.is_active || !integ.pixel_id || !integ.access_token) {
      return { ok: false, error: "no_integration" };
    }
    const ud = opts.userData ?? {};
    const userData = {
      em: ud.email ? [sha256(ud.email)] : void 0,
      ph: ud.phone ? [sha256(ud.phone.replace(/\D/g, ""))] : void 0,
      external_id: ud.externalId != null ? [sha256(String(ud.externalId))] : void 0,
      fn: ud.firstName ? [sha256(ud.firstName)] : void 0,
      ln: ud.lastName ? [sha256(ud.lastName)] : void 0,
      client_ip_address: ud.clientIp ?? void 0,
      client_user_agent: ud.userAgent ?? void 0,
      fbp: ud.fbp ?? void 0,
      fbc: ud.fbc ?? void 0
    };
    Object.keys(userData).forEach((k) => userData[k] === void 0 && delete userData[k]);
    const event = {
      event_name: opts.eventName,
      event_time: opts.eventTime ?? Math.floor(Date.now() / 1e3),
      action_source: opts.actionSource ?? "system_generated",
      event_id: opts.eventId,
      event_source_url: opts.eventSourceUrl,
      user_data: userData,
      custom_data: finalCustomData
    };
    Object.keys(event).forEach((k) => event[k] === void 0 && delete event[k]);
    const body = { data: [event] };
    if (integ.test_event_code) body.test_event_code = integ.test_event_code;
    const url = `https://graph.facebook.com/${GRAPH_VERSION}/${integ.pixel_id}/events?access_token=${encodeURIComponent(integ.access_token)}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    const json = await res.json().catch(() => ({}));
    const ok = res.ok && !json?.error;
    await supabaseAdmin.from("meta_event_logs").insert({
      user_id: opts.userId,
      event_name: opts.eventName,
      event_id: opts.eventId ?? null,
      ok,
      request_payload: body,
      response_payload: json,
      error: ok ? null : json?.error?.message ?? `HTTP ${res.status}`
    });
    return ok ? { ok: true } : { ok: false, error: json?.error?.message ?? `HTTP ${res.status}` };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    try {
      await supabaseAdmin.from("meta_event_logs").insert({
        user_id: opts.userId,
        event_name: opts.eventName,
        event_id: opts.eventId ?? null,
        ok: false,
        error: msg
      });
    } catch {
    }
    return { ok: false, error: msg };
  }
}
export {
  sendMetaEvent as s
};
