import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { createRootRouteWithContext, useRouter, Link, Outlet, HeadContent, Scripts, createFileRoute, lazyRouteComponent, redirect, createRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import * as React from "react";
import { useState, useEffect, createContext, useContext } from "react";
import { s as supabase } from "./client-bD0og8Nx.js";
import { Toaster as Toaster$1 } from "sonner";
import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { c as createSsrRpc, a as allocateAndAutoDispatch, r as runEngagementOrdersSync, t as triggerSignalReactions } from "./engagement.functions-BnPQkoHV.js";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X, ChevronDown, Check, ChevronUp } from "lucide-react";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { z } from "zod";
import { randomBytes, createHash, timingSafeEqual } from "crypto";
import { s as sendMetaEvent } from "./meta-capi.server-BrVcTWbs.js";
import { STORE_CLIENTS } from "./registry.server-BHRe8HTK.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { m as mirrorIfMarked } from "./forwarder.server-aBU8sP40.js";
import { g as getUserEmojiLookup, r as renderEmojiTokens, s as sendPhotoWithPremiumEmojiCaption, a as sendTextWithPremiumEmojis, b as renderEmojiTokensToHtml, c as sendPhotoWithPremiumEmojiCaptionRetry, d as sendTextWithPremiumEmojisRetry, h as hasEmojiTokens, e as sendVideoWithPremiumEmojiCaption } from "./premium-send.server-B6I-0YLO.js";
import { n as nowParts$2, b as buildSlots, p as pickRandom, c as categoryFor, r as renderTemplate$2, g as getBinanceCandle, a as resolveBinary } from "./signals.server-CxsfAlOW.js";
import { l as loadVideoThumbnail, d as dispatchVideo, a as dispatchVideoNote } from "./videos.functions-DCpzn6E3.js";
import * as LabelPrimitive from "@radix-ui/react-label";
import * as PopoverPrimitive from "@radix-ui/react-popover";
import * as SwitchPrimitives from "@radix-ui/react-switch";
import * as SelectPrimitive from "@radix-ui/react-select";
const appCss = "/assets/styles-_YjQAJSa.css";
const AuthContext = createContext(void 0);
function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);
  const signOut = async () => {
    await supabase.auth.signOut();
  };
  return /* @__PURE__ */ jsx(AuthContext.Provider, { value: { user: session?.user ?? null, session, loading, signOut }, children });
}
function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
const ThemeContext = createContext(void 0);
const STORAGE_KEY = "telesignal-theme";
function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState("dark");
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const stored = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
    const initial = stored === "light" ? "light" : "dark";
    setThemeState(initial);
    setMounted(true);
  }, []);
  useEffect(() => {
    if (!mounted) return;
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
    }
  }, [theme, mounted]);
  const setTheme = (t) => setThemeState(t);
  const toggleTheme = () => setThemeState((p) => p === "dark" ? "light" : "dark");
  return /* @__PURE__ */ jsx(ThemeContext.Provider, { value: { theme, toggleTheme, setTheme, mounted }, children });
}
function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
const Toaster = ({ ...props }) => {
  return /* @__PURE__ */ jsx(
    Toaster$1,
    {
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
function NotFoundComponent() {
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxs("div", { className: "mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded text-left overflow-auto max-h-64", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-sm font-bold text-red-500", children: [
        error?.name,
        ": ",
        error?.message
      ] }),
      /* @__PURE__ */ jsx("pre", { className: "text-xs text-red-400 mt-2 whitespace-pre-wrap font-mono", children: error?.stack })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$T = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "TeleSignal" },
      { name: "description", content: "Gerencie e automatize contas do Telegram em larga escala." },
      { name: "author", content: "TeleSignal" },
      { property: "og:title", content: "TeleSignal" },
      { property: "og:description", content: "Painel para gerenciar contas Telegram, grupos e envio agendado de sinais." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@TeleSignal" },
      { name: "twitter:title", content: "TeleSignal" },
      { name: "twitter:description", content: "Painel para gerenciar contas Telegram, grupos e envio agendado de sinais." },
      { property: "og:image", content: "/favicon.png" },
      { name: "twitter:image", content: "/favicon.png" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      },
      { rel: "icon", type: "image/png", href: "/favicon.png" },
      { rel: "apple-touch-icon", href: "/favicon.png" }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxs("html", { lang: "pt-BR", className: "dark", children: [
    /* @__PURE__ */ jsxs("head", { children: [
      /* @__PURE__ */ jsx("script", { dangerouslySetInnerHTML: { __html: `
          try {
            if (localStorage.getItem('telesignal-theme') === 'light') {
              document.documentElement.classList.remove('dark');
            }
          } catch(e) {}
        ` } }),
      /* @__PURE__ */ jsx(HeadContent, {}),
      /* @__PURE__ */ jsx("script", { dangerouslySetInnerHTML: { __html: `
          if (typeof Node === 'function' && Node.prototype) {
            const originalRemoveChild = Node.prototype.removeChild;
            Node.prototype.removeChild = function(child) {
              if (child.parentNode !== this) {
                if (console) console.warn('Cannot remove a child from a different parent', child, this);
                return child;
              }
              return originalRemoveChild.apply(this, arguments);
            };
          
            const originalInsertBefore = Node.prototype.insertBefore;
            Node.prototype.insertBefore = function(newNode, referenceNode) {
              if (referenceNode && referenceNode.parentNode !== this) {
                if (console) console.warn('Cannot insert before a reference node from a different parent', referenceNode, this);
                return newNode;
              }
              return originalInsertBefore.apply(this, arguments);
            };
          }
        ` } })
    ] }),
    /* @__PURE__ */ jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$T.useRouteContext();
  return /* @__PURE__ */ jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsx(ThemeProvider, { children: /* @__PURE__ */ jsxs(AuthProvider, { children: [
    /* @__PURE__ */ jsx(Outlet, {}),
    /* @__PURE__ */ jsx(Toaster, { richColors: true, position: "top-right" })
  ] }) }) });
}
const $$splitComponentImporter$w = () => import("./signup-uP95RCKf.js");
const Route$S = createFileRoute("/signup")({
  component: lazyRouteComponent($$splitComponentImporter$w, "component")
});
const $$splitComponentImporter$v = () => import("./login-CpbdGRvr.js");
const Route$R = createFileRoute("/login")({
  component: lazyRouteComponent($$splitComponentImporter$v, "component")
});
const $$splitComponentImporter$u = () => import("./_authenticated-CiXR1mh3.js");
const Route$Q = createFileRoute("/_authenticated")({
  component: lazyRouteComponent($$splitComponentImporter$u, "component")
});
const $$splitComponentImporter$t = () => import("./index-D2nggIq-.js");
const Route$P = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "TeleSignal — Automação Telegram para Sinais, Promoções e Comunidades"
    }, {
      name: "description",
      content: "Plataforma all-in-one para criar bots, automatizar envios, gerenciar grupos VIP e escalar sua comunidade no Telegram."
    }, {
      property: "og:title",
      content: "TeleSignal — Automação Telegram"
    }, {
      property: "og:description",
      content: "Automatize sinais, promoções de afiliado, funis VIP e engajamento no Telegram em um único painel."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$t, "component")
});
const $$splitComponentImporter$s = () => import("./videos-Cc__zna3.js");
const Route$O = createFileRoute("/_authenticated/videos")({
  component: lazyRouteComponent($$splitComponentImporter$s, "component")
});
const $$splitComponentImporter$r = () => import("./tutorial-B02boJZR.js");
const Route$N = createFileRoute("/_authenticated/tutorial")({
  component: lazyRouteComponent($$splitComponentImporter$r, "component")
});
const $$splitComponentImporter$q = () => import("./telegram-accounts-Cho4G8t1.js");
const Route$M = createFileRoute("/_authenticated/telegram-accounts")({
  component: lazyRouteComponent($$splitComponentImporter$q, "component")
});
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = React.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
const Card = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx(
    "div",
    {
      ref,
      className: cn("rounded-xl border bg-card text-card-foreground shadow", className),
      ...props
    }
  )
);
Card.displayName = "Card";
const CardHeader = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("flex flex-col space-y-1.5 p-6", className), ...props })
);
CardHeader.displayName = "CardHeader";
const CardTitle = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx(
    "div",
    {
      ref,
      className: cn("font-semibold leading-none tracking-tight", className),
      ...props
    }
  )
);
CardTitle.displayName = "CardTitle";
const CardDescription = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("text-sm text-muted-foreground", className), ...props })
);
CardDescription.displayName = "CardDescription";
const CardContent = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("p-6 pt-0", className), ...props })
);
CardContent.displayName = "CardContent";
const CardFooter = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("flex items-center p-6 pt-0", className), ...props })
);
CardFooter.displayName = "CardFooter";
const badgeVariants = cva(
  "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
        outline: "text-foreground"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Badge({ className, variant, ...props }) {
  return /* @__PURE__ */ jsx("div", { className: cn(badgeVariants({ variant }), className), ...props });
}
const Input = React.forwardRef(
  ({ className, type, ...props }, ref) => {
    return /* @__PURE__ */ jsx(
      "input",
      {
        type,
        className: cn(
          "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Input.displayName = "Input";
const Table = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { className: "relative w-full overflow-auto", children: /* @__PURE__ */ jsx("table", { ref, className: cn("w-full caption-bottom text-sm", className), ...props }) })
);
Table.displayName = "Table";
const TableHeader = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx("thead", { ref, className: cn("[&_tr]:border-b", className), ...props }));
TableHeader.displayName = "TableHeader";
const TableBody = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx("tbody", { ref, className: cn("[&_tr:last-child]:border-0", className), ...props }));
TableBody.displayName = "TableBody";
const TableFooter = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  "tfoot",
  {
    ref,
    className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
    ...props
  }
));
TableFooter.displayName = "TableFooter";
const TableRow = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx(
    "tr",
    {
      ref,
      className: cn(
        "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
        className
      ),
      ...props
    }
  )
);
TableRow.displayName = "TableRow";
const TableHead = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  "th",
  {
    ref,
    className: cn(
      "h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className
    ),
    ...props
  }
));
TableHead.displayName = "TableHead";
const TableCell = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  "td",
  {
    ref,
    className: cn(
      "p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className
    ),
    ...props
  }
));
TableCell.displayName = "TableCell";
const TableCaption = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx("caption", { ref, className: cn("mt-4 text-sm text-muted-foreground", className), ...props }));
TableCaption.displayName = "TableCaption";
const Dialog = DialogPrimitive.Root;
const DialogTrigger = DialogPrimitive.Trigger;
const DialogPortal = DialogPrimitive.Portal;
const DialogOverlay = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Overlay,
  {
    ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props
  }
));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;
const DialogContent = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs(DialogPortal, { children: [
  /* @__PURE__ */ jsx(DialogOverlay, {}),
  /* @__PURE__ */ jsxs(
    DialogPrimitive.Content,
    {
      ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxs(DialogPrimitive.Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground", children: [
          /* @__PURE__ */ jsx(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Close" })
        ] })
      ]
    }
  )
] }));
DialogContent.displayName = DialogPrimitive.Content.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props }) => /* @__PURE__ */ jsx(
  "div",
  {
    className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
    ...props
  }
);
DialogFooter.displayName = "DialogFooter";
const DialogTitle = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Title,
  {
    ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props
  }
));
DialogTitle.displayName = DialogPrimitive.Title.displayName;
const DialogDescription = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  DialogPrimitive.Description,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
DialogDescription.displayName = DialogPrimitive.Description.displayName;
const generateWivenCheckout = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("a6eb9cfecce08eeca471a5584dd509eec92be5b9515d87e410241db9f4e87631"));
const generateDirectPix = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("fe9a16f4db01d7aec400648cf6b6d02a2e165627cc80ebce4dc8dbca82262f56"));
const generateDirectCard = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("b0cf405fbeeba96b0eb1db1c6c8fbd933356d60651d8e45d00afde4d9382a307"));
const $$splitComponentImporter$p = () => import("./recarga-bt0KHIZy.js");
const Route$L = createFileRoute("/_authenticated/recarga")({
  component: lazyRouteComponent($$splitComponentImporter$p, "component")
});
const $$splitComponentImporter$o = () => import("./premium-emojis-C7_MSsG1.js");
const Route$K = createFileRoute("/_authenticated/premium-emojis")({
  component: lazyRouteComponent($$splitComponentImporter$o, "component")
});
const $$splitComponentImporter$n = () => import("./perfil-C5hMk2FL.js");
const Route$J = createFileRoute("/_authenticated/perfil")({
  component: lazyRouteComponent($$splitComponentImporter$n, "component")
});
const $$splitComponentImporter$m = () => import("./notificacoes-BYHnhyUy.js");
const Route$I = createFileRoute("/_authenticated/notificacoes")({
  component: lazyRouteComponent($$splitComponentImporter$m, "component")
});
const $$splitComponentImporter$l = () => import("./mensagens-SdfDd4PM.js");
const Route$H = createFileRoute("/_authenticated/mensagens")({
  component: lazyRouteComponent($$splitComponentImporter$l, "component")
});
const $$splitComponentImporter$k = () => import("./membros-_rOZLGSO.js");
const Route$G = createFileRoute("/_authenticated/membros")({
  component: lazyRouteComponent($$splitComponentImporter$k, "component")
});
const $$splitComponentImporter$j = () => import("./dashboard-BK5nud_m.js");
const Route$F = createFileRoute("/_authenticated/dashboard")({
  component: lazyRouteComponent($$splitComponentImporter$j, "component")
});
const $$splitComponentImporter$i = () => import("./audios-BrPIkBxg.js");
const Route$E = createFileRoute("/_authenticated/audios")({
  component: lazyRouteComponent($$splitComponentImporter$i, "component")
});
const Route$D = createFileRoute("/_authenticated/trackeamento/")({
  beforeLoad: () => {
    throw redirect({ to: "/trackeamento/pixels" });
  }
});
const $$splitComponentImporter$h = () => import("./rooms.index-DEVCAkro.js");
const Route$C = createFileRoute("/_authenticated/rooms/")({
  component: lazyRouteComponent($$splitComponentImporter$h, "component")
});
const $$splitComponentImporter$g = () => import("./trackeamento.utms-B1YRUxaE.js");
const Route$B = createFileRoute("/_authenticated/trackeamento/utms")({
  component: lazyRouteComponent($$splitComponentImporter$g, "component")
});
const $$splitComponentImporter$f = () => import("./trackeamento.postbacks-DeOWO3UB.js");
const Route$A = createFileRoute("/_authenticated/trackeamento/postbacks")({
  validateSearch: (s) => ({
    pixel: typeof s.pixel === "string" ? s.pixel : void 0
  }),
  component: lazyRouteComponent($$splitComponentImporter$f, "component")
});
const $$splitComponentImporter$e = () => import("./trackeamento.pixels-Cz76SUrr.js");
const Route$z = createFileRoute("/_authenticated/trackeamento/pixels")({
  component: lazyRouteComponent($$splitComponentImporter$e, "component")
});
const $$splitComponentImporter$d = () => import("./trackeamento.metricas-UjaoWh1A.js");
const Route$y = createFileRoute("/_authenticated/trackeamento/metricas")({
  validateSearch: (s) => ({
    pixel: typeof s.pixel === "string" ? s.pixel : void 0
  }),
  component: lazyRouteComponent($$splitComponentImporter$d, "component")
});
const $$splitComponentImporter$c = () => import("./trackeamento.mensagens-a05BmN5p.js");
const Route$x = createFileRoute("/_authenticated/trackeamento/mensagens")({
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./trackeamento.integracoes-Df20aM4U.js");
const Route$w = createFileRoute("/_authenticated/trackeamento/integracoes")({
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
const $$splitComponentImporter$a = () => import("./trackeamento.funis-BYT4ZL5Y.js");
const Route$v = createFileRoute("/_authenticated/trackeamento/funis")({
  validateSearch: (s) => ({
    pixel: typeof s.pixel === "string" ? s.pixel : void 0
  }),
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./trackeamento.dominios-DhbXbKS6.js");
const Route$u = createFileRoute("/_authenticated/trackeamento/dominios")({
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./trackeamento.canal-BrQ7EUtn.js");
const Route$t = createFileRoute("/_authenticated/trackeamento/canal")({
  validateSearch: (s) => ({
    pixel: typeof s.pixel === "string" ? s.pixel : void 0
  }),
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./promocoes.estatisticas-Dv9rTEvu.js");
const Route$s = createFileRoute("/_authenticated/promocoes/estatisticas")({
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./promocoes.contas-CFJwaBGA.js");
const Route$r = createFileRoute("/_authenticated/promocoes/contas")({
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./integracoes.meta-CBMZawsm.js");
const Route$q = createFileRoute("/_authenticated/integracoes/meta")({
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./bots.logs-B-JkDbjX.js");
const Route$p = createFileRoute("/_authenticated/bots/logs")({
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./bots.followup-BH_vlnDl.js");
const Route$o = createFileRoute("/_authenticated/bots/followup")({
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./bots.encaminhador-BYLc-oxG.js");
const Route$n = createFileRoute("/_authenticated/bots/encaminhador")({
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./bots.boasvindas-BII4SSwl.js");
const Route$m = createFileRoute("/_authenticated/bots/boasvindas")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const Route$l = createFileRoute("/api/public/wiven/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const rawBody = await request.text();
          let payload;
          try {
            payload = JSON.parse(rawBody);
          } catch (e) {
            return new Response("Invalid JSON", { status: 400 });
          }
          console.log("=== WIVEN WEBHOOK RECEBIDO ===");
          console.log("Headers:", Object.fromEntries(request.headers));
          console.log("Payload:", payload);
          if (payload?.action === "TEST_PUSH" && payload?.userId) {
            const { data: u } = await supabaseAdmin.auth.admin.getUserById(payload.userId);
            const rawSettings = u?.user?.user_metadata?.push_settings || {};
            let title = "Venda aprovada!";
            if (rawSettings.show_dashboard !== false) title += " | igu.ads";
            let body = "";
            if (rawSettings.show_product) body += "Produto Teste\n";
            if (rawSettings.sale_value !== "hide") body += "Valor: R$ 99,90\n";
            if (rawSettings.show_utm) body += "UTM: campanha_teste";
            const { sendWebPushNotification: sendWebPushNotification2 } = await Promise.resolve().then(() => webpush_server);
            await sendWebPushNotification2(payload.userId, {
              title,
              body: body.trim() || "Sua comissão foi aprovada!",
              icon: "/push-icon.jpg"
            });
            return new Response("OK", { status: 200 });
          }
          const status = payload?.status || payload?.event_type || "";
          const email = payload?.customer?.email || payload?.email;
          const value = payload?.amount || payload?.value || null;
          const currency = payload?.currency || "BRL";
          const clickId = payload?.metadata?.click_id || payload?.utm_source || null;
          if (email || clickId) {
            let updateData = {};
            const now = (/* @__PURE__ */ new Date()).toISOString();
            const st = status.toLowerCase();
            if (st === "paid" || st === "approved" || st === "compra_aprovada") {
              updateData.purchased_at = now;
              if (value) {
                updateData.sale_value = value;
                updateData.sale_currency = currency;
              }
            } else if (st === "refunded" || st === "reembolso") {
              updateData.refunded_at = now;
            } else if (st === "chargeback") {
              updateData.chargeback_at = now;
            } else if (st === "abandoned_cart" || st === "abandono") {
              updateData.abandoned_cart_at = now;
            } else if (st === "checkout_started" || st === "checkout") {
              updateData.checkout_at = now;
            }
            if (Object.keys(updateData).length > 0) {
              const { createHash: createHash2 } = await import("crypto");
              const hashedEmail = email ? createHash2("sha256").update(email.trim().toLowerCase()).digest("hex") : null;
              let q = supabaseAdmin.from("tracking_clicks").update(updateData);
              if (clickId && clickId.length > 5) {
                q = q.eq("click_id", clickId);
              } else if (hashedEmail) {
                q = q.eq("external_id", hashedEmail);
              }
              await q;
            }
          }
          return new Response("OK", { status: 200 });
        } catch (err) {
          console.error("Wiven Webhook Error:", err);
          return new Response("Internal Server Error", { status: 500 });
        }
      }
    }
  }
});
const ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
function generateClickId(length = 12) {
  const bytes = randomBytes(length);
  let out = "";
  for (let i = 0; i < length; i++) {
    out += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return out;
}
function deriveFbc(fbc, fbclid) {
  if (fbc) return fbc;
  if (!fbclid) return null;
  return `fb.1.${Date.now()}.${fbclid}`;
}
const STAGE_TO_COLUMN = {
  join: "joined_at",
  offer_click: "clicked_offer_at",
  register: "registered_at",
  deposit: "deposited_at",
  view: "viewed_at",
  lead: "lead_at",
  checkout: "checkout_at",
  payment_info: "payment_info_at",
  purchase: "purchased_at",
  abandoned_cart: "abandoned_cart_at",
  chargeback: "chargeback_at",
  refund: "refunded_at"
};
async function fireTrackingEvent(opts) {
  const { data: click } = await supabaseAdmin.from("tracking_clicks").select("*, tracking_pixels(*)").eq("click_id", opts.clickId).maybeSingle();
  if (!click) return { ok: false, error: "click not found" };
  const pixel = click.tracking_pixels;
  if (!pixel) return { ok: false, error: "pixel not found" };
  if (!pixel.is_active) return { ok: false, error: "pixel inactive" };
  const sent = click.meta_events_sent ?? {};
  if (sent[opts.stage]) {
    return { ok: true, eventId: sent[opts.stage], eventName: "(already sent)" };
  }
  const eventName = opts.stage === "join" ? pixel.event_on_join : opts.stage === "offer_click" ? pixel.event_on_offer_click : opts.stage === "register" ? pixel.event_on_register : opts.stage === "deposit" ? pixel.event_on_deposit : opts.stage === "view" ? pixel.event_on_view : opts.stage === "lead" ? pixel.event_on_lead : opts.stage === "checkout" ? pixel.event_on_checkout : opts.stage === "payment_info" ? pixel.event_on_payment_info : opts.stage === "purchase" ? pixel.event_on_purchase : opts.stage === "abandoned_cart" ? "off" : opts.stage === "chargeback" ? "off" : opts.stage === "refund" ? "off" : "off";
  if (!eventName || eventName === "off") {
    return { ok: false, error: "event disabled for stage" };
  }
  const eventId = `${opts.clickId}:${opts.stage}`;
  const customData = {
    content_name: pixel.name,
    ...opts.extraCustomData ?? {}
  };
  if (opts.value != null) customData.value = opts.value;
  if (opts.currency) customData.currency = opts.currency;
  const userData = {
    fbp: click.fbp ?? void 0,
    fbc: deriveFbc(click.fbc, click.fbclid) ?? void 0,
    clientIp: click.ip ?? void 0,
    userAgent: click.user_agent ?? void 0,
    externalId: click.external_id ?? void 0,
    ...opts.extraUserData ?? {}
  };
  const result = await sendMetaEvent({
    userId: click.user_id,
    eventName,
    eventId,
    actionSource: "website",
    eventSourceUrl: click.landing_url ?? void 0,
    userData,
    customData
  });
  if (result.ok) {
    const nextSent = { ...sent, [opts.stage]: eventId };
    await supabaseAdmin.from("tracking_clicks").update({ meta_events_sent: nextSent, [STAGE_TO_COLUMN[opts.stage]]: (/* @__PURE__ */ new Date()).toISOString() }).eq("click_id", opts.clickId);
  }
  return { ok: result.ok, eventName, eventId, error: result.error };
}
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Postback-Secret",
    "Access-Control-Max-Age": "86400"
  };
}
function jsonCors(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(), "Content-Type": "application/json" }
  });
}
const bodySchema$2 = z.object({
  pixel_id: z.string().uuid(),
  fbp: z.string().max(200).nullish(),
  fbc: z.string().max(500).nullish(),
  fbclid: z.string().max(500).nullish(),
  ttclid: z.string().max(500).nullish(),
  gclid: z.string().max(500).nullish(),
  kwai_click_id: z.string().max(500).nullish(),
  utm_source: z.string().max(200).nullish(),
  utm_medium: z.string().max(200).nullish(),
  utm_campaign: z.string().max(200).nullish(),
  utm_content: z.string().max(200).nullish(),
  utm_term: z.string().max(200).nullish(),
  referrer: z.string().max(2e3).nullish(),
  landing_url: z.string().max(2e3).nullish(),
  external_id: z.string().max(200).nullish(),
  offer_slug: z.string().max(60).nullish()
});
const Route$k = createFileRoute("/api/public/track/click")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      POST: async ({ request }) => {
        let body;
        try {
          const raw = await request.json();
          body = bodySchema$2.parse(raw);
        } catch (e) {
          return jsonCors({ ok: false, error: e instanceof Error ? e.message : "invalid body" }, 400);
        }
        const { data: pixel } = await supabaseAdmin.from("tracking_pixels").select("id, user_id, is_active, account_id, bot_username").eq("id", body.pixel_id).maybeSingle();
        if (!pixel || !pixel.is_active) {
          return jsonCors({ ok: false, error: "pixel inactive or not found" }, 404);
        }
        const p = pixel;
        let botUsername = p.bot_username ?? null;
        if (!botUsername && p.account_id) {
          const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_username").eq("id", p.account_id).maybeSingle();
          botUsername = acc?.bot_username ?? null;
        }
        const ip = request.headers.get("cf-connecting-ip") ?? request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
        const userAgent = request.headers.get("user-agent");
        let clickId = generateClickId();
        for (let i = 0; i < 5; i++) {
          const { data: existing } = await supabaseAdmin.from("tracking_clicks").select("click_id").eq("click_id", clickId).maybeSingle();
          if (!existing) break;
          clickId = generateClickId();
        }
        const fbc = deriveFbc(body.fbc ?? null, body.fbclid ?? null);
        const { error: insertErr } = await supabaseAdmin.from("tracking_clicks").insert({
          click_id: clickId,
          pixel_id: p.id,
          user_id: p.user_id,
          fbp: body.fbp ?? null,
          fbc,
          fbclid: body.fbclid ?? null,
          ttclid: body.ttclid ?? null,
          gclid: body.gclid ?? null,
          kwai_click_id: body.kwai_click_id ?? null,
          utm_source: body.utm_source ?? null,
          utm_medium: body.utm_medium ?? null,
          utm_campaign: body.utm_campaign ?? null,
          utm_content: body.utm_content ?? null,
          utm_term: body.utm_term ?? null,
          ip,
          user_agent: userAgent,
          referrer: body.referrer ?? null,
          landing_url: body.landing_url ?? null,
          external_id: body.external_id ?? null
        });
        if (insertErr) {
          return jsonCors({ ok: false, error: insertErr.message }, 500);
        }
        let deeplink = null;
        if (botUsername) {
          deeplink = `https://t.me/${botUsername}?start=tk_${clickId}`;
        }
        return jsonCors({ ok: true, click_id: clickId, deeplink });
      }
    }
  }
});
const subscribeToWebPush = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  subscription: z.any()
}).parse(d)).handler(createSsrRpc("b0779274d026cee49e2f496b1308fdf4f5f1f3e5de91278300acb1c16518c541"));
const PushSettingsSchema = z.object({
  sales_pending: z.boolean().default(false),
  sales_approved: z.boolean().default(true),
  sale_value: z.enum(["total", "hide"]).default("total"),
  show_product: z.boolean().default(false),
  show_utm: z.boolean().default(false),
  show_dashboard: z.boolean().default(true),
  report_times: z.array(z.string()).default([]),
  report_style: z.enum(["profit", "summary", "creative"]).default("profit")
});
const getPushSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("9466a54ef971f4cd6a7a1443d5910ac11966795d1365e65adb861340118e6607"));
const updatePushSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => PushSettingsSchema.parse(d)).handler(createSsrRpc("21a2bd418abda5888124a9b90fafe712ec4ba263111a97f33cb800fa1e0c3392"));
async function sendWebPushNotification(userId, payload) {
  const {
    data,
    error
  } = await supabaseAdmin.auth.admin.getUserById(userId);
  if (error || !data.user || !data.user.user_metadata?.push_subscription) {
    return;
  }
  const push_subscription = data.user.user_metadata.push_subscription;
  try {
    const webpush = (await import("web-push")).default;
    const publicVapidKey = process.env.VAPID_PUBLIC_KEY || "";
    const privateVapidKey = process.env.VAPID_PRIVATE_KEY || "";
    if (publicVapidKey && privateVapidKey) {
      webpush.setVapidDetails("mailto:contato@telesignal.com.br", publicVapidKey, privateVapidKey);
    }
    await webpush.sendNotification(push_subscription, JSON.stringify(payload));
  } catch (error2) {
    console.error("Erro ao enviar Web Push:", error2);
  }
}
const webpush_server = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  PushSettingsSchema,
  getPushSettings,
  sendWebPushNotification,
  subscribeToWebPush,
  updatePushSettings
}, Symbol.toStringTag, { value: "Module" }));
const Route$j = createFileRoute("/api/public/kirvano/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const expected = process.env.KIRVANO_WEBHOOK_TOKEN;
        if (!expected) {
          return new Response("Webhook não configurado", { status: 503 });
        }
        const token = request.headers.get("x-kirvano-token") ?? request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
        if (token !== expected) {
          return new Response("Unauthorized", { status: 401 });
        }
        let payload;
        try {
          payload = await request.json();
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }
        const userId = payload.metadata?.user_id ?? payload.utm?.utm_content;
        const offerUrl = payload.product?.offer_url;
        const slug = payload.product?.slug;
        if (!userId) {
          return Response.json({ ok: false, error: "user_id ausente em metadata/utm_content" }, { status: 400 });
        }
        let planQuery = supabaseAdmin.from("engagement_plans").select("*").limit(1);
        if (offerUrl) planQuery = planQuery.eq("kirvano_checkout_url", offerUrl);
        else if (slug) planQuery = planQuery.eq("slug", slug);
        else return Response.json({ ok: false, error: "produto não identificado" }, { status: 400 });
        const { data: plan, error: planErr } = await planQuery.maybeSingle();
        if (planErr || !plan) {
          return Response.json({ ok: false, error: "plano não encontrado" }, { status: 404 });
        }
        const event = (payload.event ?? "").toUpperCase();
        const isApproved = event.includes("APPROVED") || event.includes("PAID") || event.includes("ACTIVE");
        const isCanceled = event.includes("CANCEL") || event.includes("REFUND") || event.includes("CHARGEBACK");
        if (isApproved) {
          try {
            await sendWebPushNotification(userId, {
              title: "Venda aprovada! | Telesignal",
              body: `Valor: ${payload.currency === "BRL" ? "R$ " : ""}${payload.total_price || ""}`,
              icon: "/favicon.ico"
            });
          } catch (e) {
          }
          const now = /* @__PURE__ */ new Date();
          const periodEnd = new Date(now);
          periodEnd.setMonth(periodEnd.getMonth() + 1);
          const { data: prevSub } = await supabaseAdmin.from("user_engagement_subscriptions").select("target_room_id").eq("user_id", userId).eq("bot_type", plan.bot_type).in("status", ["active", "pending", "canceled"]).not("target_room_id", "is", null).order("created_at", { ascending: false }).limit(1).maybeSingle();
          const inheritedRoomId = prevSub?.target_room_id ?? null;
          await supabaseAdmin.from("user_engagement_subscriptions").update({ status: "canceled" }).eq("user_id", userId).eq("bot_type", plan.bot_type).in("status", ["active", "pending"]);
          const { data: newSub, error: insErr } = await supabaseAdmin.from("user_engagement_subscriptions").insert({
            user_id: userId,
            plan_id: plan.id,
            bot_type: plan.bot_type,
            status: "active",
            current_period_start: now.toISOString(),
            current_period_end: periodEnd.toISOString(),
            kirvano_sale_id: payload.sale_id ?? null,
            kirvano_customer_email: payload.customer?.email ?? null,
            last_event: payload
          }).select("id").single();
          if (insErr) {
            return Response.json({ ok: false, error: insErr.message }, { status: 500 });
          }
          let autoDispatch = null;
          if (inheritedRoomId && newSub?.id && (plan.bot_type === "inscritos" || plan.bot_type === "interacoes")) {
            try {
              autoDispatch = await allocateAndAutoDispatch({
                userId,
                subscriptionId: newSub.id,
                roomId: inheritedRoomId
              });
            } catch (e) {
              autoDispatch = { ok: false, error: e instanceof Error ? e.message : String(e) };
            }
          }
          if (plan.bot_type === "salas" && (plan.monthly_quota ?? 0) > 0) {
            const { data: prof } = await supabaseAdmin.from("profiles").select("credits").eq("id", userId).maybeSingle();
            const current = prof?.credits ?? 0;
            await supabaseAdmin.from("profiles").update({ credits: current + plan.monthly_quota }).eq("id", userId);
            await supabaseAdmin.from("credit_transactions").insert({
              user_id: userId,
              delta: plan.monthly_quota,
              reason: `kirvano_${plan.slug}`
            });
          }
          return Response.json({ ok: true, action: "activated", inheritedRoomId, autoDispatch });
        }
        if (isCanceled && payload.sale_id) {
          await supabaseAdmin.from("user_engagement_subscriptions").update({ status: "canceled", last_event: payload }).eq("kirvano_sale_id", payload.sale_id);
          return Response.json({ ok: true, action: "canceled" });
        }
        return Response.json({ ok: true, action: "ignored", event });
      }
    }
  }
});
async function hashIp(ip) {
  const enc = new TextEncoder().encode(ip);
  const buf = await crypto.subtle.digest("SHA-256", enc);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
const Route$i = createFileRoute("/api/public/go/$dispatchId")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const { dispatchId } = params;
        const { data: disp } = await supabaseAdmin.from("promo_dispatches").select("affiliate_link, user_id").eq("id", dispatchId).maybeSingle();
        if (!disp) return new Response("Not found", { status: 404 });
        try {
          const ip = request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || "";
          const ipHash = ip ? await hashIp(ip.split(",")[0].trim()) : null;
          await supabaseAdmin.from("promo_clicks").insert({
            dispatch_id: dispatchId,
            user_id: disp.user_id,
            ip_hash: ipHash,
            user_agent: request.headers.get("user-agent") ?? null,
            referrer: request.headers.get("referer") ?? null,
            country: request.headers.get("cf-ipcountry") ?? null
          });
        } catch {
        }
        return new Response(null, {
          status: 302,
          headers: { Location: disp.affiliate_link, "Cache-Control": "no-store" }
        });
      }
    }
  }
});
const Route$h = createFileRoute("/api/public/cron/sync-promo-conversions")({
  server: {
    handlers: {
      POST: async () => {
        const startedAt = (/* @__PURE__ */ new Date()).toISOString();
        const { data: accounts, error } = await supabaseAdmin.from("affiliate_accounts").select("id,user_id,store,credentials,last_sync_at,is_active").eq("is_active", true);
        if (error) {
          return new Response(JSON.stringify({ ok: false, error: error.message }), {
            status: 500,
            headers: { "content-type": "application/json" }
          });
        }
        let total = 0;
        let failed = 0;
        const results = [];
        for (const acc of accounts ?? []) {
          const client = STORE_CLIENTS[acc.store];
          if (!client) continue;
          const since = acc.last_sync_at ? new Date(acc.last_sync_at) : new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3);
          try {
            const conversions = await client.fetchConversions(acc.credentials, since);
            let inserted = 0;
            for (const c of conversions) {
              const { data: existing } = await supabaseAdmin.from("promo_conversions").select("id,status,sale_value,commission_value").eq("user_id", acc.user_id).eq("store", c.store).eq("order_id", c.orderId).maybeSingle();
              let dispatchId = null;
              if (c.subId) {
                const { data: disp } = await supabaseAdmin.from("promo_dispatches").select("id").eq("user_id", acc.user_id).eq("external_id", c.subId).maybeSingle();
                dispatchId = disp?.id ?? null;
              }
              if (existing) {
                await supabaseAdmin.from("promo_conversions").update({
                  status: c.status,
                  sale_value: c.saleValue,
                  commission_value: c.commissionValue,
                  currency: c.currency,
                  confirmed_at: c.confirmedAt,
                  raw: c.raw,
                  dispatch_id: dispatchId ?? void 0
                }).eq("id", existing.id);
              } else {
                await supabaseAdmin.from("promo_conversions").insert({
                  user_id: acc.user_id,
                  store: c.store,
                  order_id: c.orderId,
                  sub_id: c.subId ?? null,
                  sale_value: c.saleValue,
                  commission_value: c.commissionValue,
                  currency: c.currency,
                  status: c.status,
                  confirmed_at: c.confirmedAt ?? null,
                  dispatch_id: dispatchId,
                  raw: c.raw
                });
                inserted += 1;
              }
              total += 1;
            }
            await supabaseAdmin.from("affiliate_accounts").update({ last_sync_at: (/* @__PURE__ */ new Date()).toISOString(), last_error: null }).eq("id", acc.id);
            results.push({ account_id: acc.id, store: acc.store, count: inserted });
          } catch (err) {
            failed += 1;
            await supabaseAdmin.from("affiliate_accounts").update({ last_error: String(err?.message ?? err).slice(0, 500) }).eq("id", acc.id);
            results.push({
              account_id: acc.id,
              store: acc.store,
              count: 0,
              error: String(err?.message ?? err)
            });
          }
        }
        return new Response(
          JSON.stringify({ ok: true, startedAt, processed: total, failed, results }),
          { status: 200, headers: { "content-type": "application/json" } }
        );
      }
    }
  }
});
const Route$g = createFileRoute("/api/public/cron/sync-engagement-orders")({
  server: {
    handlers: {
      POST: async () => {
        try {
          const result = await runEngagementOrdersSync({ limit: 100 });
          return Response.json({ ok: true, ...result });
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          return Response.json({ ok: false, error: msg }, { status: 500 });
        }
      }
    }
  }
});
const Route$f = createFileRoute("/api/public/cron/hot-teasers")({
  server: {
    handlers: {
      POST: async () => {
        const now = Date.now();
        const { data: funnels } = await supabaseAdmin.from("hot_vip_funnel").select("*").eq("enabled", true);
        let sent = 0;
        for (const f of funnels ?? []) {
          const intervalMs = (f.teaser_interval_hours ?? 3) * 3600 * 1e3;
          const last = f.last_teaser_at ? new Date(f.last_teaser_at).getTime() : 0;
          if (last + intervalMs > now) continue;
          const [{ data: teasers }, { data: chats }, { data: room }] = await Promise.all([
            supabaseAdmin.from("hot_teasers").select("*").eq("room_id", f.room_id).eq("is_active", true).order("sort_order"),
            supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", f.room_id),
            supabaseAdmin.from("rooms").select("default_account_id").eq("id", f.room_id).maybeSingle()
          ]);
          const list = teasers ?? [];
          if (!list.length || !chats?.length || !room?.default_account_id) continue;
          const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
          if (!acc?.bot_token) continue;
          const idx = Math.floor(now / intervalMs) % list.length;
          const teaser = list[idx];
          const inlineKb = f.vip_checkout_url ? { inline_keyboard: [[{ text: f.cta_button_text ?? "VIP 🔥", url: f.vip_checkout_url }]] } : void 0;
          for (const c of chats) {
            try {
              if (teaser.image_path) {
                await callTelegram(acc.bot_token, "sendPhoto", {
                  chat_id: c.chat_id,
                  photo: teaser.image_path,
                  caption: teaser.caption ?? "",
                  parse_mode: "HTML",
                  reply_markup: inlineKb
                });
              } else {
                await callTelegram(acc.bot_token, "sendMessage", {
                  chat_id: c.chat_id,
                  text: teaser.caption ?? "",
                  parse_mode: "HTML",
                  reply_markup: inlineKb
                });
              }
              sent += 1;
            } catch (e) {
              console.error("hot-teaser send failed", e);
            }
          }
          await supabaseAdmin.from("hot_vip_funnel").update({ last_teaser_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", f.id);
        }
        return Response.json({ ok: true, sent });
      }
    }
  }
});
function nowInSP() {
  const d = /* @__PURE__ */ new Date();
  const tz = "America/Sao_Paulo";
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    weekday: "short",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour12: false
  }).formatToParts(d);
  const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
  const wdMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return {
    hhmm: `${get("hour")}:${get("minute")}`,
    weekday: wdMap[get("weekday")] ?? 0,
    dateKey: `${get("year")}-${get("month")}-${get("day")}`
  };
}
const Route$e = createFileRoute("/api/public/cron/expert-engagement")({
  server: {
    handlers: {
      POST: async () => {
        const { hhmm, weekday, dateKey: dateKey2 } = nowInSP();
        const { data: prompts } = await supabaseAdmin.from("expert_engagement_prompts").select("*").eq("is_active", true);
        let sent = 0;
        for (const p of prompts ?? []) {
          const wd = p.weekdays ?? [];
          if (!wd.includes(weekday)) continue;
          const promptTime = (p.send_time ?? "").slice(0, 5);
          if (promptTime !== hhmm) continue;
          const last = p.last_sent_at ? new Date(p.last_sent_at).toISOString().slice(0, 10) : "";
          if (last === dateKey2) continue;
          const [{ data: chats }, { data: room }] = await Promise.all([
            supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", p.room_id),
            supabaseAdmin.from("rooms").select("default_account_id").eq("id", p.room_id).maybeSingle()
          ]);
          if (!chats?.length || !room?.default_account_id) continue;
          const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
          if (!acc?.bot_token) continue;
          for (const c of chats) {
            try {
              if (p.kind === "poll" && Array.isArray(p.options) && p.options.length >= 2) {
                await callTelegram(acc.bot_token, "sendPoll", {
                  chat_id: c.chat_id,
                  question: p.content,
                  options: p.options,
                  is_anonymous: true
                });
              } else {
                await callTelegram(acc.bot_token, "sendMessage", {
                  chat_id: c.chat_id,
                  text: p.content,
                  parse_mode: "HTML"
                });
              }
              sent += 1;
            } catch (e) {
              console.error("expert-engagement send failed", e);
            }
          }
          await supabaseAdmin.from("expert_engagement_prompts").update({ last_sent_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", p.id);
        }
        return Response.json({ ok: true, sent });
      }
    }
  }
});
function reportDateKey(date, tz) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(date);
  const get = (type) => parts.find((p) => p.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}
function aggregateTerminalStats(events, opts) {
  const todayKey = reportDateKey(opts.now, opts.tz);
  const inToday = events.filter(
    (e) => reportDateKey(new Date(e.entry_at), opts.tz) === todayKey
  );
  const terminal = inToday.filter((e) => {
    const st = String(e.status);
    if (st === "win" || st === "win_g1" || st === "win_g2") return true;
    if (st === "loss" && Number(e.gale_level ?? 0) >= Number(e.max_gales ?? 0)) return true;
    return false;
  });
  const totalWins = terminal.filter(
    (e) => ["win", "win_g1", "win_g2"].includes(String(e.status))
  ).length;
  const totalLosses = terminal.filter((e) => String(e.status) === "loss").length;
  const total = totalWins + totalLosses;
  const winRate = total ? Math.round(totalWins / total * 100) : 0;
  return { totalWins, totalLosses, total, winRate };
}
async function withRetry(fn, opts = {}) {
  const attempts = opts.attempts ?? 3;
  const base = opts.baseMs ?? 400;
  let lastErr;
  let lastRes;
  for (let i = 0; i < attempts; i++) {
    try {
      lastRes = await fn();
      const retry = opts.isRetryable ? opts.isRetryable(lastRes, void 0) : false;
      if (!retry) return lastRes;
    } catch (e) {
      lastErr = e;
      const retry = opts.isRetryable ? opts.isRetryable(void 0, e) : true;
      if (!retry) throw e;
    }
    if (i < attempts - 1) await new Promise((r) => setTimeout(r, base * Math.pow(2, i)));
  }
  if (lastRes !== void 0) return lastRes;
  throw lastErr ?? new Error("withRetry: exhausted attempts");
}
function asMessageIds(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
async function buildReplyMarkup(userId, buttons, kind) {
  const lookup = await getUserEmojiLookup(userId);
  const rows = buttons.filter((b) => b.template_kind === kind && b.label && b.url).sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)).map((b) => [{ text: renderEmojiTokens(b.label, lookup).text, url: b.url }]);
  return rows.length ? { inline_keyboard: rows } : void 0;
}
async function renderBotApiText(userId, text) {
  const lookup = await getUserEmojiLookup(userId);
  return renderEmojiTokensToHtml(text, lookup).text;
}
function fmtHHMM(d, tz) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).format(d);
}
function dirLabel(d) {
  return d === "buy" ? "🟢 COMPRA" : "🔴 VENDA";
}
async function sendToRoom(opts) {
  const out = {};
  for (const cid of opts.chatIds) {
    if (opts.imagePath) {
      const { data: pub } = supabaseAdmin.storage.from("room-images").getPublicUrl(opts.imagePath);
      const premiumPhoto = await sendPhotoWithPremiumEmojiCaption({
        userId: opts.userId,
        chatId: cid,
        photoUrl: pub.publicUrl,
        caption: opts.text,
        replyToMessageId: opts.replyTo?.[String(cid)],
        buttonRows: opts.replyMarkup?.inline_keyboard
      });
      if (premiumPhoto.applied && premiumPhoto.ok && premiumPhoto.messageId) {
        out[String(cid)] = premiumPhoto.messageId;
        continue;
      }
      const botText2 = await renderBotApiText(opts.userId, opts.text);
      const r2 = await withRetry(
        async () => {
          const res = await callTelegram(opts.botToken, "sendPhoto", {
            chat_id: cid,
            photo: pub.publicUrl,
            caption: botText2 || void 0,
            parse_mode: opts.parseMode || "HTML",
            reply_to_message_id: opts.replyTo?.[String(cid)],
            allow_sending_without_reply: true,
            reply_markup: opts.replyMarkup
          });
          if (!res.ok) console.error(`[dispatch-signals] Erro Telegram sendPhoto (chat ${cid}):`, res.description);
          return res;
        },
        { isRetryable: (res, err) => Boolean(err) || !res?.ok }
      ).catch((e) => {
        console.error(`[dispatch-signals] Exception em sendPhoto:`, e);
        return { ok: false };
      });
      if (r2.ok && r2.result?.message_id) out[String(cid)] = r2.result.message_id;
      continue;
    }
    const premium = await sendTextWithPremiumEmojis({
      userId: opts.userId,
      chatId: cid,
      text: opts.text,
      replyToMessageId: opts.replyTo?.[String(cid)],
      buttonRows: opts.replyMarkup?.inline_keyboard
    });
    if (premium.applied) {
      if (premium.ok && premium.messageId) {
        out[String(cid)] = premium.messageId;
      }
      continue;
    }
    const botText = await renderBotApiText(opts.userId, opts.text);
    const r = await withRetry(
      async () => {
        const res = await callTelegram(opts.botToken, "sendMessage", {
          chat_id: cid,
          text: botText,
          parse_mode: opts.parseMode || "HTML",
          reply_to_message_id: opts.replyTo?.[String(cid)],
          allow_sending_without_reply: true,
          reply_markup: opts.replyMarkup
        });
        if (!res.ok) console.error(`[dispatch-signals] Erro Telegram sendMessage (chat ${cid}):`, res.description);
        return res;
      },
      { isRetryable: (res, err) => Boolean(err) || !res?.ok }
    ).catch((e) => {
      console.error(`[dispatch-signals] Exception em sendMessage:`, e);
      return { ok: false };
    });
    if (r.ok && r.result?.message_id) out[String(cid)] = r.result.message_id;
  }
  return out;
}
async function getRoomContext(roomId) {
  const { data: room } = await supabaseAdmin.from("rooms").select("id, user_id, timezone, default_account_id, is_active").eq("id", roomId).maybeSingle();
  if (!room || !room.is_active) return null;
  const { data: chats } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", roomId);
  const { data: tpls } = await supabaseAdmin.from("room_templates").select("kind, content, parse_mode, image_path, image_mime, image_ext").eq("room_id", roomId);
  const { data: btns } = await supabaseAdmin.from("room_template_buttons").select("template_kind, label, url, sort_order").eq("room_id", roomId).order("sort_order", { ascending: true });
  let botToken = null;
  if (room.default_account_id) {
    const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
    botToken = acc?.bot_token ?? null;
  }
  return {
    room,
    chatIds: (chats ?? []).map((c) => Number(c.chat_id)),
    templates: tpls ?? [],
    buttons: btns ?? [],
    botToken
  };
}
function getTpl(list, kind, fallback) {
  return list.find((t) => t.kind === kind) ?? { kind, content: fallback, parse_mode: "HTML" };
}
async function scheduleSignals() {
  const { data: windows } = await supabaseAdmin.from("room_windows").select(
    "id, user_id, room_id, start_time, end_time, weekdays, signals_qty, asset_filter, use_all_assets, timeframes, max_losses, martingale, is_active"
  ).eq("is_active", true);
  if (!windows?.length) return 0;
  const now = /* @__PURE__ */ new Date();
  const nextMinute = new Date(
    Math.ceil((now.getTime() + 1) / 6e4) * 6e4 + 12e4
  );
  let scheduled = 0;
  for (const w of windows) {
    const { data: room } = await supabaseAdmin.from("rooms").select("timezone, is_active").eq("id", w.room_id).maybeSingle();
    if (!room?.is_active) continue;
    const tz = room?.timezone ?? "America/Sao_Paulo";
    const { weekday, hhmm: nowHHMM } = nowParts$2(tz);
    if (!w.weekdays.includes(weekday)) continue;
    const dispatchTime = new Date(nextMinute.getTime() - 12e4);
    const dispatchHHMM = fmtHHMM(dispatchTime, tz);
    const slots = buildSlots(w.start_time.slice(0, 5), w.end_time.slice(0, 5), w.signals_qty);
    if (!slots.includes(dispatchHHMM)) continue;
    const startStr = w.start_time.slice(0, 5);
    const endStr = w.end_time.slice(0, 5);
    const crossesMidnight = endStr < startStr;
    if (crossesMidnight) {
      const inWindow = nowHHMM >= startStr || nowHHMM < endStr;
      if (!inWindow) continue;
    } else {
      if (nowHHMM > endStr) continue;
    }
    let assetPool = [];
    if (w.use_all_assets || !w.asset_filter?.length) {
      const { data: ras } = await supabaseAdmin.from("room_assets").select("asset_code").eq("room_id", w.room_id).eq("is_open", true);
      assetPool = (ras ?? []).map((r) => r.asset_code);
    } else {
      assetPool = w.asset_filter;
    }
    if (!assetPool.length) continue;
    const asset = pickRandom(assetPool);
    const direction = Math.random() < 0.5 ? "buy" : "sell";
    const timeframe = pickRandom(w.timeframes?.length ? w.timeframes : ["M1"]);
    const expires = new Date(nextMinute.getTime() + 6e4);
    const { error } = await supabaseAdmin.from("signal_events").insert({
      user_id: w.user_id,
      room_id: w.room_id,
      window_id: w.id,
      asset_code: asset,
      asset_category: categoryFor(asset),
      direction,
      timeframe,
      entry_at: nextMinute.toISOString(),
      expires_at: expires.toISOString(),
      max_gales: w.martingale ?? 2,
      status: "scheduled"
    });
    if (!error) scheduled++;
  }
  return scheduled;
}
async function sendScheduled() {
  const now = /* @__PURE__ */ new Date();
  const horizon = new Date(now.getTime() + 125e3).toISOString();
  const { data: list } = await supabaseAdmin.from("signal_events").select("*").eq("status", "scheduled").lte("entry_at", horizon).limit(200);
  if (!list?.length) return 0;
  let sent = 0;
  for (const s of list) {
    const ctx = await getRoomContext(s.room_id);
    if (!ctx?.botToken || !ctx.chatIds.length) {
      await supabaseAdmin.from("signal_events").update({
        status: "error",
        last_error: "Sem bot/chats vinculados"
      }).eq("id", s.id);
      continue;
    }
    const tz = ctx.room.timezone;
    const entryAt = new Date(s.entry_at);
    const entryHHMM = fmtHHMM(entryAt, tz);
    const g1 = fmtHHMM(new Date(entryAt.getTime() + 6e4), tz);
    const g2 = fmtHHMM(new Date(entryAt.getTime() + 12e4), tz);
    const tpl = getTpl(
      ctx.templates,
      "signal",
      "✅ ENTRADA CONFIRMADA ✅\n🌎 Ativo: {ATIVO}\n⏳ Expiração: {TIMEFRAME}\n📊 Direção: {DIRECAO}\n⏰ Entrada: {ENTRADA}\n👉 Fazer até {MARTINGALE} POSIÇÕES em caso de loss!\nGale 1: {ENTRADAGALE1}\nGale 2: {ENTRADAGALE2}"
    );
    const text = renderTemplate$2(tpl.content, {
      ATIVO: s.asset_code,
      TIMEFRAME: s.timeframe,
      DIRECAO: dirLabel(s.direction),
      ENTRADA: entryHHMM,
      ENTRADAGALE1: g1,
      ENTRADAGALE2: g2,
      MARTINGALE: String(s.max_gales)
    });
    const signalReplyMarkup = await buildReplyMarkup(ctx.room.user_id, ctx.buttons, "signal");
    const ids = await sendToRoom({
      userId: ctx.room.user_id,
      botToken: ctx.botToken,
      chatIds: ctx.chatIds,
      text,
      parseMode: tpl.parse_mode,
      replyMarkup: signalReplyMarkup
    });
    await supabaseAdmin.from("signal_events").update({
      status: "sent",
      signal_message_ids: ids
    }).eq("id", s.id);
    for (const [cid, mid] of Object.entries(ids)) {
      await mirrorIfMarked({
        roomId: s.room_id,
        fromChatId: Number(cid),
        messageId: mid,
        origin: { kind: "template", id: "signal" },
        payload: {
          userId: ctx.room.user_id,
          content: text,
          parseMode: tpl.parse_mode,
          replyMarkup: signalReplyMarkup
        }
      });
    }
    sent++;
  }
  return sent;
}
async function resolveExpired() {
  const now = /* @__PURE__ */ new Date();
  const cutoff = new Date(now.getTime() - 15e3).toISOString();
  const { data: list } = await supabaseAdmin.from("signal_events").select("*").eq("status", "sent").lte("expires_at", cutoff).limit(100);
  if (!list?.length) return 0;
  let resolved = 0;
  for (const s of list) {
    const candle = await getBinanceCandle(s.asset_code, new Date(s.entry_at), s.timeframe);
    if (!candle) {
      const win = Math.random() < 0.85;
      await postResult(s, win ? "win" : "loss");
      resolved++;
      continue;
    }
    let result = resolveBinary(s.direction, candle.open, candle.close);
    if (result === "draw") {
      result = "win";
    }
    if (result === "loss" && Math.random() < 0.75) {
      result = "win";
      const variation = candle.open * 5e-4;
      candle.close = s.direction === "buy" ? candle.open + variation : candle.open - variation;
    }
    await postResult(s, result, candle);
    resolved++;
  }
  return resolved;
}
async function postResult(s, outcome, candle) {
  const ctx = await getRoomContext(s.room_id);
  if (!ctx?.botToken) {
    await supabaseAdmin.from("signal_events").update({
      status: "error",
      last_error: "bot ausente na resolução",
      entry_price: candle?.open ?? null,
      close_price: candle?.close ?? null
    }).eq("id", s.id);
    return;
  }
  const tplKind = outcome === "win" ? s.gale_level > 0 ? "win_martingale" : "win" : "loss";
  const fallback = outcome === "win" ? s.gale_level > 0 ? "✅ VITÓRIA no martingale {ATIVO} 🟢" : "✅ VITÓRIA no {ATIVO} 🟢" : "🔴 DERROTA no {ATIVO}";
  const tpl = getTpl(ctx.templates, tplKind, fallback);
  const text = renderTemplate$2(tpl.content, {
    ATIVO: s.asset_code,
    TIMEFRAME: s.timeframe,
    DIRECAO: dirLabel(s.direction),
    ENTRADA: ""
  });
  const replyTo = asMessageIds(s.signal_message_ids);
  const resultReplyMarkup = await buildReplyMarkup(ctx.room.user_id, ctx.buttons, tplKind);
  const ids = await sendToRoom({
    userId: ctx.room.user_id,
    botToken: ctx.botToken,
    chatIds: ctx.chatIds,
    text,
    parseMode: tpl.parse_mode,
    imagePath: tpl.image_path,
    replyTo,
    replyMarkup: resultReplyMarkup
  });
  for (const [cid, mid] of Object.entries(ids)) {
    await mirrorIfMarked({
      roomId: s.room_id,
      fromChatId: Number(cid),
      messageId: mid,
      origin: { kind: "template", id: tplKind },
      payload: {
        userId: ctx.room.user_id,
        content: text,
        parseMode: tpl.parse_mode,
        imagePath: tpl.image_path,
        replyMarkup: resultReplyMarkup
      }
    });
  }
  if (Object.keys(ids).length === 0 && ctx.chatIds.length > 0) {
    console.error(`[dispatch-signals][Error] SINAL ${s.id}: Nenhuma mensagem de ${outcome} (${tplKind}) foi entregue. Verifique possiveis quebras no HTML ou erros de parse do template!`);
  }
  if (outcome === "loss" && s.gale_level < (s.max_gales ?? 0)) {
    const nextEntry = new Date(new Date(s.entry_at).getTime() + 6e4 * (s.gale_level + 1));
    const nextExpires = new Date(nextEntry.getTime() + 6e4);
    const galeNumero = s.gale_level + 1;
    console.log(
      `[dispatch-signals][gale] LOSS room=${s.room_id} signal=${s.id} asset=${s.asset_code} dir=${s.direction} gale_level=${s.gale_level} max_gales=${s.max_gales} → disparando gale #${galeNumero} entry=${nextEntry.toISOString()}`
    );
    const galeTpl = getTpl(
      ctx.templates,
      "gale",
      "🔁 VAMOS PARA A {GALE_NUMERO}ª POSIÇÃO\n🌎 Ativo: {ATIVO}\n📊 Direção: {DIRECAO}\n⏰ Entrada: {ENTRADA}"
    );
    const galeVars = {
      ATIVO: s.asset_code,
      TIMEFRAME: s.timeframe,
      DIRECAO: dirLabel(s.direction),
      ENTRADA: fmtHHMM(nextEntry, ctx.room.timezone),
      GALE_NUMERO: String(galeNumero)
    };
    const galeText = renderTemplate$2(galeTpl.content, galeVars);
    console.log(
      `[dispatch-signals][gale] room=${s.room_id} vars=${JSON.stringify(galeVars)} chats=${ctx.chatIds.length} usingDefaultTpl=${ctx.templates.find((t) => t.kind === "gale") ? "no" : "yes"}`
    );
    const galeReplyMarkup = await buildReplyMarkup(ctx.room.user_id, ctx.buttons, "gale");
    const galeIds = await sendToRoom({
      userId: ctx.room.user_id,
      botToken: ctx.botToken,
      chatIds: ctx.chatIds,
      text: galeText,
      parseMode: galeTpl.parse_mode,
      imagePath: galeTpl.image_path,
      replyTo,
      replyMarkup: galeReplyMarkup
    });
    console.log(
      `[dispatch-signals][gale] room=${s.room_id} gale#${galeNumero} sent_to=${Object.keys(galeIds).length}/${ctx.chatIds.length} message_ids=${JSON.stringify(galeIds)}`
    );
    for (const [cid, mid] of Object.entries(galeIds)) {
      await mirrorIfMarked({
        roomId: s.room_id,
        fromChatId: Number(cid),
        messageId: mid,
        origin: { kind: "template", id: "gale" },
        payload: {
          userId: ctx.room.user_id,
          content: galeText,
          parseMode: galeTpl.parse_mode,
          imagePath: galeTpl.image_path,
          replyMarkup: galeReplyMarkup
        }
      });
    }
    await supabaseAdmin.from("signal_events").insert({
      user_id: s.user_id,
      room_id: s.room_id,
      window_id: s.window_id,
      asset_code: s.asset_code,
      asset_category: s.asset_category,
      direction: s.direction,
      timeframe: s.timeframe,
      entry_at: nextEntry.toISOString(),
      expires_at: nextExpires.toISOString(),
      gale_level: galeNumero,
      max_gales: s.max_gales ?? 0,
      status: "sent",
      // já consideramos enviado pois é continuação
      signal_message_ids: Object.keys(galeIds).length ? galeIds : replyTo
    });
  }
  const finalStatus = outcome === "win" ? s.gale_level === 0 ? "win" : s.gale_level === 1 ? "win_g1" : "win_g2" : "loss";
  await supabaseAdmin.from("signal_events").update({
    status: finalStatus,
    entry_price: candle?.open ?? null,
    close_price: candle?.close ?? null,
    result_message_ids: ids
  }).eq("id", s.id);
}
async function sendDueReports() {
  const { data: reports } = await supabaseAdmin.from("room_reports").select("user_id, room_id, enabled, delay_minutes, template, image_path").eq("enabled", true);
  if (!reports?.length) return 0;
  let sent = 0;
  const now = /* @__PURE__ */ new Date();
  for (const report of reports) {
    const ctx = await getRoomContext(report.room_id);
    if (!ctx?.botToken || !ctx.chatIds.length) continue;
    const { data: windows } = await supabaseAdmin.from("room_windows").select("id, name, end_time").eq("room_id", report.room_id).eq("is_active", true);
    for (const w of windows ?? []) {
      const tz = ctx.room.timezone;
      const tzNowHHMM = fmtHHMM(now, tz);
      const toMin = (s) => {
        const [h, m] = s.split(":").map(Number);
        return h * 60 + m;
      };
      const fromMin = (m) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
      const endMin = toMin(String(w.end_time).slice(0, 5));
      const delay = Math.max(0, Number(report.delay_minutes) || 0);
      const target = (endMin + delay) % 1440;
      if (tzNowHHMM !== fromMin(target)) continue;
      const windowDate = new Date(now.getTime() - delay * 6e4);
      const windowDay = reportDateKey(windowDate, tz);
      const key = `${windowDay}:${String(w.end_time).slice(0, 5)}`;
      const { data: claim } = await supabaseAdmin.from("room_report_runs").insert({ user_id: report.user_id, room_id: report.room_id, window_id: w.id, report_key: key }).select("id").maybeSingle();
      if (!claim) continue;
      const since = new Date(now.getTime() - 24 * 60 * 60 * 1e3).toISOString();
      const { data: stats } = await supabaseAdmin.from("signal_events").select("status, gale_level, max_gales, entry_at, asset_code").eq("room_id", report.room_id).eq("window_id", w.id).gte("entry_at", since);
      const { totalWins, totalLosses, total, winRate } = aggregateTerminalStats(
        stats ?? [],
        { tz, now: windowDate }
      );
      const todayKey = windowDay;
      const terminalList = (stats ?? []).filter((e) => reportDateKey(new Date(e.entry_at), tz) === todayKey).filter((e) => {
        const st = String(e.status);
        if (st === "win" || st === "win_g1" || st === "win_g2") return true;
        if (st === "loss" && Number(e.gale_level ?? 0) >= Number(e.max_gales ?? 0)) return true;
        return false;
      }).sort((a, b) => new Date(a.entry_at).getTime() - new Date(b.entry_at).getTime()).map((e) => {
        const isWin = String(e.status).startsWith("win");
        return `${fmtHHMM(new Date(e.entry_at), tz)} ${e.asset_code ?? "—"} ${isWin ? "✅" : "❌"}`;
      }).join("\n");
      const text = String(report.template || "📊 RELATÓRIO {SESSAO_NOME}\n{OPERACOES_LISTA}\n\n✅ Wins: {TOTAL_WINS}\n🔴 Losses: {TOTAL_LOSSES}\n📈 Operações: {TOTAL_OPERACOES}\n🎯 Win rate: {WIN_RATE}%").replaceAll("{SESSAO_NOME}", w.name ?? "Sessão").replaceAll("{TOTAL_WINS}", String(totalWins)).replaceAll("{TOTAL_LOSSES}", String(totalLosses)).replaceAll("{TOTAL_OPERACOES}", String(total)).replaceAll("{WIN_RATE}", String(winRate)).replaceAll("{OPERACOES_LISTA}", terminalList || "—");
      const ids = await sendToRoom({
        userId: report.user_id,
        botToken: ctx.botToken,
        chatIds: ctx.chatIds,
        text,
        parseMode: "HTML",
        imagePath: report.image_path
      });
      await supabaseAdmin.from("room_report_runs").update({ message_ids: ids }).eq("id", claim.id);
      if (Object.keys(ids).length) sent++;
    }
  }
  return sent;
}
const Route$d = createFileRoute("/api/public/cron/dispatch-signals")({
  server: {
    handlers: {
      POST: async () => {
        try {
          const [scheduled, sent, resolved, reports] = [
            await scheduleSignals(),
            await sendScheduled(),
            await resolveExpired(),
            await sendDueReports()
          ];
          return Response.json({ ok: true, scheduled, sent, resolved, reports });
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          return Response.json({ ok: false, error: msg }, { status: 500 });
        }
      },
      GET: async () => Response.json({ ok: true, hint: "Use POST" })
    }
  }
});
const PREMIUM_LOCK_ERROR$1 = "Envio bloqueado: a mensagem contém tokens {EMOJI} que não foram processados. Conecte uma conta Telegram Premium ativa e cadastre os emojis em Premium Emojis para liberar o envio.";
function nowParts$1(tz) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
  const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
  const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
  const wdMap = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 0 };
  const weekday = wdMap[get("weekday")] ?? 0;
  return { weekday, hhmm: `${get("hour").padStart(2, "0")}:${get("minute").padStart(2, "0")}` };
}
function dateKey(tz) {
  const fmt = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" });
  return fmt.format(/* @__PURE__ */ new Date());
}
function addMinutes(hhmm, delta) {
  const [h, m] = hhmm.split(":").map(Number);
  let total = h * 60 + m + delta;
  total = (total % 1440 + 1440) % 1440;
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}
const Route$c = createFileRoute("/api/public/cron/dispatch-sessions")({
  server: {
    handlers: {
      POST: async () => {
        const { data: windows } = await supabaseAdmin.from("room_windows").select("id, user_id, room_id, start_time, end_time, weekdays, is_active, last_session_fire, name").eq("is_active", true);
        if (!windows?.length) return Response.json({ ok: true, fired: 0 });
        let fired = 0;
        for (const w of windows) {
          const { data: room } = await supabaseAdmin.from("rooms").select("timezone, default_account_id, is_active").eq("id", w.room_id).maybeSingle();
          if (!room || !room.is_active) continue;
          const tz = room.timezone ?? "America/Sao_Paulo";
          const { weekday, hhmm } = nowParts$1(tz);
          if (!w.weekdays.includes(weekday)) continue;
          const { data: msgs } = await supabaseAdmin.from("room_session_messages").select("kind, enabled, lead_minutes, content, image_path").eq("room_id", w.room_id);
          if (!msgs?.length) continue;
          const today = dateKey(tz);
          const fireState = w.last_session_fire ?? {};
          const start = String(w.start_time).slice(0, 5);
          const end = String(w.end_time).slice(0, 5);
          for (const m of msgs) {
            if (!m.enabled) continue;
            const lead = Number(m.lead_minutes ?? 0) || 0;
            const targetHHMM = m.kind === "open" ? addMinutes(start, -lead) : addMinutes(end, lead);
            const tgtMin = (() => {
              const [h, mm] = targetHHMM.split(":").map(Number);
              return h * 60 + mm;
            })();
            const nowMin = (() => {
              const [h, mm] = hhmm.split(":").map(Number);
              return h * 60 + mm;
            })();
            if (nowMin < tgtMin || nowMin > tgtMin + 1) continue;
            const fireKey = `${w.id}:${m.kind}:${today}`;
            if (fireState[fireKey]) continue;
            const nextState = { ...fireState, [fireKey]: (/* @__PURE__ */ new Date()).toISOString() };
            await supabaseAdmin.from("room_windows").update({ last_session_fire: nextState }).eq("id", w.id);
            if (!room.default_account_id) continue;
            const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
            if (!acc?.bot_token) continue;
            const { data: chats } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", w.room_id);
            if (!chats?.length) continue;
            const baseContent = (m.content ?? "").replaceAll("{MINUTOS}", String(lead));
            const wantsPremium = hasEmojiTokens(baseContent);
            const imageUrl = m.image_path ? supabaseAdmin.storage.from("room-images").getPublicUrl(m.image_path).data.publicUrl : null;
            for (const c of chats) {
              let r = { ok: false };
              let premiumStatus = "plain";
              if (wantsPremium && imageUrl) {
                const pv = await sendPhotoWithPremiumEmojiCaptionRetry({
                  userId: w.user_id,
                  chatId: c.chat_id,
                  photoUrl: imageUrl,
                  caption: baseContent,
                  strict: true
                });
                if (pv.applied) {
                  premiumStatus = pv.ok ? "premium" : "blocked";
                  r = pv.ok ? { ok: true, result: { message_id: pv.messageId ?? void 0 } } : { ok: false, description: pv.error };
                }
              } else if (wantsPremium && !imageUrl && baseContent) {
                const pt = await sendTextWithPremiumEmojisRetry({
                  userId: w.user_id,
                  chatId: c.chat_id,
                  text: baseContent,
                  strict: true
                });
                if (pt.applied) {
                  premiumStatus = pt.ok ? "premium" : "blocked";
                  r = pt.ok ? { ok: true, result: { message_id: pt.messageId ?? void 0 } } : { ok: false, description: pt.error };
                }
              }
              if (premiumStatus === "plain") {
                if (wantsPremium) {
                  r = { ok: false, description: PREMIUM_LOCK_ERROR$1 };
                  premiumStatus = "blocked";
                } else if (imageUrl) {
                  r = await callTelegram(acc.bot_token, "sendPhoto", {
                    chat_id: c.chat_id,
                    photo: imageUrl,
                    caption: baseContent || void 0
                  });
                } else {
                  r = await callTelegram(acc.bot_token, "sendMessage", {
                    chat_id: c.chat_id,
                    text: baseContent
                  });
                }
              }
              await supabaseAdmin.from("message_logs").insert({
                user_id: w.user_id,
                account_id: room.default_account_id,
                room_id: w.room_id,
                source: `session_${m.kind}`,
                chat_id: c.chat_id,
                ok: r.ok,
                telegram_message_id: r.result?.message_id ?? null,
                error: r.ok ? null : r.description ?? "erro",
                premium_status: premiumStatus
              });
              if (r.ok) fired++;
            }
          }
        }
        return Response.json({ ok: true, fired });
      }
    }
  }
});
const PREMIUM_LOCK_ERROR = "Envio bloqueado: a mensagem contém tokens {EMOJI} que não foram processados. Conecte uma conta Telegram Premium ativa e cadastre os emojis em Premium Emojis para liberar o envio.";
async function sendCompanionButtonMessage(botToken, chatId, replyMarkup) {
  if (!replyMarkup) return { ok: true };
  return await callTelegram(botToken, "sendMessage", {
    chat_id: chatId,
    text: "⁣",
    reply_markup: replyMarkup
  });
}
async function withCompanionButton(primary, botToken, chatId, replyMarkup) {
  if (!primary.ok || !replyMarkup) return primary;
  const button = await sendCompanionButtonMessage(botToken, chatId, replyMarkup);
  if (!button.ok) {
    return {
      ok: false,
      result: primary.result,
      description: `Mensagem enviada, mas o botão falhou: ${button.description ?? "erro"}`
    };
  }
  return primary;
}
function nowParts(tz) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    weekday: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
  const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
  const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
  const wdMap = {
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
    Sun: 7
  };
  const weekday = wdMap[get("weekday")] ?? 0;
  const monthDay = parseInt(get("day"), 10) || 1;
  const hh = get("hour").padStart(2, "0");
  const mm = get("minute").padStart(2, "0");
  return { weekday, monthDay, hhmm: `${hh}:${mm}` };
}
async function sendOne(botToken, chatId, msg) {
  if (!msg.image_path && msg.content && msg.user_id && msg.is_premium) {
    const premium = await sendTextWithPremiumEmojisRetry({
      userId: msg.user_id,
      chatId,
      text: msg.content,
      strict: true
    });
    if (premium.applied) {
      return await withCompanionButton(
        premium.ok ? { ok: true, result: { message_id: premium.messageId ?? void 0 } } : { ok: false, description: premium.error },
        botToken,
        chatId,
        msg.reply_markup
      );
    }
  }
  if (msg.image_path) {
    const { data: pub } = supabaseAdmin.storage.from("room-images").getPublicUrl(msg.image_path);
    if (msg.is_premium && msg.user_id) {
      const premiumPhoto = await sendPhotoWithPremiumEmojiCaptionRetry({
        userId: msg.user_id,
        chatId,
        photoUrl: pub.publicUrl,
        caption: msg.content,
        strict: true
      });
      if (premiumPhoto.applied) {
        return await withCompanionButton(
          premiumPhoto.ok ? { ok: true, result: { message_id: premiumPhoto.messageId ?? void 0 } } : { ok: false, description: premiumPhoto.error },
          botToken,
          chatId,
          msg.reply_markup
        );
      }
    }
    if (hasEmojiTokens(msg.content)) {
      return { ok: false, description: PREMIUM_LOCK_ERROR };
    }
    return await callTelegram(botToken, "sendPhoto", {
      chat_id: chatId,
      photo: pub.publicUrl,
      caption: msg.content ?? void 0,
      parse_mode: msg.content ? msg.parse_mode : void 0,
      reply_markup: msg.reply_markup
    });
  }
  if (hasEmojiTokens(msg.content)) {
    return { ok: false, description: PREMIUM_LOCK_ERROR };
  }
  return await callTelegram(botToken, "sendMessage", {
    chat_id: chatId,
    text: msg.content ?? "",
    parse_mode: msg.parse_mode,
    reply_markup: msg.reply_markup,
    link_preview_options: { is_disabled: true }
  });
}
const Route$b = createFileRoute("/api/public/cron/dispatch-recurring")({
  server: {
    handlers: {
      POST: async () => {
        await supabaseAdmin.from("recurring_pending_followups").update({ status: "pending" }).eq("status", "sending").lt("scheduled_at", new Date(Date.now() - 5 * 60 * 1e3).toISOString());
        const { data: schedules, error } = await supabaseAdmin.from("recurring_schedules").select(
          "id, user_id, room_id, account_id, content, video_id, audio_id, image_path, image_mime, parse_mode, is_premium, times, weekdays, schedule_type, month_days, weekday_overrides, follow_ups, timezone, last_fire_key, button_text, button_url"
        ).eq("is_active", true);
        if (error) {
          return Response.json({ error: error.message }, { status: 500 });
        }
        const now = /* @__PURE__ */ new Date();
        const dateKey2 = now.toISOString().slice(0, 16);
        let processed = 0;
        let fired = 0;
        for (const s of schedules ?? []) {
          const { weekday, monthDay, hhmm } = nowParts(s.timezone);
          if (s.schedule_type === "monthly") {
            if (!s.month_days || !s.month_days.includes(monthDay)) continue;
            if (!s.times.includes(hhmm)) continue;
          } else {
            if (!s.weekdays.includes(weekday)) continue;
            const override = s.weekday_overrides?.[String(weekday)];
            const effectiveTimes = override && override.length > 0 ? override : s.times;
            if (!effectiveTimes.includes(hhmm)) continue;
          }
          if (s.last_fire_key === dateKey2) continue;
          const { data: claim } = await supabaseAdmin.from("recurring_schedules").update({ last_fire_key: dateKey2 }).eq("id", s.id).or(`last_fire_key.is.null,last_fire_key.neq.${dateKey2}`).select("id").maybeSingle();
          if (!claim) continue;
          processed++;
          let accountId = s.account_id;
          if (!accountId) {
            const { data: room } = await supabaseAdmin.from("rooms").select("default_account_id").eq("id", s.room_id).maybeSingle();
            accountId = room?.default_account_id ?? null;
          }
          if (!accountId) continue;
          const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", accountId).maybeSingle();
          const { data: chats } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", s.room_id);
          if (!acc || !chats?.length) continue;
          let video = null;
          if (s.video_id) {
            const { data: v } = await supabaseAdmin.from("videos").select("storage_path, mime_type, duration_seconds, title, kind, width, height").eq("id", s.video_id).maybeSingle();
            video = v ?? null;
          }
          let audio = null;
          if (s.audio_id) {
            const { data: a } = await supabaseAdmin.from("audios").select("storage_path, duration_seconds, title").eq("id", s.audio_id).maybeSingle();
            audio = a ?? null;
          }
          const isNormalVideo = video && video.kind === "normal";
          const replyMarkup = void 0;
          let okAny = false;
          for (const c of chats) {
            let r;
            const wantsPremium = s.is_premium || hasEmojiTokens(s.content);
            const premium = wantsPremium && !s.image_path && !video && s.content ? await sendTextWithPremiumEmojisRetry({
              userId: s.user_id,
              chatId: c.chat_id,
              text: s.content,
              strict: true
            }) : { applied: false };
            if (premium.applied) {
              r = await withCompanionButton(
                premium.ok ? { ok: true, result: { message_id: premium.messageId ?? void 0 } } : { ok: false, description: premium.error },
                acc.bot_token,
                c.chat_id,
                replyMarkup
              );
            } else
              r = s.image_path ? await (async () => {
                const { data: pub } = supabaseAdmin.storage.from("room-images").getPublicUrl(s.image_path);
                if (wantsPremium) {
                  const premiumPhoto = await sendPhotoWithPremiumEmojiCaptionRetry({
                    userId: s.user_id,
                    chatId: c.chat_id,
                    photoUrl: pub.publicUrl,
                    caption: s.content,
                    strict: true
                  });
                  if (premiumPhoto.applied) {
                    return await withCompanionButton(
                      premiumPhoto.ok ? {
                        ok: true,
                        result: { message_id: premiumPhoto.messageId ?? void 0 }
                      } : { ok: false, description: premiumPhoto.error },
                      acc.bot_token,
                      c.chat_id,
                      replyMarkup
                    );
                  }
                }
                if (hasEmojiTokens(s.content)) {
                  return { ok: false, description: PREMIUM_LOCK_ERROR };
                }
                return await callTelegram(acc.bot_token, "sendPhoto", {
                  chat_id: c.chat_id,
                  photo: pub.publicUrl,
                  caption: s.content ?? void 0,
                  parse_mode: s.content ? s.parse_mode : void 0,
                  reply_markup: replyMarkup
                });
              })() : video ? isNormalVideo ? await (async () => {
                if (wantsPremium && s.content && hasEmojiTokens(s.content)) {
                  const { data: file } = await supabaseAdmin.storage.from("videos").download(video.storage_path);
                  if (file) {
                    const bytes = await file.arrayBuffer();
                    const pv = await sendVideoWithPremiumEmojiCaption({
                      userId: s.user_id,
                      chatId: c.chat_id,
                      videoBytes: bytes,
                      thumbnailBytes: await loadVideoThumbnail(video.storage_path),
                      filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
                      mimeType: video.mime_type ?? "video/mp4",
                      duration: video.duration_seconds,
                      width: video.width,
                      height: video.height,
                      caption: s.content,
                      strict: true
                    });
                    if (pv.applied) {
                      return await withCompanionButton(
                        pv.ok ? { ok: true, result: { message_id: pv.messageId ?? void 0 } } : { ok: false, description: pv.error },
                        acc.bot_token,
                        c.chat_id,
                        replyMarkup
                      );
                    }
                  }
                }
                return await dispatchVideo({
                  botToken: acc.bot_token,
                  storagePath: video.storage_path,
                  chatId: c.chat_id,
                  duration: video.duration_seconds,
                  width: video.width,
                  height: video.height,
                  mimeType: video.mime_type,
                  filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
                  caption: s.content,
                  parseMode: s.parse_mode,
                  replyMarkup
                });
              })() : await dispatchVideoNote({
                botToken: acc.bot_token,
                storagePath: video.storage_path,
                chatId: c.chat_id,
                duration: video.duration_seconds,
                mimeType: video.mime_type,
                filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
              }) : audio ? await (async () => {
                const { data: fileData, error: error2 } = await supabaseAdmin.storage.from("audio-files").download(audio.storage_path);
                if (error2 || !fileData) return { ok: false, description: "Falha ao baixar áudio" };
                const bytes = await fileData.arrayBuffer();
                const { sendVoiceToChat } = await import("./audios.functions-DUKTM5eK.js");
                return await sendVoiceToChat({
                  botToken: acc.bot_token,
                  chatId: c.chat_id,
                  fileBytes: bytes,
                  filename: audio.title + ".ogg",
                  mimeType: "audio/ogg",
                  duration: audio.duration_seconds,
                  caption: s.content
                });
              })() : hasEmojiTokens(s.content) ? { ok: false, description: PREMIUM_LOCK_ERROR } : await callTelegram(acc.bot_token, "sendMessage", {
                chat_id: c.chat_id,
                text: s.content ?? "",
                parse_mode: s.parse_mode,
                reply_markup: replyMarkup,
                link_preview_options: { is_disabled: true }
              });
            await supabaseAdmin.from("message_logs").insert({
              user_id: s.user_id,
              account_id: accountId,
              chat_id: c.chat_id,
              ok: r.ok,
              telegram_message_id: r.result?.message_id ?? null,
              error: r.ok ? null : r.description ?? "erro"
            });
            if (r.ok) okAny = true;
            if (r.ok && r.result?.message_id) {
              await triggerSignalReactions({
                userId: s.user_id,
                chatId: c.chat_id,
                telegramMessageId: r.result.message_id,
                roomId: s.room_id
              });
              await mirrorIfMarked({
                roomId: s.room_id,
                fromChatId: c.chat_id,
                messageId: r.result.message_id,
                origin: { kind: "recurring", id: s.id },
                payload: {
                  userId: s.user_id,
                  content: s.content,
                  parseMode: s.parse_mode,
                  imagePath: s.image_path,
                  video: video && isNormalVideo ? {
                    storagePath: video.storage_path,
                    mimeType: video.mime_type,
                    duration: video.duration_seconds,
                    width: video.width,
                    height: video.height,
                    filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
                  } : null
                }
              });
            }
          }
          await supabaseAdmin.from("recurring_schedules").update({ last_sent_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", s.id);
          if (okAny) fired++;
          const fups = Array.isArray(s.follow_ups) ? s.follow_ups : [];
          if (fups.length > 0) {
            let cumulative = 0;
            const rows = fups.map((f) => {
              const sec = f.delay_seconds != null && Number(f.delay_seconds) > 0 ? Number(f.delay_seconds) : Math.max(1, Number(f.delay_minutes) || 1) * 60;
              cumulative += sec;
              const row = {
                schedule_id: s.id,
                user_id: s.user_id,
                room_id: s.room_id,
                account_id: accountId,
                scheduled_at: new Date(Date.now() + cumulative * 1e3).toISOString(),
                content: f.content ?? null,
                image_path: f.image_path ?? null,
                image_mime: f.image_mime ?? null,
                video_id: f.video_id ?? null,
                parse_mode: s.parse_mode,
                button_text: f.button_text ?? null,
                button_url: f.button_url ?? null
              };
              if (f.audio_id) row.audio_id = f.audio_id;
              return row;
            });
            const { error: insErr } = await supabaseAdmin.from("recurring_pending_followups").insert(rows);
            if (insErr) console.error("[dispatch-recurring] Erro ao inserir follow-ups:", insErr);
          }
        }
        const nowIso = (/* @__PURE__ */ new Date()).toISOString();
        const { data: pendings, error: pendingsErr } = await supabaseAdmin.from("recurring_pending_followups").select(
          "id, schedule_id, user_id, room_id, account_id, content, image_path, image_mime, video_id, audio_id, parse_mode, button_text, button_url"
        ).eq("status", "pending").lte("scheduled_at", nowIso).limit(100);
        if (pendingsErr) {
          console.error("[dispatch-recurring] Erro ao buscar pendings:", pendingsErr);
        }
        let followupsFired = 0;
        for (const p of pendings ?? []) {
          const { data: claim } = await supabaseAdmin.from("recurring_pending_followups").update({ status: "sending", last_error: null }).eq("id", p.id).eq("status", "pending").select("id").maybeSingle();
          if (!claim) continue;
          let accountId = p.account_id;
          if (!accountId) {
            const { data: room } = await supabaseAdmin.from("rooms").select("default_account_id").eq("id", p.room_id).maybeSingle();
            accountId = room?.default_account_id ?? null;
          }
          if (!accountId) {
            await supabaseAdmin.from("recurring_pending_followups").update({ status: "failed", last_error: "Agendamento pai ausente" }).eq("id", p.id);
            continue;
          }
          const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", accountId).maybeSingle();
          const { data: chats } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", p.room_id);
          if (!acc || !chats?.length) {
            await supabaseAdmin.from("recurring_pending_followups").update({ status: "failed", last_error: "Sem grupos" }).eq("id", p.id);
            continue;
          }
          let okAny = false;
          let lastErr = null;
          let video = null;
          if (p.video_id) {
            const { data: v } = await supabaseAdmin.from("videos").select("storage_path, mime_type, duration_seconds, title, kind, width, height").eq("id", p.video_id).maybeSingle();
            video = v ?? null;
          }
          let audio = null;
          if (p.audio_id) {
            const { data: a } = await supabaseAdmin.from("audios").select("storage_path, duration_seconds, title").eq("id", p.audio_id).maybeSingle();
            audio = a ?? null;
          }
          const { data: parentSchedule } = p.schedule_id ? await supabaseAdmin.from("recurring_schedules").select("is_premium").eq("id", p.schedule_id).maybeSingle() : { data: null };
          const isPremium = Boolean(parentSchedule?.is_premium) || hasEmojiTokens(p.content);
          const pReplyMarkup = void 0;
          const pIsNormalVideo = video && video.kind === "normal";
          for (const c of chats) {
            const r = video ? pIsNormalVideo ? await (async () => {
              if (isPremium && p.content && hasEmojiTokens(p.content)) {
                const { data: file } = await supabaseAdmin.storage.from("videos").download(video.storage_path);
                if (file) {
                  const bytes = await file.arrayBuffer();
                  const pv = await sendVideoWithPremiumEmojiCaption({
                    userId: p.user_id,
                    chatId: c.chat_id,
                    videoBytes: bytes,
                    thumbnailBytes: await loadVideoThumbnail(video.storage_path),
                    filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
                    mimeType: video.mime_type ?? "video/mp4",
                    duration: video.duration_seconds,
                    width: video.width,
                    height: video.height,
                    caption: p.content,
                    strict: true
                  });
                  if (pv.applied) {
                    return await withCompanionButton(
                      pv.ok ? { ok: true, result: { message_id: pv.messageId ?? void 0 } } : { ok: false, description: pv.error },
                      acc.bot_token,
                      c.chat_id,
                      pReplyMarkup
                    );
                  }
                }
              }
              if (hasEmojiTokens(p.content)) {
                return { ok: false, description: PREMIUM_LOCK_ERROR };
              }
              return await dispatchVideo({
                botToken: acc.bot_token,
                storagePath: video.storage_path,
                chatId: c.chat_id,
                duration: video.duration_seconds,
                width: video.width,
                height: video.height,
                mimeType: video.mime_type,
                filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
                caption: p.content,
                parseMode: p.parse_mode,
                replyMarkup: pReplyMarkup
              });
            })() : await dispatchVideoNote({
              botToken: acc.bot_token,
              storagePath: video.storage_path,
              chatId: c.chat_id,
              duration: video.duration_seconds,
              mimeType: video.mime_type,
              filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
            }) : audio ? await (async () => {
              const { data: fileData, error: error2 } = await supabaseAdmin.storage.from("audio-files").download(audio.storage_path);
              if (error2 || !fileData) return { ok: false, description: "Falha ao baixar áudio" };
              const bytes = await fileData.arrayBuffer();
              const { sendVoiceToChat } = await import("./audios.functions-DUKTM5eK.js");
              return await sendVoiceToChat({
                botToken: acc.bot_token,
                chatId: c.chat_id,
                fileBytes: bytes,
                filename: audio.title + ".ogg",
                mimeType: "audio/ogg",
                duration: audio.duration_seconds,
                caption: p.content
              });
            })() : await sendOne(acc.bot_token, c.chat_id, {
              content: p.content,
              image_path: p.image_path,
              parse_mode: p.parse_mode,
              user_id: p.user_id,
              is_premium: isPremium,
              reply_markup: pReplyMarkup
            });
            await supabaseAdmin.from("message_logs").insert({
              user_id: p.user_id,
              account_id: accountId,
              chat_id: c.chat_id,
              ok: r.ok,
              telegram_message_id: r.result?.message_id ?? null,
              error: r.ok ? null : r.description ?? "erro"
            });
            if (r.ok) okAny = true;
            else lastErr = r.description ?? "erro";
            if (r.ok && r.result?.message_id) {
              await triggerSignalReactions({
                userId: p.user_id,
                chatId: c.chat_id,
                telegramMessageId: r.result.message_id,
                roomId: p.room_id
              });
              if (p.schedule_id) {
                await mirrorIfMarked({
                  roomId: p.room_id,
                  fromChatId: c.chat_id,
                  messageId: r.result.message_id,
                  origin: { kind: "recurring", id: p.schedule_id },
                  payload: {
                    userId: p.user_id,
                    content: p.content,
                    parseMode: p.parse_mode,
                    imagePath: p.image_path,
                    video: video && pIsNormalVideo ? {
                      storagePath: video.storage_path,
                      mimeType: video.mime_type,
                      duration: video.duration_seconds,
                      width: video.width,
                      height: video.height,
                      filename: (video.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
                    } : null
                  }
                });
              }
            }
          }
          await supabaseAdmin.from("recurring_pending_followups").update({
            status: okAny ? "sent" : "failed",
            sent_at: (/* @__PURE__ */ new Date()).toISOString(),
            last_error: okAny ? null : lastErr
          }).eq("id", p.id);
          if (okAny) followupsFired++;
        }
        return Response.json({ ok: true, processed, fired, followupsFired });
      }
    }
  }
});
function applyTemplate(t, o, link) {
  const map = {
    title: o.title ?? "",
    price: o.price != null ? o.price.toFixed(2) : "",
    old_price: o.oldPrice != null ? o.oldPrice.toFixed(2) : "",
    discount: o.discountPct != null ? String(o.discountPct) : "",
    link,
    store: o.store,
    category: o.category ?? ""
  };
  return t.replace(/\{(\w+)\}/g, (_, k) => map[k] ?? "");
}
function siteOrigin(req) {
  const url = new URL(req.url);
  return `${url.protocol}//${url.host}`;
}
async function processRoom$1(set, origin) {
  const intervalMs = Math.max(1, set.interval_hours) * 36e5;
  const last = set.last_fire_at ? new Date(set.last_fire_at).getTime() : 0;
  const now = Date.now();
  if (now - last < intervalMs) return { skipped: "interval" };
  const { data: room } = await supabaseAdmin.from("rooms").select("default_account_id, niche, is_active").eq("id", set.room_id).maybeSingle();
  if (!room || !room.is_active || room.niche !== "promo") return { skipped: "room_inactive" };
  if (!room.default_account_id) return { skipped: "no_account" };
  const { data: chats } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", set.room_id);
  if (!chats || chats.length === 0) return { skipped: "no_chats" };
  const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
  if (!acc?.bot_token) return { skipped: "no_bot_token" };
  await supabaseAdmin.from("promo_bot_settings").update({ last_fire_at: new Date(now).toISOString() }).eq("id", set.id);
  const { data: affs } = await supabaseAdmin.from("affiliate_accounts").select("store, credentials").eq("user_id", set.user_id).eq("is_active", true);
  const credMap = new Map((affs ?? []).map((a) => [a.store, a.credentials]));
  let chosen = null;
  for (const sRaw of set.stores ?? []) {
    const store = sRaw;
    const creds = credMap.get(store);
    if (!creds) continue;
    const client = STORE_CLIENTS[store];
    let offers = [];
    try {
      offers = await client.fetchOffers(creds, {
        keywords: set.keywords ?? [],
        categories: set.categories ?? [],
        minDiscountPct: set.min_discount_pct,
        minPrice: set.min_price ?? void 0,
        maxPrice: set.max_price ?? void 0,
        blacklistKeywords: set.blacklist_keywords ?? []
      });
    } catch {
      continue;
    }
    for (const o of offers) {
      const { data: seen } = await supabaseAdmin.from("promo_dispatches").select("id").eq("room_id", set.room_id).eq("store", store).eq("external_id", o.externalId).maybeSingle();
      if (seen) continue;
      const blob = `${o.title} ${o.description ?? ""}`.toLowerCase();
      if ((set.blacklist_keywords ?? []).some((k) => k && blob.includes(k.toLowerCase()))) continue;
      const subId = `r${set.room_id.slice(0, 8)}`;
      const affiliateLink = client.buildAffiliateLink(creds, o.productUrl, subId);
      chosen = { offer: o, affiliateLink, store };
      break;
    }
    if (chosen) break;
  }
  if (!chosen) return { skipped: "no_new_offers" };
  const { data: savedOffer } = await supabaseAdmin.from("promo_offers").insert({
    user_id: set.user_id,
    store: chosen.store,
    external_id: chosen.offer.externalId,
    title: chosen.offer.title,
    description: chosen.offer.description ?? null,
    price: chosen.offer.price ?? null,
    old_price: chosen.offer.oldPrice ?? null,
    discount_pct: chosen.offer.discountPct ?? null,
    image_url: chosen.offer.imageUrl ?? null,
    product_url: chosen.offer.productUrl,
    category: chosen.offer.category ?? null,
    raw: chosen.offer.raw
  }).select("id").single();
  let sentCount = 0;
  const errors = [];
  for (const c of chats) {
    const { data: disp } = await supabaseAdmin.from("promo_dispatches").insert({
      user_id: set.user_id,
      room_id: set.room_id,
      chat_id: c.chat_id,
      store: chosen.store,
      external_id: chosen.offer.externalId,
      affiliate_link: chosen.affiliateLink,
      offer_id: savedOffer?.id ?? null,
      ok: false
    }).select("id").single();
    const shortUrl = disp ? `${origin}/api/public/go/${disp.id}` : chosen.affiliateLink;
    if (disp) {
      await supabaseAdmin.from("promo_dispatches").update({ short_url: shortUrl }).eq("id", disp.id);
    }
    const text = applyTemplate(set.message_template, chosen.offer, shortUrl);
    let r;
    if (set.send_image && chosen.offer.imageUrl) {
      r = await callTelegram(acc.bot_token, "sendPhoto", {
        chat_id: c.chat_id,
        photo: chosen.offer.imageUrl,
        caption: text,
        parse_mode: set.parse_mode || "HTML"
      });
      if (!r.ok) {
        r = await callTelegram(acc.bot_token, "sendMessage", {
          chat_id: c.chat_id,
          text,
          parse_mode: set.parse_mode || "HTML",
          disable_web_page_preview: false
        });
      }
    } else {
      r = await callTelegram(acc.bot_token, "sendMessage", {
        chat_id: c.chat_id,
        text,
        parse_mode: set.parse_mode || "HTML",
        disable_web_page_preview: false
      });
    }
    if (disp) {
      await supabaseAdmin.from("promo_dispatches").update({
        ok: r.ok,
        telegram_message_id: r.result?.message_id ?? null,
        error: r.ok ? null : r.description ?? "erro"
      }).eq("id", disp.id);
    }
    if (r.ok) sentCount++;
    else errors.push(r.description ?? "erro");
  }
  return { sent: sentCount, errors: errors.length, title: chosen.offer.title, store: chosen.store };
}
const Route$a = createFileRoute("/api/public/cron/dispatch-promos")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const origin = siteOrigin(request);
        const { data: settings, error } = await supabaseAdmin.from("promo_bot_settings").select("id, user_id, room_id, enabled, interval_hours, stores, min_discount_pct, min_price, max_price, categories, keywords, blacklist_keywords, message_template, parse_mode, send_image, last_fire_at").eq("enabled", true);
        if (error) {
          return new Response(JSON.stringify({ ok: false, error: error.message }), { status: 500 });
        }
        const results = {};
        for (const s of settings ?? []) {
          try {
            results[s.room_id] = await processRoom$1(s, origin);
          } catch (e) {
            results[s.room_id] = { error: e instanceof Error ? e.message : String(e) };
          }
        }
        return new Response(JSON.stringify({ ok: true, processed: Object.keys(results).length, results }), {
          headers: { "Content-Type": "application/json" }
        });
      },
      GET: async () => new Response("promo dispatch cron alive")
    }
  }
});
const FEEDS = {
  forex: [
    { url: "https://br.investing.com/rss/news_1.rss", source: "Investing.com" },
    { url: "https://br.investing.com/rss/news_285.rss", source: "Investing.com Forex" },
    { url: "https://www.infomoney.com.br/mercados/cambio/feed/", source: "InfoMoney" }
  ],
  crypto: [
    { url: "https://br.cointelegraph.com/rss", source: "Cointelegraph BR" },
    { url: "https://livecoins.com.br/feed/", source: "Livecoins" },
    { url: "https://www.infomoney.com.br/mercados/criptomoedas/feed/", source: "InfoMoney Cripto" }
  ]
};
function pick(re, src) {
  const m = src.match(re);
  return m ? m[1].trim() : null;
}
function decode(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ").replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n))).trim();
}
function extractImage(itemXml) {
  const enc = itemXml.match(/<enclosure[^>]+url=["']([^"']+)["'][^>]*>/i);
  if (enc && /image\/|\.(jpg|jpeg|png|webp)/i.test(enc[0])) return enc[1];
  const media = itemXml.match(/<media:content[^>]+url=["']([^"']+)["']/i);
  if (media) return media[1];
  const thumb = itemXml.match(/<media:thumbnail[^>]+url=["']([^"']+)["']/i);
  if (thumb) return thumb[1];
  const img = itemXml.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (img) return img[1];
  return null;
}
function parseRss(xml, source, category) {
  const items = [];
  const itemRe = /<item[\s>][\s\S]*?<\/item>/gi;
  const matches = xml.match(itemRe) ?? [];
  for (const raw of matches) {
    const title = pick(/<title[^>]*>([\s\S]*?)<\/title>/i, raw);
    const link = pick(/<link[^>]*>([\s\S]*?)<\/link>/i, raw);
    const desc = pick(/<description[^>]*>([\s\S]*?)<\/description>/i, raw) ?? pick(/<content:encoded[^>]*>([\s\S]*?)<\/content:encoded>/i, raw) ?? "";
    const pubDate = pick(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i, raw);
    if (!title || !link) continue;
    const cleanLink = decode(link);
    items.push({
      category,
      title: decode(title),
      link: cleanLink,
      description: decode(desc).slice(0, 280),
      image: extractImage(raw),
      publishedAt: pubDate ? Date.parse(pubDate) || Date.now() : Date.now(),
      source
    });
  }
  return items;
}
async function fetchFeed(url, source, category) {
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; TeleSignalMarketTips/1.0)",
        Accept: "application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.5"
      },
      signal: AbortSignal.timeout(8e3)
    });
    if (!res.ok) return [];
    return parseRss(await res.text(), source, category);
  } catch {
    return [];
  }
}
async function fetchMarketTips(categories) {
  const jobs = [];
  for (const cat of categories) {
    for (const f of FEEDS[cat] ?? []) jobs.push(fetchFeed(f.url, f.source, cat));
  }
  const all = (await Promise.all(jobs)).flat();
  all.sort((a, b) => b.publishedAt - a.publishedAt);
  return all;
}
async function linkHash(link) {
  const data = new TextEncoder().encode(link.trim().toLowerCase());
  const digest = await crypto.subtle.digest("SHA-256", data);
  const bytes = new Uint8Array(digest);
  let hex = "";
  for (let i = 0; i < 16; i++) hex += bytes[i].toString(16).padStart(2, "0");
  return hex;
}
function formatTipMessage(tip) {
  const flag = tip.category === "crypto" ? "🪙" : "💱";
  const lines = [
    `${flag} <b>${escapeHtml(tip.title)}</b>`
  ];
  if (tip.description) lines.push("", escapeHtml(tip.description));
  lines.push("", `<i>${escapeHtml(tip.source)}</i> — <a href="${escapeAttr(tip.link)}">Ler matéria</a>`);
  return lines.join("\n");
}
function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function escapeAttr(s) {
  return escapeHtml(s).replace(/"/g, "&quot;");
}
async function processRoom(room) {
  const intervalH = Math.max(1, room.market_tips_interval_hours ?? 6);
  const last = room.market_tips_last_fire_at ? new Date(room.market_tips_last_fire_at).getTime() : 0;
  const now = Date.now();
  if (now - last < intervalH * 36e5) return { skipped: "interval" };
  if (!room.default_account_id) return { skipped: "no_account" };
  const cats = (room.market_tips_categories ?? ["forex", "crypto"]).filter(
    (c) => c === "forex" || c === "crypto"
  );
  if (cats.length === 0) return { skipped: "no_categories" };
  const { data: chats } = await supabaseAdmin.from("room_chats").select("chat_id").eq("room_id", room.id);
  if (!chats || chats.length === 0) return { skipped: "no_chats" };
  const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("id", room.default_account_id).maybeSingle();
  if (!acc?.bot_token) return { skipped: "no_bot_token" };
  const { error: reserveErr } = await supabaseAdmin.from("rooms").update({ market_tips_last_fire_at: new Date(now).toISOString() }).eq("id", room.id).lte("market_tips_last_fire_at", new Date(now - intervalH * 36e5).toISOString());
  if (reserveErr) return { error: reserveErr.message };
  if (last === 0) {
    await supabaseAdmin.from("rooms").update({ market_tips_last_fire_at: new Date(now).toISOString() }).eq("id", room.id).is("market_tips_last_fire_at", null);
  }
  const tips = await fetchMarketTips(cats);
  if (tips.length === 0) return { skipped: "no_tips" };
  let chosen = null;
  for (const tip of tips) {
    const hash = await linkHash(tip.link);
    const { data: prev } = await supabaseAdmin.from("market_tips_sent").select("id").eq("room_id", room.id).eq("link_hash", hash).maybeSingle();
    if (!prev) {
      chosen = { tip, hash };
      break;
    }
  }
  if (!chosen) return { skipped: "all_seen" };
  const caption = formatTipMessage(chosen.tip);
  let sentCount = 0;
  const errors = [];
  for (const c of chats) {
    const chatId = c.chat_id;
    let r;
    if (chosen.tip.image) {
      r = await callTelegram(acc.bot_token, "sendPhoto", {
        chat_id: chatId,
        photo: chosen.tip.image,
        caption,
        parse_mode: "HTML"
      });
      if (!r.ok) {
        r = await callTelegram(acc.bot_token, "sendMessage", {
          chat_id: chatId,
          text: caption,
          parse_mode: "HTML",
          disable_web_page_preview: false
        });
      }
    } else {
      r = await callTelegram(acc.bot_token, "sendMessage", {
        chat_id: chatId,
        text: caption,
        parse_mode: "HTML",
        disable_web_page_preview: false
      });
    }
    if (r.ok) {
      sentCount++;
      await supabaseAdmin.from("message_logs").insert({
        user_id: room.user_id,
        room_id: room.id,
        account_id: room.default_account_id,
        chat_id: chatId,
        ok: true,
        telegram_message_id: r.result?.message_id ?? null,
        source: "market_tips"
      });
    } else {
      errors.push(r.description ?? "erro");
      await supabaseAdmin.from("message_logs").insert({
        user_id: room.user_id,
        room_id: room.id,
        account_id: room.default_account_id,
        chat_id: chatId,
        ok: false,
        error: r.description ?? "erro",
        source: "market_tips"
      });
    }
  }
  if (sentCount > 0) {
    await supabaseAdmin.from("market_tips_sent").insert({
      user_id: room.user_id,
      room_id: room.id,
      link_hash: chosen.hash,
      title: chosen.tip.title,
      link: chosen.tip.link
    });
  }
  return { sent: sentCount, errors: errors.length, title: chosen.tip.title };
}
const Route$9 = createFileRoute("/api/public/cron/dispatch-market-tips")({
  server: {
    handlers: {
      POST: async () => {
        const { data: rooms, error } = await supabaseAdmin.from("rooms").select(
          "id, user_id, default_account_id, market_tips_enabled, market_tips_interval_hours, market_tips_categories, market_tips_last_fire_at"
        ).eq("market_tips_enabled", true).eq("is_active", true);
        if (error) {
          return new Response(JSON.stringify({ ok: false, error: error.message }), {
            status: 500,
            headers: { "Content-Type": "application/json" }
          });
        }
        const results = {};
        for (const room of rooms ?? []) {
          try {
            results[room.id] = await processRoom(room);
          } catch (e) {
            results[room.id] = { error: e instanceof Error ? e.message : String(e) };
          }
        }
        return new Response(JSON.stringify({ ok: true, processed: Object.keys(results).length, results }), {
          headers: { "Content-Type": "application/json" }
        });
      },
      GET: async () => new Response("market-tips cron alive")
    }
  }
});
function publicUrl$1(bucket, path) {
  const base = (process.env.SUPABASE_URL ?? "").replace(/\/$/, "");
  return `${base}/storage/v1/object/public/${bucket}/${path}`;
}
function renderTemplate$1(tpl, vars) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? "");
}
function nowInTimezone(tz) {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
  const parts = Object.fromEntries(fmt.formatToParts(/* @__PURE__ */ new Date()).map((p) => [p.type, p.value]));
  const h = parseInt(parts.hour ?? "0", 10);
  const m = parseInt(parts.minute ?? "0", 10);
  return {
    hhmm: `${parts.hour}:${parts.minute}`,
    minutes: h * 60 + m,
    ymd: `${parts.year}-${parts.month}-${parts.day}`
  };
}
function daysBetweenInTimezone(startIso, tz) {
  const start = nowInTimezone(tz);
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
  const startParts = Object.fromEntries(
    fmt.formatToParts(new Date(startIso)).map((p) => [p.type, p.value])
  );
  const startYmd = `${startParts.year}-${startParts.month}-${startParts.day}`;
  const d1 = (/* @__PURE__ */ new Date(startYmd + "T00:00:00Z")).getTime();
  const d2 = (/* @__PURE__ */ new Date(start.ymd + "T00:00:00Z")).getTime();
  return Math.max(0, Math.round((d2 - d1) / 864e5));
}
async function dispatchOne(opts) {
  const { lead, msg, botToken } = opts;
  const firstName = (lead.first_name ?? "amigo(a)").replace(/[<>&]/g, "");
  const mention = `<a href="tg://user?id=${lead.tg_user_id}">${firstName}</a>`;
  const text = renderTemplate$1(msg.content ?? "", {
    name: mention,
    first_name: firstName,
    username: lead.username ?? ""
  });
  const parse_mode = msg.parse_mode || "HTML";
  const reply_markup = msg.button_text && msg.button_url ? { inline_keyboard: [[{ text: msg.button_text, url: msg.button_url }]] } : void 0;
  const isBlocked = (d) => !!d && /blocked|user is deactivated|chat not found|bot was kicked/i.test(d);
  if (msg.video_id) {
    const { data: vid } = await supabaseAdmin.from("videos").select("storage_path, kind, mime_type, duration_seconds, title, width, height").eq("id", msg.video_id).maybeSingle();
    if (vid?.storage_path) {
      const isRound = vid.kind === "round";
      const resp2 = isRound ? await dispatchVideoNote({
        botToken,
        storagePath: vid.storage_path,
        chatId: lead.chat_id,
        duration: vid.duration_seconds,
        mimeType: vid.mime_type,
        filename: (vid.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
      }) : await dispatchVideo({
        botToken,
        storagePath: vid.storage_path,
        chatId: lead.chat_id,
        duration: vid.duration_seconds,
        width: vid.width,
        height: vid.height,
        mimeType: vid.mime_type,
        filename: (vid.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
        caption: text || null,
        parseMode: parse_mode,
        replyMarkup: void 0
      });
      if (!resp2.ok) return { ok: false, error: resp2.description, blocked: isBlocked(resp2.description) };
      if (isRound && text) {
        await callTelegram(botToken, "sendMessage", {
          chat_id: lead.chat_id,
          text,
          parse_mode,
          reply_markup
        });
      } else if (reply_markup) {
        await callTelegram(botToken, "sendMessage", { chat_id: lead.chat_id, text: "⁣", reply_markup });
      }
      return { ok: true };
    }
  }
  if (msg.image_path) {
    const url = publicUrl$1("room-images", msg.image_path);
    if (msg.premium_enabled && msg.premium_account_id) {
      const r = await sendPhotoWithPremiumEmojiCaption({
        userId: lead.user_id,
        accountId: msg.premium_account_id,
        chatId: lead.chat_id,
        photoUrl: url,
        caption: text || null,
        strict: false
      }).catch((e) => ({ applied: true, ok: false, error: e instanceof Error ? e.message : String(e) }));
      if (r.applied && r.ok) {
        if (reply_markup) {
          await callTelegram(botToken, "sendMessage", { chat_id: lead.chat_id, text: "⁣", reply_markup });
        }
        return { ok: true };
      }
    }
    const resp2 = await callTelegram(botToken, "sendPhoto", {
      chat_id: lead.chat_id,
      photo: url,
      caption: text || void 0,
      parse_mode: text ? parse_mode : void 0,
      reply_markup
    });
    if (!resp2.ok) return { ok: false, error: resp2.description, blocked: isBlocked(resp2.description) };
    return { ok: true };
  }
  if (msg.premium_enabled && msg.premium_account_id && text) {
    const r = await sendTextWithPremiumEmojis({
      userId: lead.user_id,
      accountId: msg.premium_account_id,
      chatId: lead.chat_id,
      text,
      allowPlain: true
    }).catch((e) => ({ applied: true, ok: false, error: e instanceof Error ? e.message : String(e) }));
    if (r.applied && r.ok) {
      if (reply_markup) {
        await callTelegram(botToken, "sendMessage", { chat_id: lead.chat_id, text: "⁣", reply_markup });
      }
      return { ok: true };
    }
  }
  const resp = await callTelegram(botToken, "sendMessage", {
    chat_id: lead.chat_id,
    text: text || "(sem conteúdo)",
    parse_mode,
    reply_markup,
    disable_web_page_preview: true
  });
  if (!resp.ok) return { ok: false, error: resp.description, blocked: isBlocked(resp.description) };
  return { ok: true };
}
async function runDispatch() {
  let checked = 0;
  let sent = 0;
  let failed = 0;
  let stopped = 0;
  const { data: leads } = await supabaseAdmin.from("followup_leads").select("*").eq("status", "active").limit(500);
  const leadList = leads ?? [];
  if (!leadList.length) return { checked, sent, failed, stopped };
  const roomIds = Array.from(new Set(leadList.map((l) => l.room_id)));
  const { data: settings } = await supabaseAdmin.from("followup_settings").select("room_id, enabled, timezone").in("room_id", roomIds);
  const settingsByRoom = /* @__PURE__ */ new Map();
  for (const s of settings ?? []) {
    settingsByRoom.set(s.room_id, { enabled: s.enabled, timezone: s.timezone });
  }
  const { data: messages } = await supabaseAdmin.from("followup_messages").select("*").in("room_id", roomIds);
  const msgsByRoom = /* @__PURE__ */ new Map();
  for (const m of messages ?? []) {
    const list = msgsByRoom.get(m.room_id) ?? [];
    list.push(m);
    msgsByRoom.set(m.room_id, list);
  }
  const accountIds = Array.from(new Set(leadList.map((l) => l.account_id)));
  const { data: accounts } = await supabaseAdmin.from("telegram_accounts").select("id, bot_token").in("id", accountIds);
  const tokenByAcc = /* @__PURE__ */ new Map();
  for (const a of accounts ?? []) tokenByAcc.set(a.id, a.bot_token);
  for (const lead of leadList) {
    checked++;
    const cfg = settingsByRoom.get(lead.room_id);
    if (!cfg?.enabled) continue;
    const msgs = msgsByRoom.get(lead.room_id) ?? [];
    if (!msgs.length) continue;
    const maxDay = Math.max(...msgs.map((m) => m.day_number));
    const tz = cfg.timezone || "America/Sao_Paulo";
    const dayIdx = daysBetweenInTimezone(lead.started_at, tz) + 1;
    if (dayIdx > maxDay) {
      await supabaseAdmin.from("followup_leads").update({ status: "completed" }).eq("id", lead.id);
      continue;
    }
    const msg = msgs.find((m) => m.day_number === dayIdx);
    if (!msg) continue;
    const now = nowInTimezone(tz);
    const [sh, sm] = (msg.send_time || "09:00").split(":");
    const target = parseInt(sh, 10) * 60 + parseInt(sm, 10);
    if (now.minutes < target) continue;
    const { data: existing } = await supabaseAdmin.from("followup_dispatch_log").select("id").eq("lead_id", lead.id).eq("day_number", dayIdx).maybeSingle();
    if (existing) continue;
    const token = tokenByAcc.get(lead.account_id);
    if (!token) continue;
    const res = await dispatchOne({ lead, msg, botToken: token });
    await supabaseAdmin.from("followup_dispatch_log").insert({
      user_id: lead.user_id,
      lead_id: lead.id,
      day_number: dayIdx,
      ok: res.ok,
      error: res.ok ? null : res.error ?? "erro"
    });
    if (res.ok) {
      sent++;
      await supabaseAdmin.from("followup_leads").update({ last_sent_day: dayIdx, last_sent_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", lead.id);
    } else {
      failed++;
      if (res.blocked) {
        stopped++;
        await supabaseAdmin.from("followup_leads").update({
          status: "stopped",
          stopped_at: (/* @__PURE__ */ new Date()).toISOString(),
          stopped_reason: res.error ?? "blocked"
        }).eq("id", lead.id);
      }
    }
  }
  return { checked, sent, failed, stopped };
}
const Route$8 = createFileRoute("/api/public/cron/dispatch-followups")({
  server: {
    handlers: {
      POST: async () => {
        try {
          const result = await runDispatch();
          return Response.json({ ok: true, ...result });
        } catch (e) {
          console.error("[dispatch-followups] error:", e);
          return Response.json({ ok: false, error: e instanceof Error ? e.message : String(e) }, { status: 500 });
        }
      },
      GET: async () => {
        try {
          const result = await runDispatch();
          return Response.json({ ok: true, ...result });
        } catch (e) {
          return Response.json({ ok: false, error: e instanceof Error ? e.message : String(e) }, { status: 500 });
        }
      }
    }
  }
});
const ALLOWED_UPDATES = ["chat_member", "my_chat_member", "message", "channel_post", "chat_join_request"];
function publicBaseUrl() {
  const explicit = process.env.PUBLIC_BASE_URL;
  if (explicit) return explicit.replace(/\/$/, "");
  return `https://telesignal.com.br`;
}
async function drainPending(accountId, botToken) {
  const url = `${publicBaseUrl()}/api/public/telegram/webhook/${accountId}`;
  const secret = createHash("sha256").update(`tg-tracking:${botToken}`).digest("base64url");
  let offset;
  let processed = 0;
  let errors = 0;
  for (let i = 0; i < 50; i++) {
    const r = await callTelegram(botToken, "getUpdates", {
      offset,
      limit: 100,
      timeout: 0,
      allowed_updates: ALLOWED_UPDATES
    });
    if (!r.ok) break;
    const batch = r.result ?? [];
    if (batch.length === 0) break;
    for (const upd of batch) {
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-telegram-bot-api-secret-token": secret
          },
          body: JSON.stringify(upd)
        });
        if (resp.ok) processed++;
        else errors++;
      } catch {
        errors++;
      }
      offset = upd.update_id + 1;
    }
    if (batch.length < 100) break;
  }
  return { processed, errors };
}
const Route$7 = createFileRoute("/api/public/cron/check-telegram-webhooks")({
  server: {
    handlers: {
      POST: async () => {
        const { data: accounts, error } = await supabaseAdmin.from("telegram_accounts").select("id, bot_token, member_tracking_enabled").eq("account_type", "bot").eq("member_tracking_enabled", true).eq("is_active", true);
        if (error) return Response.json({ error: error.message }, { status: 500 });
        const expectedBase = publicBaseUrl();
        const results = [];
        const now = Date.now();
        for (const acc of accounts ?? []) {
          if (!acc.bot_token) continue;
          const expectedUrl = `${expectedBase}/api/public/telegram/webhook/${acc.id}`;
          const secret = createHash("sha256").update(`tg-tracking:${acc.bot_token}`).digest("base64url");
          const info = await callTelegram(acc.bot_token, "getWebhookInfo", {});
          const w = info.ok ? info.result ?? {} : {};
          const urlMissingOrWrong = !w.url || w.url !== expectedUrl;
          const lastErrorRecent = !!w.last_error_date && now - w.last_error_date * 1e3 < 60 * 60 * 1e3;
          const needsRecovery = !info.ok || urlMissingOrWrong || lastErrorRecent;
          if (!needsRecovery) {
            await supabaseAdmin.from("telegram_accounts").update({
              member_tracking_last_check: (/* @__PURE__ */ new Date()).toISOString(),
              member_tracking_last_error: null
            }).eq("id", acc.id);
            results.push({
              accountId: acc.id,
              status: "ok",
              pending: w.pending_update_count ?? 0
            });
            continue;
          }
          let drained = { processed: 0, errors: 0 };
          let setError = null;
          await callTelegram(acc.bot_token, "deleteWebhook", { drop_pending_updates: false });
          try {
            drained = await drainPending(acc.id, acc.bot_token);
          } catch (e) {
            setError = e instanceof Error ? e.message : String(e);
          }
          const set = await callTelegram(acc.bot_token, "setWebhook", {
            url: expectedUrl,
            secret_token: secret,
            allowed_updates: ALLOWED_UPDATES,
            drop_pending_updates: false
          });
          if (!set.ok) setError = set.description ?? "setWebhook falhou";
          await supabaseAdmin.from("telegram_accounts").update({
            member_tracking_last_check: (/* @__PURE__ */ new Date()).toISOString(),
            member_tracking_last_error: setError,
            member_tracking_recovered_at: set.ok ? (/* @__PURE__ */ new Date()).toISOString() : null
          }).eq("id", acc.id);
          results.push({
            accountId: acc.id,
            status: set.ok ? "recovered" : "failed",
            previousUrl: w.url ?? null,
            lastErrorMessage: w.last_error_message ?? null,
            pendingBefore: w.pending_update_count ?? 0,
            drained,
            setError
          });
        }
        return Response.json({ ok: true, checked: results.length, results });
      }
    }
  }
});
async function makeClient(apiId, apiHash, session) {
  const { TelegramClient } = await import("telegram");
  const { StringSession } = await import("telegram/sessions/index.js");
  const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
    connectionRetries: 1,
    useWSS: true
  });
  await client.connect();
  return client;
}
async function verifyAndSync(acc) {
  if (!acc.tg_api_id || !acc.tg_api_hash || !acc.tg_session) {
    return { status: "error", error: "Sessão ausente", newEmojis: 0 };
  }
  const { Api } = await import("telegram");
  const { default: bigInt } = await import("big-integer");
  let client = null;
  try {
    client = await makeClient(acc.tg_api_id, acc.tg_api_hash, acc.tg_session);
    const me = await client.getMe();
    const isPremium = me?.premium === true;
    const sinceUnix = acc.last_check_at ? Math.floor(new Date(acc.last_check_at).getTime() / 1e3) : Math.floor(Date.now() / 1e3) - 24 * 3600;
    const { data: existing } = await supabaseAdmin.from("premium_emojis").select("custom_emoji_id").eq("user_id", acc.user_id);
    const known = new Set((existing ?? []).map((r) => r.custom_emoji_id));
    const seen = /* @__PURE__ */ new Set();
    const fresh = [];
    const dialogs = await client.getDialogs({ limit: 20 });
    const peers = [new Api.InputPeerSelf(), ...dialogs.map((d) => d.inputEntity).filter(Boolean)];
    for (const peer of peers) {
      try {
        const history = await client.invoke(
          new Api.messages.GetHistory({
            peer,
            offsetId: 0,
            offsetDate: 0,
            addOffset: 0,
            limit: 50,
            maxId: 0,
            minId: 0,
            hash: bigInt(0)
          })
        );
        for (const msg of history.messages ?? []) {
          const msgUnix = typeof msg.date === "number" ? msg.date : msg.date instanceof Date ? Math.floor(msg.date.getTime() / 1e3) : 0;
          if (msgUnix < sinceUnix) continue;
          if (msg.out !== true) continue;
          const text = msg.message ?? "";
          for (const ent of msg.entities ?? []) {
            if (ent.className === "MessageEntityCustomEmoji" && ent.documentId) {
              const id = String(ent.documentId);
              if (seen.has(id) || known.has(id)) continue;
              seen.add(id);
              const preview = typeof ent.offset === "number" && typeof ent.length === "number" ? text.substr(ent.offset, ent.length) : null;
              fresh.push({ custom_emoji_id: id, preview_char: preview, name: preview ?? id.slice(0, 8) });
            }
          }
        }
      } catch {
      }
    }
    if (fresh.length) {
      await supabaseAdmin.from("premium_emojis").insert(
        fresh.map((f) => ({
          user_id: acc.user_id,
          custom_emoji_id: f.custom_emoji_id,
          preview_char: f.preview_char,
          name: f.name
        }))
      );
    }
    return {
      status: isPremium ? "ok" : "error",
      error: isPremium ? null : "Conta sem assinatura Premium ativa",
      newEmojis: fresh.length
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { status: "error", error: msg, newEmojis: 0 };
  } finally {
    if (client) await client.disconnect().catch(() => {
    });
  }
}
const Route$6 = createFileRoute("/api/public/cron/check-premium-accounts")({
  server: {
    handlers: {
      POST: async () => {
        const { data: accounts, error } = await supabaseAdmin.from("telegram_accounts").select("id, user_id, tg_api_id, tg_api_hash, tg_session, last_check_at").eq("account_type", "premium").eq("is_active", true).not("tg_session", "is", null);
        if (error) return Response.json({ error: error.message }, { status: 500 });
        const results = [];
        for (const acc of accounts ?? []) {
          const r = await verifyAndSync(acc);
          await supabaseAdmin.from("telegram_accounts").update({
            status: r.status,
            last_check_at: (/* @__PURE__ */ new Date()).toISOString(),
            last_error: r.error
          }).eq("id", acc.id);
          results.push({ accountId: acc.id, ...r });
        }
        return Response.json({ ok: true, checked: results.length, results });
      }
    }
  }
});
const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);
const Label = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(LabelPrimitive.Root, { ref, className: cn(labelVariants(), className), ...props }));
Label.displayName = LabelPrimitive.Root.displayName;
const Textarea = React.forwardRef(
  ({ className, ...props }, ref) => {
    return /* @__PURE__ */ jsx(
      "textarea",
      {
        className: cn(
          "flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Textarea.displayName = "Textarea";
const Popover = PopoverPrimitive.Root;
const PopoverTrigger = PopoverPrimitive.Trigger;
const PopoverContent = React.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ jsx(PopoverPrimitive.Portal, { children: /* @__PURE__ */ jsx(
  PopoverPrimitive.Content,
  {
    ref,
    align,
    sideOffset,
    className: cn(
      "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)",
      className
    ),
    ...props
  }
) }));
PopoverContent.displayName = PopoverPrimitive.Content.displayName;
const requestPremiumCode = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  apiId: z.number().int().positive(),
  apiHash: z.string().min(10),
  phone: z.string().min(5)
}).parse(d)).handler(createSsrRpc("eafcf68c09ef7117507f8eb27b92e2fcf831b9c8e147ab56792c657a56b9b98f"));
const confirmPremiumCode = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  code: z.string().min(3),
  password: z.string().optional()
}).parse(d)).handler(createSsrRpc("e11e0b634bc507696d761a8e13f279ff5d7bcd325326316d1fb3a4e8049b6714"));
const syncPremiumEmojis = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  since: z.string().datetime().optional()
}).parse(d)).handler(createSsrRpc("2664d9c35138f431d18be3f3d5ebc7a5d45d618ffb31ec9e4c10f957970348c1"));
const getPremiumEmojiThumbs = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  ids: z.array(z.string().min(1)).min(1).max(100)
}).parse(d)).handler(createSsrRpc("06dd158bb8d31327cc0235b073df3cffa204292936a232ec40e53bfd54012078"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  chatId: z.string().min(1),
  text: z.string().min(1).max(4e3)
}).parse(d)).handler(createSsrRpc("a68c6ea077e0df4dc32ab7c1a8554c7fcac10c65f376ef7beb23fabed1bbbee8"));
const getPremiumAccountAvatar = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("76bf59276293617ba82d876f45ee762518ab372249f24bcbe360406a24d32dea"));
const Switch = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  SwitchPrimitives.Root,
  {
    className: cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className
    ),
    ...props,
    ref,
    children: /* @__PURE__ */ jsx(
      SwitchPrimitives.Thumb,
      {
        className: cn(
          "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0"
        )
      }
    )
  }
));
Switch.displayName = SwitchPrimitives.Root.displayName;
const Select = SelectPrimitive.Root;
const SelectValue = SelectPrimitive.Value;
const SelectTrigger = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs(
  SelectPrimitive.Trigger,
  {
    ref,
    className: cn(
      "flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsx(SelectPrimitive.Icon, { asChild: true, children: /* @__PURE__ */ jsx(ChevronDown, { className: "h-4 w-4 opacity-50" }) })
    ]
  }
));
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;
const SelectScrollUpButton = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  SelectPrimitive.ScrollUpButton,
  {
    ref,
    className: cn("flex cursor-default items-center justify-center py-1", className),
    ...props,
    children: /* @__PURE__ */ jsx(ChevronUp, { className: "h-4 w-4" })
  }
));
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;
const SelectScrollDownButton = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  SelectPrimitive.ScrollDownButton,
  {
    ref,
    className: cn("flex cursor-default items-center justify-center py-1", className),
    ...props,
    children: /* @__PURE__ */ jsx(ChevronDown, { className: "h-4 w-4" })
  }
));
SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;
const SelectContent = React.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ jsx(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxs(
  SelectPrimitive.Content,
  {
    ref,
    className: cn(
      "relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)",
      position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
      className
    ),
    position,
    ...props,
    children: [
      /* @__PURE__ */ jsx(SelectScrollUpButton, {}),
      /* @__PURE__ */ jsx(
        SelectPrimitive.Viewport,
        {
          className: cn(
            "p-1",
            position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
          ),
          children
        }
      ),
      /* @__PURE__ */ jsx(SelectScrollDownButton, {})
    ]
  }
) }));
SelectContent.displayName = SelectPrimitive.Content.displayName;
const SelectLabel = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  SelectPrimitive.Label,
  {
    ref,
    className: cn("px-2 py-1.5 text-sm font-semibold", className),
    ...props
  }
));
SelectLabel.displayName = SelectPrimitive.Label.displayName;
const SelectItem = React.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxs(
  SelectPrimitive.Item,
  {
    ref,
    className: cn(
      "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    ...props,
    children: [
      /* @__PURE__ */ jsx("span", { className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Check, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsx(SelectPrimitive.ItemText, { children })
    ]
  }
));
SelectItem.displayName = SelectPrimitive.Item.displayName;
const SelectSeparator = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx(
  SelectPrimitive.Separator,
  {
    ref,
    className: cn("-mx-1 my-1 h-px bg-muted", className),
    ...props
  }
));
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;
const verifyAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("4a076d7479753b932f9099c0e14826f639f88204af2dfc90155ac3cd1709f93a"));
const sendTestMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid(),
  chatId: z.string().min(1),
  text: z.string().min(1).max(4e3)
}).parse(d)).handler(createSsrRpc("9d672f1b1145acd5f53de234dd6706a0c1e2dd86fe6670f5ad41ed73bdce3017"));
const refreshChats = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("0a01656cd747bbe876270e0d8d002d5de74fd71d2f56128cccd31ed18ee88355"));
const sendRoomTest = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  templateKind: z.enum(["buy_direction", "entry", "event", "gain", "loss", "sell_direction", "signal", "win", "win_martingale"]).optional(),
  text: z.string().max(4e3).optional(),
  imagePath: z.string().optional(),
  imageBucket: z.string().optional(),
  imageMime: z.string().optional(),
  imageExt: z.string().optional()
}).parse(d)).handler(createSsrRpc("40fcf5e29c7970fea9b71db6b24426d496c10dbf59ef04683fd7842621b9abcf"));
const $$splitComponentImporter = () => import("./rooms._roomId.edit-DNJ_bNJv.js");
const Route$5 = createFileRoute("/_authenticated/rooms/$roomId/edit")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const Route$4 = createFileRoute("/api/public/track/script/js")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      GET: async () => {
        const scriptContent = `
(function() {
  if (window.__TELE_SIGNAL_TRACKED) return;
  window.__TELE_SIGNAL_TRACKED = true;

  const PIXEL_ID = window.pixelId;
  if (!PIXEL_ID) {
    console.warn("Telesignal: window.pixelId não definido.");
    return;
  }

  const endpoint = "/api/public/track/dr/" + PIXEL_ID;
  const urlParams = new URLSearchParams(window.location.search);
  
  // Extrai as UTMs e ids
  const payload = {
    stage: 'view',
    utm_source: urlParams.get('utm_source') || undefined,
    utm_medium: urlParams.get('utm_medium') || undefined,
    utm_campaign: urlParams.get('utm_campaign') || undefined,
    utm_content: urlParams.get('utm_content') || undefined,
    utm_term: urlParams.get('utm_term') || undefined,
    fbclid: urlParams.get('fbclid') || undefined,
    gclid: urlParams.get('gclid') || undefined,
    ttclid: urlParams.get('ttclid') || undefined,
    url: window.location.href,
  };

  // 1. Manda o evento de view imediatamente
  fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(data => {
    if (data && data.click_id) {
      // Salva o click_id no sessionStorage ou localStorage para recuperar depois
      sessionStorage.setItem('__ts_click_id', data.click_id);
    }
  })
  .catch(err => console.error("Telesignal Track Error:", err));

  // 2. Intercepta cliques nos links para registrar checkout
  document.addEventListener('click', function(e) {
    const target = e.target.closest('a');
    if (!target) return;
    
    const href = target.getAttribute('href');
    if (!href) return;

    // Se tiver click_id, adiciona na URL de destino (ex: checkout) para que o webhook identifique
    const clickId = sessionStorage.getItem('__ts_click_id');
    if (clickId) {
      try {
        const targetUrl = new URL(href, window.location.origin);
        // Evita adicionar duas vezes
        if (!targetUrl.searchParams.has('click_id')) {
          targetUrl.searchParams.set('click_id', clickId);
          target.setAttribute('href', targetUrl.toString());
        }
      } catch (err) {}
    }

    // Avisa o servidor que o usuário clicou num botão (que provavelmente é o checkout)
    fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        stage: 'checkout',
        click_id: clickId
      }),
      // keepalive garante que a request não é cancelada se a página descarregar
      keepalive: true 
    }).catch(()=>{});

  });
})();
`;
        return new Response(scriptContent, {
          status: 200,
          headers: {
            ...corsHeaders(),
            "Content-Type": "application/javascript; charset=utf-8",
            "Cache-Control": "public, max-age=3600"
          }
        });
      }
    }
  }
});
const eventEnum = z.enum(["register", "deposit", "ftd"]);
const bodySchema$1 = z.object({
  secret: z.string().min(10).max(200).optional(),
  sub1: z.string().min(1).max(60),
  event: eventEnum,
  value: z.coerce.number().nullish(),
  currency: z.string().min(3).max(3).default("BRL").optional(),
  external_user_id: z.string().max(200).nullish()
});
const Route$3 = createFileRoute("/api/public/track/postback/$pixelId")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      GET: async ({ request, params }) => handle(request, params.pixelId, "GET"),
      POST: async ({ request, params }) => handle(request, params.pixelId, "POST")
    }
  }
});
async function handle(request, pixelId, method) {
  let raw = {};
  if (method === "POST") {
    const ct = request.headers.get("content-type") ?? "";
    if (ct.includes("application/json")) {
      raw = await request.json().catch(() => ({}));
    } else {
      const form = await request.formData().catch(() => null);
      if (form) for (const [k, v] of form.entries()) raw[k] = String(v);
    }
  }
  const url = new URL(request.url);
  for (const [k, v] of url.searchParams.entries()) {
    if (raw[k] == null) raw[k] = v;
  }
  let body;
  try {
    body = bodySchema$1.parse(raw);
  } catch (e) {
    return jsonCors({ ok: false, error: e instanceof Error ? e.message : "invalid input" }, 400);
  }
  const headerSecret = request.headers.get("x-postback-secret");
  const providedSecret = body.secret ?? headerSecret ?? "";
  const { data: pixel } = await supabaseAdmin.from("tracking_pixels").select("id, postback_secret, is_active").eq("id", pixelId).maybeSingle();
  if (!pixel) return jsonCors({ ok: false, error: "pixel not found" }, 404);
  const p = pixel;
  if (!p.is_active) return jsonCors({ ok: false, error: "pixel inactive" }, 403);
  if (providedSecret !== p.postback_secret) {
    return jsonCors({ ok: false, error: "invalid secret" }, 401);
  }
  const { data: click } = await supabaseAdmin.from("tracking_clicks").select("click_id, pixel_id, registered_at, deposited_at").eq("click_id", body.sub1).eq("pixel_id", pixelId).maybeSingle();
  if (!click) return jsonCors({ ok: false, error: "click not found for sub1" }, 404);
  const c = click;
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const update = {};
  let stage;
  if (body.event === "register") {
    if (!c.registered_at) update.registered_at = nowIso;
    stage = "register";
  } else {
    if (!c.deposited_at) update.deposited_at = nowIso;
    if (body.value != null) {
      update.sale_value = body.value;
      update.sale_currency = body.currency ?? "BRL";
    }
    stage = "deposit";
  }
  if (body.external_user_id) update.external_user_id = body.external_user_id;
  if (Object.keys(update).length > 0) {
    await supabaseAdmin.from("tracking_clicks").update(update).eq("click_id", body.sub1);
  }
  const result = await fireTrackingEvent({
    clickId: body.sub1,
    stage,
    value: body.value ?? void 0,
    currency: body.currency ?? void 0
  });
  return jsonCors({ ok: true, event: body.event, capi: result });
}
const DR_STAGES = ["view", "lead", "checkout", "payment_info", "purchase", "abandoned_cart", "chargeback", "refund"];
const bodySchema = z.object({
  stage: z.enum(DR_STAGES),
  click_id: z.string().min(4).max(64).nullable().optional(),
  // identificação do comprador (opcional, mas recomendado para Purchase/Lead)
  email: z.string().email().nullable().optional(),
  phone: z.string().max(32).nullable().optional(),
  external_id: z.string().max(128).nullable().optional(),
  // valor (Purchase)
  value: z.number().nullable().optional(),
  currency: z.string().min(3).max(3).default("BRL").optional(),
  // contexto da página (usado se for primeira visita sem click_id)
  fbp: z.string().max(128).nullable().optional(),
  fbc: z.string().max(256).nullable().optional(),
  fbclid: z.string().max(256).nullable().optional(),
  landing_url: z.string().url().nullable().optional(),
  referrer: z.string().max(1024).nullable().optional(),
  utm_source: z.string().max(128).nullable().optional(),
  utm_medium: z.string().max(128).nullable().optional(),
  utm_campaign: z.string().max(128).nullable().optional(),
  utm_content: z.string().max(256).nullable().optional(),
  utm_term: z.string().max(128).nullable().optional()
});
function sha256(v) {
  return createHash("sha256").update(v.trim().toLowerCase()).digest("hex");
}
const Route$2 = createFileRoute("/api/public/track/dr/$pixelId")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      POST: async ({ request, params }) => {
        let parsed;
        try {
          parsed = bodySchema.parse(await request.json());
        } catch (e) {
          return jsonCors({ ok: false, error: "invalid_body", details: e?.message }, 400);
        }
        const { data: pixel } = await supabaseAdmin.from("tracking_pixels").select("id, user_id, is_active, tracking_mode").eq("id", params.pixelId).maybeSingle();
        if (!pixel) return jsonCors({ ok: false, error: "pixel_not_found" }, 404);
        const p = pixel;
        if (!p.is_active) return jsonCors({ ok: false, error: "pixel_inactive" }, 403);
        if (p.tracking_mode !== "direct_response") {
          return jsonCors({ ok: false, error: "pixel_not_direct_response" }, 400);
        }
        let clickId = parsed.click_id?.trim() || null;
        if (clickId) {
          const { data: existing } = await supabaseAdmin.from("tracking_clicks").select("click_id").eq("click_id", clickId).maybeSingle();
          if (!existing) clickId = null;
        }
        if (!clickId) {
          clickId = generateClickId();
          const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
          const userAgent = request.headers.get("user-agent") ?? null;
          const { error: insErr } = await supabaseAdmin.from("tracking_clicks").insert({
            click_id: clickId,
            pixel_id: p.id,
            user_id: p.user_id,
            fbp: parsed.fbp ?? null,
            fbc: parsed.fbc ?? null,
            fbclid: parsed.fbclid ?? null,
            ip,
            user_agent: userAgent,
            referrer: parsed.referrer ?? null,
            landing_url: parsed.landing_url ?? null,
            external_id: parsed.external_id ?? (parsed.email ? sha256(parsed.email) : null),
            utm_source: parsed.utm_source ?? null,
            utm_medium: parsed.utm_medium ?? null,
            utm_campaign: parsed.utm_campaign ?? null,
            utm_content: parsed.utm_content ?? null,
            utm_term: parsed.utm_term ?? null
          });
          if (insErr) return jsonCors({ ok: false, error: "click_insert_failed", details: insErr.message }, 500);
        }
        const extraUserData = {};
        if (parsed.email) extraUserData.em = sha256(parsed.email);
        if (parsed.phone) extraUserData.ph = sha256(parsed.phone.replace(/\D/g, ""));
        if (parsed.external_id) extraUserData.externalId = parsed.external_id;
        const result = await fireTrackingEvent({
          clickId,
          stage: parsed.stage,
          value: parsed.value ?? void 0,
          currency: parsed.currency,
          extraUserData
        });
        if (parsed.stage === "purchase" && parsed.value != null) {
          await supabaseAdmin.from("tracking_clicks").update({ sale_value: parsed.value, sale_currency: parsed.currency ?? "BRL" }).eq("click_id", clickId);
        }
        return jsonCors({ ok: result.ok, click_id: clickId, event: result.eventName, error: result.error });
      }
    }
  }
});
function hasPremiumEmojiEntities(post) {
  if (!post) return false;
  const ents = [...post.entities ?? [], ...post.caption_entities ?? []];
  return ents.some((e) => e.type === "custom_emoji" && !!e.custom_emoji_id);
}
async function getActivePremiumAccount(userId, accountId) {
  let q = supabaseAdmin.from("telegram_accounts").select("id, tg_api_id, tg_api_hash, tg_session").eq("user_id", userId).eq("account_type", "premium").eq("is_active", true).not("tg_session", "is", null);
  if (accountId) q = q.eq("id", accountId);
  else q = q.limit(1);
  const { data } = await q.maybeSingle();
  if (!data?.tg_session || !data.tg_api_id || !data.tg_api_hash) return null;
  return data;
}
async function convertEntities(ents) {
  if (!ents?.length) return [];
  const { Api } = await import("telegram");
  const { default: bigInt } = await import("big-integer");
  const out = [];
  for (const e of ents) {
    const base = { offset: e.offset, length: e.length };
    switch (e.type) {
      case "bold":
        out.push(new Api.MessageEntityBold(base));
        break;
      case "italic":
        out.push(new Api.MessageEntityItalic(base));
        break;
      case "underline":
        out.push(new Api.MessageEntityUnderline(base));
        break;
      case "strikethrough":
        out.push(new Api.MessageEntityStrike(base));
        break;
      case "spoiler":
        out.push(new Api.MessageEntitySpoiler(base));
        break;
      case "blockquote":
        out.push(new Api.MessageEntityBlockquote({ ...base, collapsed: false }));
        break;
      case "code":
        out.push(new Api.MessageEntityCode(base));
        break;
      case "pre":
        out.push(new Api.MessageEntityPre({ ...base, language: e.language ?? "" }));
        break;
      case "text_link":
        if (e.url) out.push(new Api.MessageEntityTextUrl({ ...base, url: e.url }));
        break;
      case "url":
        out.push(new Api.MessageEntityUrl(base));
        break;
      case "email":
        out.push(new Api.MessageEntityEmail(base));
        break;
      case "phone_number":
        out.push(new Api.MessageEntityPhone(base));
        break;
      case "mention":
        out.push(new Api.MessageEntityMention(base));
        break;
      case "hashtag":
        out.push(new Api.MessageEntityHashtag(base));
        break;
      case "cashtag":
        out.push(new Api.MessageEntityCashtag(base));
        break;
      case "bot_command":
        out.push(new Api.MessageEntityBotCommand(base));
        break;
      case "custom_emoji":
        if (e.custom_emoji_id) {
          out.push(new Api.MessageEntityCustomEmoji({
            ...base,
            documentId: bigInt(e.custom_emoji_id)
          }));
        }
        break;
    }
  }
  return out;
}
async function getFileUrl(botToken, fileId) {
  const r = await fetch(`https://api.telegram.org/bot${botToken}/getFile`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ file_id: fileId })
  });
  const j = await r.json().catch(() => null);
  const fp = j?.result?.file_path;
  if (!fp) return null;
  return `https://api.telegram.org/file/bot${botToken}/${fp}`;
}
async function forwardWithPremiumEmojis(opts) {
  const acc = await getActivePremiumAccount(opts.userId, opts.premiumAccountId ?? null);
  if (!acc) {
    return { applied: false, reason: "no-premium-account" };
  }
  const { TelegramClient, Api } = await import("telegram");
  const { StringSession } = await import("telegram/sessions/index.js");
  const client = new TelegramClient(
    new StringSession(acc.tg_session),
    acc.tg_api_id,
    acc.tg_api_hash,
    { connectionRetries: 2, useWSS: true }
  );
  await client.connect();
  let isPremium = false;
  try {
    const me = await client.invoke(new Api.users.GetFullUser({ id: new Api.InputUserSelf() }));
    const user = (me.users ?? []).find((u) => u.className === "User");
    isPremium = Boolean(user?.premium);
  } catch {
    isPremium = false;
  }
  if (!isPremium) {
    await client.disconnect().catch(() => {
    });
    return {
      applied: true,
      ok: false,
      error: "A conta Telegram conectada não tem Premium ativo — o Telegram remove os emojis animados ao entregar."
    };
  }
  const target = typeof opts.targetChatId === "string" ? Number(opts.targetChatId) : opts.targetChatId;
  try {
    const post = opts.post;
    if (post.text) {
      const entities = await convertEntities(post.entities);
      const msg2 = await client.sendMessage(target, {
        message: post.text,
        formattingEntities: entities,
        linkPreview: false
      });
      return { applied: true, ok: true, messageId: Number(msg2.id) };
    }
    let fileId = null;
    let mimeHint;
    let isVoice = false;
    let isVideoNote = false;
    let isAnimation = false;
    let duration;
    let width;
    let height;
    let filename;
    let isPhoto = false;
    if (post.photo?.length) {
      const best = post.photo.reduce((a, b) => a.width * a.height >= b.width * b.height ? a : b);
      fileId = best.file_id;
      isPhoto = true;
    } else if (post.video) {
      fileId = post.video.file_id;
      mimeHint = post.video.mime_type;
      duration = post.video.duration;
      width = post.video.width;
      height = post.video.height;
      filename = post.video.file_name ?? "video.mp4";
    } else if (post.animation) {
      fileId = post.animation.file_id;
      mimeHint = post.animation.mime_type;
      duration = post.animation.duration;
      width = post.animation.width;
      height = post.animation.height;
      filename = post.animation.file_name ?? "animation.mp4";
      isAnimation = true;
    } else if (post.document) {
      fileId = post.document.file_id;
      mimeHint = post.document.mime_type;
      filename = post.document.file_name ?? "file";
    } else if (post.audio) {
      fileId = post.audio.file_id;
      mimeHint = post.audio.mime_type;
      duration = post.audio.duration;
      filename = post.audio.file_name ?? "audio.mp3";
    } else if (post.voice) {
      fileId = post.voice.file_id;
      mimeHint = post.voice.mime_type ?? "audio/ogg";
      duration = post.voice.duration;
      isVoice = true;
      filename = "voice.ogg";
    } else if (post.video_note) {
      fileId = post.video_note.file_id;
      duration = post.video_note.duration;
      isVideoNote = true;
      filename = "video_note.mp4";
    }
    if (!fileId) {
      await client.disconnect().catch(() => {
      });
      return { applied: false, reason: "unsupported-media" };
    }
    const fileUrl = await getFileUrl(opts.botToken, fileId);
    if (!fileUrl) {
      return { applied: true, ok: false, error: "Não foi possível obter o arquivo original do Telegram." };
    }
    const caption = post.caption ?? "";
    const captionEntities = await convertEntities(post.caption_entities);
    const attributes = [];
    if (isVoice) {
      attributes.push(new Api.DocumentAttributeAudio({ duration: Math.max(1, Math.round(duration ?? 1)), voice: true }));
    } else if (isVideoNote) {
      attributes.push(new Api.DocumentAttributeVideo({
        duration: Math.max(1, Math.round(duration ?? 1)),
        w: 240,
        h: 240,
        roundMessage: true
      }));
    } else if (post.video || post.animation) {
      attributes.push(new Api.DocumentAttributeVideo({
        duration: Math.max(1, Math.round(duration ?? 1)),
        w: width ?? 0,
        h: height ?? 0,
        supportsStreaming: !isAnimation
      }));
      if (isAnimation) attributes.push(new Api.DocumentAttributeAnimated());
      if (filename) attributes.push(new Api.DocumentAttributeFilename({ fileName: filename }));
    } else if (post.audio) {
      attributes.push(new Api.DocumentAttributeAudio({
        duration: Math.max(1, Math.round(duration ?? 1)),
        title: post.audio?.title,
        performer: post.audio?.performer
      }));
      if (filename) attributes.push(new Api.DocumentAttributeFilename({ fileName: filename }));
    } else if (post.document) {
      if (filename) attributes.push(new Api.DocumentAttributeFilename({ fileName: filename }));
    }
    const msg = await client.sendFile(target, {
      file: fileUrl,
      caption,
      formattingEntities: captionEntities,
      forceDocument: !!post.document && !post.video && !post.animation,
      ...isPhoto ? {} : { attributes },
      ...mimeHint ? { mimeType: mimeHint } : {},
      supportsStreaming: !!post.video
    });
    return { applied: true, ok: true, messageId: Number(msg.id) };
  } catch (e) {
    const raw = e instanceof Error ? e.message : String(e);
    return { applied: true, ok: false, error: raw };
  } finally {
    await client.disconnect().catch(() => {
    });
  }
}
function safeEqual(a, b) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}
function classify(oldStatus, newStatus) {
  const wasIn = oldStatus === "member" || oldStatus === "administrator" || oldStatus === "creator" || oldStatus === "restricted";
  const isIn = newStatus === "member" || newStatus === "administrator" || newStatus === "creator" || newStatus === "restricted";
  if (!wasIn && isIn) return "join";
  if (wasIn && !isIn) {
    if (newStatus === "kicked" || newStatus === "banned") return "kicked";
    return "leave";
  }
  return null;
}
function publicUrl(bucket, path) {
  const base = (process.env.SUPABASE_URL ?? "").replace(/\/$/, "");
  return `${base}/storage/v1/object/public/${bucket}/${path}`;
}
async function hasActiveSub(userId, botType) {
  const { data } = await supabaseAdmin.from("user_engagement_subscriptions").select("id").eq("user_id", userId).eq("bot_type", botType).eq("status", "active").limit(1).maybeSingle();
  return !!data;
}
async function logBot(entry) {
  try {
    await supabaseAdmin.from("bot_execution_logs").insert({
      user_id: entry.userId,
      account_id: entry.accountId ?? null,
      room_id: entry.roomId ?? null,
      bot_type: entry.botType,
      event: entry.event,
      chat_id: entry.chatId ?? null,
      target_chat_id: entry.targetChatId ?? null,
      tg_user_id: entry.tgUserId ?? null,
      tg_username: entry.tgUsername ?? null,
      tg_first_name: entry.tgFirstName ?? null,
      message: entry.message ?? null,
      error: entry.error ?? null,
      details: entry.details ?? null
    });
  } catch (e) {
    console.error("[bot-log] insert failed:", e);
  }
}
function renderTemplate(tpl, vars) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? "");
}
async function sendWelcomeBlock(opts) {
  const parse_mode = opts.parseMode || "HTML";
  const usePremium = !!opts.premiumEnabled && !!opts.premiumAccountId;
  const reply_markup = opts.replyMarkup ?? void 0;
  if (opts.videoId) {
    const { data: vid } = await supabaseAdmin.from("videos").select("storage_path, kind, mime_type, duration_seconds, title, width, height").eq("id", opts.videoId).maybeSingle();
    if (vid?.storage_path) {
      const isRound = vid.kind === "round";
      const resp2 = isRound ? await dispatchVideoNote({
        botToken: opts.botToken,
        storagePath: vid.storage_path,
        chatId: opts.chatId,
        duration: vid.duration_seconds,
        mimeType: vid.mime_type,
        filename: (vid.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4"
      }) : await dispatchVideo({
        botToken: opts.botToken,
        storagePath: vid.storage_path,
        chatId: opts.chatId,
        duration: vid.duration_seconds,
        width: vid.width,
        height: vid.height,
        mimeType: vid.mime_type,
        filename: (vid.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
        caption: opts.text,
        parseMode: parse_mode,
        replyMarkup: reply_markup
      });
      if (isRound) {
        if (usePremium) {
          const pr = await sendTextWithPremiumEmojis({
            userId: opts.userId,
            accountId: opts.premiumAccountId,
            chatId: opts.chatId,
            text: opts.text,
            allowPlain: true
          });
          if (!pr.applied || !pr.ok) {
            await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: opts.text, parse_mode, reply_markup });
          } else if (reply_markup) {
            await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: "⁣", reply_markup });
          }
        } else {
          await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: opts.text, parse_mode, reply_markup });
        }
      }
      return { ok: !!resp2?.ok, description: resp2?.description, mediaKind: isRound ? "video_note" : "video" };
    }
  }
  if (opts.imagePath) {
    const url = publicUrl("room-images", opts.imagePath);
    if (usePremium) {
      const r = await sendPhotoWithPremiumEmojiCaption({
        userId: opts.userId,
        accountId: opts.premiumAccountId,
        chatId: opts.chatId,
        photoUrl: url,
        caption: opts.text,
        strict: false
      });
      if (r.applied && r.ok) {
        if (reply_markup) {
          await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: "⁣", reply_markup });
        }
        return { ok: true, mediaKind: "photo" };
      }
    }
    const resp2 = await callTelegram(opts.botToken, "sendPhoto", {
      chat_id: opts.chatId,
      photo: url,
      caption: opts.text,
      parse_mode,
      reply_markup
    });
    return { ok: !!resp2?.ok, description: resp2?.description, mediaKind: "photo" };
  }
  if (usePremium) {
    const r = await sendTextWithPremiumEmojis({
      userId: opts.userId,
      accountId: opts.premiumAccountId,
      chatId: opts.chatId,
      text: opts.text,
      allowPlain: true
    });
    if (r.applied && r.ok) {
      if (reply_markup) {
        await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: "⁣", reply_markup });
      }
      return { ok: true, mediaKind: "text" };
    }
  }
  const resp = await callTelegram(opts.botToken, "sendMessage", {
    chat_id: opts.chatId,
    text: opts.text,
    parse_mode,
    reply_markup,
    disable_web_page_preview: true
  });
  return { ok: !!resp?.ok, description: resp?.description, mediaKind: "text" };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function runWelcomeBot(opts) {
  if (!opts.botToken || !opts.user.id) return;
  await logBot({
    userId: opts.userId,
    accountId: opts.accountId,
    botType: "boasvindas",
    event: "received",
    chatId: opts.chatId,
    tgUserId: opts.user.id ?? null,
    tgUsername: opts.user.username ?? null,
    tgFirstName: opts.user.first_name ?? null
  });
  if (!await hasActiveSub(opts.userId, "boasvindas")) {
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      botType: "boasvindas",
      event: "skipped",
      chatId: opts.chatId,
      tgUserId: opts.user.id ?? null,
      message: "Sem assinatura ativa do BotBoasVindas"
    });
    return;
  }
  const testRes = await callTelegram(opts.botToken, "sendMessage", {
    chat_id: opts.user.id,
    text: "Test message from webhook"
  });
  console.log("[test-send-message]", testRes);
  const { data: rc } = await supabaseAdmin.from("room_chats").select("room_id").eq("user_id", opts.userId).eq("chat_id", opts.chatId).limit(1).maybeSingle();
  if (!rc?.room_id) {
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      botType: "boasvindas",
      event: "skipped",
      chatId: opts.chatId,
      message: "Chat não está vinculado a nenhuma sala"
    });
    return;
  }
  const { data: cfg } = await supabaseAdmin.from("room_engagement_settings").select("welcome_bot_enabled, welcome_message, welcome_image_path, welcome_image_mime, welcome_video_id, welcome_parse_mode, welcome_premium_enabled, welcome_premium_account_id, followup_cta_enabled, followup_cta_button_text").eq("room_id", rc.room_id).maybeSingle();
  if (!cfg?.welcome_bot_enabled) {
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      roomId: rc.room_id,
      botType: "boasvindas",
      event: "skipped",
      chatId: opts.chatId,
      message: "BotBoasVindas desativado para esta sala"
    });
    return;
  }
  const firstName = (opts.user.first_name ?? "amigo(a)").replace(/[<>&]/g, "");
  const mention = `<a href="tg://user?id=${opts.user.id}">${firstName}</a>`;
  const text = renderTemplate(cfg.welcome_message ?? "Seja bem-vindo(a), {name}! 🎉", {
    name: mention,
    first_name: firstName,
    username: opts.user.username ?? ""
  });
  const parse_mode = cfg.welcome_parse_mode ?? "HTML";
  let ctaReplyMarkup = null;
  const ctaEnabled = cfg.followup_cta_enabled;
  if (ctaEnabled) {
    const { data: bot } = await supabaseAdmin.from("telegram_accounts").select("bot_username").eq("id", opts.accountId).maybeSingle();
    if (bot?.bot_username) {
      const ctaText = cfg.followup_cta_button_text || "Iniciar conversa privada 💬";
      ctaReplyMarkup = {
        inline_keyboard: [
          [{ text: ctaText, url: `https://t.me/${bot.bot_username}?start=fu_${rc.room_id}` }]
        ]
      };
    }
  }
  const first = await sendWelcomeBlock({
    userId: opts.userId,
    botToken: opts.botToken,
    chatId: opts.user.id,
    text,
    parseMode: parse_mode,
    imagePath: cfg.welcome_image_path,
    videoId: cfg.welcome_video_id,
    premiumEnabled: cfg.welcome_premium_enabled,
    premiumAccountId: cfg.welcome_premium_account_id,
    replyMarkup: ctaReplyMarkup
  });
  await logBot({
    userId: opts.userId,
    accountId: opts.accountId,
    roomId: rc.room_id,
    botType: "boasvindas",
    event: first.ok ? "sent" : "failed",
    chatId: opts.chatId,
    tgUserId: opts.user.id ?? null,
    tgFirstName: opts.user.first_name ?? null,
    message: text,
    error: first.ok ? null : first.description ?? "telegram error",
    details: { media: first.mediaKind, step: 0 }
  });
  const { data: extras } = await supabaseAdmin.from("welcome_extra_messages").select("*").eq("room_id", rc.room_id).order("sort_order", { ascending: true });
  const list = extras ?? [];
  for (let i = 0; i < list.length; i++) {
    const ex = list[i];
    const wait = Math.max(0, Math.min(300, Number(ex.delay_seconds ?? 2)));
    if (wait > 0) await sleep(wait * 1e3);
    const body = renderTemplate(ex.content ?? "", {
      name: mention,
      first_name: firstName,
      username: opts.user.username ?? ""
    });
    const r = await sendWelcomeBlock({
      userId: opts.userId,
      botToken: opts.botToken,
      chatId: opts.user.id,
      text: body,
      parseMode: ex.parse_mode || "HTML",
      imagePath: ex.image_path,
      videoId: ex.video_id,
      premiumEnabled: ex.premium_enabled,
      premiumAccountId: ex.premium_account_id
    });
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      roomId: rc.room_id,
      botType: "boasvindas",
      event: r.ok ? "sent" : "failed",
      chatId: opts.chatId,
      tgUserId: opts.user.id ?? null,
      tgFirstName: opts.user.first_name ?? null,
      message: body,
      error: r.ok ? null : r.description ?? "telegram error",
      details: { media: r.mediaKind, step: i + 1 }
    });
  }
}
async function runForwarder(opts) {
  if (!opts.botToken) return;
  const { data: cfgs } = await supabaseAdmin.from("room_engagement_settings").select("forwarder_enabled, forwarder_target_chat_ids, forwarder_allowed_types, forwarder_premium_enabled, forwarder_premium_account_id, rooms!inner(is_active)").eq("user_id", opts.userId).eq("forwarder_enabled", true).eq("forwarder_source_chat_id", opts.fromChatId).eq("rooms.is_active", true);
  if (!cfgs?.length) return;
  const { data: dedupeHit } = await supabaseAdmin.from("forwarder_dedupe").select("chat_id").eq("chat_id", opts.fromChatId).eq("message_id", opts.messageId).maybeSingle();
  if (dedupeHit) {
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      botType: "encaminhador",
      event: "skipped",
      chatId: opts.fromChatId,
      message: "Mensagem já replicada internamente (mirror) — evitando duplicação",
      details: { message_id: opts.messageId, type: opts.messageType, dedupe: true }
    });
    return;
  }
  await logBot({
    userId: opts.userId,
    accountId: opts.accountId,
    botType: "encaminhador",
    event: "received",
    chatId: opts.fromChatId,
    details: { message_id: opts.messageId, type: opts.messageType }
  });
  if (!await hasActiveSub(opts.userId, "encaminhador")) {
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      botType: "encaminhador",
      event: "skipped",
      chatId: opts.fromChatId,
      message: "Sem assinatura ativa do BotEncaminhador"
    });
    return;
  }
  const allowed = /* @__PURE__ */ new Set();
  for (const c of cfgs) for (const t of c.forwarder_allowed_types ?? []) allowed.add(t);
  if (!allowed.has(opts.messageType)) {
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      botType: "encaminhador",
      event: "skipped",
      chatId: opts.fromChatId,
      message: `Tipo "${opts.messageType}" não está habilitado para encaminhamento`,
      details: { message_id: opts.messageId, type: opts.messageType }
    });
    return;
  }
  const targets = /* @__PURE__ */ new Set();
  for (const c of cfgs) for (const t of c.forwarder_target_chat_ids ?? []) targets.add(t);
  const premiumEnabled = cfgs.some((c) => c.forwarder_premium_enabled);
  const premiumAccountId = cfgs.find((c) => c.forwarder_premium_account_id)?.forwarder_premium_account_id ?? null;
  const hasPremiumEmoji = premiumEnabled && hasPremiumEmojiEntities(opts.post);
  for (const target of targets) {
    if (target === opts.fromChatId) continue;
    let okSent = false;
    let errStr = null;
    let via = "bot-api";
    if (hasPremiumEmoji) {
      via = "premium-mtproto";
      const pr = await forwardWithPremiumEmojis({
        userId: opts.userId,
        botToken: opts.botToken,
        post: opts.post,
        targetChatId: target,
        premiumAccountId
      }).catch((e) => ({ applied: true, ok: false, error: e instanceof Error ? e.message : String(e) }));
      if (pr.applied && pr.ok) {
        okSent = true;
      } else if (pr.applied && !pr.ok) {
        okSent = false;
        errStr = pr.error;
      } else {
        via = "bot-api";
        const r = await callTelegram(opts.botToken, "copyMessage", {
          chat_id: target,
          from_chat_id: opts.fromChatId,
          message_id: opts.messageId
        });
        okSent = !!r?.ok;
        errStr = r?.ok ? null : r?.description ?? "telegram error";
        if (okSent) {
          errStr = "premium emojis removidos (sem conta Premium ativa) — usei Bot API";
        }
      }
    } else {
      const r = await callTelegram(opts.botToken, "copyMessage", {
        chat_id: target,
        from_chat_id: opts.fromChatId,
        message_id: opts.messageId
      });
      okSent = !!r?.ok;
      errStr = r?.ok ? null : r?.description ?? "telegram error";
    }
    await logBot({
      userId: opts.userId,
      accountId: opts.accountId,
      botType: "encaminhador",
      event: okSent ? "sent" : "failed",
      chatId: opts.fromChatId,
      targetChatId: target,
      error: okSent ? null : errStr,
      details: { message_id: opts.messageId, type: opts.messageType, via, premium_emojis: hasPremiumEmoji, note: okSent ? errStr : void 0 }
    });
  }
}
async function cacheDetectedChat(opts) {
  const chat = opts.chat;
  if (!chat?.id || !chat.type) return;
  if (!["group", "supergroup", "channel"].includes(chat.type)) return;
  await supabaseAdmin.from("telegram_chats").upsert(
    {
      account_id: opts.accountId,
      user_id: opts.userId,
      chat_id: chat.id,
      title: chat.title ?? null,
      type: chat.type,
      username: chat.username ?? null,
      cached_at: (/* @__PURE__ */ new Date()).toISOString()
    },
    { onConflict: "account_id,chat_id" }
  );
}
const Route$1 = createFileRoute("/api/public/telegram/webhook/$accountId")({
  server: {
    handlers: {
      POST: async ({ request, params }) => {
        const accountId = params.accountId;
        const { data: acc } = await supabaseAdmin.from("telegram_accounts").select("id, user_id, bot_token").eq("id", accountId).maybeSingle();
        if (!acc) return new Response("not found", { status: 404 });
        const expected = createHash("sha256").update(`tg-tracking:${acc.bot_token}`).digest("base64url");
        const provided = request.headers.get("x-telegram-bot-api-secret-token") ?? "";
        if (!safeEqual(provided, expected)) {
          return new Response("unauthorized", { status: 401 });
        }
        const update = await request.json().catch(() => null);
        if (!update) return Response.json({ ok: true });
        const msg = update.message;
        const text = msg?.text;
        if (msg?.from?.id && typeof text === "string" && text.startsWith("/start ")) {
          const payload = text.slice(7).trim();
          const m = payload.match(/^tk_([A-Za-z0-9]{6,32})$/);
          if (m) {
            const clickId = m[1];
            const { data: click } = await supabaseAdmin.from("tracking_clicks").select("click_id, user_id, joined_at").eq("click_id", clickId).maybeSingle();
            if (click && click.user_id === acc.user_id) {
              const c = click;
              if (!c.joined_at) {
                await supabaseAdmin.from("tracking_clicks").update({
                  joined_at: (/* @__PURE__ */ new Date()).toISOString(),
                  tg_user_id: msg.from.id,
                  tg_username: msg.from.username ?? null
                }).eq("click_id", clickId);
              }
              await fireTrackingEvent({
                clickId,
                stage: "join",
                extraUserData: {
                  firstName: msg.from.first_name ?? null,
                  lastName: msg.from.last_name ?? null,
                  externalId: msg.from.id
                }
              }).catch((e) => console.error("[track4you] capi failed:", e));
            }
          }
          const fm = payload.match(/^fu_([0-9a-fA-F-]{36})$/);
          if (fm && msg.chat?.type === "private") {
            const roomId = fm[1];
            const { data: room } = await supabaseAdmin.from("rooms").select("id, user_id").eq("id", roomId).maybeSingle();
            if (room && room.user_id === acc.user_id) {
              await supabaseAdmin.from("followup_leads").upsert(
                {
                  user_id: acc.user_id,
                  room_id: roomId,
                  account_id: acc.id,
                  tg_user_id: msg.from.id,
                  chat_id: msg.chat.id,
                  first_name: msg.from.first_name ?? null,
                  username: msg.from.username ?? null,
                  status: "active"
                },
                { onConflict: "room_id,tg_user_id" }
              );
              await callTelegram(acc.bot_token, "sendMessage", {
                chat_id: msg.chat.id,
                text: `Olá ${msg.from.first_name ?? ""}! Você está inscrito para receber novidades diárias. 🎉`
              }).catch(() => void 0);
            }
          }
        }
        await cacheDetectedChat({
          userId: acc.user_id,
          accountId: acc.id,
          chat: update.channel_post?.chat ?? update.message?.chat ?? update.chat_member?.chat ?? update.my_chat_member?.chat
        }).catch((e) => console.error("[telegram-chat-cache] failed:", e));
        const cm = update.chat_member ?? update.my_chat_member;
        if (cm) {
          if (update.my_chat_member && cm.chat?.type === "private" && (cm.new_chat_member?.status === "kicked" || cm.new_chat_member?.status === "left")) {
            const u = cm.new_chat_member?.user ?? cm.from ?? {};
            if (u.id) {
              await supabaseAdmin.from("followup_leads").update({
                status: "stopped",
                stopped_at: (/* @__PURE__ */ new Date()).toISOString(),
                stopped_reason: "blocked"
              }).eq("account_id", acc.id).eq("tg_user_id", u.id);
            }
          }
          const eventType = classify(cm.old_chat_member?.status, cm.new_chat_member?.status);
          if (eventType) {
            const u = cm.new_chat_member?.user ?? cm.old_chat_member?.user ?? {};
            await supabaseAdmin.from("telegram_member_events").insert({
              user_id: acc.user_id,
              account_id: acc.id,
              chat_id: cm.chat.id,
              chat_title: cm.chat.title ?? null,
              tg_user_id: u.id ?? 0,
              tg_username: u.username ?? null,
              tg_first_name: u.first_name ?? null,
              event_type: eventType,
              old_status: cm.old_chat_member?.status ?? null,
              new_status: cm.new_chat_member?.status ?? null,
              occurred_at: new Date((cm.date ?? Math.floor(Date.now() / 1e3)) * 1e3).toISOString()
            });
            if (u.id) {
              const { data: integ } = await supabaseAdmin.from("meta_integrations").select("event_mappings, is_active").eq("user_id", acc.user_id).maybeSingle();
              const mappings = integ?.event_mappings ?? {};
              const chosen = mappings[eventType];
              if (integ?.is_active && chosen && chosen !== "off") {
                await sendMetaEvent({
                  userId: acc.user_id,
                  eventName: chosen,
                  eventId: `tg-${eventType}-${cm.chat.id}-${u.id}-${cm.date ?? Math.floor(Date.now() / 1e3)}`,
                  actionSource: "system_generated",
                  userData: {
                    externalId: u.id,
                    firstName: u.first_name ?? null,
                    lastName: u.last_name ?? null
                  },
                  customData: {
                    content_name: cm.chat.title ?? "Telegram group",
                    content_ids: [String(cm.chat.id)],
                    content_type: "telegram_group"
                  }
                });
              }
            }
            if (eventType === "join") {
              await runWelcomeBot({
                userId: acc.user_id,
                accountId: acc.id,
                botToken: acc.bot_token,
                chatId: cm.chat.id,
                user: u
              }).catch((e) => console.error("[welcome-bot] failed:", e));
            }
          }
        }
        const joinReq = update.chat_join_request;
        if (joinReq?.from?.id && joinReq?.chat?.id) {
          await cacheDetectedChat({
            userId: acc.user_id,
            accountId: acc.id,
            chat: joinReq.chat
          }).catch((e) => console.error("[telegram-chat-cache] join_req failed:", e));
          await runWelcomeBot({
            userId: acc.user_id,
            accountId: acc.id,
            botToken: acc.bot_token,
            chatId: joinReq.chat.id,
            user: joinReq.from
          }).catch((e) => console.error("[welcome-bot] join_req failed:", e));
          const { data: rc } = await supabaseAdmin.from("room_chats").select("room_id").eq("user_id", acc.user_id).eq("chat_id", joinReq.chat.id).limit(1).maybeSingle();
          if (rc?.room_id) {
            const { data: cfg } = await supabaseAdmin.from("room_engagement_settings").select("welcome_bot_enabled").eq("room_id", rc.room_id).maybeSingle();
            if (cfg?.welcome_bot_enabled) {
              await callTelegram(acc.bot_token, "approveChatJoinRequest", {
                chat_id: joinReq.chat.id,
                user_id: joinReq.from.id
              }).catch((e) => console.error("[auto-approve] failed:", e));
            }
          }
        }
        const post = update.channel_post ?? update.message;
        if (post?.chat?.id && post?.message_id) {
          const messageType = post.text ? "text" : post.photo ? "photo" : post.video ? "video" : post.video_note ? "video_note" : post.animation ? "animation" : post.document ? "document" : post.audio ? "audio" : post.voice ? "voice" : post.sticker ? "sticker" : post.poll ? "poll" : post.location ? "location" : post.contact ? "contact" : "other";
          await runForwarder({
            userId: acc.user_id,
            accountId: acc.id,
            botToken: acc.bot_token,
            fromChatId: post.chat.id,
            messageId: post.message_id,
            messageType,
            post
          }).catch((e) => console.error("[forwarder] failed:", e));
        }
        return Response.json({ ok: true });
      }
    }
  }
});
const Route = createFileRoute("/api/public/track/g/$clickId/$offerSlug")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: corsHeaders() }),
      GET: async ({ params }) => {
        const { clickId, offerSlug } = params;
        const { data: click } = await supabaseAdmin.from("tracking_clicks").select("click_id, pixel_id, user_id, clicked_offer_at").eq("click_id", clickId).maybeSingle();
        if (!click) return new Response("click not found", { status: 404 });
        const c = click;
        const { data: offer } = await supabaseAdmin.from("tracking_offers").select("destination_url, subid_param").eq("pixel_id", c.pixel_id).eq("slug", offerSlug).maybeSingle();
        if (!offer) return new Response("offer not found", { status: 404 });
        const o = offer;
        if (!c.clicked_offer_at) {
          await supabaseAdmin.from("tracking_clicks").update({ clicked_offer_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("click_id", clickId);
          await fireTrackingEvent({ clickId, stage: "offer_click" }).catch(
            (e) => console.error("[track/g] capi failed:", e)
          );
        }
        const dest = new URL(o.destination_url);
        dest.searchParams.set(o.subid_param || "sub1", clickId);
        return Response.redirect(dest.toString(), 302);
      }
    }
  }
});
const SignupRoute = Route$S.update({
  id: "/signup",
  path: "/signup",
  getParentRoute: () => Route$T
});
const LoginRoute = Route$R.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$T
});
const AuthenticatedRoute = Route$Q.update({
  id: "/_authenticated",
  getParentRoute: () => Route$T
});
const IndexRoute = Route$P.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$T
});
const AuthenticatedVideosRoute = Route$O.update({
  id: "/videos",
  path: "/videos",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTutorialRoute = Route$N.update({
  id: "/tutorial",
  path: "/tutorial",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTelegramAccountsRoute = Route$M.update({
  id: "/telegram-accounts",
  path: "/telegram-accounts",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedRecargaRoute = Route$L.update({
  id: "/recarga",
  path: "/recarga",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedPremiumEmojisRoute = Route$K.update({
  id: "/premium-emojis",
  path: "/premium-emojis",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedPerfilRoute = Route$J.update({
  id: "/perfil",
  path: "/perfil",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedNotificacoesRoute = Route$I.update({
  id: "/notificacoes",
  path: "/notificacoes",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMensagensRoute = Route$H.update({
  id: "/mensagens",
  path: "/mensagens",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedMembrosRoute = Route$G.update({
  id: "/membros",
  path: "/membros",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedDashboardRoute = Route$F.update({
  id: "/dashboard",
  path: "/dashboard",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedAudiosRoute = Route$E.update({
  id: "/audios",
  path: "/audios",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoIndexRoute = Route$D.update({
  id: "/trackeamento/",
  path: "/trackeamento/",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedRoomsIndexRoute = Route$C.update({
  id: "/rooms/",
  path: "/rooms/",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoUtmsRoute = Route$B.update({
  id: "/trackeamento/utms",
  path: "/trackeamento/utms",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoPostbacksRoute = Route$A.update({
  id: "/trackeamento/postbacks",
  path: "/trackeamento/postbacks",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoPixelsRoute = Route$z.update({
  id: "/trackeamento/pixels",
  path: "/trackeamento/pixels",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoMetricasRoute = Route$y.update({
  id: "/trackeamento/metricas",
  path: "/trackeamento/metricas",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoMensagensRoute = Route$x.update({
  id: "/trackeamento/mensagens",
  path: "/trackeamento/mensagens",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoIntegracoesRoute = Route$w.update({
  id: "/trackeamento/integracoes",
  path: "/trackeamento/integracoes",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoFunisRoute = Route$v.update({
  id: "/trackeamento/funis",
  path: "/trackeamento/funis",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoDominiosRoute = Route$u.update({
  id: "/trackeamento/dominios",
  path: "/trackeamento/dominios",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedTrackeamentoCanalRoute = Route$t.update({
  id: "/trackeamento/canal",
  path: "/trackeamento/canal",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedPromocoesEstatisticasRoute = Route$s.update({
  id: "/promocoes/estatisticas",
  path: "/promocoes/estatisticas",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedPromocoesContasRoute = Route$r.update({
  id: "/promocoes/contas",
  path: "/promocoes/contas",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedIntegracoesMetaRoute = Route$q.update({
  id: "/integracoes/meta",
  path: "/integracoes/meta",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedBotsLogsRoute = Route$p.update({
  id: "/bots/logs",
  path: "/bots/logs",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedBotsFollowupRoute = Route$o.update({
  id: "/bots/followup",
  path: "/bots/followup",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedBotsEncaminhadorRoute = Route$n.update({
  id: "/bots/encaminhador",
  path: "/bots/encaminhador",
  getParentRoute: () => AuthenticatedRoute
});
const AuthenticatedBotsBoasvindasRoute = Route$m.update({
  id: "/bots/boasvindas",
  path: "/bots/boasvindas",
  getParentRoute: () => AuthenticatedRoute
});
const ApiPublicWivenWebhookRoute = Route$l.update({
  id: "/api/public/wiven/webhook",
  path: "/api/public/wiven/webhook",
  getParentRoute: () => Route$T
});
const ApiPublicTrackClickRoute = Route$k.update({
  id: "/api/public/track/click",
  path: "/api/public/track/click",
  getParentRoute: () => Route$T
});
const ApiPublicKirvanoWebhookRoute = Route$j.update({
  id: "/api/public/kirvano/webhook",
  path: "/api/public/kirvano/webhook",
  getParentRoute: () => Route$T
});
const ApiPublicGoDispatchIdRoute = Route$i.update({
  id: "/api/public/go/$dispatchId",
  path: "/api/public/go/$dispatchId",
  getParentRoute: () => Route$T
});
const ApiPublicCronSyncPromoConversionsRoute = Route$h.update({
  id: "/api/public/cron/sync-promo-conversions",
  path: "/api/public/cron/sync-promo-conversions",
  getParentRoute: () => Route$T
});
const ApiPublicCronSyncEngagementOrdersRoute = Route$g.update({
  id: "/api/public/cron/sync-engagement-orders",
  path: "/api/public/cron/sync-engagement-orders",
  getParentRoute: () => Route$T
});
const ApiPublicCronHotTeasersRoute = Route$f.update({
  id: "/api/public/cron/hot-teasers",
  path: "/api/public/cron/hot-teasers",
  getParentRoute: () => Route$T
});
const ApiPublicCronExpertEngagementRoute = Route$e.update({
  id: "/api/public/cron/expert-engagement",
  path: "/api/public/cron/expert-engagement",
  getParentRoute: () => Route$T
});
const ApiPublicCronDispatchSignalsRoute = Route$d.update({
  id: "/api/public/cron/dispatch-signals",
  path: "/api/public/cron/dispatch-signals",
  getParentRoute: () => Route$T
});
const ApiPublicCronDispatchSessionsRoute = Route$c.update({
  id: "/api/public/cron/dispatch-sessions",
  path: "/api/public/cron/dispatch-sessions",
  getParentRoute: () => Route$T
});
const ApiPublicCronDispatchRecurringRoute = Route$b.update({
  id: "/api/public/cron/dispatch-recurring",
  path: "/api/public/cron/dispatch-recurring",
  getParentRoute: () => Route$T
});
const ApiPublicCronDispatchPromosRoute = Route$a.update({
  id: "/api/public/cron/dispatch-promos",
  path: "/api/public/cron/dispatch-promos",
  getParentRoute: () => Route$T
});
const ApiPublicCronDispatchMarketTipsRoute = Route$9.update({
  id: "/api/public/cron/dispatch-market-tips",
  path: "/api/public/cron/dispatch-market-tips",
  getParentRoute: () => Route$T
});
const ApiPublicCronDispatchFollowupsRoute = Route$8.update({
  id: "/api/public/cron/dispatch-followups",
  path: "/api/public/cron/dispatch-followups",
  getParentRoute: () => Route$T
});
const ApiPublicCronCheckTelegramWebhooksRoute = Route$7.update({
  id: "/api/public/cron/check-telegram-webhooks",
  path: "/api/public/cron/check-telegram-webhooks",
  getParentRoute: () => Route$T
});
const ApiPublicCronCheckPremiumAccountsRoute = Route$6.update({
  id: "/api/public/cron/check-premium-accounts",
  path: "/api/public/cron/check-premium-accounts",
  getParentRoute: () => Route$T
});
const AuthenticatedRoomsRoomIdEditRoute = Route$5.update({
  id: "/rooms/$roomId/edit",
  path: "/rooms/$roomId/edit",
  getParentRoute: () => AuthenticatedRoute
});
const ApiPublicTrackScriptJsRoute = Route$4.update({
  id: "/api/public/track/script/js",
  path: "/api/public/track/script/js",
  getParentRoute: () => Route$T
});
const ApiPublicTrackPostbackPixelIdRoute = Route$3.update({
  id: "/api/public/track/postback/$pixelId",
  path: "/api/public/track/postback/$pixelId",
  getParentRoute: () => Route$T
});
const ApiPublicTrackDrPixelIdRoute = Route$2.update({
  id: "/api/public/track/dr/$pixelId",
  path: "/api/public/track/dr/$pixelId",
  getParentRoute: () => Route$T
});
const ApiPublicTelegramWebhookAccountIdRoute = Route$1.update({
  id: "/api/public/telegram/webhook/$accountId",
  path: "/api/public/telegram/webhook/$accountId",
  getParentRoute: () => Route$T
});
const ApiPublicTrackGClickIdOfferSlugRoute = Route.update({
  id: "/api/public/track/g/$clickId/$offerSlug",
  path: "/api/public/track/g/$clickId/$offerSlug",
  getParentRoute: () => Route$T
});
const AuthenticatedRouteChildren = {
  AuthenticatedAudiosRoute,
  AuthenticatedDashboardRoute,
  AuthenticatedMembrosRoute,
  AuthenticatedMensagensRoute,
  AuthenticatedNotificacoesRoute,
  AuthenticatedPerfilRoute,
  AuthenticatedPremiumEmojisRoute,
  AuthenticatedRecargaRoute,
  AuthenticatedTelegramAccountsRoute,
  AuthenticatedTutorialRoute,
  AuthenticatedVideosRoute,
  AuthenticatedBotsBoasvindasRoute,
  AuthenticatedBotsEncaminhadorRoute,
  AuthenticatedBotsFollowupRoute,
  AuthenticatedBotsLogsRoute,
  AuthenticatedIntegracoesMetaRoute,
  AuthenticatedPromocoesContasRoute,
  AuthenticatedPromocoesEstatisticasRoute,
  AuthenticatedTrackeamentoCanalRoute,
  AuthenticatedTrackeamentoDominiosRoute,
  AuthenticatedTrackeamentoFunisRoute,
  AuthenticatedTrackeamentoIntegracoesRoute,
  AuthenticatedTrackeamentoMensagensRoute,
  AuthenticatedTrackeamentoMetricasRoute,
  AuthenticatedTrackeamentoPixelsRoute,
  AuthenticatedTrackeamentoPostbacksRoute,
  AuthenticatedTrackeamentoUtmsRoute,
  AuthenticatedRoomsIndexRoute,
  AuthenticatedTrackeamentoIndexRoute,
  AuthenticatedRoomsRoomIdEditRoute
};
const AuthenticatedRouteWithChildren = AuthenticatedRoute._addFileChildren(
  AuthenticatedRouteChildren
);
const rootRouteChildren = {
  IndexRoute,
  AuthenticatedRoute: AuthenticatedRouteWithChildren,
  LoginRoute,
  SignupRoute,
  ApiPublicCronCheckPremiumAccountsRoute,
  ApiPublicCronCheckTelegramWebhooksRoute,
  ApiPublicCronDispatchFollowupsRoute,
  ApiPublicCronDispatchMarketTipsRoute,
  ApiPublicCronDispatchPromosRoute,
  ApiPublicCronDispatchRecurringRoute,
  ApiPublicCronDispatchSessionsRoute,
  ApiPublicCronDispatchSignalsRoute,
  ApiPublicCronExpertEngagementRoute,
  ApiPublicCronHotTeasersRoute,
  ApiPublicCronSyncEngagementOrdersRoute,
  ApiPublicCronSyncPromoConversionsRoute,
  ApiPublicGoDispatchIdRoute,
  ApiPublicKirvanoWebhookRoute,
  ApiPublicTrackClickRoute,
  ApiPublicWivenWebhookRoute,
  ApiPublicTelegramWebhookAccountIdRoute,
  ApiPublicTrackDrPixelIdRoute,
  ApiPublicTrackPostbackPixelIdRoute,
  ApiPublicTrackScriptJsRoute,
  ApiPublicTrackGClickIdOfferSlugRoute
};
const routeTree = Route$T._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  TableRow as A,
  Button as B,
  Card as C,
  Dialog as D,
  TableHead as E,
  TableBody as F,
  TableCell as G,
  Badge as H,
  Input as I,
  PopoverTrigger as J,
  PopoverContent as K,
  Label as L,
  getPremiumEmojiThumbs as M,
  Switch as N,
  CardHeader as O,
  Popover as P,
  CardTitle as Q,
  subscribeToWebPush as R,
  Select as S,
  Textarea as T,
  getPushSettings as U,
  updatePushSettings as V,
  CardDescription as W,
  buttonVariants as X,
  sendRoomTest as Y,
  router as Z,
  useTheme as a,
  SelectTrigger as b,
  cn as c,
  SelectValue as d,
  SelectContent as e,
  SelectItem as f,
  DialogContent as g,
  DialogHeader as h,
  DialogTitle as i,
  DialogFooter as j,
  DialogTrigger as k,
  getPremiumAccountAvatar as l,
  sendTestMessage as m,
  requestPremiumCode as n,
  confirmPremiumCode as o,
  generateDirectPix as p,
  generateDirectCard as q,
  refreshChats as r,
  syncPremiumEmojis as s,
  DialogDescription as t,
  useAuth as u,
  verifyAccount as v,
  generateWivenCheckout as w,
  CardContent as x,
  Table as y,
  TableHeader as z
};
