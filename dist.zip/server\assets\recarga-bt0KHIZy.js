import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import React__default, { useState } from "react";
import { p as generateDirectPix, q as generateDirectCard, D as Dialog, i as DialogTitle, t as DialogDescription, g as DialogContent, B as Button, I as Input, u as useAuth, w as generateWivenCheckout, C as Card, x as CardContent, y as Table, z as TableHeader, A as TableRow, E as TableHead, F as TableBody, G as TableCell, H as Badge } from "./router-Cw6OHOsO.js";
import { CheckCircle2, Copy, ArrowLeft, Lock, Loader2, ArrowRight, ShieldCheck, User, CreditCard, Calendar, Sparkles, Database, Code, History, XCircle, AlertCircle, Clock } from "lucide-react";
import { toast } from "sonner";
import { l as listEngagementPlans, g as getMySubscriptions, b as listMyPaymentHistory, d as listMyEngagementOrders, e as listEngagementAudit } from "./engagement.functions-BnPQkoHV.js";
import "@tanstack/react-router";
import "./client-bD0og8Nx.js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "./client.server-CDheR9QG.js";
import "zod";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function CustomCheckoutModal({
  open,
  onOpenChange,
  planId,
  customPrice,
  customName,
  customDescription,
  isSubscription,
  billingCycle
}) {
  const [step, setStep] = useState(1);
  const [selectedMethod, setSelectedMethod] = useState("card");
  const [loading, setLoading] = useState(false);
  const [pixData, setPixData] = useState(null);
  const [copied, setCopied] = useState(false);
  const [clientData, setClientData] = useState({ name: "", email: "", phone: "", document: "" });
  const [addressData, setAddressData] = useState({ zipCode: "", street: "", number: "", complement: "", neighborhood: "", city: "", state: "" });
  const [cardData, setCardData] = useState({ number: "", owner: "", expiresAt: "", cvv: "" });
  const handleCepChange = async (val) => {
    let cep = val.replace(/\D/g, "").substring(0, 8);
    let formattedCep = cep;
    if (cep.length > 5) {
      formattedCep = cep.replace(/^(\d{5})(\d)/, "$1-$2");
    }
    setAddressData((prev) => ({ ...prev, zipCode: formattedCep }));
    if (cep.length === 8) {
      try {
        const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const data = await res.json();
        if (!data.erro) {
          setAddressData((prev) => ({
            ...prev,
            zipCode: formattedCep,
            street: data.logradouro || prev.street,
            neighborhood: data.bairro || prev.neighborhood,
            city: data.localidade || prev.city,
            state: data.uf || prev.state
          }));
        }
      } catch (e) {
      }
    }
  };
  const handleGeneratePix = useServerFn(generateDirectPix);
  const handleGenerateCard = useServerFn(generateDirectCard);
  const isStep1Valid = clientData.name && clientData.email && clientData.document && addressData.zipCode && addressData.street && addressData.number;
  async function processPayment(e) {
    e.preventDefault();
    if (step === 1) {
      if (!isStep1Valid) {
        toast.error("Preencha os campos obrigatórios para continuar.");
        return;
      }
      setStep(2);
      return;
    }
    if (!clientData.document || clientData.document.length < 11) {
      toast.error("O CPF/CNPJ é obrigatório.");
      return;
    }
    setLoading(true);
    if (selectedMethod === "pix") {
      try {
        const data = await handleGeneratePix({
          data: { planId, customPrice, customName, customDescription, clientDocument: clientData.document, isSubscription, billingCycle }
        });
        setPixData(data);
      } catch (e2) {
        toast.error(e2.message || "Erro ao gerar PIX");
      } finally {
        setLoading(false);
      }
    } else {
      try {
        const res = await handleGenerateCard({
          data: {
            planId,
            customPrice,
            customName,
            isSubscription,
            billingCycle,
            client: clientData,
            address: { ...addressData, country: "BR" },
            card: cardData
          }
        });
        if (res.status === "OK" || res.status === "PENDING") {
          toast.success("Pagamento aprovado com sucesso!");
          onOpenChange(false);
        } else {
          toast.error("Pagamento recusado ou falhou. Verifique os dados.");
        }
      } catch (e2) {
        toast.error(e2.message || "Erro ao processar cartão");
      } finally {
        setLoading(false);
      }
    }
  }
  React__default.useEffect(() => {
    if (!open) {
      setTimeout(() => {
        setPixData(null);
        setCopied(false);
        setStep(1);
      }, 300);
    }
  }, [open]);
  const copyToClipboard = () => {
    if (!pixData?.code) return;
    navigator.clipboard.writeText(pixData.code);
    setCopied(true);
    toast.success("Código PIX copiado!");
    setTimeout(() => setCopied(false), 2e3);
  };
  const renderInputWithIcon = (label, placeholder, value, onChange, Icon, type = "text", autoComplete) => /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
    /* @__PURE__ */ jsx("label", { className: "text-sm font-medium text-foreground", children: label }),
    /* @__PURE__ */ jsxs("div", { className: "relative", children: [
      /* @__PURE__ */ jsx(
        Input,
        {
          required: true,
          type,
          name: autoComplete,
          autoComplete,
          placeholder,
          value,
          onChange: (e) => onChange(e.target.value),
          className: "bg-background border-input h-12 text-[15px] text-foreground focus-visible:ring-1 focus-visible:ring-primary rounded-lg pl-3 pr-10"
        }
      ),
      /* @__PURE__ */ jsx(Icon, { className: "w-5 h-5 text-muted-foreground absolute right-3 top-3.5" })
    ] })
  ] });
  return /* @__PURE__ */ jsxs(Dialog, { open, onOpenChange, children: [
    /* @__PURE__ */ jsx(DialogTitle, { className: "sr-only", children: "Checkout" }),
    /* @__PURE__ */ jsx(DialogDescription, { className: "sr-only", children: "Finalize seu pagamento" }),
    /* @__PURE__ */ jsx(DialogContent, { className: "max-w-[900px] w-full min-h-[780px] max-h-[90vh] p-0 gap-0 overflow-hidden bg-background rounded-2xl shadow-2xl border flex flex-col", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row flex-1 overflow-hidden h-full min-h-[780px]", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex-1 flex flex-col bg-card overflow-hidden", children: [
        /* @__PURE__ */ jsx("div", { className: "flex-none px-16 pt-8 pb-4 relative", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between relative", children: [
          /* @__PURE__ */ jsx("div", { className: "absolute top-3 left-4 right-4 h-[2px] bg-muted z-0" }),
          /* @__PURE__ */ jsx("div", { className: "absolute top-3 left-4 h-[2px] bg-primary transition-all duration-500 z-0", style: { width: step === 2 ? "calc(100% - 32px)" : "0%" } }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-2 relative z-10 bg-card px-4", children: [
            /* @__PURE__ */ jsx("div", { className: `w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${step >= 1 ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" : "bg-muted text-muted-foreground"}`, children: "1" }),
            /* @__PURE__ */ jsx("span", { className: `text-xs font-medium ${step >= 1 ? "text-primary" : "text-muted-foreground"}`, children: "Contato" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-2 relative z-10 bg-card px-4", children: [
            /* @__PURE__ */ jsx("div", { className: `w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors duration-500 ${step >= 2 ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" : "bg-muted text-muted-foreground"}`, children: "2" }),
            /* @__PURE__ */ jsx("span", { className: `text-xs font-medium transition-colors duration-500 ${step >= 2 ? "text-primary" : "text-muted-foreground"}`, children: "Pagamento" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto px-8 py-6 checkout-scrollbar min-h-0", children: pixData ? (
          // Tela de Sucesso PIX
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center space-y-6 animate-in fade-in zoom-in duration-300 h-full min-h-[300px]", children: [
            /* @__PURE__ */ jsx("h2", { className: "text-2xl font-bold text-foreground tracking-tight", children: "Escaneie o QR Code" }),
            /* @__PURE__ */ jsx("div", { className: "p-4 bg-white rounded-2xl border border-border shadow-xl shadow-primary/5 flex items-center justify-center", children: /* @__PURE__ */ jsx(
              "img",
              {
                src: pixData.qrCodeBase64 ? pixData.qrCodeBase64.startsWith("data:image") ? pixData.qrCodeBase64 : `data:image/png;base64,${pixData.qrCodeBase64}` : pixData.qrCodeImage || `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(pixData.code)}`,
                onError: (e) => {
                  e.currentTarget.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(pixData.code)}`;
                },
                alt: "QR Code PIX",
                className: "w-48 h-48 object-contain"
              }
            ) }),
            /* @__PURE__ */ jsxs("div", { className: "text-center space-y-3 w-full max-w-sm", children: [
              /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-hidden bg-muted p-4 rounded-xl border border-border text-xs text-muted-foreground break-all text-left font-mono shadow-inner", children: pixData.code }),
              /* @__PURE__ */ jsxs(Button, { onClick: copyToClipboard, className: "w-full h-12 text-base font-semibold rounded-xl gap-2 shadow-lg transition-all", children: [
                copied ? /* @__PURE__ */ jsx(CheckCircle2, { className: "h-5 w-5" }) : /* @__PURE__ */ jsx(Copy, { className: "h-5 w-5" }),
                copied ? "Copiado!" : "Copiar código PIX"
              ] })
            ] })
          ] })
        ) : /* @__PURE__ */ jsxs("form", { id: "checkout-form", onSubmit: processPayment, className: "space-y-6 flex flex-col", children: [
          step === 1 && /* @__PURE__ */ jsxs("div", { className: "space-y-6 animate-in fade-in slide-in-from-left-4 duration-300", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h2", { className: "text-2xl font-bold text-foreground tracking-tight", children: "Detalhes do Contato" }),
              /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1", children: "Para onde enviaremos o recibo e o acesso." })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
              renderInputWithIcon("Nome Completo", "João da Silva", clientData.name, (val) => setClientData({ ...clientData, name: val }), User, "text", "name"),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
                renderInputWithIcon("CPF / CNPJ", "000.000.000-00", clientData.document, (val) => setClientData({ ...clientData, document: val }), ShieldCheck),
                renderInputWithIcon("Telefone", "(11) 99999-9999", clientData.phone, (val) => setClientData({ ...clientData, phone: val }), User, "tel", "tel")
              ] }),
              renderInputWithIcon("E-mail", "joao@gmail.com", clientData.email, (val) => setClientData({ ...clientData, email: val }), User, "email", "email")
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "pt-4 space-y-4", children: [
              /* @__PURE__ */ jsx("h3", { className: "text-lg font-semibold text-foreground", children: "Endereço de Faturamento" }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsx("div", { className: "col-span-1", children: renderInputWithIcon("CEP", "00000-000", addressData.zipCode, handleCepChange, Lock, "text", "postal-code") }),
                /* @__PURE__ */ jsx("div", { className: "col-span-2", children: renderInputWithIcon("Rua", "Rua Principal", addressData.street, (val) => setAddressData({ ...addressData, street: val }), Lock, "text", "address-line1") }),
                /* @__PURE__ */ jsx("div", { className: "col-span-1", children: renderInputWithIcon("Número", "123", addressData.number, (val) => setAddressData({ ...addressData, number: val }), Lock) }),
                /* @__PURE__ */ jsx("div", { className: "col-span-2", children: /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                  /* @__PURE__ */ jsx("label", { className: "text-sm font-medium text-foreground", children: "Complemento (opc.)" }),
                  /* @__PURE__ */ jsx(Input, { placeholder: "Apto 1", name: "address-line2", autoComplete: "address-line2", value: addressData.complement, onChange: (e) => setAddressData({ ...addressData, complement: e.target.value }), className: "bg-background border-input h-12 text-foreground rounded-lg" })
                ] }) })
              ] })
            ] })
          ] }),
          step === 2 && /* @__PURE__ */ jsxs("div", { className: "space-y-6 animate-in fade-in slide-in-from-right-4 duration-300", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
                /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setStep(1), className: "p-1 hover:bg-accent rounded-md transition-colors text-muted-foreground", children: /* @__PURE__ */ jsx(ArrowLeft, { className: "w-5 h-5" }) }),
                /* @__PURE__ */ jsx("h2", { className: "text-2xl font-bold text-foreground tracking-tight", children: "Pagamento" })
              ] }),
              /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx(Lock, { className: "w-4 h-4 text-primary" }),
                " Transação segura e criptografada"
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "border border-border rounded-xl overflow-hidden bg-card shadow-sm", children: [
              /* @__PURE__ */ jsxs(
                "div",
                {
                  className: `flex items-center justify-between p-4 cursor-pointer transition-colors ${selectedMethod === "card" ? "bg-accent/50" : "hover:bg-accent/30"}`,
                  onClick: () => setSelectedMethod("card"),
                  children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsx("div", { className: `w-4 h-4 rounded-full border flex items-center justify-center ${selectedMethod === "card" ? "border-primary bg-primary" : "border-border"}`, children: selectedMethod === "card" && /* @__PURE__ */ jsx("div", { className: "w-1.5 h-1.5 rounded-full bg-white" }) }),
                      /* @__PURE__ */ jsx("span", { className: "font-semibold text-[15px] text-foreground", children: "Cartão de crédito" })
                    ] }),
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 opacity-80", children: [
                      /* @__PURE__ */ jsx("div", { className: "w-8 h-5 bg-[#1a1f71] rounded flex items-center justify-center text-[8px] font-bold text-white italic", children: "VISA" }),
                      /* @__PURE__ */ jsx("div", { className: "w-8 h-5 bg-[#eb001b] rounded flex items-center justify-center overflow-hidden", children: /* @__PURE__ */ jsx("div", { className: "w-3 h-3 rounded-full bg-[#f79e1b] -ml-1 mix-blend-screen opacity-90" }) })
                    ] })
                  ]
                }
              ),
              selectedMethod === "card" && /* @__PURE__ */ jsxs("div", { className: "p-5 pt-2 bg-accent/20 border-t border-border animate-in fade-in duration-300 space-y-4", children: [
                renderInputWithIcon("Nome no Cartão", "Jannatul Ferdous", cardData.owner, (val) => setCardData({ ...cardData, owner: val.toUpperCase() }), User, "text", "cc-name"),
                renderInputWithIcon("Número do Cartão", "0000 0000 0000 0000", cardData.number, (val) => setCardData({ ...cardData, number: val }), CreditCard, "text", "cc-number"),
                /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
                  renderInputWithIcon("Data de Vencimento", "19/28", cardData.expiresAt, (val) => setCardData({ ...cardData, expiresAt: val }), Calendar, "text", "cc-exp"),
                  renderInputWithIcon("CVV", "•••", cardData.cvv, (val) => setCardData({ ...cardData, cvv: val }), ShieldCheck, "password", "cc-csc")
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "border-t border-border" }),
              /* @__PURE__ */ jsxs(
                "div",
                {
                  className: `flex items-center justify-between p-4 cursor-pointer transition-colors ${selectedMethod === "pix" ? "bg-accent/50" : "hover:bg-accent/30"}`,
                  onClick: () => setSelectedMethod("pix"),
                  children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsx("div", { className: `w-4 h-4 rounded-full border flex items-center justify-center ${selectedMethod === "pix" ? "border-primary bg-primary" : "border-border"}`, children: selectedMethod === "pix" && /* @__PURE__ */ jsx("div", { className: "w-1.5 h-1.5 rounded-full bg-white" }) }),
                      /* @__PURE__ */ jsx("span", { className: "font-semibold text-[15px] text-foreground", children: "Pix Instantâneo" })
                    ] }),
                    /* @__PURE__ */ jsx("svg", { className: "w-12 h-4 text-[#32BCAD]", viewBox: "0 0 100 25", fill: "currentColor", children: /* @__PURE__ */ jsx("path", { d: "M26.4 17.6L31 22.2L35.6 17.6L31 13L26.4 17.6ZM31 3.8L26.4 8.4L31 13L35.6 8.4L31 3.8ZM16.3 12.5C16.3 15.6 18.8 18.1 21.9 18.1H24.3L28.9 22.7L31 24.8L33.1 22.7L37.7 18.1H40.1C43.2 18.1 45.7 15.6 45.7 12.5C45.7 9.4 43.2 6.9 40.1 6.9H37.7L33.1 2.3L31 0.2L28.9 2.3L24.3 6.9H21.9C18.8 6.9 16.3 9.4 16.3 12.5ZM21.9 8.9H24.3L28.9 13.5L31 15.6L33.1 13.5L37.7 8.9H40.1C42.1 8.9 43.7 10.5 43.7 12.5C43.7 14.5 42.1 16.1 40.1 16.1H37.7L33.1 11.5L31 9.4L28.9 11.5L24.3 16.1H21.9C19.9 16.1 18.3 14.5 18.3 12.5C18.3 10.5 19.9 8.9 21.9 8.9Z" }) })
                  ]
                }
              )
            ] })
          ] })
        ] }) }),
        !pixData && /* @__PURE__ */ jsx("div", { className: "flex-none p-6 bg-card border-t border-border z-10 shadow-[0_-10px_20px_-10px_rgba(0,0,0,0.2)]", children: /* @__PURE__ */ jsx(
          Button,
          {
            form: "checkout-form",
            type: "submit",
            disabled: loading,
            className: "w-full h-[52px] text-base font-semibold rounded-xl shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2",
            children: loading ? /* @__PURE__ */ jsx(Loader2, { className: "w-5 h-5 animate-spin" }) : step === 1 ? /* @__PURE__ */ jsxs(Fragment, { children: [
              "Avançar para Pagamento ",
              /* @__PURE__ */ jsx(ArrowRight, { className: "w-4 h-4 ml-1" })
            ] }) : "Processar Checkout"
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "hidden md:flex w-[380px] relative bg-[#111116] flex-col justify-center p-10 overflow-hidden border-l border-border", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 opacity-20 mix-blend-screen pointer-events-none", style: { backgroundImage: "radial-gradient(circle at 80% 20%, rgba(255,255,255,0.4), transparent 50%), radial-gradient(circle at 20% 80%, rgba(255,255,255,0.1), transparent 50%)" } }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 text-center text-white space-y-4", children: [
          /* @__PURE__ */ jsx("div", { className: "w-16 h-16 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 mx-auto flex items-center justify-center mb-6 shadow-2xl", children: /* @__PURE__ */ jsx(ShieldCheck, { className: "w-8 h-8 text-white/80" }) }),
          /* @__PURE__ */ jsx("h2", { className: "text-3xl font-extrabold tracking-tight", children: customName || "Plano Telesignal" }),
          /* @__PURE__ */ jsx("p", { className: "text-white/60 text-sm font-medium", children: customDescription || "Acesso premium imediato." }),
          /* @__PURE__ */ jsxs("div", { className: "pt-4", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-5xl font-black tracking-tight text-white", children: [
              "R$ ",
              customPrice ? Number(customPrice).toFixed(2).replace(".", ",") : "..."
            ] }),
            isSubscription && /* @__PURE__ */ jsx("span", { className: "text-white/40 text-sm font-medium ml-1", children: billingCycle === "mensal" ? "/mês" : billingCycle === "trimestral" ? "/trimestre" : "/ano" })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 opacity-20 mix-blend-overlay", style: { backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h40v40H0V0zm20 20h20v20H20V20zM0 20h20v20H0V20z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E")` } })
      ] })
    ] }) })
  ] });
}
const salasPlanos = [{
  id: "salas-1",
  nome: "Base",
  preco: 207,
  features: ["Dashboard", "1 Conta Telegram", "1 Sala", "Agendamentos"]
}, {
  id: "salas-3",
  nome: "Premium",
  preco: 520,
  features: ["Tudo do Base mais:", "3 Contas Telegram", "3 Salas", "Conta e Emojis Premium", "Vídeos", "Áudios", "Trackeamento"],
  destaque: true,
  badge: "MAIS POPULAR"
}, {
  id: "salas-unlimited",
  nome: "Unlimited",
  preco: 700,
  features: ["Tudo do Premium mais:", "BotBoasVindas", "BotEncaminhador", "BotFollowUp", "Integrações"]
}];
function RecargaPage() {
  const {
    user
  } = useAuth();
  const generateUrl = useServerFn(generateWivenCheckout);
  const fetchPlans = useServerFn(listEngagementPlans);
  const fetchSubs = useServerFn(getMySubscriptions);
  const fetchHistory = useServerFn(listMyPaymentHistory);
  const fetchOrders = useServerFn(listMyEngagementOrders);
  const fetchAudit = useServerFn(listEngagementAudit);
  const [billingCycle, setBillingCycle] = useState("mensal");
  const plansQ = useQuery({
    queryKey: ["engagement-plans"],
    queryFn: () => fetchPlans()
  });
  const subsQ = useQuery({
    queryKey: ["engagement-subs", user?.id],
    queryFn: () => fetchSubs(),
    enabled: !!user
  });
  const historyQ = useQuery({
    queryKey: ["payment-history", user?.id],
    queryFn: () => fetchHistory(),
    enabled: !!user
  });
  useQuery({
    queryKey: ["smm-orders", user?.id],
    queryFn: () => fetchOrders(),
    enabled: !!user,
    refetchInterval: 3e4
  });
  useQuery({
    queryKey: ["smm-audit", user?.id],
    queryFn: () => fetchAudit(),
    enabled: !!user,
    refetchInterval: 6e4
  });
  const subs = subsQ.data ?? [];
  const subByBot = /* @__PURE__ */ new Map();
  for (const s of subs) {
    const bt = s.plan?.bot_type;
    if (bt && !subByBot.has(bt)) subByBot.set(bt, s);
  }
  const plansByBot = /* @__PURE__ */ new Map();
  for (const p of plansQ.data ?? []) {
    const bt = p.bot_type;
    if (!plansByBot.has(bt)) plansByBot.set(bt, []);
    plansByBot.get(bt).push(p);
  }
  const salasUrlBySlug = /* @__PURE__ */ new Map();
  for (const p of plansQ.data ?? []) {
    if (p.bot_type === "salas") salasUrlBySlug.set(p.slug, p.wiven_checkout_url);
  }
  const salasPlanosResolved = salasPlanos.map((p) => ({
    ...p,
    checkoutUrl: salasUrlBySlug.get(p.id) ?? p.checkoutUrl
  }));
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold tracking-tight flex items-center gap-2 flex-wrap", children: [
        /* @__PURE__ */ jsx(Sparkles, { className: "size-6 text-primary" }),
        "Assinatura"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground text-sm mt-1", children: "Assine o plano que melhor impulsiona sua operação." })
    ] }),
    /* @__PURE__ */ jsxs("section", { className: "pb-12 border-b border-white/5 pt-8", children: [
      /* @__PURE__ */ jsx("div", { className: "flex justify-center mb-16 relative z-20", children: /* @__PURE__ */ jsxs("div", { className: "relative flex items-center p-1.5 bg-[#090a0f] rounded-[32px] border border-white/5 shadow-inner w-full max-w-[460px]", children: [
        /* @__PURE__ */ jsx("div", { className: "absolute inset-y-1.5 bg-gradient-to-r from-[#202434] to-[#1b1e2a] border border-white/10 rounded-[28px] transition-all duration-500 shadow-[0_4px_20px_-5px_rgba(0,0,0,0.5)] ease-out", style: {
          width: "calc(33.333% - 4px)",
          left: "6px",
          transform: `translateX(${billingCycle === "mensal" ? "0" : billingCycle === "trimestral" ? "100%" : "200%"})`
        } }),
        /* @__PURE__ */ jsx("button", { onClick: () => setBillingCycle("mensal"), className: `relative z-10 flex-1 py-3 text-sm font-semibold transition-colors duration-500 ${billingCycle === "mensal" ? "text-white" : "text-gray-500 hover:text-gray-300"}`, children: "Mensal" }),
        /* @__PURE__ */ jsxs("button", { onClick: () => setBillingCycle("trimestral"), className: `relative z-10 flex-1 py-3 text-sm font-semibold transition-colors duration-500 flex items-center justify-center gap-1.5 ${billingCycle === "trimestral" ? "text-white" : "text-gray-500 hover:text-gray-300"}`, children: [
          "Trimestral",
          /* @__PURE__ */ jsx("span", { className: `transition-all duration-500 text-[9px] px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider ${billingCycle === "trimestral" ? "bg-primary/20 text-primary border border-primary/30" : "bg-white/5 text-gray-400 border border-white/5"}`, children: "-10%" })
        ] }),
        /* @__PURE__ */ jsxs("button", { onClick: () => setBillingCycle("anual"), className: `relative z-10 flex-1 py-3 text-sm font-semibold transition-colors duration-500 flex items-center justify-center gap-1.5 ${billingCycle === "anual" ? "text-white" : "text-gray-500 hover:text-gray-300"}`, children: [
          "Anual",
          /* @__PURE__ */ jsx("span", { className: `transition-all duration-500 text-[9px] px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider ${billingCycle === "anual" ? "bg-primary/20 text-primary border border-primary/30" : "bg-white/5 text-gray-400 border border-white/5"}`, children: "-20%" })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "grid gap-6 md:grid-cols-3 max-w-6xl mx-auto items-stretch", children: salasPlanosResolved.map((p) => {
        const isBase = p.id === "salas-1";
        const isPremium = p.id === "salas-3";
        const isUnlimited = p.id === "salas-unlimited";
        const multiplier = billingCycle === "mensal" ? 1 : billingCycle === "trimestral" ? 3 : 12;
        const discount = billingCycle === "mensal" ? 1 : billingCycle === "trimestral" ? 0.9 : 0.8;
        const finalPrice = p.preco * multiplier * discount;
        const oldPrice = p.preco * multiplier;
        const equivalentMonthly = finalPrice / multiplier;
        let cardBg = "";
        let textColor = "";
        let mutedColor = "";
        let borderColor = "";
        let btnClass = "";
        let dividerClass = "";
        if (isBase) {
          cardBg = "bg-gradient-to-b from-[#181a25] to-[#10121a] hover:from-[#1c1e2b] hover:to-[#12141c]";
          textColor = "text-white";
          mutedColor = "text-gray-400";
          borderColor = "border-transparent ring-1 ring-white/5 hover:ring-white/10";
          btnClass = "bg-white/5 text-white hover:bg-white/10 border border-white/5 transition-all group-hover:shadow-[0_0_15px_rgba(255,255,255,0.05)]";
          dividerClass = "border-white/5";
        } else if (isPremium) {
          cardBg = "bg-gradient-to-b from-[#1e1518] to-[#0f0a0d] hover:from-[#261a1e] hover:to-[#140e11]";
          textColor = "text-white";
          mutedColor = "text-gray-300";
          borderColor = "border-transparent ring-1 ring-primary/40 shadow-[0_0_50px_-15px_rgba(var(--primary),0.2)] group-hover:shadow-[0_0_80px_-15px_rgba(var(--primary),0.4)] group-hover:ring-primary/60 md:-translate-y-4 z-20";
          btnClass = "bg-primary text-primary-foreground hover:opacity-90 shadow-[0_0_20px_rgba(var(--primary),0.4)] transition-all";
          dividerClass = "border-white/5";
        } else {
          cardBg = "bg-gradient-to-b from-[#14151f] to-[#0a0b0f] hover:from-[#181a26] hover:to-[#0c0d12]";
          textColor = "text-white";
          mutedColor = "text-gray-400";
          borderColor = "border-transparent ring-1 ring-white/5 hover:ring-white/10";
          btnClass = "bg-white text-black hover:bg-gray-200 border border-transparent shadow-[0_0_15px_rgba(255,255,255,0.1)] transition-all";
          dividerClass = "border-white/5";
        }
        return /* @__PURE__ */ jsxs("div", { className: `group rounded-[32px] p-8 flex flex-col relative overflow-hidden transition-all duration-700 ease-out border ${cardBg} ${textColor} ${borderColor} hover:-translate-y-2`, children: [
          /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" }),
          p.badge && /* @__PURE__ */ jsxs("div", { className: "absolute top-6 right-6 rounded-md bg-primary/10 border border-primary/20 px-3 py-1.5 text-[9px] font-bold text-primary uppercase tracking-widest flex items-center gap-1.5 shadow-[0_0_15px_rgba(var(--primary),0.2)] group-hover:shadow-[0_0_30px_rgba(var(--primary),0.5)] transition-all duration-500 backdrop-blur-sm", children: [
            /* @__PURE__ */ jsx(Sparkles, { className: "size-3 animate-pulse" }),
            " ",
            p.badge
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-3 mb-6 pt-2", children: [
            /* @__PURE__ */ jsx("div", { className: "mb-4 text-current opacity-70", children: /* @__PURE__ */ jsx(Database, { className: "size-6" }) }),
            /* @__PURE__ */ jsx("h3", { className: "text-3xl font-bold tracking-tight", children: p.nome }),
            /* @__PURE__ */ jsx("p", { className: `text-sm ${mutedColor} leading-relaxed pr-4 min-h-[40px]`, children: "Para quem quer otimizar suas operações de sinal." })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "min-h-[80px]", children: [
              billingCycle !== "mensal" ? /* @__PURE__ */ jsxs("div", { className: `text-sm line-through opacity-50 mb-1 font-semibold`, children: [
                "R$ ",
                oldPrice.toFixed(0)
              ] }) : /* @__PURE__ */ jsx("div", { className: "h-5 mb-1" }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-end gap-1 font-sans", children: [
                /* @__PURE__ */ jsxs("span", { className: `text-5xl font-black ${textColor}`, children: [
                  "R$ ",
                  finalPrice.toFixed(0)
                ] }),
                billingCycle === "mensal" && /* @__PURE__ */ jsx("span", { className: `text-base font-medium ${mutedColor} mb-1.5`, children: "/mês" }),
                billingCycle === "trimestral" && /* @__PURE__ */ jsx("span", { className: `text-base font-medium ${mutedColor} mb-1.5`, children: "/trimestre" }),
                billingCycle === "anual" && /* @__PURE__ */ jsx("span", { className: `text-base font-medium ${mutedColor} mb-1.5`, children: "/ano" })
              ] }),
              billingCycle !== "mensal" ? /* @__PURE__ */ jsxs("div", { className: `inline-flex mt-3 items-center px-3 py-1.5 rounded-full text-xs font-semibold ${isUnlimited ? "bg-white/10 text-white" : "bg-primary/10 text-primary"}`, children: [
                /* @__PURE__ */ jsx("div", { className: `w-1.5 h-1.5 rounded-full mr-2 ${isUnlimited ? "bg-white" : "bg-primary"}` }),
                "cobrança ",
                billingCycle,
                " • equivale R$",
                equivalentMonthly.toFixed(0),
                "/mês"
              ] }) : /* @__PURE__ */ jsx("div", { className: "h-8 mt-3" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "mt-8 mb-6", children: (() => {
              const planNameExt = p.nome + (billingCycle === "trimestral" ? " (Trimestral)" : billingCycle === "anual" ? " (Anual)" : "");
              const planIdExt = p.id + (billingCycle === "trimestral" ? "-trimestral" : billingCycle === "anual" ? "-anual" : "");
              return p.checkoutUrl ? /* @__PURE__ */ jsx(Button, { asChild: true, className: `w-full py-6 text-base font-bold rounded-full transition-all ${btnClass}`, children: /* @__PURE__ */ jsx("a", { href: p.checkoutUrl, target: "_blank", rel: "noreferrer", children: "Comece agora" }) }) : /* @__PURE__ */ jsx(CheckoutButton, { planId: planIdExt, customPrice: finalPrice, customName: planNameExt, customDescription: p.features?.join("\\n") || "", generateUrl, className: `w-full py-6 text-base font-bold rounded-full transition-all ${btnClass}`, label: "Comece agora", isSubscription: true, billingCycle });
            })() }),
            /* @__PURE__ */ jsxs("div", { className: `pt-6 border-t ${dividerClass} flex-1`, children: [
              /* @__PURE__ */ jsx("h4", { className: `text-sm italic mb-4 font-serif ${mutedColor}`, children: "Features" }),
              /* @__PURE__ */ jsx("ul", { className: "space-y-4", children: p.features?.map((feature, idx) => /* @__PURE__ */ jsxs("li", { className: `flex items-start gap-3 text-sm pb-4 ${idx !== p.features.length - 1 ? `border-b ${dividerClass}` : ""}`, children: [
                /* @__PURE__ */ jsx(Code, { className: `size-4 mt-0.5 shrink-0 opacity-50 text-primary` }),
                /* @__PURE__ */ jsx("span", { className: `text-gray-300 leading-snug`, children: feature })
              ] }, idx)) })
            ] })
          ] })
        ] }, p.id);
      }) })
    ] }),
    /* @__PURE__ */ jsx(PaymentHistorySection, { rows: historyQ.data ?? [], isLoading: historyQ.isLoading })
  ] });
}
const STATUS_META = {
  active: {
    label: "Pagamento aprovado",
    variant: "default",
    icon: CheckCircle2
  },
  pending: {
    label: "Aguardando pagamento",
    variant: "secondary",
    icon: Clock
  },
  canceled: {
    label: "Cancelado",
    variant: "outline",
    icon: XCircle
  },
  refunded: {
    label: "Reembolsado",
    variant: "outline",
    icon: XCircle
  },
  failed: {
    label: "Pagamento recusado",
    variant: "destructive",
    icon: AlertCircle
  },
  expired: {
    label: "Expirado",
    variant: "outline",
    icon: XCircle
  }
};
function PaymentHistorySection({
  rows,
  isLoading
}) {
  return _PaymentHistorySectionImpl({
    rows,
    isLoading
  });
}
function _PaymentHistorySectionImpl({
  rows,
  isLoading
}) {
  return /* @__PURE__ */ jsxs("section", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx("div", { className: "size-9 rounded-md bg-primary/10 flex items-center justify-center", children: /* @__PURE__ */ jsx(History, { className: "size-5 text-primary" }) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h2", { className: "font-semibold", children: "Histórico de pagamentos" }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Acompanhe o status dos seus pagamentos e assinaturas." })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsx(CardContent, { className: "p-0", children: isLoading ? /* @__PURE__ */ jsx("div", { className: "p-6 text-sm text-muted-foreground text-center", children: "Carregando…" }) : rows.length === 0 ? /* @__PURE__ */ jsx("div", { className: "p-6 text-sm text-muted-foreground text-center", children: "Nenhum pagamento registrado ainda." }) : /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(TableHeader, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableHead, { children: "Data" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Plano" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Valor" }),
        /* @__PURE__ */ jsx(TableHead, { children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: rows.map((r) => {
        const meta = STATUS_META[r.status] ?? {
          label: r.status,
          variant: "outline",
          icon: AlertCircle
        };
        const Icon = meta.icon;
        const date = r.created_at ? new Date(r.created_at).toLocaleString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }) : "—";
        const price = r.plan?.price_brl != null ? `R$ ${Number(r.plan.price_brl).toFixed(2).replace(".", ",")}` : "—";
        return /* @__PURE__ */ jsxs(TableRow, { children: [
          /* @__PURE__ */ jsx(TableCell, { className: "text-xs text-muted-foreground whitespace-nowrap", children: date }),
          /* @__PURE__ */ jsx(TableCell, { className: "text-sm", children: r.plan?.name ?? "—" }),
          /* @__PURE__ */ jsx(TableCell, { className: "text-sm font-medium", children: price }),
          /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsxs(Badge, { variant: meta.variant, className: "gap-1", children: [
            /* @__PURE__ */ jsx(Icon, { className: "size-3" }),
            meta.label
          ] }) })
        ] }, r.id);
      }) })
    ] }) }) })
  ] });
}
function CheckoutButton({
  planId,
  customPrice,
  customName,
  customDescription,
  generateUrl,
  className,
  label,
  isSubscription,
  billingCycle
}) {
  const [modalOpen, setModalOpen] = useState(false);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Button, { size: "sm", className: className || "w-full", onClick: () => setModalOpen(true), children: label || "Adquirir agora" }),
    /* @__PURE__ */ jsx(CustomCheckoutModal, { open: modalOpen, onOpenChange: setModalOpen, planId, customPrice, customName, customDescription, isSubscription, billingCycle })
  ] });
}
export {
  CheckoutButton,
  RecargaPage as component
};
