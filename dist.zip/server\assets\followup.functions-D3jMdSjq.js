import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { c as callTelegram } from "./telegram.server-CxWEOea-.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const TimeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
const getFollowupSettings_createServerFn_handler = createServerRpc({
  id: "f48828778ab4b266229fca37c08d9cabbb9dbc1c3dabb92a1cfa06342d0cc3da",
  name: "getFollowupSettings",
  filename: "src/lib/followup.functions.ts"
}, (opts) => getFollowupSettings.__executeServer(opts));
const getFollowupSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(getFollowupSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const [settings, cta] = await Promise.all([supabase.from("followup_settings").select("*").eq("room_id", data.roomId).maybeSingle(), supabase.from("room_engagement_settings").select("followup_cta_enabled, followup_cta_button_text").eq("room_id", data.roomId).maybeSingle()]);
  return {
    settings: settings.data ?? null,
    cta: cta.data ?? null
  };
});
const upsertFollowupSettings_createServerFn_handler = createServerRpc({
  id: "7df86b85148b921548fad209068bd2a4df1065e2faf92d77d46f443bfb583327",
  name: "upsertFollowupSettings",
  filename: "src/lib/followup.functions.ts"
}, (opts) => upsertFollowupSettings.__executeServer(opts));
const upsertFollowupSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid(),
  enabled: z.boolean(),
  timezone: z.string().max(64).default("America/Sao_Paulo"),
  ctaEnabled: z.boolean(),
  ctaButtonText: z.string().min(1).max(64)
}).parse(d)).handler(upsertFollowupSettings_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    error: e1
  } = await supabase.from("followup_settings").upsert({
    room_id: data.roomId,
    user_id: userId,
    enabled: data.enabled,
    timezone: data.timezone
  }, {
    onConflict: "room_id"
  });
  if (e1) throw new Error(e1.message);
  const {
    error: e2
  } = await supabase.from("room_engagement_settings").upsert({
    room_id: data.roomId,
    user_id: userId,
    followup_cta_enabled: data.ctaEnabled,
    followup_cta_button_text: data.ctaButtonText
  }, {
    onConflict: "room_id"
  });
  if (e2) throw new Error(e2.message);
  return {
    ok: true
  };
});
const listFollowupMessages_createServerFn_handler = createServerRpc({
  id: "80441ab02eac154f6657535381da3d124701a05d170692798cd1d17dc4db2f25",
  name: "listFollowupMessages",
  filename: "src/lib/followup.functions.ts"
}, (opts) => listFollowupMessages.__executeServer(opts));
const listFollowupMessages = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(listFollowupMessages_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: rows,
    error
  } = await supabase.from("followup_messages").select("*").eq("room_id", data.roomId).order("day_number", {
    ascending: true
  });
  if (error) throw new Error(error.message);
  return rows ?? [];
});
const MessageInput = z.object({
  id: z.string().uuid().optional(),
  roomId: z.string().uuid(),
  dayNumber: z.number().int().min(1).max(365),
  sendTime: z.string().regex(TimeRe).default("09:00"),
  content: z.string().max(4e3).nullable().optional(),
  imagePath: z.string().max(500).nullable().optional(),
  imageMime: z.string().max(100).nullable().optional(),
  videoId: z.string().uuid().nullable().optional(),
  parseMode: z.enum(["HTML", "Markdown", "MarkdownV2"]).default("HTML"),
  premiumEnabled: z.boolean().default(false),
  premiumAccountId: z.string().uuid().nullable().optional(),
  buttonText: z.string().max(64).nullable().optional(),
  buttonUrl: z.string().url().max(2048).nullable().optional()
});
const upsertFollowupMessage_createServerFn_handler = createServerRpc({
  id: "d56497e25ef5da3d47b18edba31efa6c353d09ea5a59cbdf36c3fa274d1cca34",
  name: "upsertFollowupMessage",
  filename: "src/lib/followup.functions.ts"
}, (opts) => upsertFollowupMessage.__executeServer(opts));
const upsertFollowupMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => MessageInput.parse(d)).handler(upsertFollowupMessage_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const row = {
    user_id: userId,
    room_id: data.roomId,
    day_number: data.dayNumber,
    send_time: data.sendTime,
    content: data.content ?? null,
    image_path: data.imagePath ?? null,
    image_mime: data.imageMime ?? null,
    video_id: data.videoId ?? null,
    parse_mode: data.parseMode,
    premium_enabled: data.premiumEnabled,
    premium_account_id: data.premiumAccountId ?? null,
    button_text: data.buttonText ?? null,
    button_url: data.buttonUrl ?? null,
    sort_order: data.dayNumber
  };
  if (data.id) {
    const {
      error: error2
    } = await supabase.from("followup_messages").update(row).eq("id", data.id);
    if (error2) throw new Error(error2.message);
    return {
      id: data.id
    };
  }
  const {
    data: ins,
    error
  } = await supabase.from("followup_messages").insert(row).select("id").single();
  if (error) throw new Error(error.message);
  return {
    id: ins.id
  };
});
const deleteFollowupMessage_createServerFn_handler = createServerRpc({
  id: "8a4a9f25a4085c0541cc9e082c48eb8180b7581ec60b5e1c348b0b1313986344",
  name: "deleteFollowupMessage",
  filename: "src/lib/followup.functions.ts"
}, (opts) => deleteFollowupMessage.__executeServer(opts));
const deleteFollowupMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteFollowupMessage_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("followup_messages").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const listFollowupLeads_createServerFn_handler = createServerRpc({
  id: "89ecdf9193e124ab5c95ef460718580f06c31c416785688a45efaee2a3ea49e0",
  name: "listFollowupLeads",
  filename: "src/lib/followup.functions.ts"
}, (opts) => listFollowupLeads.__executeServer(opts));
const listFollowupLeads = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  roomId: z.string().uuid()
}).parse(d)).handler(listFollowupLeads_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase
  } = context;
  const {
    data: rows,
    error
  } = await supabase.from("followup_leads").select("*").eq("room_id", data.roomId).order("started_at", {
    ascending: false
  }).limit(100);
  if (error) throw new Error(error.message);
  const list = rows ?? [];
  const counts = {
    active: 0,
    stopped: 0,
    completed: 0
  };
  for (const r of list) {
    const s = String(r.status ?? "");
    if (s === "active") counts.active++;
    else if (s === "stopped") counts.stopped++;
    else if (s === "completed") counts.completed++;
  }
  return {
    leads: list,
    counts
  };
});
const setFollowupLeadStatus_createServerFn_handler = createServerRpc({
  id: "5322917ff3d34b3b9b9fa76ed9eaa81529bb8d180eab85ac31a0ff84efd147f9",
  name: "setFollowupLeadStatus",
  filename: "src/lib/followup.functions.ts"
}, (opts) => setFollowupLeadStatus.__executeServer(opts));
const setFollowupLeadStatus = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  status: z.enum(["active", "stopped"])
}).parse(d)).handler(setFollowupLeadStatus_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("followup_leads").update({
    status: data.status,
    stopped_at: data.status === "stopped" ? (/* @__PURE__ */ new Date()).toISOString() : null,
    stopped_reason: data.status === "stopped" ? "manual" : null
  }).eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const testFollowupMessage_createServerFn_handler = createServerRpc({
  id: "a9396ecd29149ed85ff4893dd56fd9164d94f50a3a3b93bdfe53e9d74ae7fbff",
  name: "testFollowupMessage",
  filename: "src/lib/followup.functions.ts"
}, (opts) => testFollowupMessage.__executeServer(opts));
const testFollowupMessage = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  chatId: z.number().int()
}).parse(d)).handler(testFollowupMessage_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId
  } = context;
  const {
    data: msg
  } = await supabaseAdmin.from("followup_messages").select("*").eq("id", data.id).maybeSingle();
  if (!msg || msg.user_id !== userId) {
    throw new Error("Mensagem não encontrada");
  }
  const m = msg;
  const {
    data: acc
  } = await supabaseAdmin.from("telegram_accounts").select("bot_token").eq("user_id", userId).eq("account_type", "bot").eq("is_active", true).limit(1).maybeSingle();
  if (!acc?.bot_token) throw new Error("Nenhuma conta de bot ativa");
  const r = await callTelegram(acc.bot_token, "sendMessage", {
    chat_id: data.chatId,
    text: m.content ?? "(sem conteúdo)",
    parse_mode: m.parse_mode ?? "HTML",
    reply_markup: m.button_text && m.button_url ? {
      inline_keyboard: [[{
        text: m.button_text,
        url: m.button_url
      }]]
    } : void 0
  });
  if (!r.ok) throw new Error(r.description ?? "Falha no envio");
  return {
    ok: true
  };
});
export {
  deleteFollowupMessage_createServerFn_handler,
  getFollowupSettings_createServerFn_handler,
  listFollowupLeads_createServerFn_handler,
  listFollowupMessages_createServerFn_handler,
  setFollowupLeadStatus_createServerFn_handler,
  testFollowupMessage_createServerFn_handler,
  upsertFollowupMessage_createServerFn_handler,
  upsertFollowupSettings_createServerFn_handler
};
