const API_BASE = "https://api.telegram.org";
async function callTelegram(token, method, body) {
  if (!token) {
    return { ok: false, description: "Conta sem bot_token (use uma conta do tipo Bot)" };
  }
  const res = await fetch(`${API_BASE}/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body ?? {})
  });
  return await res.json();
}
export {
  callTelegram as c
};
