import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const FolderInput = z.object({
  id: z.string().uuid().optional(),
  name: z.string().min(1).max(60),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#6366f1"),
  sortOrder: z.number().int().min(0).max(9999).default(0)
});
const upsertFolder_createServerFn_handler = createServerRpc({
  id: "cf9fb7d494ca0dc248c68827ebce13e7b58a3849c2b47f8d8c7bbae511326c12",
  name: "upsertFolder",
  filename: "src/lib/schedule-folders.functions.ts"
}, (opts) => upsertFolder.__executeServer(opts));
const upsertFolder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => FolderInput.parse(d)).handler(upsertFolder_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const row = {
    user_id: userId,
    name: data.name.trim(),
    color: data.color,
    sort_order: data.sortOrder
  };
  if (data.id) {
    const {
      error: error2
    } = await supabase.from("schedule_folders").update(row).eq("id", data.id);
    if (error2) throw new Error(error2.message);
    return {
      id: data.id
    };
  }
  const {
    data: ins,
    error
  } = await supabase.from("schedule_folders").insert(row).select("id").single();
  if (error) throw new Error(error.message);
  return {
    id: ins.id
  };
});
const deleteFolder_createServerFn_handler = createServerRpc({
  id: "61862fba5b5b90c901af2a948eb0b0dacbcc29b7531291ee094eb7eb5b12d6cb",
  name: "deleteFolder",
  filename: "src/lib/schedule-folders.functions.ts"
}, (opts) => deleteFolder.__executeServer(opts));
const deleteFolder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid()
}).parse(d)).handler(deleteFolder_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("schedule_folders").delete().eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
const moveScheduleToFolder_createServerFn_handler = createServerRpc({
  id: "7ddac3775442677f15be4eb2baf7b48fb9a762abcb3f88759782abe845d23c8c",
  name: "moveScheduleToFolder",
  filename: "src/lib/schedule-folders.functions.ts"
}, (opts) => moveScheduleToFolder.__executeServer(opts));
const moveScheduleToFolder = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  id: z.string().uuid(),
  folderId: z.string().uuid().nullable()
}).parse(d)).handler(moveScheduleToFolder_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    error
  } = await context.supabase.from("recurring_schedules").update({
    folder_id: data.folderId
  }).eq("id", data.id);
  if (error) throw new Error(error.message);
  return {
    ok: true
  };
});
export {
  deleteFolder_createServerFn_handler,
  moveScheduleToFolder_createServerFn_handler,
  upsertFolder_createServerFn_handler
};
