import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
const StoreSchema = z.enum(["amazon", "shopee", "aliexpress", "mercadolivre", "privacy", "crakrevenue", "awempire", "bet365", "betano", "blaze", "kto", "sportingbet"]);
const listAffiliateAccounts = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("845178501925ff025a9075c6462f357f94ec9cb82a28dbfd46f6218c98fdc76e"));
const upsertAffiliateAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid().optional(),
  store: StoreSchema,
  label: z.string().min(1).max(80),
  credentials: z.record(z.string(), z.string().max(500)),
  is_active: z.boolean().default(true)
})).handler(createSsrRpc("9afc4db0fbd526bdaab58d3ce560f1706664391f3d15201b0fdb4bff6680416e"));
const deleteAffiliateAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid()
})).handler(createSsrRpc("e8b80aab3a5edd12c8cd36b84055ad3e0a0a07fecf4aaac6a831e395d4556df3"));
const testAffiliateAccount = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid()
})).handler(createSsrRpc("669cdc114ce30c21c3b0bb25985c1773530a9a91b1a8a14bbda1ed26cb2597ff"));
const PromoSettingsSchema = z.object({
  room_id: z.string().uuid(),
  enabled: z.boolean(),
  interval_hours: z.number().int().min(1).max(168),
  stores: z.array(StoreSchema).min(0).max(12),
  min_discount_pct: z.number().int().min(0).max(100),
  min_price: z.number().nullable(),
  max_price: z.number().nullable(),
  categories: z.array(z.string().max(80)).max(20),
  keywords: z.array(z.string().max(80)).max(20),
  blacklist_keywords: z.array(z.string().max(80)).max(20),
  message_template: z.string().min(1).max(2e3),
  parse_mode: z.enum(["HTML", "MarkdownV2"]),
  send_image: z.boolean(),
  premium_account_id: z.string().uuid().nullable(),
  premium_enabled: z.boolean()
});
const getPromoBotSettings = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid()
})).handler(createSsrRpc("5c064b1cd7807dad52ee0e35ec5f01be01887e7c00d782fb369be6e9abcc33ae"));
const upsertPromoBotSettings = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(PromoSettingsSchema).handler(createSsrRpc("feb054bee80e3924b6fe4bdf91fa85c425c969a5bb0f4f861806e4f33b8119da"));
const previewPromoOffers = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid()
})).handler(createSsrRpc("ce9a7d566fb40d3e8cc4ebc0df1f0b6341c8e1fef77b8effaf4f6fc4a482e59c"));
const listPromoDispatches = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid().optional(),
  limit: z.number().int().min(1).max(200).default(50)
})).handler(createSsrRpc("2ce89b173a66e2e1bc8690700f4d6aa2606470a5648c1a92072d2f895353964e"));
const getPromoStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator(z.object({
  room_id: z.string().uuid().optional(),
  days: z.number().int().min(1).max(180).default(30)
})).handler(createSsrRpc("dd19c28962d785d1e990e836471a4acb4b5543ce828b5b28741b36a8e474263d"));
export {
  listAffiliateAccounts as a,
  getPromoBotSettings as b,
  upsertPromoBotSettings as c,
  deleteAffiliateAccount as d,
  getPromoStats as g,
  listPromoDispatches as l,
  previewPromoOffers as p,
  testAffiliateAccount as t,
  upsertAffiliateAccount as u
};
