import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { s as supabaseAdmin } from "./client.server-CDheR9QG.js";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const generateWivenCheckout_createServerFn_handler = createServerRpc({
  id: "a6eb9cfecce08eeca471a5584dd509eec92be5b9515d87e410241db9f4e87631",
  name: "generateWivenCheckout",
  filename: "src/lib/checkout.functions.ts"
}, (opts) => generateWivenCheckout.__executeServer(opts));
const generateWivenCheckout = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(generateWivenCheckout_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId,
    claims
  } = context;
  if (!userId) {
    throw new Error("Não autenticado");
  }
  const {
    planId,
    customPrice,
    customName,
    customDescription
  } = data;
  let priceToCharge = customPrice;
  let productName = customName || "Plano Telesignal";
  if (planId && !planId.startsWith("salas-") && !planId.startsWith("track-")) {
    const {
      data: planDb,
      error
    } = await supabaseAdmin.from("plans").select("name, price_brl").eq("id", planId).single();
    if (error || !planDb) {
      throw new Error("Plano não encontrado no banco de dados.");
    }
    priceToCharge = Number(planDb.price_brl);
    productName = planDb.name;
  }
  if (!priceToCharge || priceToCharge <= 0) {
    throw new Error("Preço inválido.");
  }
  const priceInCents = Number(priceToCharge);
  const payload = {
    product: {
      name: productName,
      externalId: planId,
      // Passamos o planId aqui para referência
      offer: {
        name: "Oferta Principal",
        price: priceInCents,
        offerType: "NATIONAL",
        currency: "BRL",
        lang: "pt-BR"
      }
    },
    settings: {
      paymentMethods: ["PIX", "CREDIT_CARD"],
      acceptedDocs: ["CPF"],
      askForAddress: false
    },
    customer: {
      // Enviar os dados básicos do usuário logado se possível
      email: claims?.email || "cliente@telesignal.com.br"
    },
    trackProps: {
      external_id: userId
      // O webhook deve nos retornar isso como clientIdentifier
    }
  };
  const pubKey = process.env.WIVEN_PUBLIC_KEY;
  const secKey = process.env.WIVEN_SECRET_KEY;
  if (!pubKey || !secKey) {
    throw new Error("Chaves da Wiven não configuradas no servidor.");
  }
  const response = await fetch("https://app.wiven.com.br/api/v1/gateway/checkout", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-public-key": pubKey,
      "x-secret-key": secKey
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const text = await response.text();
    console.error("Wiven Checkout Error:", text);
    throw new Error("Falha ao se comunicar com a Wiven: " + response.status);
  }
  const result = await response.json();
  if (!result || !result.checkoutUrl) {
    console.error("Wiven response:", result);
    throw new Error("Wiven não retornou a URL de checkout.");
  }
  return result.checkoutUrl;
});
const generateDirectPix_createServerFn_handler = createServerRpc({
  id: "fe9a16f4db01d7aec400648cf6b6d02a2e165627cc80ebce4dc8dbca82262f56",
  name: "generateDirectPix",
  filename: "src/lib/checkout.functions.ts"
}, (opts) => generateDirectPix.__executeServer(opts));
const generateDirectPix = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(generateDirectPix_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId,
    claims
  } = context;
  if (!userId) throw new Error("Não autenticado");
  const {
    planId,
    customPrice,
    customName,
    clientDocument,
    isSubscription,
    billingCycle
  } = data;
  let priceToCharge = customPrice;
  let productName = customName || "Plano Telesignal";
  if (planId && !planId.startsWith("salas-") && !planId.startsWith("track-")) {
    const {
      data: planDb,
      error
    } = await supabaseAdmin.from("plans").select("name, price_brl").eq("id", planId).single();
    if (error || !planDb) throw new Error("Plano não encontrado");
    priceToCharge = Number(planDb.price_brl);
    productName = planDb.name;
  }
  if (!priceToCharge || priceToCharge <= 0) throw new Error("Preço inválido");
  const pubKey = process.env.WIVEN_PUBLIC_KEY;
  const secKey = process.env.WIVEN_SECRET_KEY;
  if (!pubKey || !secKey) throw new Error("Chaves da Wiven não configuradas");
  const userEmail = claims?.email || "cliente@telesignal.com.br";
  const userName = claims?.user_metadata?.full_name || "Cliente Telesignal";
  if (!clientDocument || clientDocument.length < 11) {
    throw new Error("CPF/CNPJ é obrigatório para gerar o PIX.");
  }
  const payload = {
    identifier: `pix-${userId}-${Date.now()}`,
    amount: Number(priceToCharge),
    client: {
      name: userName,
      email: userEmail,
      phone: "(11) 99999-9999",
      // dummy
      document: clientDocument.replace(/\D/g, "")
      // Wiven obriga documento válido
    },
    products: [{
      id: planId || "custom",
      name: productName,
      quantity: 1,
      price: Number(priceToCharge)
    }],
    metadata: {
      userId,
      planId
    }
  };
  if (isSubscription) {
    payload.offerType = "SUBSCRIPTION";
    payload.recurring = true;
    if (billingCycle === "mensal") payload.interval = "MONTHLY";
    else if (billingCycle === "trimestral") payload.interval = "QUARTERLY";
    else if (billingCycle === "anual") payload.interval = "YEARLY";
  }
  const response = await fetch("https://app.wiven.com.br/api/v1/gateway/pix/receive", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-public-key": pubKey,
      "x-secret-key": secKey
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const text = await response.text();
    console.error("Wiven PIX Error:", text);
    throw new Error("Falha ao gerar PIX: " + response.status);
  }
  const result = await response.json();
  if (!result || !result.pix) {
    throw new Error("Wiven não retornou os dados do PIX.");
  }
  return {
    transactionId: result.transactionId,
    code: result.pix.code,
    qrCodeBase64: result.pix.base64,
    qrCodeImage: result.pix.image
  };
});
const generateDirectCard_createServerFn_handler = createServerRpc({
  id: "b0cf405fbeeba96b0eb1db1c6c8fbd933356d60651d8e45d00afde4d9382a307",
  name: "generateDirectCard",
  filename: "src/lib/checkout.functions.ts"
}, (opts) => generateDirectCard.__executeServer(opts));
const generateDirectCard = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(generateDirectCard_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    userId,
    claims
  } = context;
  if (!userId) throw new Error("Não autenticado");
  const {
    planId,
    customPrice,
    customName,
    isSubscription,
    billingCycle,
    client,
    address,
    card
  } = data;
  let priceToCharge = customPrice;
  let productName = customName || "Plano Telesignal";
  if (planId && !planId.startsWith("salas-") && !planId.startsWith("track-")) {
    const {
      data: planDb,
      error
    } = await supabaseAdmin.from("plans").select("name, price_brl").eq("id", planId).single();
    if (error || !planDb) throw new Error("Plano não encontrado");
    priceToCharge = Number(planDb.price_brl);
    productName = planDb.name;
  }
  if (!priceToCharge || priceToCharge <= 0) throw new Error("Preço inválido");
  const pubKey = process.env.WIVEN_PUBLIC_KEY;
  const secKey = process.env.WIVEN_SECRET_KEY;
  if (!pubKey || !secKey) throw new Error("Chaves da Wiven não configuradas");
  const payload = {
    identifier: `card-${userId}-${Date.now()}`,
    amount: Number(priceToCharge),
    clientIp: "127.0.0.1",
    // Wiven obriga IP
    client: {
      name: client.name || claims?.user_metadata?.full_name || "Cliente",
      email: client.email || claims?.email,
      phone: client.phone || "(11) 99999-9999",
      document: client.document || "00000000000",
      address: {
        country: address.country || "BR",
        state: address.state || "SP",
        city: address.city || "São Paulo",
        neighborhood: address.neighborhood || "Centro",
        zipCode: address.zipCode || "01000-000",
        street: address.street || "Rua Centro",
        number: address.number || "0",
        complement: address.complement || ""
      }
    },
    card: {
      number: card.number.replace(/\s+/g, ""),
      owner: card.owner,
      expiresAt: card.expiresAt,
      cvv: card.cvv,
      statementDescriptor: "TELESIGNAL"
    },
    installments: 1,
    products: [{
      id: planId || "custom",
      name: productName,
      quantity: 1,
      price: Number(priceToCharge)
    }],
    metadata: {
      userId,
      planId
    }
  };
  if (isSubscription) {
    payload.offerType = "SUBSCRIPTION";
    payload.recurring = true;
    if (billingCycle === "mensal") payload.interval = "MONTHLY";
    else if (billingCycle === "trimestral") payload.interval = "QUARTERLY";
    else if (billingCycle === "anual") payload.interval = "YEARLY";
  }
  const response = await fetch("https://app.wiven.com.br/api/v1/gateway/card/receive", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-public-key": pubKey,
      "x-secret-key": secKey
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const text = await response.text();
    console.error("Wiven CARD Error:", text);
    try {
      const errJson = JSON.parse(text);
      if (errJson.details?.issue) {
        throw new Error(`Erro na Wiven: ${errJson.details.issue}`);
      }
      throw new Error(`Erro Wiven: ${errJson.message}`);
    } catch (e) {
      throw new Error("Falha ao gerar Cartão: " + text);
    }
  }
  const result = await response.json();
  return {
    transactionId: result.transactionId,
    status: result.status,
    details: result.details
  };
});
export {
  generateDirectCard_createServerFn_handler,
  generateDirectPix_createServerFn_handler,
  generateWivenCheckout_createServerFn_handler
};
