import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import { C as Card, O as CardHeader, Q as CardTitle, H as Badge, W as CardDescription, x as CardContent, L as Label, I as Input, N as Switch, B as Button, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem } from "./router-Cw6OHOsO.js";
import { CheckCircle2, ExternalLink, XCircle } from "lucide-react";
import "@tanstack/react-router";
import "./client.server-CDheR9QG.js";
import "@supabase/supabase-js";
import "./telegram.server-CxWEOea-.js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "./client-bD0og8Nx.js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
const META_EVENT_OPTIONS = ["off", "Lead", "CompleteRegistration", "Subscribe", "ViewContent", "Contact", "AddToWishlist", "InitiateCheckout", "StartTrial", "Purchase", "AddToCart", "AddPaymentInfo", "Search", "FindLocation", "Schedule", "SubmitApplication", "Donate", "CustomizeProduct", "PageView", "AdImpression", "AdClick", "Rate", "SpentCredits", "AchievementUnlocked", "ActivateApp", "CompleteTutorial", "LevelAchieved", "UnlockAchievement"];
const eventMappingsSchema = z.object({
  join: z.enum(META_EVENT_OPTIONS).default("CompleteRegistration"),
  leave: z.enum(META_EVENT_OPTIONS).default("off"),
  kicked: z.enum(META_EVENT_OPTIONS).default("off")
});
const getMetaIntegration = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("30ce60d49560fcf320a3a093acb10d55e657cdf4c528a23f700015448776354f"));
const upsertMetaIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  pixelId: z.string().min(5).max(64).regex(/^\d+$/, "Pixel ID deve ser numérico"),
  accessToken: z.string().min(20).max(500),
  testEventCode: z.string().max(64).optional().nullable(),
  isActive: z.boolean().default(true),
  eventMappings: eventMappingsSchema
}).parse(d)).handler(createSsrRpc("9d460463a69d1d09a9ecdf7507943a909f8e8353acc22ca2f63749a4dc1c9511"));
const deleteMetaIntegration = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("f5b8d4937c62913dcb9bf1b20173daa211b68e17bb379a9742e0090a20b9b26a"));
const sendMetaTestEvent = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("f577b17f42b4ffc5eced72efbef6329ff0c4c1541605a624ec6066a450ae6cfe"));
const listMetaEventLogs = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("cdd38ff44aee3057891b299148a5f45f2fbc3bfea5efb820f335a626c82ea503"));
function MetaIntegrationPage() {
  const qc = useQueryClient();
  const getFn = useServerFn(getMetaIntegration);
  const upsertFn = useServerFn(upsertMetaIntegration);
  const deleteFn = useServerFn(deleteMetaIntegration);
  const testFn = useServerFn(sendMetaTestEvent);
  const logsFn = useServerFn(listMetaEventLogs);
  const integ = useQuery({
    queryKey: ["meta-integ"],
    queryFn: () => getFn()
  });
  const logs = useQuery({
    queryKey: ["meta-logs"],
    queryFn: () => logsFn()
  });
  const [pixelId, setPixelId] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [testEventCode, setTestEventCode] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [joinEvent, setJoinEvent] = useState("CompleteRegistration");
  const [leaveEvent, setLeaveEvent] = useState("off");
  const [kickedEvent, setKickedEvent] = useState("off");
  useEffect(() => {
    if (integ.data) {
      setPixelId(integ.data.pixel_id ?? "");
      setAccessToken(integ.data.access_token ?? "");
      setTestEventCode(integ.data.test_event_code ?? "");
      setIsActive(integ.data.is_active ?? true);
      const m = integ.data.event_mappings ?? {};
      setJoinEvent(m.join ?? "CompleteRegistration");
      setLeaveEvent(m.leave ?? "off");
      setKickedEvent(m.kicked ?? "off");
    }
  }, [integ.data]);
  const save = useMutation({
    mutationFn: () => upsertFn({
      data: {
        pixelId,
        accessToken,
        testEventCode: testEventCode || null,
        isActive,
        eventMappings: {
          join: joinEvent,
          leave: leaveEvent,
          kicked: kickedEvent
        }
      }
    }),
    onSuccess: () => {
      toast.success("Integração salva");
      qc.invalidateQueries({
        queryKey: ["meta-integ"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const remove = useMutation({
    mutationFn: () => deleteFn(),
    onSuccess: () => {
      toast.success("Integração removida");
      setPixelId("");
      setAccessToken("");
      setTestEventCode("");
      qc.invalidateQueries({
        queryKey: ["meta-integ"]
      });
    }
  });
  const test = useMutation({
    mutationFn: () => testFn(),
    onSuccess: () => {
      toast.success("Evento de teste enviado ao Meta");
      qc.invalidateQueries({
        queryKey: ["meta-logs"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6 max-w-3xl", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold", children: "Conectar Meta (Conversions API)" }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1", children: "Envie eventos do Telegram (novos membros, vendas, leads) direto para o seu Pixel do Facebook/Instagram, atribuindo às suas campanhas de Ads." })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsxs(CardHeader, { children: [
        /* @__PURE__ */ jsxs(CardTitle, { className: "flex items-center gap-2", children: [
          "Credenciais do Pixel",
          integ.data?.is_active && /* @__PURE__ */ jsxs(Badge, { variant: "default", className: "gap-1", children: [
            /* @__PURE__ */ jsx(CheckCircle2, { className: "size-3" }),
            "Ativo"
          ] })
        ] }),
        /* @__PURE__ */ jsxs(CardDescription, { children: [
          "Obtenha em ",
          /* @__PURE__ */ jsxs("a", { href: "https://business.facebook.com/events_manager", target: "_blank", rel: "noreferrer", className: "underline inline-flex items-center gap-1", children: [
            "Events Manager ",
            /* @__PURE__ */ jsx(ExternalLink, { className: "size-3" })
          ] }),
          " → seu Pixel → Configurações → Conversions API → Gerar token de acesso."
        ] })
      ] }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Pixel ID" }),
          /* @__PURE__ */ jsx(Input, { value: pixelId, onChange: (e) => setPixelId(e.target.value), placeholder: "123456789012345" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Access Token (CAPI)" }),
          /* @__PURE__ */ jsx(Input, { type: "password", value: accessToken, onChange: (e) => setAccessToken(e.target.value), placeholder: "EAAB..." })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxs(Label, { children: [
            "Test Event Code ",
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs", children: "(opcional, só pra debug)" })
          ] }),
          /* @__PURE__ */ jsx(Input, { value: testEventCode, onChange: (e) => setTestEventCode(e.target.value), placeholder: "TEST12345" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between rounded-lg border p-3", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: "Integração ativa" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Quando desligado, nenhum evento é enviado ao Meta." })
          ] }),
          /* @__PURE__ */ jsx(Switch, { checked: isActive, onCheckedChange: setIsActive })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending || !pixelId || !accessToken, children: save.isPending ? "Salvando..." : "Salvar" }),
          /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: () => test.mutate(), disabled: test.isPending || !integ.data, children: test.isPending ? "Enviando..." : "Enviar evento de teste" }),
          integ.data && /* @__PURE__ */ jsx(Button, { variant: "destructive", onClick: () => remove.mutate(), disabled: remove.isPending, children: "Remover" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsxs(CardHeader, { children: [
        /* @__PURE__ */ jsx(CardTitle, { children: "Eventos disparados automaticamente" }),
        /* @__PURE__ */ jsx(CardDescription, { children: 'Escolha qual evento padrão do Meta enviar para cada acontecimento no Telegram. Selecione "Desativado" para não enviar.' })
      ] }),
      /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
        /* @__PURE__ */ jsx(EventMappingRow, { label: "Novo membro entra no grupo / canal", description: "Disparado quando alguém entra em um grupo ou canal monitorado pelo bot.", value: joinEvent, onChange: setJoinEvent }),
        /* @__PURE__ */ jsx(EventMappingRow, { label: "Membro sai do grupo / canal", description: "Disparado quando alguém sai voluntariamente.", value: leaveEvent, onChange: setLeaveEvent }),
        /* @__PURE__ */ jsx(EventMappingRow, { label: "Membro removido / banido", description: "Disparado quando um membro é expulso ou banido.", value: kickedEvent, onChange: setKickedEvent }),
        /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
          "Lembre de clicar em ",
          /* @__PURE__ */ jsx("strong", { children: "Salvar" }),
          " acima após alterar."
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { children: [
      /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { children: "Últimos envios" }) }),
      /* @__PURE__ */ jsx(CardContent, { children: logs.data && logs.data.length > 0 ? /* @__PURE__ */ jsx("div", { className: "space-y-1 text-sm max-h-80 overflow-auto", children: logs.data.map((l) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2 py-1.5 border-b last:border-b-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
          l.ok ? /* @__PURE__ */ jsx(CheckCircle2, { className: "size-4 text-green-500 shrink-0" }) : /* @__PURE__ */ jsx(XCircle, { className: "size-4 text-destructive shrink-0" }),
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: l.event_name }),
          l.error && /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground truncate", children: l.error })
        ] }),
        /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground shrink-0", children: new Date(l.created_at).toLocaleString("pt-BR") })
      ] }, l.id)) }) : /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Nenhum evento enviado ainda." }) })
    ] })
  ] });
}
function EventMappingRow({
  label,
  description,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3 last:border-b-0 last:pb-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-medium", children: label }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: description })
    ] }),
    /* @__PURE__ */ jsxs(Select, { value, onValueChange: (v) => onChange(v), children: [
      /* @__PURE__ */ jsx(SelectTrigger, { className: "w-full sm:w-56", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
      /* @__PURE__ */ jsx(SelectContent, { children: META_EVENT_OPTIONS.map((opt) => /* @__PURE__ */ jsx(SelectItem, { value: opt, children: opt === "off" ? "Desativado" : opt }, opt)) })
    ] })
  ] });
}
export {
  MetaIntegrationPage as component
};
