import { jsxs, jsx } from "react/jsx-runtime";
import { useRef, useState } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { u as useAuth, B as Button, C as Card, L as Label, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, I as Input, D as Dialog, g as DialogContent, h as DialogHeader, i as DialogTitle, j as DialogFooter } from "./router-Cw6OHOsO.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { b as deleteVideo, s as sendVideoNoteNow } from "./videos.functions-DCpzn6E3.js";
import { c as createVideoThumbnailBlob, t as thumbnailPathForVideoPath } from "./video-thumbnail-fuRi0AXJ.js";
import { toast } from "sonner";
import { HelpCircle, Loader2, Upload, Video, Send, Trash2 } from "lucide-react";
import "@tanstack/react-router";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function VideoPreview({
  path,
  kind
}) {
  const {
    data: url
  } = useQuery({
    queryKey: ["video-signed", path],
    queryFn: async () => {
      const {
        data
      } = await supabase.storage.from("videos").createSignedUrl(path, 3600);
      return data?.signedUrl ?? null;
    },
    staleTime: 50 * 60 * 1e3
  });
  const wrapperClass = kind === "round" ? "relative aspect-square w-full overflow-hidden rounded-full bg-muted ring-2 ring-border" : "relative aspect-video w-full overflow-hidden rounded-lg bg-muted ring-1 ring-border";
  return /* @__PURE__ */ jsx("div", { className: wrapperClass, children: url ? /* @__PURE__ */ jsx("video", { src: url, className: "size-full object-cover", controls: true, playsInline: true, preload: "metadata" }) : /* @__PURE__ */ jsx("div", { className: "size-full grid place-items-center", children: /* @__PURE__ */ jsx(Loader2, { className: "size-5 animate-spin text-muted-foreground" }) }) });
}
const MAX_BYTES_ROUND = 12 * 1024 * 1024;
const MAX_DURATION_ROUND = 60;
const MAX_BYTES_NORMAL = 50 * 1024 * 1024;
async function validateVideoFile(file, kind) {
  if (kind === "round" && file.size > MAX_BYTES_ROUND) {
    throw new Error("O vídeo redondo deve ter no máximo 12 MB (limite do Telegram para video note).");
  }
  if (kind === "normal" && file.size > MAX_BYTES_NORMAL) {
    throw new Error("O vídeo deve ter no máximo 50 MB (limite do Telegram para bots).");
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.preload = "metadata";
    v.muted = true;
    v.src = url;
    v.onloadedmetadata = () => {
      const dur = v.duration;
      const w = v.videoWidth;
      const h = v.videoHeight;
      URL.revokeObjectURL(url);
      if (kind === "round") {
        if (!w || !h || w !== h) {
          reject(new Error(`Para virar redondo no Telegram o vídeo precisa ser quadrado (atual: ${w}x${h}). Recorte para 1:1 antes de enviar.`));
          return;
        }
        if (dur > MAX_DURATION_ROUND + 0.5) {
          reject(new Error(`Duração máxima de 60s (atual: ${Math.round(dur)}s).`));
          return;
        }
      }
      resolve({
        duration: Math.round(dur),
        width: w,
        height: h
      });
    };
    v.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Não foi possível ler o vídeo."));
    };
  });
}
function VideosPage() {
  const {
    user
  } = useAuth();
  const qc = useQueryClient();
  const sendNow = useServerFn(sendVideoNoteNow);
  const delFn = useServerFn(deleteVideo);
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState("");
  const [kind, setKind] = useState("round");
  const [pendingFile, setPendingFile] = useState(null);
  const [sendDialog, setSendDialog] = useState(null);
  const [accountId, setAccountId] = useState("");
  const [roomId, setRoomId] = useState("");
  const [sending, setSending] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const videos = useQuery({
    queryKey: ["videos"],
    queryFn: async () => (await supabase.from("videos").select("id, title, storage_path, file_size, duration_seconds, created_at, kind").order("created_at", {
      ascending: false
    })).data ?? []
  });
  const accounts = useQuery({
    queryKey: ["accounts-min"],
    queryFn: async () => (await supabase.from("telegram_accounts").select("id, label")).data ?? []
  });
  const rooms = useQuery({
    queryKey: ["rooms-min"],
    queryFn: async () => (await supabase.from("rooms").select("id, name, default_account_id")).data ?? []
  });
  const onPickFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const {
        duration,
        width,
        height
      } = await validateVideoFile(f, kind);
      setPendingFile({
        file: f,
        duration,
        width,
        height
      });
      setTitle(f.name.replace(/\.mp4$/i, ""));
    } catch (err) {
      toast.error(err.message);
      if (fileRef.current) fileRef.current.value = "";
    }
  };
  const upload = async () => {
    if (!pendingFile || !user) return;
    setUploading(true);
    try {
      const ext = pendingFile.file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "mp4";
      const mimeType = pendingFile.file.type || "video/mp4";
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const thumbnailBlob = kind === "normal" ? await createVideoThumbnailBlob(pendingFile.file) : null;
      const thumbnailPath = thumbnailBlob ? thumbnailPathForVideoPath(path) : null;
      const {
        error: upErr
      } = await supabase.storage.from("videos").upload(path, pendingFile.file, {
        contentType: mimeType,
        upsert: false
      });
      if (upErr) throw upErr;
      if (thumbnailBlob && thumbnailPath) {
        const {
          error: thumbErr
        } = await supabase.storage.from("videos").upload(thumbnailPath, thumbnailBlob, {
          contentType: "image/jpeg",
          upsert: false
        });
        if (thumbErr) throw thumbErr;
      }
      const {
        error: insErr
      } = await supabase.from("videos").insert({
        user_id: user.id,
        title: title.trim() || "Vídeo",
        storage_path: path,
        file_size: pendingFile.file.size,
        duration_seconds: pendingFile.duration,
        mime_type: mimeType,
        kind,
        width: pendingFile.width,
        height: pendingFile.height
      });
      if (insErr) throw insErr;
      toast.success("Vídeo enviado");
      setPendingFile(null);
      setTitle("");
      if (fileRef.current) fileRef.current.value = "";
      qc.invalidateQueries({
        queryKey: ["videos"]
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  };
  const delMut = useMutation({
    mutationFn: async (id) => {
      await delFn({
        data: {
          id
        }
      });
    },
    onSuccess: () => {
      toast.success("Vídeo removido");
      qc.invalidateQueries({
        queryKey: ["videos"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const submitSend = async () => {
    if (!sendDialog || !accountId || !roomId) return;
    setSending(true);
    try {
      const {
        data: chats
      } = await supabase.from("room_chats").select("chat_id").eq("room_id", roomId);
      const chatIds = (chats ?? []).map((c) => c.chat_id);
      if (!chatIds.length) {
        toast.error("Esse grupo não tem chats vinculados.");
        return;
      }
      const res = await sendNow({
        data: {
          videoId: sendDialog.videoId,
          accountId,
          chatIds
        }
      });
      const okCount = res.results.filter((r) => r.ok).length;
      const failCount = res.results.length - okCount;
      if (failCount === 0) toast.success(`Enviado para ${okCount} chat(s)`);
      else toast.warning(`Enviado: ${okCount} · Falhas: ${failCount}`);
      setSendDialog(null);
      setAccountId("");
      setRoomId("");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-2xl font-bold tracking-tight", children: "Vídeos" }),
        /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", onClick: () => setHelpOpen(true), children: [
          /* @__PURE__ */ jsx(HelpCircle, { className: "size-4" }),
          "Como deixar 1:1"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground", children: [
        "Envie vídeos para o Telegram em dois formatos: ",
        /* @__PURE__ */ jsx("b", { children: "redondo" }),
        " (video note: quadrado 1:1, MP4/H.264, até 60s e 12 MB) ou ",
        /* @__PURE__ */ jsx("b", { children: "normal" }),
        " (vídeo comum, até 50 MB)."
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-5 space-y-4", "data-tour": "video-upload", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row gap-3 sm:items-end", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2 sm:w-44", children: [
          /* @__PURE__ */ jsx(Label, { children: "Tipo" }),
          /* @__PURE__ */ jsxs(Select, { value: kind, onValueChange: (v) => {
            setKind(v);
            setPendingFile(null);
            if (fileRef.current) fileRef.current.value = "";
          }, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              /* @__PURE__ */ jsx(SelectItem, { value: "round", children: "Redondo (video note)" }),
              /* @__PURE__ */ jsx(SelectItem, { value: "normal", children: "Normal" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: kind === "round" ? "Vídeo quadrado MP4/H.264 (≤ 60s, ≤ 12 MB)" : "Vídeo MP4 (≤ 50 MB)" }),
          /* @__PURE__ */ jsx(Input, { ref: fileRef, type: "file", accept: "video/*", onChange: onPickFile })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Título" }),
          /* @__PURE__ */ jsx(Input, { value: title, onChange: (e) => setTitle(e.target.value), placeholder: "Nome do vídeo" })
        ] }),
        /* @__PURE__ */ jsxs(Button, { onClick: upload, disabled: !pendingFile || uploading, children: [
          uploading ? /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsx(Upload, { className: "size-4" }),
          "Enviar"
        ] })
      ] }),
      pendingFile && /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
        "Pronto: ",
        pendingFile.file.name,
        " · ",
        pendingFile.width,
        "×",
        pendingFile.height,
        " · ",
        pendingFile.duration,
        "s ·",
        " ",
        (pendingFile.file.size / 1024 / 1024).toFixed(2),
        " MB"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid gap-3 md:grid-cols-2 lg:grid-cols-3", children: [
      videos.data?.length === 0 && /* @__PURE__ */ jsxs(Card, { className: "p-10 text-center text-muted-foreground text-sm md:col-span-2 lg:col-span-3", children: [
        /* @__PURE__ */ jsx(Video, { className: "size-8 mx-auto mb-2 opacity-50" }),
        "Nenhum vídeo ainda."
      ] }),
      videos.data?.map((v) => /* @__PURE__ */ jsxs(Card, { className: "p-4 space-y-3", children: [
        /* @__PURE__ */ jsx("div", { className: v.kind === "normal" ? "w-full" : "mx-auto w-40", children: /* @__PURE__ */ jsx(VideoPreview, { path: v.storage_path, kind: v.kind ?? "round" }) }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium truncate", children: v.title }),
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
            (v.kind ?? "round") === "round" ? "Redondo" : "Normal",
            " ·",
            " ",
            v.duration_seconds ?? "?",
            "s ·",
            " ",
            v.file_size ? (v.file_size / 1024 / 1024).toFixed(2) + " MB" : "—"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: new Date(v.created_at).toLocaleString("pt-BR") })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxs(Button, { size: "sm", className: "flex-1", onClick: () => setSendDialog({
            videoId: v.id,
            title: v.title
          }), children: [
            /* @__PURE__ */ jsx(Send, { className: "size-4" }),
            "Enviar agora"
          ] }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => {
            if (confirm("Excluir este vídeo?")) delMut.mutate(v.id);
          }, children: /* @__PURE__ */ jsx(Trash2, { className: "size-4" }) })
        ] })
      ] }, v.id))
    ] }),
    /* @__PURE__ */ jsx(Dialog, { open: !!sendDialog, onOpenChange: (o) => !o && setSendDialog(null), children: /* @__PURE__ */ jsxs(DialogContent, { children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsxs(DialogTitle, { children: [
        'Enviar "',
        sendDialog?.title,
        '"'
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Grupo" }),
          /* @__PURE__ */ jsxs(Select, { value: roomId, onValueChange: (v) => {
            setRoomId(v);
            const r = rooms.data?.find((x) => x.id === v);
            if (r?.default_account_id) setAccountId(r.default_account_id);
          }, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: rooms.data?.map((r) => /* @__PURE__ */ jsx(SelectItem, { value: r.id, children: r.name }, r.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Conta Telegram" }),
          /* @__PURE__ */ jsxs(Select, { value: accountId, onValueChange: setAccountId, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione" }) }),
            /* @__PURE__ */ jsx(SelectContent, { children: accounts.data?.map((a) => /* @__PURE__ */ jsx(SelectItem, { value: a.id, children: a.label }, a.id)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs(DialogFooter, { children: [
        /* @__PURE__ */ jsx(Button, { variant: "ghost", onClick: () => setSendDialog(null), children: "Cancelar" }),
        /* @__PURE__ */ jsxs(Button, { onClick: submitSend, disabled: !accountId || !roomId || sending, children: [
          sending && /* @__PURE__ */ jsx(Loader2, { className: "size-4 animate-spin" }),
          "Enviar"
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(Dialog, { open: helpOpen, onOpenChange: setHelpOpen, children: /* @__PURE__ */ jsxs(DialogContent, { className: "max-w-lg", children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Como deixar o vídeo 1:1 (redondo)" }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-4 text-sm", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium mb-1", children: "Requisitos do Telegram" }),
          /* @__PURE__ */ jsxs("ul", { className: "list-disc pl-5 text-muted-foreground space-y-1", children: [
            /* @__PURE__ */ jsxs("li", { children: [
              "Proporção ",
              /* @__PURE__ */ jsx("b", { children: "1:1" }),
              " (quadrado, ex.: 480×480 ou 640×640)"
            ] }),
            /* @__PURE__ */ jsxs("li", { children: [
              "Formato ",
              /* @__PURE__ */ jsx("b", { children: "MP4" }),
              " com codec ",
              /* @__PURE__ */ jsx("b", { children: "H.264" }),
              " + áudio AAC"
            ] }),
            /* @__PURE__ */ jsxs("li", { children: [
              "Duração ",
              /* @__PURE__ */ jsx("b", { children: "até 60s" })
            ] }),
            /* @__PURE__ */ jsxs("li", { children: [
              "Tamanho ",
              /* @__PURE__ */ jsx("b", { children: "até 12 MB" }),
              " (limite do Telegram para vídeo redondo)"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium mb-1", children: "📱 No celular (mais fácil)" }),
          /* @__PURE__ */ jsxs("ol", { className: "list-decimal pl-5 text-muted-foreground space-y-1", children: [
            /* @__PURE__ */ jsxs("li", { children: [
              "Abra o ",
              /* @__PURE__ */ jsx("b", { children: "CapCut" }),
              " ou ",
              /* @__PURE__ */ jsx("b", { children: "InShot" }),
              " (grátis)"
            ] }),
            /* @__PURE__ */ jsx("li", { children: "Importe o vídeo" }),
            /* @__PURE__ */ jsxs("li", { children: [
              'Em "Proporção / Canvas", escolha ',
              /* @__PURE__ */ jsx("b", { children: "1:1" })
            ] }),
            /* @__PURE__ */ jsx("li", { children: "Arraste o vídeo para enquadrar a parte que quer mostrar" }),
            /* @__PURE__ */ jsx("li", { children: "Corte para no máximo 60 segundos" }),
            /* @__PURE__ */ jsxs("li", { children: [
              "Exporte em ",
              /* @__PURE__ */ jsx("b", { children: "480p" }),
              " ou ",
              /* @__PURE__ */ jsx("b", { children: "360p" }),
              " com qualidade ",
              /* @__PURE__ */ jsx("b", { children: "média" }),
              " (para ficar abaixo de 12 MB)"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("p", { className: "font-medium mb-1", children: "💻 No computador (ffmpeg)" }),
          /* @__PURE__ */ jsx("p", { className: "text-muted-foreground mb-1", children: "Recorta para o quadrado central, redimensiona para 480×480 e comprime:" }),
          /* @__PURE__ */ jsx("pre", { className: "bg-muted p-3 rounded text-xs overflow-x-auto", children: `ffmpeg -i entrada.mp4 \\
  -vf "crop=min(iw\\,ih):min(iw\\,ih),scale=384:384" \\
  -t 60 -c:v libx264 -crf 30 -preset medium \\
  -c:a aac -b:a 48k -movflags +faststart \\
  saida.mp4` })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-amber-500/30 bg-amber-500/10 p-3 text-xs", children: [
          "⚠️ O Telegram limita vídeos redondos a ",
          /* @__PURE__ */ jsx("b", { children: "12 MB" }),
          ". Se passar disso, diminua a resolução (ex.: 320×320), reduza a duração ou aumente o ",
          /* @__PURE__ */ jsx("code", { children: "-crf" }),
          " para 32."
        ] })
      ] }),
      /* @__PURE__ */ jsx(DialogFooter, { children: /* @__PURE__ */ jsx(Button, { onClick: () => setHelpOpen(false), children: "Entendi" }) })
    ] }) })
  ] });
}
export {
  VideosPage as component
};
