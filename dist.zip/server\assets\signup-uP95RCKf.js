import { jsxs, jsx } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { s as supabase } from "./client-bD0og8Nx.js";
import { C as Card, L as Label, I as Input, B as Button } from "./router-Cw6OHOsO.js";
import { toast } from "sonner";
import "@supabase/supabase-js";
import "@tanstack/react-query";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "lucide-react";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function SignupPage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const redirectUrl = `${window.location.origin}/dashboard`;
    const {
      error
    } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          display_name: name
        }
      }
    });
    setLoading(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Conta criada! Você já pode entrar.");
    navigate({
      to: "/login"
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen relative flex items-center justify-center p-4 overflow-hidden", children: [
    /* @__PURE__ */ jsx("div", { className: "absolute inset-0 grid-bg opacity-60 pointer-events-none" }),
    /* @__PURE__ */ jsx("div", { className: "absolute -top-32 -right-32 size-[480px] rounded-full cyber-gradient opacity-30 blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsx("div", { className: "absolute -bottom-32 -left-32 size-[520px] rounded-full cyber-gradient opacity-30 blur-3xl pointer-events-none" }),
    /* @__PURE__ */ jsxs(Card, { className: "relative w-full max-w-md p-8 space-y-6 glass-strong cyber-border neon-glow rounded-2xl border-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-2", children: [
        /* @__PURE__ */ jsx("img", { src: "/favicon.png", alt: "Logo", className: "size-16 rounded-2xl neon-glow" }),
        /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold tracking-tight cyber-text", children: "Criar conta" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Comece a enviar sinais" })
      ] }),
      /* @__PURE__ */ jsxs("form", { onSubmit, className: "space-y-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "name", children: "Nome" }),
          /* @__PURE__ */ jsx(Input, { id: "name", required: true, value: name, onChange: (e) => setName(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: "Email" }),
          /* @__PURE__ */ jsx(Input, { id: "email", type: "email", required: true, value: email, onChange: (e) => setEmail(e.target.value) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "password", children: "Senha" }),
          /* @__PURE__ */ jsx(Input, { id: "password", type: "password", required: true, minLength: 6, value: password, onChange: (e) => setPassword(e.target.value) })
        ] }),
        /* @__PURE__ */ jsx(Button, { type: "submit", className: "w-full cyber-gradient text-primary-foreground border-0 hover:opacity-90 neon-glow", disabled: loading, children: loading ? "Criando..." : "Criar conta" })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "text-sm text-center text-muted-foreground", children: [
        "Já tem conta?",
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/login", className: "cyber-text font-semibold hover:underline", children: "Entrar" })
      ] })
    ] })
  ] });
}
export {
  SignupPage as component
};
