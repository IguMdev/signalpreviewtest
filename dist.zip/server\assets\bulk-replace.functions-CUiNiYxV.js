import { c as createServerRpc } from "./createServerRpc-Da-G_f3h.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "react";
import "@tanstack/react-router";
import "react/jsx-runtime";
import "@tanstack/react-router/ssr/server";
const BulkReplaceInput = z.object({
  oldLink: z.string().min(1),
  newLink: z.string().min(1)
});
const bulkReplaceLinks_createServerFn_handler = createServerRpc({
  id: "b9ff1a6bc1d5c7403ffc0951cb8843216e98d11123f4a3455fb6f287af1a8f87",
  name: "bulkReplaceLinks",
  filename: "src/lib/bulk-replace.functions.ts"
}, (opts) => bulkReplaceLinks.__executeServer(opts));
const bulkReplaceLinks = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => BulkReplaceInput.parse(d)).handler(bulkReplaceLinks_createServerFn_handler, async ({
  data,
  context
}) => {
  const {
    supabase,
    userId
  } = context;
  const {
    oldLink,
    newLink
  } = data;
  const replaceStr = (str) => {
    if (!str) return str;
    return str.split(oldLink).join(newLink);
  };
  let recurringUpdated = 0;
  let scheduledUpdated = 0;
  const {
    data: recurringSchedules,
    error: err1
  } = await supabase.from("recurring_schedules").select("*").eq("user_id", userId);
  if (err1) throw new Error("Erro ao buscar agendamentos recorrentes: " + err1.message);
  for (const schedule of recurringSchedules || []) {
    let changed = false;
    const updates = {};
    const newContent = replaceStr(schedule.content);
    if (newContent !== schedule.content) {
      updates.content = newContent;
      changed = true;
    }
    const newButtonUrl = replaceStr(schedule.button_url);
    if (newButtonUrl !== schedule.button_url) {
      updates.button_url = newButtonUrl;
      changed = true;
    }
    if (schedule.follow_ups && Array.isArray(schedule.follow_ups)) {
      let followUpsChanged = false;
      const newFollowUps = schedule.follow_ups.map((f) => {
        const fNewContent = replaceStr(f.content);
        const fNewButtonUrl = replaceStr(f.button_url);
        if (fNewContent !== f.content || fNewButtonUrl !== f.button_url) {
          followUpsChanged = true;
          return {
            ...f,
            content: fNewContent,
            button_url: fNewButtonUrl
          };
        }
        return f;
      });
      if (followUpsChanged) {
        updates.follow_ups = newFollowUps;
        changed = true;
      }
    }
    if (changed) {
      const {
        error: updErr
      } = await supabase.from("recurring_schedules").update(updates).eq("id", schedule.id);
      if (updErr) throw new Error("Erro ao atualizar agendamento recorrente: " + updErr.message);
      recurringUpdated++;
    }
  }
  const {
    data: scheduledMessages,
    error: err2
  } = await supabase.from("scheduled_messages").select("*").eq("user_id", userId).eq("status", "pending");
  if (err2) throw new Error("Erro ao buscar agendamentos únicos: " + err2.message);
  for (const msg of scheduledMessages || []) {
    const newContent = replaceStr(msg.content);
    if (newContent !== msg.content) {
      const {
        error: updErr
      } = await supabase.from("scheduled_messages").update({
        content: newContent
      }).eq("id", msg.id);
      if (updErr) throw new Error("Erro ao atualizar agendamento único: " + updErr.message);
      scheduledUpdated++;
    }
  }
  return {
    recurringUpdated,
    scheduledUpdated,
    ok: true
  };
});
export {
  bulkReplaceLinks_createServerFn_handler
};
