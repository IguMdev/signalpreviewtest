import { jsxs, jsx } from "react/jsx-runtime";
import { u as useAuth, B as Button, C as Card, x as CardContent, O as CardHeader, Q as CardTitle, L as Label, I as Input } from "./router-Cw6OHOsO.js";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { s as supabase } from "./client-bD0og8Nx.js";
import { A as Avatar, a as AvatarImage, b as AvatarFallback } from "./avatar-BU2g_-Ad.js";
import { LogOut, Upload, EyeOff, Eye } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";
import { g as getMySubscriptions } from "./engagement.functions-BnPQkoHV.js";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { isPast, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import "@tanstack/react-router";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./auth-middleware-76zZrGAr.js";
import "@supabase/supabase-js";
import "./createMiddleware-BvN2ghIY.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "./client.server-CDheR9QG.js";
import "zod";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-avatar";
function splitName(full) {
  if (!full) return {
    first: "",
    last: ""
  };
  const parts = full.trim().split(/\s+/);
  return {
    first: parts[0] ?? "",
    last: parts.slice(1).join(" ")
  };
}
function PerfilPage() {
  const {
    user,
    signOut
  } = useAuth();
  const qc = useQueryClient();
  const {
    data: profile
  } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("profiles").select("display_name, avatar_url").eq("id", user.id).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [cpf, setCpf] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [nationality, setNationality] = useState("");
  const [phone, setPhone] = useState("");
  const [savingInfo, setSavingInfo] = useState(false);
  const fetchSubs = useServerFn(getMySubscriptions);
  const subsQ = useQuery({
    queryKey: ["engagement-subs", user?.id],
    queryFn: () => fetchSubs(),
    enabled: !!user
  });
  useEffect(() => {
    const n = splitName(profile?.display_name);
    setFirstName(n.first);
    setLastName(n.last);
    if (user?.email) setEmail(user.email);
    if (user?.user_metadata) {
      setAddress(user.user_metadata.address || "");
      setCpf(user.user_metadata.cpf || "");
      setBirthDate(user.user_metadata.birth_date || "");
      setNationality(user.user_metadata.nationality || "");
      setPhone(user.user_metadata.phone || "");
    }
  }, [profile?.display_name, user]);
  const [currentPwd, setCurrentPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  async function handleAvatarUpload(e) {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 800 * 1024) {
      toast.error("Tamanho máximo: 800KB");
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() ?? "png";
      const path = `${user.id}/avatar-${Date.now()}.${ext}`;
      const {
        error: upErr
      } = await supabase.storage.from("avatars").upload(path, file, {
        upsert: true,
        contentType: file.type
      });
      if (upErr) throw upErr;
      const {
        data: pub
      } = supabase.storage.from("avatars").getPublicUrl(path);
      const {
        error: updErr
      } = await supabase.from("profiles").update({
        avatar_url: pub.publicUrl
      }).eq("id", user.id);
      if (updErr) throw updErr;
      await qc.invalidateQueries({
        queryKey: ["profile", user.id]
      });
      toast.success("Foto atualizada");
    } catch (err) {
      toast.error(err?.message ?? "Falha ao enviar foto");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }
  async function saveInfo() {
    if (!user) return;
    setSavingInfo(true);
    try {
      const display_name = `${firstName} ${lastName}`.trim();
      const {
        error
      } = await supabase.from("profiles").update({
        display_name
      }).eq("id", user.id);
      if (error) throw error;
      const updates = {};
      if (email && email !== user.email) {
        updates.email = email;
      }
      updates.data = {
        address,
        cpf,
        birth_date: birthDate,
        nationality,
        phone
      };
      const {
        error: authErr
      } = await supabase.auth.updateUser(updates);
      if (authErr) throw authErr;
      if (email && email !== user.email) {
        toast.info("Enviamos um email de confirmação para o novo endereço.");
      }
      await qc.invalidateQueries({
        queryKey: ["profile", user.id]
      });
      toast.success("Informações salvas");
    } catch (err) {
      toast.error(err?.message ?? "Falha ao salvar");
    } finally {
      setSavingInfo(false);
    }
  }
  async function savePassword() {
    if (!newPwd || newPwd.length < 6) {
      toast.error("A nova senha deve ter pelo menos 6 caracteres");
      return;
    }
    if (!user?.email) return;
    setSavingPwd(true);
    try {
      const {
        error: reauthErr
      } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: currentPwd
      });
      if (reauthErr) {
        toast.error("Senha atual incorreta");
        return;
      }
      const {
        error
      } = await supabase.auth.updateUser({
        password: newPwd
      });
      if (error) throw error;
      setCurrentPwd("");
      setNewPwd("");
      toast.success("Senha atualizada");
    } catch (err) {
      toast.error(err?.message ?? "Falha ao atualizar senha");
    } finally {
      setSavingPwd(false);
    }
  }
  const initials = (firstName?.[0] ?? "") + (lastName?.[0] ?? "") || (user?.email?.[0] ?? "U");
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-8", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold tracking-tight", children: "Minha Conta" }),
        /* @__PURE__ */ jsx("p", { className: "text-muted-foreground", children: "Gerencie sua conta e preferências." })
      ] }),
      /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", onClick: () => signOut(), children: [
        /* @__PURE__ */ jsx(LogOut, { className: "size-4 mr-1.5" }),
        " Sair"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid gap-6 lg:grid-cols-[340px_1fr]", children: [
      /* @__PURE__ */ jsx(Card, { children: /* @__PURE__ */ jsxs(CardContent, { className: "pt-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-4", children: [
          /* @__PURE__ */ jsxs(Avatar, { className: "size-20 rounded-md", children: [
            /* @__PURE__ */ jsx(AvatarImage, { src: profile?.avatar_url ?? void 0, alt: firstName }),
            /* @__PURE__ */ jsx(AvatarFallback, { className: "rounded-md text-lg", children: initials.toUpperCase() })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "space-y-2 flex-1", children: [
            /* @__PURE__ */ jsx("p", { className: "font-semibold", children: firstName || "Usuário" }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "JPG, GIF ou PNG. Tamanho máximo de 800K" }),
            /* @__PURE__ */ jsx("input", { ref: fileRef, type: "file", accept: "image/png,image/jpeg,image/gif", className: "hidden", onChange: handleAvatarUpload }),
            /* @__PURE__ */ jsxs(Button, { size: "sm", onClick: () => fileRef.current?.click(), disabled: uploading, children: [
              /* @__PURE__ */ jsx(Upload, { className: "size-4 mr-1.5" }),
              uploading ? "Enviando..." : "Enviar foto"
            ] })
          ] })
        ] }),
        subsQ.data && subsQ.data.length > 0 && /* @__PURE__ */ jsxs("div", { className: "mt-6 pt-6 border-t space-y-4", children: [
          /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-foreground/90 uppercase tracking-wide", children: "Assinatura Atual" }),
          subsQ.data.map((sub) => {
            const isExpired = sub.current_period_end && isPast(new Date(sub.current_period_end));
            const timeLeft = sub.current_period_end ? formatDistanceToNow(new Date(sub.current_period_end), {
              locale: ptBR
            }) : null;
            const endDate = sub.current_period_end ? new Date(sub.current_period_end).toLocaleDateString("pt-BR") : "--/--/----";
            return /* @__PURE__ */ jsxs("div", { className: "relative overflow-hidden rounded-xl border bg-gradient-to-br from-background to-muted/30 p-4 shadow-sm transition-all hover:shadow-md", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx("span", { className: "flex size-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse" }),
                  /* @__PURE__ */ jsx("p", { className: "font-bold text-base text-foreground truncate max-w-[150px]", children: sub.plan?.name || "Plano Customizado" })
                ] }),
                /* @__PURE__ */ jsx("span", { className: "px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider shrink-0", children: sub.status === "active" ? "Ativo" : sub.status })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5 mt-4", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center text-xs", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-muted-foreground font-medium", children: "Próxima cobrança" }),
                  /* @__PURE__ */ jsx("span", { className: "font-semibold", children: endDate })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center text-xs", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-muted-foreground font-medium", children: "Tempo restante" }),
                  /* @__PURE__ */ jsx("span", { className: "font-semibold text-primary", children: isExpired ? "Expirado" : timeLeft })
                ] })
              ] })
            ] }, sub.id);
          })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxs(Card, { children: [
          /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Informações Gerais" }) }),
          /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "firstName", children: "Nome" }),
                /* @__PURE__ */ jsx(Input, { id: "firstName", placeholder: "Digite seu nome", value: firstName, onChange: (e) => setFirstName(e.target.value), maxLength: 60 })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "lastName", children: "Sobrenome" }),
                /* @__PURE__ */ jsx(Input, { id: "lastName", placeholder: "Digite seu sobrenome", value: lastName, onChange: (e) => setLastName(e.target.value), maxLength: 60 })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: "Email" }),
              /* @__PURE__ */ jsx(Input, { id: "email", value: email, onChange: (e) => setEmail(e.target.value) }),
              /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Ao trocar o email, você precisará confirmar a alteração no novo e no antigo endereço." })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "cpf", children: "CPF" }),
                /* @__PURE__ */ jsx(Input, { id: "cpf", placeholder: "Digite seu CPF", value: cpf, onChange: (e) => setCpf(e.target.value), maxLength: 14 })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "phone", children: "Telefone" }),
                /* @__PURE__ */ jsx(Input, { id: "phone", placeholder: "Digite seu número", value: phone, onChange: (e) => setPhone(e.target.value) })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "address", children: "Endereço" }),
              /* @__PURE__ */ jsx(Input, { id: "address", placeholder: "Digite seu endereço", value: address, onChange: (e) => setAddress(e.target.value) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "birthDate", children: "Data de Nascimento" }),
                /* @__PURE__ */ jsx(Input, { id: "birthDate", placeholder: "DD/MM/AAAA", value: birthDate, onChange: (e) => setBirthDate(e.target.value) })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "nationality", children: "Nacionalidade" }),
                /* @__PURE__ */ jsx(Input, { id: "nationality", placeholder: "Sua nacionalidade", value: nationality, onChange: (e) => setNationality(e.target.value) })
              ] })
            ] }),
            /* @__PURE__ */ jsx(Button, { onClick: saveInfo, disabled: savingInfo, children: savingInfo ? "Salvando..." : "Salvar tudo" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Card, { children: [
          /* @__PURE__ */ jsx(CardHeader, { children: /* @__PURE__ */ jsx(CardTitle, { className: "text-base", children: "Informações da Senha" }) }),
          /* @__PURE__ */ jsxs(CardContent, { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "currentPwd", children: "Senha atual" }),
                /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsx(Input, { id: "currentPwd", type: showCurrent ? "text" : "password", placeholder: "Senha atual", value: currentPwd, onChange: (e) => setCurrentPwd(e.target.value), className: "pr-10" }),
                  /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setShowCurrent((s) => !s), className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground", "aria-label": "Mostrar senha", children: showCurrent ? /* @__PURE__ */ jsx(EyeOff, { className: "size-4" }) : /* @__PURE__ */ jsx(Eye, { className: "size-4" }) })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "newPwd", children: "Nova senha" }),
                /* @__PURE__ */ jsxs("div", { className: "relative", children: [
                  /* @__PURE__ */ jsx(Input, { id: "newPwd", type: showNew ? "text" : "password", placeholder: "Nova senha", value: newPwd, onChange: (e) => setNewPwd(e.target.value), className: "pr-10" }),
                  /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setShowNew((s) => !s), className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground", "aria-label": "Mostrar senha", children: showNew ? /* @__PURE__ */ jsx(EyeOff, { className: "size-4" }) : /* @__PURE__ */ jsx(Eye, { className: "size-4" }) })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsx(Button, { onClick: savePassword, disabled: savingPwd, children: savingPwd ? "Salvando..." : "Salvar tudo" })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  PerfilPage as component
};
