import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Link, useParams, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { s as supabase } from "./client-bD0og8Nx.js";
import { C as Card, L as Label, N as Switch, I as Input, T as Textarea, B as Button, H as Badge, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, Y as sendRoomTest } from "./router-Cw6OHOsO.js";
import { P as PremiumEmojiPicker } from "./PremiumEmojiPicker-KRfbHKuL.js";
import { C as Checkbox } from "./checkbox-CU7rmJt5.js";
import { toast } from "sonner";
import { ShoppingBag, AlertTriangle, Eye, Crown, Image, Plus, Trash2, GraduationCap, MessageCircle, TrendingUp, Home, ChevronRight, ExternalLink, X, Info, Smile, RotateCcw, Send, ImageIcon, Upload, ChevronDown, ChevronUp } from "lucide-react";
import { A as ASSETS_CATALOG, D as DEFAULT_PAYOUT } from "./signals.server-CxsfAlOW.js";
import { T as Tabs, a as TabsList, b as TabsTrigger, c as TabsContent } from "./tabs-Bc7VJTwT.js";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
import { b as getPromoBotSettings, c as upsertPromoBotSettings, p as previewPromoOffers } from "./promo.functions-D_8o42Ut.js";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-dialog";
import "./client.server-CDheR9QG.js";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./telegram.server-CxWEOea-.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
import "@radix-ui/react-checkbox";
import "@radix-ui/react-tabs";
import "./createMiddleware-BvN2ghIY.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
const testWindow = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((input) => z.object({
  windowId: z.string().uuid()
}).parse(input)).handler(createSsrRpc("124b67b88312178f40f4489f9bbb49f4f3b5dd9d256a7171ef7515d7039df67e"));
const STORE_LABELS = {
  amazon: "Amazon",
  shopee: "Shopee",
  aliexpress: "AliExpress",
  mercadolivre: "Mercado Livre",
  privacy: "Privacy",
  crakrevenue: "CrakRevenue",
  awempire: "AWEmpire",
  bet365: "Bet365",
  betano: "Betano",
  blaze: "Blaze",
  kto: "KTO",
  sportingbet: "Sportingbet"
};
const STORES_BY_NICHE = {
  promo: ["amazon", "shopee", "aliexpress", "mercadolivre"],
  hot: ["privacy", "crakrevenue", "awempire"],
  igaming: ["bet365", "betano", "blaze", "kto", "sportingbet"]
};
const DEFAULT_STORES = ["amazon", "shopee", "aliexpress", "mercadolivre"];
const DEFAULT_TEMPLATE = `🔥 <b>{title}</b>

<s>De R$ {old_price}</s> por <b>R$ {price}</b>
💰 {discount}% OFF

👉 {link}`;
function PromoBotCard({
  roomId,
  allowedStores = DEFAULT_STORES,
  title = "Bot de Promoções",
  description = "Envia ofertas automaticamente a partir das APIs oficiais (Amazon, Shopee, AliExpress, Mercado Livre)."
}) {
  const qc = useQueryClient();
  const getSettings = useServerFn(getPromoBotSettings);
  const saveSettings = useServerFn(upsertPromoBotSettings);
  const preview = useServerFn(previewPromoOffers);
  const q = useQuery({
    queryKey: ["promo-bot-settings", roomId],
    queryFn: () => getSettings({ data: { room_id: roomId } })
  });
  const [enabled, setEnabled] = useState(false);
  const [intervalHours, setIntervalHours] = useState(4);
  const [stores, setStores] = useState([]);
  const [minDiscount, setMinDiscount] = useState(0);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [keywords, setKeywords] = useState("");
  const [blacklist, setBlacklist] = useState("");
  const [categories, setCategories] = useState("");
  const [template, setTemplate] = useState(DEFAULT_TEMPLATE);
  const [sendImage, setSendImage] = useState(true);
  useEffect(() => {
    const s = q.data?.settings;
    if (!s) return;
    setEnabled(!!s.enabled);
    setIntervalHours(s.interval_hours ?? 4);
    setStores(s.stores ?? []);
    setMinDiscount(s.min_discount_pct ?? 0);
    setMinPrice(s.min_price?.toString() ?? "");
    setMaxPrice(s.max_price?.toString() ?? "");
    setKeywords((s.keywords ?? []).join(", "));
    setBlacklist((s.blacklist_keywords ?? []).join(", "));
    setCategories((s.categories ?? []).join(", "));
    setTemplate(s.message_template || DEFAULT_TEMPLATE);
    setSendImage(s.send_image ?? true);
  }, [q.data]);
  const save = useMutation({
    mutationFn: () => saveSettings({
      data: {
        room_id: roomId,
        enabled,
        interval_hours: intervalHours,
        stores,
        min_discount_pct: minDiscount,
        min_price: minPrice ? Number(minPrice) : null,
        max_price: maxPrice ? Number(maxPrice) : null,
        categories: categories.split(",").map((s) => s.trim()).filter(Boolean),
        keywords: keywords.split(",").map((s) => s.trim()).filter(Boolean),
        blacklist_keywords: blacklist.split(",").map((s) => s.trim()).filter(Boolean),
        message_template: template,
        parse_mode: "HTML",
        send_image: sendImage,
        premium_account_id: null,
        premium_enabled: false
      }
    }),
    onSuccess: () => {
      toast.success("Configurações do bot de promoções salvas");
      qc.invalidateQueries({ queryKey: ["promo-bot-settings", roomId] });
    },
    onError: (e) => toast.error(e.message)
  });
  const previewMut = useMutation({
    mutationFn: () => preview({ data: { room_id: roomId } }),
    onError: (e) => toast.error(e.message)
  });
  function toggleStore(s) {
    setStores((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]);
  }
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-5", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-3 flex-wrap", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(ShoppingBag, { className: "size-5 text-primary" }),
          title
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: description })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Ativo" }),
        /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-dashed p-3 text-xs flex items-start gap-2 bg-muted/40", children: [
      /* @__PURE__ */ jsx(AlertTriangle, { className: "size-4 text-amber-500 shrink-0 mt-0.5" }),
      /* @__PURE__ */ jsxs("div", { children: [
        "Para receber ofertas, cadastre suas credenciais em",
        " ",
        /* @__PURE__ */ jsx(Link, { to: "/promocoes/contas", className: "underline text-primary", children: "Promoções → Contas de afiliado" }),
        "."
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Intervalo (horas)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 1, max: 168, value: intervalHours, onChange: (e) => setIntervalHours(Number(e.target.value)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Desconto mínimo (%)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 0, max: 100, value: minDiscount, onChange: (e) => setMinDiscount(Number(e.target.value)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Enviar imagem do produto" }),
        /* @__PURE__ */ jsx("div", { className: "h-9 flex items-center", children: /* @__PURE__ */ jsx(Switch, { checked: sendImage, onCheckedChange: setSendImage }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Preço mínimo (R$)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", value: minPrice, onChange: (e) => setMinPrice(e.target.value), placeholder: "opcional" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Preço máximo (R$)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", value: maxPrice, onChange: (e) => setMaxPrice(e.target.value), placeholder: "opcional" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Lojas habilitadas" }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: allowedStores.map((v) => {
        const active = stores.includes(v);
        return /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: () => toggleStore(v),
            className: `px-3 py-1.5 rounded-md text-xs border transition ${active ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"}`,
            children: STORE_LABELS[v]
          },
          v
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Palavras-chave (separadas por vírgula)" }),
        /* @__PURE__ */ jsx(Input, { value: keywords, onChange: (e) => setKeywords(e.target.value), placeholder: "celular, fone, notebook" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Categorias" }),
        /* @__PURE__ */ jsx(Input, { value: categories, onChange: (e) => setCategories(e.target.value), placeholder: "eletronicos, casa" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Blacklist (não enviar)" }),
        /* @__PURE__ */ jsx(Input, { value: blacklist, onChange: (e) => setBlacklist(e.target.value), placeholder: "usado, recondicionado" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Template da mensagem" }),
      /* @__PURE__ */ jsx(Textarea, { rows: 6, value: template, onChange: (e) => setTemplate(e.target.value) }),
      /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-muted-foreground", children: [
        "Variáveis: ",
        /* @__PURE__ */ jsx("code", { children: `{title} {price} {old_price} {discount} {link} {store} {category}` })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2 pt-2", children: [
      /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar configurações" }),
      /* @__PURE__ */ jsxs(Button, { variant: "outline", onClick: () => previewMut.mutate(), disabled: previewMut.isPending, children: [
        /* @__PURE__ */ jsx(Eye, { className: "size-4 mr-1.5" }),
        previewMut.isPending ? "Buscando..." : "Pré-visualizar ofertas"
      ] })
    ] }),
    previewMut.data && /* @__PURE__ */ jsxs("div", { className: "space-y-2 pt-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-xs font-medium", children: [
        "Amostra (",
        previewMut.data.offers.length,
        ")"
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-2 max-h-96 overflow-auto", children: previewMut.data.offers.map((o, i) => /* @__PURE__ */ jsxs("div", { className: "border rounded-md p-2 text-xs flex gap-2", children: [
        o.imageUrl && /* @__PURE__ */ jsx("img", { src: o.imageUrl, alt: "", className: "size-14 object-cover rounded" }),
        /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsx(Badge, { variant: "secondary", className: "mb-1", children: o.store }),
          o.error ? /* @__PURE__ */ jsx("div", { className: "text-destructive", children: o.error }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("div", { className: "font-medium line-clamp-2", children: o.title }),
            /* @__PURE__ */ jsxs("div", { className: "text-muted-foreground", children: [
              o.oldPrice && /* @__PURE__ */ jsxs("s", { className: "mr-1", children: [
                "R$ ",
                o.oldPrice
              ] }),
              /* @__PURE__ */ jsxs("strong", { children: [
                "R$ ",
                o.price
              ] }),
              o.discountPct ? /* @__PURE__ */ jsxs("span", { className: "ml-1 text-emerald-600", children: [
                "-",
                o.discountPct,
                "%"
              ] }) : null
            ] })
          ] })
        ] })
      ] }, i)) })
    ] })
  ] });
}
function HotVipFunnelCard({ roomId }) {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["hot-vip-funnel", roomId],
    queryFn: async () => {
      const { data, error } = await supabase.from("hot_vip_funnel").select("*").eq("room_id", roomId).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const [enabled, setEnabled] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState("");
  const [price, setPrice] = useState("");
  const [interval, setInterval] = useState(3);
  const [cta, setCta] = useState("Entrar no VIP 🔥");
  const [welcome, setWelcome] = useState("");
  useEffect(() => {
    if (!q.data) return;
    setEnabled(!!q.data.enabled);
    setCheckoutUrl(q.data.vip_checkout_url ?? "");
    setPrice(q.data.vip_price_brl?.toString() ?? "");
    setInterval(q.data.teaser_interval_hours ?? 3);
    setCta(q.data.cta_button_text ?? "Entrar no VIP 🔥");
    setWelcome(q.data.welcome_message ?? "");
  }, [q.data]);
  const save = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const payload = {
        room_id: roomId,
        user_id: u.user.id,
        enabled,
        vip_checkout_url: checkoutUrl || null,
        vip_price_brl: price ? Number(price) : null,
        teaser_interval_hours: interval,
        cta_button_text: cta,
        welcome_message: welcome || null
      };
      const { error } = await supabase.from("hot_vip_funnel").upsert(payload, { onConflict: "room_id" });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Funil VIP salvo");
      qc.invalidateQueries({ queryKey: ["hot-vip-funnel", roomId] });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Crown, { className: "size-5 text-primary" }),
          " Funil VIP (free → pago)"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Empurra membros do grupo gratuito para o checkout do VIP via prévias agendadas + welcome bot." })
      ] }),
      /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "URL do checkout VIP" }),
        /* @__PURE__ */ jsx(Input, { value: checkoutUrl, onChange: (e) => setCheckoutUrl(e.target.value), placeholder: "https://..." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Preço VIP (R$)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", value: price, onChange: (e) => setPrice(e.target.value), placeholder: "29.90" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Intervalo entre prévias (h)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", min: 1, max: 48, value: interval, onChange: (e) => setInterval(Number(e.target.value)) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Texto do botão CTA" }),
        /* @__PURE__ */ jsx(Input, { value: cta, onChange: (e) => setCta(e.target.value) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Mensagem de boas-vindas (free)" }),
      /* @__PURE__ */ jsx(Textarea, { rows: 3, value: welcome, onChange: (e) => setWelcome(e.target.value), placeholder: "Bem-vinda(o)! Aqui é a prévia. Para o conteúdo completo entre no VIP 🔥" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-2 border-t", children: /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar funil VIP" }) })
  ] });
}
function HotTeasersCard({ roomId }) {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["hot-teasers", roomId],
    queryFn: async () => {
      const { data, error } = await supabase.from("hot_teasers").select("*").eq("room_id", roomId).order("sort_order", { ascending: true });
      if (error) throw error;
      return data ?? [];
    }
  });
  const [caption, setCaption] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const add = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("hot_teasers").insert({
        user_id: u.user.id,
        room_id: roomId,
        caption,
        image_path: imageUrl || null,
        sort_order: q.data?.length ?? 0
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setCaption("");
      setImageUrl("");
      qc.invalidateQueries({ queryKey: ["hot-teasers", roomId] });
      toast.success("Prévia adicionada");
    },
    onError: (e) => toast.error(e.message)
  });
  const del = useMutation({
    mutationFn: async (id) => {
      const { error } = await supabase.from("hot_teasers").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["hot-teasers", roomId] })
  });
  const toggle = useMutation({
    mutationFn: async (t) => {
      const { error } = await supabase.from("hot_teasers").update({ is_active: !t.is_active }).eq("id", t.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["hot-teasers", roomId] })
  });
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Image, { className: "size-5 text-primary" }),
        " Prévias Agendadas"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Mídias rotacionadas que o bot envia no grupo free a cada intervalo definido no Funil VIP." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-2 items-end", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Legenda" }),
        /* @__PURE__ */ jsx(Textarea, { rows: 2, value: caption, onChange: (e) => setCaption(e.target.value), placeholder: "Texto da prévia (com CTA pro VIP)" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "URL da imagem/vídeo (opcional)" }),
        /* @__PURE__ */ jsx(Input, { value: imageUrl, onChange: (e) => setImageUrl(e.target.value), placeholder: "https://..." })
      ] }),
      /* @__PURE__ */ jsxs(Button, { onClick: () => add.mutate(), disabled: !caption || add.isPending, children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-1" }),
        " Adicionar"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
      q.data?.map((t) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 border rounded-md p-3 text-sm", children: [
        t.image_path && /* @__PURE__ */ jsx("img", { src: t.image_path, alt: "", className: "size-12 rounded object-cover" }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "truncate", children: t.caption }),
          /* @__PURE__ */ jsx(Badge, { variant: t.is_active ? "default" : "secondary", className: "text-[10px]", children: t.is_active ? "ativo" : "inativo" })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: t.is_active, onCheckedChange: () => toggle.mutate(t) }),
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => del.mutate(t.id), children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
      ] }, t.id)),
      q.data?.length === 0 && /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Nenhuma prévia cadastrada ainda." })
    ] })
  ] });
}
function ExpertFunnelCard({ roomId }) {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["expert-funnel", roomId],
    queryFn: async () => {
      const { data, error } = await supabase.from("expert_funnel").select("*").eq("room_id", roomId).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const [enabled, setEnabled] = useState(false);
  const [productName, setProductName] = useState("");
  const [checkoutUrl, setCheckoutUrl] = useState("");
  const [price, setPrice] = useState("");
  const [cta, setCta] = useState("Quero participar 🎓");
  const [welcome, setWelcome] = useState("");
  useEffect(() => {
    if (!q.data) return;
    setEnabled(!!q.data.enabled);
    setProductName(q.data.product_name ?? "");
    setCheckoutUrl(q.data.checkout_url ?? "");
    setPrice(q.data.price_brl?.toString() ?? "");
    setCta(q.data.cta_button_text ?? "Quero participar 🎓");
    setWelcome(q.data.welcome_message ?? "");
  }, [q.data]);
  const save = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("expert_funnel").upsert(
        {
          room_id: roomId,
          user_id: u.user.id,
          enabled,
          product_name: productName || null,
          checkout_url: checkoutUrl || null,
          price_brl: price ? Number(price) : null,
          cta_button_text: cta,
          welcome_message: welcome || null
        },
        { onConflict: "room_id" }
      );
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Funil de mentoria salvo");
      qc.invalidateQueries({ queryKey: ["expert-funnel", roomId] });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(GraduationCap, { className: "size-5 text-primary" }),
          " Funil de Mentoria / Curso"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "CTA recorrente para o checkout do seu produto (mentoria, curso, comunidade paga)." })
      ] }),
      /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Nome do produto" }),
        /* @__PURE__ */ jsx(Input, { value: productName, onChange: (e) => setProductName(e.target.value), placeholder: "Mentoria Trader 360" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "URL do checkout" }),
        /* @__PURE__ */ jsx(Input, { value: checkoutUrl, onChange: (e) => setCheckoutUrl(e.target.value), placeholder: "https://..." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Preço (R$)" }),
        /* @__PURE__ */ jsx(Input, { type: "number", value: price, onChange: (e) => setPrice(e.target.value), placeholder: "497.00" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Texto do botão CTA" }),
        /* @__PURE__ */ jsx(Input, { value: cta, onChange: (e) => setCta(e.target.value) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Mensagem de boas-vindas" }),
      /* @__PURE__ */ jsx(Textarea, { rows: 3, value: welcome, onChange: (e) => setWelcome(e.target.value) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-2 border-t", children: /* @__PURE__ */ jsx(Button, { onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar funil" }) })
  ] });
}
const WEEKDAYS$1 = [
  { v: 1, l: "Seg" },
  { v: 2, l: "Ter" },
  { v: 3, l: "Qua" },
  { v: 4, l: "Qui" },
  { v: 5, l: "Sex" },
  { v: 6, l: "Sáb" },
  { v: 0, l: "Dom" }
];
function ExpertEngagementCard({ roomId }) {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["expert-engagement", roomId],
    queryFn: async () => {
      const { data, error } = await supabase.from("expert_engagement_prompts").select("*").eq("room_id", roomId).order("send_time", { ascending: true });
      if (error) throw error;
      return data ?? [];
    }
  });
  const [kind, setKind] = useState("question");
  const [content, setContent] = useState("");
  const [opts, setOpts] = useState("");
  const [sendTime, setSendTime] = useState("10:00");
  const [weekdays, setWeekdays] = useState([1, 2, 3, 4, 5]);
  const add = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const options = kind === "poll" ? opts.split("\n").map((s) => s.trim()).filter(Boolean) : [];
      const { error } = await supabase.from("expert_engagement_prompts").insert({
        user_id: u.user.id,
        room_id: roomId,
        kind,
        content,
        options,
        send_time: sendTime + ":00",
        weekdays
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setContent("");
      setOpts("");
      qc.invalidateQueries({ queryKey: ["expert-engagement", roomId] });
      toast.success("Prompt adicionado");
    },
    onError: (e) => toast.error(e.message)
  });
  const del = useMutation({
    mutationFn: async (id) => {
      const { error } = await supabase.from("expert_engagement_prompts").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expert-engagement", roomId] })
  });
  const toggle = useMutation({
    mutationFn: async (p) => {
      const { error } = await supabase.from("expert_engagement_prompts").update({ is_active: !p.is_active }).eq("id", p.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expert-engagement", roomId] })
  });
  const toggleWeekday = (d) => setWeekdays((w) => w.includes(d) ? w.filter((x) => x !== d) : [...w, d]);
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(MessageCircle, { className: "size-5 text-primary" }),
        " Engajamento Diário"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Perguntas do dia / enquetes enviadas no horário marcado para manter a comunidade ativa." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-[140px_1fr] gap-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Tipo" }),
        /* @__PURE__ */ jsxs(Select, { value: kind, onValueChange: (v) => setKind(v), children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            /* @__PURE__ */ jsx(SelectItem, { value: "question", children: "Pergunta" }),
            /* @__PURE__ */ jsx(SelectItem, { value: "poll", children: "Enquete" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Conteúdo" }),
        /* @__PURE__ */ jsx(Textarea, { rows: 2, value: content, onChange: (e) => setContent(e.target.value), placeholder: "Qual sua maior dificuldade essa semana?" })
      ] })
    ] }),
    kind === "poll" && /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Opções da enquete (uma por linha)" }),
      /* @__PURE__ */ jsx(Textarea, { rows: 3, value: opts, onChange: (e) => setOpts(e.target.value), placeholder: "Sim\nNão\nTalvez" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-[180px_1fr] gap-3 items-end", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Horário" }),
        /* @__PURE__ */ jsx(Input, { type: "time", value: sendTime, onChange: (e) => setSendTime(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Dias da semana" }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-1", children: WEEKDAYS$1.map((d) => /* @__PURE__ */ jsx(
          Badge,
          {
            variant: weekdays.includes(d.v) ? "default" : "outline",
            className: "cursor-pointer",
            onClick: () => toggleWeekday(d.v),
            children: d.l
          },
          d.v
        )) })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxs(Button, { onClick: () => add.mutate(), disabled: !content || add.isPending, children: [
      /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-1" }),
      " Adicionar prompt"
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-2 pt-2 border-t", children: [
      q.data?.map((p) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 border rounded-md p-3 text-sm", children: [
        /* @__PURE__ */ jsx(Badge, { variant: "outline", className: "text-[10px]", children: p.kind }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsx("div", { className: "truncate", children: p.content }),
          /* @__PURE__ */ jsxs("div", { className: "text-[10px] text-muted-foreground", children: [
            p.send_time?.slice(0, 5),
            " · ",
            (p.weekdays ?? []).length,
            " dias"
          ] })
        ] }),
        /* @__PURE__ */ jsx(Switch, { checked: p.is_active, onCheckedChange: () => toggle.mutate(p) }),
        /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => del.mutate(p.id), children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
      ] }, p.id)),
      q.data?.length === 0 && /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Nenhum prompt cadastrado." })
    ] })
  ] });
}
function IGamingResultsCard({ roomId }) {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["igaming-results", roomId],
    queryFn: async () => {
      const { data, error } = await supabase.from("igaming_results").select("*").eq("room_id", roomId).order("confirmed_at", { ascending: false }).limit(30);
      if (error) throw error;
      return data ?? [];
    }
  });
  const log = useMutation({
    mutationFn: async (result) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("igaming_results").insert({
        user_id: u.user.id,
        room_id: roomId,
        result
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["igaming-results", roomId] });
      toast.success("Resultado registrado");
    },
    onError: (e) => toast.error(e.message)
  });
  const stats = (q.data ?? []).reduce(
    (acc, r) => {
      acc.total += 1;
      if (r.result === "win") acc.win += 1;
      else if (r.result === "gale_win") acc.gale += 1;
      else acc.loss += 1;
      return acc;
    },
    { total: 0, win: 0, gale: 0, loss: 0 }
  );
  const assertRate = stats.total ? Math.round((stats.win + stats.gale) / stats.total * 100) : 0;
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(TrendingUp, { className: "size-5 text-primary" }),
        " Resultados ao Vivo"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Registre GREEN/RED dos sinais enviados. Estatística aparece no relatório da sala." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-4 gap-2 text-center", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-md border p-2", children: [
        /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold", children: stats.total }),
        /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "Total" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-md border p-2 text-emerald-500", children: [
        /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold", children: stats.win }),
        /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "Win" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-md border p-2 text-amber-500", children: [
        /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold", children: stats.gale }),
        /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "Gale" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "rounded-md border p-2 text-destructive", children: [
        /* @__PURE__ */ jsx("div", { className: "text-2xl font-bold", children: stats.loss }),
        /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "Loss" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "text-center text-sm", children: [
      "Assertividade (últimos 30): ",
      /* @__PURE__ */ jsxs("span", { className: "font-bold", children: [
        assertRate,
        "%"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-2 justify-center pt-2 border-t", children: [
      /* @__PURE__ */ jsx(Button, { onClick: () => log.mutate("win"), className: "bg-emerald-600 hover:bg-emerald-700", children: "✅ Green" }),
      /* @__PURE__ */ jsx(Button, { onClick: () => log.mutate("gale_win"), className: "bg-amber-600 hover:bg-amber-700", children: "⚠️ Gale" }),
      /* @__PURE__ */ jsx(Button, { onClick: () => log.mutate("loss"), variant: "destructive", children: "❌ Red" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "space-y-1 text-xs", children: q.data?.slice(0, 8).map((r) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between border-b pb-1", children: [
      /* @__PURE__ */ jsx(Badge, { variant: r.result === "loss" ? "destructive" : "default", className: "text-[10px]", children: r.result }),
      /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: new Date(r.confirmed_at).toLocaleString("pt-BR") })
    ] }, r.id)) })
  ] });
}
const TIMEZONES = [{
  v: "America/Sao_Paulo",
  l: "São Paulo / Brasília"
}, {
  v: "America/Manaus",
  l: "Manaus"
}, {
  v: "America/Bahia",
  l: "Bahia"
}, {
  v: "America/Fortaleza",
  l: "Fortaleza"
}, {
  v: "America/Recife",
  l: "Recife"
}, {
  v: "America/Belem",
  l: "Belém"
}, {
  v: "America/Cuiaba",
  l: "Cuiabá"
}, {
  v: "America/New_York",
  l: "Nova York"
}, {
  v: "America/Los_Angeles",
  l: "Los Angeles"
}, {
  v: "Europe/Lisbon",
  l: "Lisboa"
}, {
  v: "Europe/London",
  l: "Londres"
}, {
  v: "UTC",
  l: "UTC"
}];
const TIMEFRAMES = ["M1", "M2", "M3", "M5", "M15", "M30"];
const WEEKDAYS = [{
  v: 1,
  l: "Seg"
}, {
  v: 2,
  l: "Ter"
}, {
  v: 3,
  l: "Qua"
}, {
  v: 4,
  l: "Qui"
}, {
  v: 5,
  l: "Sex"
}, {
  v: 6,
  l: "Sáb"
}, {
  v: 0,
  l: "Dom"
}];
const SAVE_ALL_EVENT = "rooms-edit:save-all";
function useSaveAll(fn) {
  useEffect(() => {
    const handler = () => fn();
    window.addEventListener(SAVE_ALL_EVENT, handler);
    return () => window.removeEventListener(SAVE_ALL_EVENT, handler);
  }, [fn]);
}
function EditRoomPage() {
  const {
    roomId
  } = useParams({
    from: "/_authenticated/rooms/$roomId/edit"
  });
  const navigate = useNavigate();
  const room = useQuery({
    queryKey: ["room", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("rooms").select("*, room_chats(id, chat_id, chat_title)").eq("id", roomId).single();
      if (error) throw error;
      return data;
    }
  });
  if (room.isLoading) return /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground p-8", children: "Carregando..." });
  if (!room.data) return /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive p-8", children: "Sala não encontrada." });
  const r = room.data;
  const chatId = r.room_chats?.[0]?.chat_id;
  const accessUrl = r.access_url || (chatId ? `https://t.me/c/${String(chatId).replace(/^-?100/, "")}` : null);
  return /* @__PURE__ */ jsxs("div", { className: "space-y-5 pb-24 xl:-mx-14 2xl:-mx-24", children: [
    /* @__PURE__ */ jsxs("nav", { className: "flex items-center gap-1.5 text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsxs(Link, { to: "/", className: "flex items-center gap-1 hover:text-foreground", children: [
        /* @__PURE__ */ jsx(Home, { className: "size-3.5" }),
        " Home"
      ] }),
      /* @__PURE__ */ jsx(ChevronRight, { className: "size-3.5" }),
      /* @__PURE__ */ jsx(Link, { to: "/rooms", className: "hover:text-foreground", children: "Salas" }),
      /* @__PURE__ */ jsx(ChevronRight, { className: "size-3.5" }),
      /* @__PURE__ */ jsx("span", { className: "text-foreground", children: "Editar Sala" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 flex-wrap", children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-2xl font-bold tracking-tight", children: [
        "Editar Sala - ",
        r.name
      ] }),
      accessUrl && /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", className: "bg-primary", children: /* @__PURE__ */ jsxs("a", { href: accessUrl, target: "_blank", rel: "noreferrer", children: [
        /* @__PURE__ */ jsx(ExternalLink, { className: "size-4 mr-1" }),
        "Acessar"
      ] }) })
    ] }),
    /* @__PURE__ */ jsx(BaseConfigCard, { room: r }),
    (() => {
      switch (r.niche) {
        case "promo":
          return /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(TimezoneCard, { room: r }),
            /* @__PURE__ */ jsx(PromoBotCard, { roomId, allowedStores: [...STORES_BY_NICHE.promo] })
          ] });
        case "hot":
          return /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(TimezoneCard, { room: r }),
            /* @__PURE__ */ jsx(HotVipFunnelCard, { roomId }),
            /* @__PURE__ */ jsx(HotTeasersCard, { roomId }),
            /* @__PURE__ */ jsx(PromoBotCard, { roomId, allowedStores: [...STORES_BY_NICHE.hot], title: "Promoções Adultas", description: "Envia ofertas de redes adultas (Privacy, CrakRevenue, AWEmpire) com tracking." })
          ] });
        case "igaming":
          return /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(MessagesInfoCard, {}),
            /* @__PURE__ */ jsx(WindowsCard, { roomId }),
            /* @__PURE__ */ jsx(TemplatesCard, { roomId }),
            /* @__PURE__ */ jsx(IGamingResultsCard, { roomId }),
            /* @__PURE__ */ jsx(PromoBotCard, { roomId, allowedStores: [...STORES_BY_NICHE.igaming], title: "Promoções de Casas de Aposta", description: "Bônus, freebets e cashback das casas conectadas (Bet365, Betano, Blaze, KTO, Sportingbet)." }),
            /* @__PURE__ */ jsx(TimezoneCard, { room: r })
          ] });
        case "expert":
          return /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(TimezoneCard, { room: r }),
            /* @__PURE__ */ jsx(ExpertFunnelCard, { roomId }),
            /* @__PURE__ */ jsx(ExpertEngagementCard, { roomId })
          ] });
        default:
          return /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(MessagesInfoCard, {}),
            /* @__PURE__ */ jsx(WindowsCard, { roomId }),
            /* @__PURE__ */ jsx(TemplatesCard, { roomId }),
            /* @__PURE__ */ jsx(SessionMessagesCard, { roomId }),
            /* @__PURE__ */ jsx(ReportsCard, { roomId }),
            /* @__PURE__ */ jsx(TimezoneCard, { room: r }),
            /* @__PURE__ */ jsx(StopLossCard, { room: r }),
            /* @__PURE__ */ jsx(MarketTipsCard, { room: r })
          ] });
      }
    })(),
    /* @__PURE__ */ jsxs("div", { className: "fixed bottom-0 left-0 right-0 lg:left-[var(--sidebar-width,16rem)] bg-background/95 backdrop-blur border-t border-border p-4 flex justify-end gap-2 z-40", children: [
      /* @__PURE__ */ jsx(Button, { onClick: () => {
        window.dispatchEvent(new CustomEvent(SAVE_ALL_EVENT));
        toast.success("Salvando todas as seções...");
      }, children: "Salvar tudo" }),
      /* @__PURE__ */ jsx(Button, { variant: "outline", onClick: () => navigate({
        to: "/rooms"
      }), children: "Cancelar" })
    ] })
  ] });
}
function BaseConfigCard({
  room
}) {
  const qc = useQueryClient();
  const [accountId, setAccountId] = useState(room.default_account_id ?? "");
  const [premiumId, setPremiumId] = useState(room.premium_account_id ?? "");
  const [broker, setBroker] = useState(room.broker ?? "");
  const [chatId, setChatId] = useState(String(room.room_chats?.[0]?.chat_id ?? ""));
  const accounts = useQuery({
    queryKey: ["telegram-accounts"],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("telegram_accounts").select("id, label, account_type, bot_username, phone");
      return data ?? [];
    }
  });
  const bots = (accounts.data ?? []).filter((a) => a.account_type === "bot");
  const premiums = (accounts.data ?? []).filter((a) => a.account_type !== "bot");
  const save = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("rooms").update({
        default_account_id: accountId || null,
        premium_account_id: premiumId || null,
        broker: broker || null
      }).eq("id", room.id);
      if (error) throw error;
      if (chatId) {
        const existing = room.room_chats?.[0];
        if (existing) {
          await supabase.from("room_chats").update({
            chat_id: Number(chatId)
          }).eq("id", existing.id);
        } else {
          const {
            data: u
          } = await supabase.auth.getUser();
          await supabase.from("room_chats").insert({
            chat_id: Number(chatId),
            room_id: room.id,
            user_id: u.user.id
          });
        }
      }
    },
    onSuccess: () => {
      toast.success("Configurações base salvas");
      qc.invalidateQueries({
        queryKey: ["room", room.id]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Configurações Base" }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs font-medium", children: "Conta do Telegram (conta do bot)" }),
        /* @__PURE__ */ jsxs(Select, { value: accountId, onValueChange: setAccountId, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Escolha um bot" }) }),
          /* @__PURE__ */ jsx(SelectContent, { children: bots.map((a) => /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
            a.label,
            " ",
            a.bot_username ? `(@${a.bot_username})` : ""
          ] }, a.id)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs font-medium", children: "Conta Premium" }),
        /* @__PURE__ */ jsxs(Select, { value: premiumId, onValueChange: setPremiumId, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Escolha uma conta premium" }) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            premiums.length === 0 && /* @__PURE__ */ jsx(SelectItem, { value: "__none", disabled: true, children: "Nenhuma disponível" }),
            premiums.map((a) => /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
              a.label,
              " ",
              a.phone ? `(${a.phone})` : ""
            ] }, a.id))
          ] })
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Conta premium para envio rápido de mensagens. Será usada em conjunto com bot para botões." })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs font-medium", children: "Corretora" }),
        /* @__PURE__ */ jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsx(Input, { value: broker, onChange: (e) => setBroker(e.target.value), placeholder: "ex.: TitaniumBroker (titaniumbroker.io)" }),
          broker && /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setBroker(""), className: "absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground", children: /* @__PURE__ */ jsx(X, { className: "size-4" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs font-medium", children: "ID do Grupo" }),
        /* @__PURE__ */ jsx(Input, { value: chatId, onChange: (e) => setChatId(e.target.value), placeholder: "-1001234567890" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-3 p-4 rounded-md bg-blue-500/10 border border-blue-500/30", children: [
      /* @__PURE__ */ jsx(Info, { className: "size-5 text-blue-400 shrink-0 mt-0.5" }),
      /* @__PURE__ */ jsxs("div", { className: "text-sm space-y-1", children: [
        /* @__PURE__ */ jsx("p", { className: "font-semibold text-foreground", children: "💡 Sistema de Envio Híbrido" }),
        /* @__PURE__ */ jsxs("ul", { className: "list-disc list-inside space-y-0.5 text-muted-foreground", children: [
          /* @__PURE__ */ jsxs("li", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Conta Premium:" }),
            " Envio rápido de mensagens (sem rate limits)"
          ] }),
          /* @__PURE__ */ jsxs("li", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Bot:" }),
            " Adição de botões inline (contas premium não suportam botões)"
          ] }),
          /* @__PURE__ */ jsxs("li", { children: [
            /* @__PURE__ */ jsx("span", { className: "font-medium text-foreground", children: "Resultado:" }),
            " Velocidade + Funcionalidade completa"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-2 border-t border-border", children: /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar seção" }) })
  ] });
}
function MessagesInfoCard() {
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-3", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Configurações de Mensagens" }),
    /* @__PURE__ */ jsxs("div", { className: "p-3 rounded-md bg-muted/40 text-sm space-y-1", children: [
      /* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Tipos de arquivos suportados:" }) }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground", children: "Imagens: JPG, JPEG, PNG, GIF" }),
      /* @__PURE__ */ jsx("p", { className: "text-muted-foreground", children: "Stickers: WEBP (sticker estático), TGS (sticker animado), WEBM (sticker de vídeo)" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "p-3 rounded-md bg-muted/40 text-sm space-y-1", children: [
      /* @__PURE__ */ jsxs("p", { children: [
        /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Tags HTML:" }),
        " ",
        /* @__PURE__ */ jsx("code", { className: "text-xs", children: '<b>negrito</b>, <i>itálico</i>, <u>sublinhado</u>, <s>tachado</s>, <a href="url">link</a>' })
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Macros para Template de Sinal:" }),
        " ",
        /* @__PURE__ */ jsx("code", { className: "text-xs", children: `{ATIVO}, {TIMEFRAME}, {DIRECAO}, {ENTRADA}, {ENTRADAGALE1}, {ENTRADAGALE2}` })
      ] })
    ] })
  ] });
}
function WindowsCard({
  roomId
}) {
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["room_windows", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("room_windows").select("*").eq("room_id", roomId).order("start_time", {
        ascending: true
      });
      if (error) throw error;
      return data;
    }
  });
  const create = useMutation({
    mutationFn: async () => {
      const {
        data: u
      } = await supabase.auth.getUser();
      const {
        error
      } = await supabase.from("room_windows").insert({
        room_id: roomId,
        user_id: u.user.id,
        name: `SESSÃO ${(/* @__PURE__ */ new Date()).toTimeString().slice(0, 5)}`,
        start_time: "09:00",
        end_time: "17:00",
        weekdays: [1, 2, 3, 4, 5],
        timeframes: ["M1"],
        signals_qty: 10,
        max_losses: 0,
        martingale: 2,
        signal_type: "message",
        use_all_assets: true,
        asset_filter: [],
        is_active: true
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Janela adicionada");
      qc.invalidateQueries({
        queryKey: ["room_windows", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Janelas de Operação" }),
      /* @__PURE__ */ jsxs(Button, { size: "sm", onClick: () => create.mutate(), disabled: create.isPending, children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-1" }),
        "Adicionar Janela"
      ] })
    ] }),
    list.isLoading && /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Carregando..." }),
    list.data?.length === 0 && /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground text-center py-8 border border-dashed rounded-md", children: 'Nenhuma janela cadastrada. Clique em "Adicionar Janela".' }),
    /* @__PURE__ */ jsx("div", { className: "space-y-4", children: list.data?.map((w) => /* @__PURE__ */ jsx(WindowItem, { window: w, roomId }, w.id)) })
  ] });
}
function WindowItem({
  window: w,
  roomId
}) {
  const qc = useQueryClient();
  const [name, setName] = useState(w.name);
  const [start, setStart] = useState(w.start_time.slice(0, 5));
  const [end, setEnd] = useState(w.end_time.slice(0, 5));
  const [signalsQty, setSignalsQty] = useState(String(w.signals_qty ?? 10));
  const [maxLosses, setMaxLosses] = useState(String(w.max_losses ?? 0));
  const [martingale, setMartingale] = useState(String(w.martingale ?? 2));
  const [signalType, setSignalType] = useState(w.signal_type ?? "message");
  const [timeframes, setTimeframes] = useState(w.timeframes ?? ["M1"]);
  const [days, setDays] = useState(w.weekdays ?? []);
  const [useAll, setUseAll] = useState(w.use_all_assets ?? true);
  const [filter, setFilter] = useState(w.asset_filter ?? []);
  const save = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("room_windows").update({
        name,
        start_time: start,
        end_time: end,
        signals_qty: parseInt(signalsQty, 10) || 0,
        max_losses: parseInt(maxLosses, 10) || 0,
        martingale: parseInt(martingale, 10) || 0,
        signal_type: signalType,
        timeframes,
        weekdays: days,
        use_all_assets: useAll,
        asset_filter: filter
      }).eq("id", w.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Janela salva");
      qc.invalidateQueries({
        queryKey: ["room_windows", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  const del = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("room_windows").delete().eq("id", w.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Janela removida");
      qc.invalidateQueries({
        queryKey: ["room_windows", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const runTest = useServerFn(testWindow);
  const test = useMutation({
    mutationFn: async () => runTest({
      data: {
        windowId: w.id
      }
    }),
    onSuccess: (r) => {
      if (r.ok) toast.success(`Sinal de teste enviado: ${r.asset} ${r.direction === "buy" ? "🟢" : "🔴"}`);
      else toast.error(r.errors?.[0] ?? "Falha ao enviar teste");
    },
    onError: (e) => toast.error(e.message)
  });
  function toggleArr(arr, item) {
    return arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item];
  }
  return /* @__PURE__ */ jsxs("div", { className: "border rounded-md p-4 space-y-4 bg-card/40", children: [
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 md:grid-cols-7 gap-3 items-end", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1 col-span-2 md:col-span-1", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Nome da Sessão" }),
        /* @__PURE__ */ jsx(Input, { value: name, onChange: (e) => setName(e.target.value), className: "h-9" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Início" }),
        /* @__PURE__ */ jsx(Input, { type: "time", value: start, onChange: (e) => setStart(e.target.value), className: "h-9 text-center" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Fim" }),
        /* @__PURE__ */ jsx(Input, { type: "time", value: end, onChange: (e) => setEnd(e.target.value), className: "h-9 text-center" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Qtd. Sinais" }),
        /* @__PURE__ */ jsx(Input, { value: signalsQty, onChange: (e) => setSignalsQty(e.target.value), className: "h-9", inputMode: "numeric" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Max Losses (Stop Loss)" }),
        /* @__PURE__ */ jsx(Input, { value: maxLosses, onChange: (e) => setMaxLosses(e.target.value), className: "h-9", inputMode: "numeric" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Martingale" }),
        /* @__PURE__ */ jsxs(Select, { value: martingale, onValueChange: setMartingale, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "h-9", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsx(SelectContent, { children: Array.from({
            length: 9
          }, (_, i) => String(i + 1)).map((n) => /* @__PURE__ */ jsx(SelectItem, { value: n, children: n }, n)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Tipo de Sinal" }),
          /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", className: "h-6 w-6", onClick: () => del.mutate(), disabled: del.isPending, children: /* @__PURE__ */ jsx(Trash2, { className: "size-3.5 text-destructive" }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 h-9", children: [
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-1 text-xs cursor-pointer", children: [
            /* @__PURE__ */ jsx("input", { type: "radio", checked: signalType === "message", onChange: () => setSignalType("message") }),
            "Mensagem"
          ] }),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-1 text-xs cursor-pointer", children: [
            /* @__PURE__ */ jsx("input", { type: "radio", checked: signalType === "list", onChange: () => setSignalType("list") }),
            "Lista"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Timeframes" }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-3", children: TIMEFRAMES.map((tf) => /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-1.5 text-sm cursor-pointer", children: [
        /* @__PURE__ */ jsx(Checkbox, { checked: timeframes.includes(tf), onCheckedChange: () => setTimeframes((p) => toggleArr(p, tf)) }),
        tf
      ] }, tf)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Dias da Semana" }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-3", children: WEEKDAYS.map((d) => /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-1.5 text-sm cursor-pointer", children: [
        /* @__PURE__ */ jsx(Checkbox, { checked: days.includes(d.v), onCheckedChange: () => setDays((p) => toggleArr(p, d.v).sort()) }),
        d.l,
        "."
      ] }, d.v)) })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer w-fit", children: [
      /* @__PURE__ */ jsx(Checkbox, { checked: useAll, onCheckedChange: (v) => setUseAll(!!v) }),
      "Usar Todos os Ativos"
    ] }),
    /* @__PURE__ */ jsx(WindowAssets, { selected: filter, setSelected: setFilter, roomId, windowId: w.id, useAll, setUseAll }),
    /* @__PURE__ */ jsxs("div", { className: "flex justify-end pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", className: "mr-2", onClick: () => test.mutate(), disabled: test.isPending, children: test.isPending ? "Enviando..." : "Testar sessão" }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar janela" })
    ] })
  ] });
}
function WindowAssets({
  selected,
  setSelected,
  roomId,
  windowId,
  useAll,
  setUseAll
}) {
  const [search, setSearch] = useState("");
  const [collapsed, setCollapsed] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [minPayoutOnly, setMinPayoutOnly] = useState(false);
  const qc = useQueryClient();
  const assets = useQuery({
    queryKey: ["room_assets", roomId],
    queryFn: async () => {
      const {
        data
      } = await supabase.from("room_assets").select("asset_code, payout, is_open").eq("room_id", roomId);
      const map = {};
      (data ?? []).forEach((a) => {
        map[a.asset_code] = {
          payout: Number(a.payout),
          is_open: a.is_open
        };
      });
      return map;
    }
  });
  const toggleOpen = useMutation({
    mutationFn: async (code) => {
      const {
        data: u
      } = await supabase.auth.getUser();
      const uid = u.user?.id;
      if (!uid) throw new Error("Sem sessão");
      const cat = Object.keys(ASSETS_CATALOG).find((c) => ASSETS_CATALOG[c].includes(code)) ?? "OTC";
      const current = assets.data?.[code];
      const nextOpen = !(current?.is_open ?? true);
      const {
        error
      } = await supabase.from("room_assets").upsert({
        user_id: uid,
        room_id: roomId,
        asset_code: code,
        category: cat,
        payout: current?.payout ?? DEFAULT_PAYOUT,
        is_open: nextOpen
      }, {
        onConflict: "room_id,asset_code"
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({
        queryKey: ["room_assets", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  function toggle(code) {
    if (useAll) {
      setUseAll(false);
      setSelected([code]);
      return;
    }
    setSelected(selected.includes(code) ? selected.filter((c) => c !== code) : [...selected, code]);
  }
  const totalSelected = useAll ? "todos" : `${selected.length} selecionado${selected.length === 1 ? "" : "s"}`;
  const getAssetState = (code) => {
    const meta = assets.data?.[code];
    return {
      meta,
      isOpen: meta?.is_open !== false,
      payout: meta?.payout ?? DEFAULT_PAYOUT
    };
  };
  const visibleAssetsByCategory = Object.keys(ASSETS_CATALOG).map((cat) => ({
    cat,
    assets: ASSETS_CATALOG[cat].filter((code) => {
      const {
        isOpen,
        payout
      } = getAssetState(code);
      const normalizedPayout = (payout > 1 ? payout - 1 : payout) * 100;
      const matchesSearch = code.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === "all" || statusFilter === "open" && isOpen || statusFilter === "closed" && !isOpen;
      const matchesPayout = !minPayoutOnly || normalizedPayout >= 70;
      return matchesSearch && matchesStatus && matchesPayout;
    })
  }));
  return /* @__PURE__ */ jsxs("div", { className: "space-y-3 border rounded-md p-3 bg-background/40", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 flex-wrap text-xs", children: [
        /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Ativos:" }),
        /* @__PURE__ */ jsx(Badge, { variant: "outline", className: "text-xs", children: totalSelected }),
        !collapsed && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setStatusFilter((current) => current === "open" ? "all" : "open"), className: statusFilter === "open" ? "h-6 rounded-full border border-emerald-500/40 bg-emerald-500/20 px-3 text-xs font-medium text-emerald-300 hover:bg-emerald-500/30" : "h-6 rounded-full border border-border px-3 text-xs font-medium text-muted-foreground hover:bg-muted/40", children: "Aberto" }),
          /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setStatusFilter((current) => current === "closed" ? "all" : "closed"), className: statusFilter === "closed" ? "h-6 rounded-full border border-emerald-500/40 bg-emerald-500/20 px-3 text-xs font-medium text-emerald-300 hover:bg-emerald-500/30" : "h-6 rounded-full border border-border px-3 text-xs font-medium text-muted-foreground hover:bg-muted/40", children: "Fechado" }),
          /* @__PURE__ */ jsx("button", { type: "button", onClick: () => setMinPayoutOnly((current) => !current), className: minPayoutOnly ? "h-6 rounded-full border border-emerald-600/40 bg-emerald-600/30 px-3 text-xs font-medium text-emerald-200 hover:bg-emerald-600/40" : "h-6 rounded-full border border-border px-3 text-xs font-medium text-muted-foreground hover:bg-muted/40", children: "≥ 70%" })
        ] })
      ] }),
      /* @__PURE__ */ jsx(Button, { type: "button", variant: "ghost", size: "sm", className: "h-7 px-2 text-xs", onClick: () => setCollapsed((c) => !c), children: collapsed ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(ChevronDown, { className: "size-3.5 mr-1" }),
        "Mostrar ativos"
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(ChevronUp, { className: "size-3.5 mr-1" }),
        "Esconder ativos"
      ] }) })
    ] }),
    !collapsed && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(Input, { placeholder: "Buscar ativo...", value: search, onChange: (e) => setSearch(e.target.value), className: "h-8 text-sm" }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: visibleAssetsByCategory.map(({
        cat,
        assets: categoryAssets
      }) => /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx("h4", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide", children: cat }),
        /* @__PURE__ */ jsx("div", { className: "space-y-1", children: categoryAssets.length === 0 ? /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground py-1", children: "Nenhum ativo" }) : categoryAssets.map((code) => {
          const {
            isOpen,
            payout
          } = getAssetState(code);
          const checked = selected.includes(code);
          return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
            /* @__PURE__ */ jsx(Checkbox, { checked: useAll ? false : checked, onCheckedChange: () => toggle(code) }),
            /* @__PURE__ */ jsx("span", { className: "flex-1 font-mono", children: code }),
            /* @__PURE__ */ jsx("button", { type: "button", onClick: () => toggleOpen.mutate(code), disabled: toggleOpen.isPending, title: "Clique para alternar Aberto/Fechado", className: !isOpen ? "relative z-10 h-6 min-w-14 cursor-pointer rounded border border-border px-2 text-[10px] font-medium text-muted-foreground hover:bg-muted/40 disabled:cursor-wait disabled:opacity-70" : "relative z-10 h-6 min-w-14 cursor-pointer rounded border border-emerald-500/40 bg-emerald-500/20 px-2 text-[10px] font-medium text-emerald-300 hover:bg-emerald-500/30 disabled:cursor-wait disabled:opacity-70", children: !isOpen ? "Fechado" : "Aberto" }),
            /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground tabular-nums w-10 text-right", children: `${((payout > 1 ? payout - 1 : payout) * 100).toFixed(0)}%` })
          ] }, code);
        }) })
      ] }, cat)) }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: '* Com "Usar Todos os Ativos" ligado, qualquer ativo é sorteado. Clique em um ativo para fixar a seleção manual.' })
    ] }),
    /* @__PURE__ */ jsx("input", { type: "hidden", value: windowId, readOnly: true })
  ] });
}
function TimezoneCard({
  room
}) {
  const qc = useQueryClient();
  const [tz, setTz] = useState(room.timezone);
  const save = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("rooms").update({
        timezone: tz
      }).eq("id", room.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Fuso salvo");
      qc.invalidateQueries({
        queryKey: ["room", room.id]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Fuso Horário" }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-md space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Selecione o Fuso Horário" }),
      /* @__PURE__ */ jsxs(Select, { value: tz, onValueChange: setTz, children: [
        /* @__PURE__ */ jsx(SelectTrigger, { children: /* @__PURE__ */ jsx(SelectValue, {}) }),
        /* @__PURE__ */ jsx(SelectContent, { children: TIMEZONES.map((t) => /* @__PURE__ */ jsx(SelectItem, { value: t.v, children: t.l }, t.v)) })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
        "Este fuso horário será usado para todos os horários da sala (sinais, sessões e mensagens agendadas). Os offsets UTC variam conforme horário de verão — configure os horários no horário ",
        /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "local" }),
        " do fuso escolhido."
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex justify-end pt-2 border-t border-border", children: /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: "Salvar seção" }) })
  ] });
}
function StopLossCard({
  room
}) {
  const qc = useQueryClient();
  const [msg, setMsg] = useState(room.stop_loss_message ?? "🔴 *STOP LOSS ATINGIDO* 🔴");
  const sendTest = useServerFn(sendRoomTest);
  const [testing, setTesting] = useState(false);
  const save = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("rooms").update({
        stop_loss_message: msg
      }).eq("id", room.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Mensagem de Stop Loss salva");
      qc.invalidateQueries({
        queryKey: ["room", room.id]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  const onTest = async () => {
    try {
      setTesting(true);
      await sendTest({
        data: {
          roomId: room.id,
          text: msg
        }
      });
      toast.success("Teste enviado");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  };
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-3", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Mensagem de Stop Loss" }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Mensagem enviada quando o stop loss for atingido" }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: msg, onChange: setMsg }) }),
      /* @__PURE__ */ jsx(Textarea, { value: msg, onChange: (e) => setMsg(e.target.value), rows: 3 }),
      /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Mensagem enviada ao grupo quando o stop loss for atingido. Deixe em branco para usar a mensagem padrão." })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: onTest, disabled: testing, children: [
        "📩 ",
        testing ? "Enviando..." : "Enviar teste"
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: "Salvar seção" })
    ] })
  ] });
}
function MarketTipsCard({
  room
}) {
  const qc = useQueryClient();
  const [enabled, setEnabled] = useState(room.market_tips_enabled ?? false);
  const [intervalH, setIntervalH] = useState(room.market_tips_interval_hours ?? 6);
  const [cats, setCats] = useState(Array.isArray(room.market_tips_categories) && room.market_tips_categories.length > 0 ? room.market_tips_categories : ["forex", "crypto"]);
  const sendTest = useServerFn(sendRoomTest);
  const [testing, setTesting] = useState(false);
  const save = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("rooms").update({
        market_tips_enabled: enabled,
        market_tips_interval_hours: intervalH,
        market_tips_categories: cats.length ? cats : ["forex", "crypto"]
      }).eq("id", room.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Dicas de Mercado salvas");
      qc.invalidateQueries({
        queryKey: ["room", room.id]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  const onTest = async () => {
    try {
      setTesting(true);
      await sendTest({
        data: {
          roomId: room.id,
          text: "📊 <b>Dica de Mercado (teste)</b>\nEsta é uma prévia. As próximas mensagens trarão manchetes reais de " + (cats.includes("forex") && cats.includes("crypto") ? "Forex e Crypto" : cats.includes("crypto") ? "Crypto" : "Forex") + ` a cada ${intervalH}h.`
        }
      });
      toast.success("Teste enviado");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  };
  const toggleCat = (c) => setCats((prev) => prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]);
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-3", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "📊 Dicas de Mercado" }),
      /* @__PURE__ */ jsx(Badge, { className: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40", children: "Forex / Crypto" })
    ] }),
    /* @__PURE__ */ jsxs("p", { className: "text-sm text-muted-foreground", children: [
      "Envia automaticamente as ",
      /* @__PURE__ */ jsx("span", { className: "font-semibold text-foreground", children: "últimas notícias e tendências" }),
      " do mercado financeiro para o grupo. Fontes em ",
      /* @__PURE__ */ jsx("span", { className: "font-semibold text-foreground", children: "português" }),
      " (Investing.com, InfoMoney, Cointelegraph, Livecoins). Cada disparo envia uma manchete inédita."
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer w-fit", children: [
      /* @__PURE__ */ jsx(Checkbox, { checked: enabled, onCheckedChange: (v) => setEnabled(!!v) }),
      /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Habilitar envio de dicas de mercado" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid sm:grid-cols-2 gap-4 pt-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx("label", { className: "text-sm font-medium", children: "Intervalo entre envios" }),
        /* @__PURE__ */ jsxs("select", { className: "w-full h-9 rounded-md border border-input bg-background px-2 text-sm", value: intervalH, onChange: (e) => setIntervalH(Number(e.target.value)), disabled: !enabled, children: [
          /* @__PURE__ */ jsx("option", { value: 1, children: "A cada 1 hora" }),
          /* @__PURE__ */ jsx("option", { value: 2, children: "A cada 2 horas" }),
          /* @__PURE__ */ jsx("option", { value: 3, children: "A cada 3 horas" }),
          /* @__PURE__ */ jsx("option", { value: 4, children: "A cada 4 horas" }),
          /* @__PURE__ */ jsx("option", { value: 6, children: "A cada 6 horas" }),
          /* @__PURE__ */ jsx("option", { value: 8, children: "A cada 8 horas" }),
          /* @__PURE__ */ jsx("option", { value: 12, children: "A cada 12 horas" }),
          /* @__PURE__ */ jsx("option", { value: 24, children: "1 vez por dia" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx("label", { className: "text-sm font-medium", children: "Categorias" }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-3 pt-1", children: [
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsx(Checkbox, { checked: cats.includes("forex"), onCheckedChange: () => toggleCat("forex"), disabled: !enabled }),
            "💱 Forex"
          ] }),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
            /* @__PURE__ */ jsx(Checkbox, { checked: cats.includes("crypto"), onCheckedChange: () => toggleCat("crypto"), disabled: !enabled }),
            "🪙 Crypto"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: onTest, disabled: testing, children: [
        "📩 ",
        testing ? "Enviando..." : "Enviar teste"
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: "Salvar seção" })
    ] })
  ] });
}
const SIGNAL_PLACEHOLDERS = {
  message: "🎯 SINAL: {ATIVO}\n⏱ {TIMEFRAME}\n📈 {DIRECAO}\n💰 Entrada: {ENTRADA}\n🔁 Gale 1: {ENTRADAGALE1}\n🔁 Gale 2: {ENTRADAGALE2}",
  list: "📋 LISTA DE SINAIS\n{LISTA_SINAIS}\n\nGerenciamento: {MARTINGALE} martingale(s)"
};
const DEFAULT_GAIN_IMAGE = "_defaults/template-gain.png";
const DEFAULT_LOSS_IMAGE = "_defaults/template-loss.png";
const RESULT_TEMPLATES = [{
  kind: "win",
  title: "Vitória",
  placeholder: "✅ VITÓRIA no {ATIVO} 🟢",
  tone: "GAIN",
  defaultImagePath: DEFAULT_GAIN_IMAGE
}, {
  kind: "win_martingale",
  title: "Vitória Martingale",
  placeholder: "✅ VITÓRIA no martingale {ATIVO} 🟢",
  tone: "GAIN",
  defaultImagePath: DEFAULT_GAIN_IMAGE
}, {
  kind: "loss",
  title: "Derrota",
  placeholder: "🔴 DERROTA no {ATIVO}",
  tone: "LOSS",
  defaultImagePath: DEFAULT_LOSS_IMAGE
}, {
  kind: "gale",
  title: "Entrada Martingale",
  placeholder: "🔁 VAMOS PARA A {GALE_NUMERO}ª POSIÇÃO\n🌎 Ativo: {ATIVO}\n📊 Direção: {DIRECAO}\n⏰ Entrada: {ENTRADA}",
  tone: "GAIN"
}];
const DIRECTION_TEMPLATES = [{
  kind: "buy_direction",
  title: "Template de Compra",
  placeholder: "📈 COMPRA"
}, {
  kind: "sell_direction",
  title: "Template de Venda",
  placeholder: "📉 VENDA"
}];
function pickTemplate(list, kind) {
  return list?.find((x) => x.kind === kind);
}
function TemplatesCard({
  roomId
}) {
  const qc = useQueryClient();
  const tpls = useQuery({
    queryKey: ["room_templates", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("room_templates").select("*").eq("room_id", roomId);
      if (error) throw error;
      return data ?? [];
    }
  });
  const btns = useQuery({
    queryKey: ["room_template_buttons", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("room_template_buttons").select("*").eq("room_id", roomId).order("sort_order", {
        ascending: true
      });
      if (error) throw error;
      return data ?? [];
    }
  });
  const refresh = () => {
    qc.invalidateQueries({
      queryKey: ["room_templates", roomId]
    });
    qc.invalidateQueries({
      queryKey: ["room_template_buttons", roomId]
    });
  };
  const templates = tpls.data ?? [];
  const buttons = btns.data ?? [];
  const signalButtons = buttons.filter((b) => b.template_kind === "signal");
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-5", children: [
    /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Templates de Mensagem" }),
      /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
        "Use macros como ",
        /* @__PURE__ */ jsx("code", { children: `{ATIVO}, {TIMEFRAME}, {DIRECAO}, {ENTRADA}, {ENTRADAGALE1}, {ENTRADAGALE2}` }),
        "."
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Tabs, { defaultValue: "message", children: [
      /* @__PURE__ */ jsxs(TabsList, { className: "grid w-full max-w-sm grid-cols-2", children: [
        /* @__PURE__ */ jsx(TabsTrigger, { value: "message", children: "Mensagem" }),
        /* @__PURE__ */ jsx(TabsTrigger, { value: "list", children: "Lista" })
      ] }),
      ["message", "list"].map((tab) => /* @__PURE__ */ jsxs(TabsContent, { value: tab, className: "pt-4 space-y-5", children: [
        /* @__PURE__ */ jsx(TemplateEditor, { roomId, kind: "signal", title: "Template principal de Sinal", helper: tab === "message" ? "Formato enviado para cada sinal individual." : "Formato usado quando os sinais são enviados em lista.", placeholder: SIGNAL_PLACEHOLDERS[tab], existing: pickTemplate(templates, "signal"), buttons: signalButtons, showButtonManager: true, actionMode: "full", rows: 8, onChanged: refresh }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 xl:grid-cols-3 gap-4", children: RESULT_TEMPLATES.map((item) => /* @__PURE__ */ jsx(TemplateEditor, { roomId, kind: item.kind, title: item.title, placeholder: item.placeholder, existing: pickTemplate(templates, item.kind), buttons: [], actionMode: "test", showImageTools: true, imageTone: item.tone, defaultImagePath: item.defaultImagePath, rows: 4, onChanged: refresh }, item.kind)) }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: DIRECTION_TEMPLATES.map((item) => /* @__PURE__ */ jsx(TemplateEditor, { roomId, kind: item.kind, title: item.title, placeholder: item.placeholder, existing: pickTemplate(templates, item.kind), buttons: [], actionMode: "test", rows: 3, onChanged: refresh }, item.kind)) })
      ] }, tab))
    ] })
  ] });
}
function TemplateEditor({
  roomId,
  kind,
  title,
  helper,
  placeholder,
  existing,
  buttons,
  onChanged,
  showButtonManager = false,
  showImageTools = false,
  imageTone = "GAIN",
  actionMode = "none",
  rows = 5,
  defaultImagePath
}) {
  const [content, setContent] = useState(existing?.content ?? placeholder);
  const [imagePath, setImagePath] = useState(existing?.image_path ?? defaultImagePath ?? null);
  const [imageMime, setImageMime] = useState(existing?.image_mime ?? (defaultImagePath ? "image/png" : null));
  const [imageExt, setImageExt] = useState(existing?.image_ext ?? (defaultImagePath ? "png" : null));
  const [newLabel, setNewLabel] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const sendTest = useServerFn(sendRoomTest);
  const [testing, setTesting] = useState(false);
  useEffect(() => {
    setContent(existing?.content ?? placeholder);
    setImagePath(existing?.image_path ?? defaultImagePath ?? null);
    setImageMime(existing?.image_mime ?? (defaultImagePath ? "image/png" : null));
    setImageExt(existing?.image_ext ?? (defaultImagePath ? "png" : null));
  }, [existing?.id, existing?.content, existing?.image_path, existing?.image_mime, existing?.image_ext]);
  const saveTpl = useMutation({
    mutationFn: async () => {
      const {
        data: u
      } = await supabase.auth.getUser();
      if (existing) {
        const {
          error
        } = await supabase.from("room_templates").update({
          content,
          image_path: imagePath,
          image_mime: imageMime,
          image_ext: imageExt
        }).eq("id", existing.id);
        if (error) throw error;
      } else {
        const {
          error
        } = await supabase.from("room_templates").insert({
          room_id: roomId,
          user_id: u.user.id,
          kind,
          content,
          parse_mode: "HTML",
          image_path: imagePath,
          image_mime: imageMime,
          image_ext: imageExt
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success("Template salvo");
      onChanged();
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => saveTpl.mutate());
  const addBtn = useMutation({
    mutationFn: async () => {
      if (!newLabel.trim() || !newUrl.trim()) throw new Error("Preencha label e URL");
      const {
        data: u
      } = await supabase.auth.getUser();
      const {
        error
      } = await supabase.from("room_template_buttons").insert({
        room_id: roomId,
        user_id: u.user.id,
        template_kind: kind,
        label: newLabel.trim(),
        url: newUrl.trim(),
        sort_order: buttons.length
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewLabel("");
      setNewUrl("");
      toast.success("Botão adicionado");
      onChanged();
    },
    onError: (e) => toast.error(e.message)
  });
  const delBtn = useMutation({
    mutationFn: async (id) => {
      const {
        error
      } = await supabase.from("room_template_buttons").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Botão removido");
      onChanged();
    },
    onError: (e) => toast.error(e.message)
  });
  const onTest = async () => {
    try {
      setTesting(true);
      if (!content?.trim() && !imagePath) {
        toast.error("Adicione conteúdo ou imagem antes de testar");
        return;
      }
      await sendTest({
        data: {
          roomId,
          templateKind: kind,
          text: content,
          imagePath: imagePath ?? void 0,
          imageMime: imageMime ?? void 0,
          imageExt: imageExt ?? void 0
        }
      });
      toast.success("Teste enviado");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "border rounded-md p-4 space-y-4 bg-card/40", children: [
    (title || helper) && /* @__PURE__ */ jsxs("div", { className: "space-y-1", children: [
      title && /* @__PURE__ */ jsx("h3", { className: "text-sm font-semibold", children: title }),
      helper && /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: helper })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Conteúdo da mensagem" }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: content, onChange: setContent }) }),
      /* @__PURE__ */ jsx(Textarea, { value: content, onChange: (e) => setContent(e.target.value), placeholder, rows, className: "font-mono text-sm" })
    ] }),
    showImageTools && /* @__PURE__ */ jsx(ImageAttachment, { tone: imageTone, roomId, value: {
      path: imagePath,
      mime: imageMime,
      ext: imageExt
    }, onChange: (v) => {
      setImagePath(v.path);
      setImageMime(v.mime);
      setImageExt(v.ext);
    } }),
    kind === "gale" && /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Pré-visualização (placeholders preenchidos)" }),
      /* @__PURE__ */ jsx("div", { className: "rounded-md border bg-background/60 p-3 text-sm whitespace-pre-wrap font-mono", children: (content || placeholder).replaceAll("{GALE_NUMERO}", "1").replaceAll("{ATIVO}", "EURUSD").replaceAll("{DIRECAO}", "🟢 COMPRA").replaceAll("{ENTRADA}", "10:15").replaceAll("{TIMEFRAME}", "M1").replaceAll("{MARTINGALE}", "2") }),
      /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-muted-foreground", children: [
        "Exemplo com ",
        /* @__PURE__ */ jsx("code", { children: "{GALE_NUMERO}=1" }),
        ", ",
        /* @__PURE__ */ jsx("code", { children: "{ATIVO}=EURUSD" }),
        ",",
        " ",
        /* @__PURE__ */ jsx("code", { children: "{DIRECAO}=🟢 COMPRA" }),
        ", ",
        /* @__PURE__ */ jsx("code", { children: "{ENTRADA}=10:15" }),
        ". Esta mensagem é enviada automaticamente após um LOSS, antes de cada nova tentativa de martingale."
      ] })
    ] }),
    showButtonManager && /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Botões inline (opcional)" }),
      buttons.length === 0 && /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Nenhum botão configurado." }),
      buttons.map((b) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 p-2 rounded-md border bg-background/40", children: [
        /* @__PURE__ */ jsx("span", { className: "text-sm font-medium flex-1", children: b.label }),
        /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground truncate max-w-[40%]", children: b.url }),
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", className: "h-7 w-7", onClick: () => delBtn.mutate(b.id), disabled: delBtn.isPending, children: /* @__PURE__ */ jsx(Trash2, { className: "size-3.5 text-destructive" }) })
      ] }, b.id)),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2 items-center", children: [
        /* @__PURE__ */ jsx(Input, { className: "h-9", placeholder: "Texto do botão", value: newLabel, onChange: (e) => setNewLabel(e.target.value) }),
        /* @__PURE__ */ jsx(Input, { className: "h-9", placeholder: "https://...", value: newUrl, onChange: (e) => setNewUrl(e.target.value) }),
        /* @__PURE__ */ jsxs(Button, { size: "sm", variant: "outline", onClick: () => addBtn.mutate(), disabled: addBtn.isPending, children: [
          /* @__PURE__ */ jsx(Plus, { className: "size-4 mr-1" }),
          "Adicionar"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
        actionMode === "full" && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", disabled: true, children: [
            /* @__PURE__ */ jsx(Smile, { className: "size-4 mr-1" }),
            "Emojis"
          ] }),
          /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", onClick: () => setContent(placeholder), children: [
            /* @__PURE__ */ jsx(RotateCcw, { className: "size-4 mr-1" }),
            "Restaurar"
          ] }),
          /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: onTest, disabled: testing, children: [
            /* @__PURE__ */ jsx(Send, { className: "size-4 mr-1" }),
            testing ? "Enviando..." : "Enviar teste"
          ] })
        ] }),
        actionMode === "test" && /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: onTest, disabled: testing, children: [
          /* @__PURE__ */ jsx(Send, { className: "size-4 mr-1" }),
          testing ? "Enviando..." : "Enviar teste"
        ] })
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => saveTpl.mutate(), disabled: saveTpl.isPending, children: saveTpl.isPending ? "Salvando..." : "Salvar template" })
    ] })
  ] });
}
function ImageAttachment({
  tone,
  roomId,
  value,
  onChange
}) {
  const [uploading, setUploading] = useState(false);
  const publicUrl = value.path ? supabase.storage.from("room-images").getPublicUrl(value.path).data.publicUrl : null;
  const handleUpload = async (file) => {
    try {
      setUploading(true);
      const {
        data: u
      } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Não autenticado");
      const ext = (file.name.split(".").pop() || "png").toLowerCase();
      const path = `${u.user.id}/${roomId}/templates/${crypto.randomUUID()}.${ext}`;
      const {
        error
      } = await supabase.storage.from("room-images").upload(path, file, {
        upsert: true,
        contentType: file.type
      });
      if (error) throw error;
      onChange({
        path,
        mime: file.type || null,
        ext
      });
      toast.success("Imagem enviada");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Imagem" }),
    /* @__PURE__ */ jsxs("div", { className: "rounded-md border border-dashed bg-background/50 p-3 space-y-3", children: [
      /* @__PURE__ */ jsx("div", { className: "min-h-24 rounded-md bg-muted/50 flex flex-col items-center justify-center text-muted-foreground overflow-hidden", children: publicUrl ? /* @__PURE__ */ jsx("img", { src: publicUrl, alt: `Preview ${tone}`, className: "max-h-48 w-auto object-contain" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(ImageIcon, { className: "size-6 mb-1" }),
        /* @__PURE__ */ jsxs("span", { className: "text-xs font-semibold", children: [
          "Preview ",
          tone
        ] })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2 justify-end", children: [
        /* @__PURE__ */ jsx(Button, { variant: "outline", size: "sm", onClick: () => onChange({
          path: null,
          mime: null,
          ext: null
        }), disabled: !value.path || uploading, children: "Remover arquivo" }),
        /* @__PURE__ */ jsx(Button, { asChild: true, size: "sm", variant: "secondary", disabled: uploading, children: /* @__PURE__ */ jsxs("label", { className: "cursor-pointer", children: [
          /* @__PURE__ */ jsx(Upload, { className: "size-4 mr-1" }),
          uploading ? "Enviando..." : "Escolher arquivo",
          /* @__PURE__ */ jsx("input", { type: "file", className: "sr-only", accept: "image/png,image/jpeg,image/gif,image/webp,application/x-tgsticker,video/webm,.tgs", onChange: (e) => {
            const f = e.target.files?.[0];
            if (f) handleUpload(f);
            e.target.value = "";
          } })
        ] }) })
      ] })
    ] })
  ] });
}
function SessionMessagesCard({
  roomId
}) {
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["room_session_messages", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("room_session_messages").select("*").eq("room_id", roomId);
      if (error) throw error;
      return data ?? [];
    }
  });
  const open = list.data?.find((m) => m.kind === "open");
  const close = list.data?.find((m) => m.kind === "close");
  const refresh = () => qc.invalidateQueries({
    queryKey: ["room_session_messages", roomId]
  });
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Mensagens de Sessão" }),
    /* @__PURE__ */ jsx("p", { className: "text-xs text-muted-foreground", children: "Mensagens automáticas enviadas antes da abertura e após o fechamento de cada janela de operação." }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsx(SessionMessageEditor, { roomId, kind: "open", title: "Abertura de Sessão", existing: open, onChanged: refresh }),
      /* @__PURE__ */ jsx(SessionMessageEditor, { roomId, kind: "close", title: "Fechamento de Sessão", existing: close, onChanged: refresh })
    ] })
  ] });
}
function SessionMessageEditor({
  roomId,
  kind,
  title,
  existing,
  onChanged
}) {
  const defaultContent = kind === "open" ? "🚀 SESSÃO COMEÇA EM {MINUTOS} MIN!\nPrepare-se para os sinais!" : "🏁 SESSÃO ENCERRADA\nObrigado por operar conosco!";
  const [content, setContent] = useState(existing?.content ?? defaultContent);
  const [enabled, setEnabled] = useState(existing?.enabled ?? true);
  const [lead, setLead] = useState(String(existing?.lead_minutes ?? 5));
  const [imagePath, setImagePath] = useState(existing?.image_path ?? null);
  const [imageMime, setImageMime] = useState(existing?.image_mime ?? null);
  const [imageExt, setImageExt] = useState(existing?.image_ext ?? null);
  const sendTest = useServerFn(sendRoomTest);
  const [testing, setTesting] = useState(false);
  useEffect(() => {
    setContent(existing?.content ?? defaultContent);
    setEnabled(existing?.enabled ?? true);
    setLead(String(existing?.lead_minutes ?? 5));
    setImagePath(existing?.image_path ?? null);
    setImageMime(existing?.image_mime ?? null);
    setImageExt(existing?.image_ext ?? null);
  }, [existing?.id, existing?.content, existing?.enabled, existing?.lead_minutes, existing?.image_path, existing?.image_mime, existing?.image_ext]);
  const save = useMutation({
    mutationFn: async () => {
      const {
        data: u
      } = await supabase.auth.getUser();
      const payload = {
        content,
        enabled,
        lead_minutes: parseInt(lead, 10) || 0,
        image_path: imagePath,
        image_mime: imageMime,
        image_ext: imageExt
      };
      if (existing) {
        const {
          error
        } = await supabase.from("room_session_messages").update(payload).eq("id", existing.id);
        if (error) throw error;
      } else {
        const {
          error
        } = await supabase.from("room_session_messages").insert({
          ...payload,
          room_id: roomId,
          user_id: u.user.id,
          kind
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(`${title} salva`);
      onChanged();
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  const onTest = async () => {
    try {
      setTesting(true);
      if (!content?.trim() && !imagePath) {
        toast.error("Adicione conteúdo ou imagem antes de testar");
        return;
      }
      await sendTest({
        data: {
          roomId,
          text: content,
          imagePath: imagePath ?? void 0,
          imageMime: imageMime ?? void 0,
          imageExt: imageExt ?? void 0
        }
      });
      toast.success("Teste enviado");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "border rounded-md p-4 space-y-3 bg-card/40", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-sm font-semibold", children: title }),
      /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer", children: [
        /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled }),
        /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: enabled ? "Ativa" : "Desativada" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: kind === "open" ? "Minutos antes da abertura" : "Minutos após o fechamento" }),
      /* @__PURE__ */ jsx(Input, { value: lead, onChange: (e) => setLead(e.target.value), className: "h-9 max-w-[140px]", inputMode: "numeric" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Conteúdo" }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: content, onChange: setContent }) }),
      /* @__PURE__ */ jsx(Textarea, { value: content, onChange: (e) => setContent(e.target.value), rows: 5, className: "font-mono text-sm", placeholder: kind === "open" ? "🚀 SESSÃO COMEÇA EM {MINUTOS} MIN!\nPrepare-se para os sinais!" : "🏁 SESSÃO ENCERRADA\nObrigado por operar conosco!" })
    ] }),
    /* @__PURE__ */ jsx(ImageAttachment, { tone: kind === "open" ? "INÍCIO" : "TÉRMINO", roomId, value: {
      path: imagePath,
      mime: imageMime,
      ext: imageExt
    }, onChange: (v) => {
      setImagePath(v.path);
      setImageMime(v.mime);
      setImageExt(v.ext);
    } }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3 pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: onTest, disabled: testing, children: [
        /* @__PURE__ */ jsx(Send, { className: "size-4 mr-1" }),
        testing ? "Enviando..." : "Enviar teste"
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar" })
    ] })
  ] });
}
function ReportsCard({
  roomId
}) {
  const qc = useQueryClient();
  const sendTest = useServerFn(sendRoomTest);
  const [testing, setTesting] = useState(false);
  const report = useQuery({
    queryKey: ["room_reports", roomId],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("room_reports").select("*").eq("room_id", roomId).maybeSingle();
      if (error) throw error;
      return data;
    }
  });
  const onTest = async () => {
    try {
      setTesting(true);
      const sampleList = ["13:36 LTCUSDT ✅", "13:41 ETHUSDT ✅", "13:49 LTCUSDT ✅", "13:53 BTCUSDT ✅", "13:59 ADAUSDT ✅", "14:05 ETHUSDT ❌", "14:13 LTCUSDT ✅"].join("\n");
      const sample = (tpl || "📊 RELATÓRIO {SESSAO_NOME}\n{OPERACOES_LISTA}\n\n✅ Wins: {TOTAL_WINS}\n🔴 Losses: {TOTAL_LOSSES}\n📈 Operações: {TOTAL_OPERACOES}\n🎯 Win rate: {WIN_RATE}%").replaceAll("{SESSAO_NOME}", "Sessão Teste").replaceAll("{TOTAL_WINS}", "7").replaceAll("{TOTAL_LOSSES}", "3").replaceAll("{TOTAL_OPERACOES}", "10").replaceAll("{WIN_RATE}", "70").replaceAll("{OPERACOES_LISTA}", sampleList);
      await sendTest({
        data: {
          roomId,
          text: sample,
          imagePath: imagePath ?? void 0,
          imageMime: imageMime ?? void 0,
          imageExt: imageExt ?? void 0
        }
      });
      toast.success("Teste enviado");
    } catch (e) {
      toast.error(e.message);
    } finally {
      setTesting(false);
    }
  };
  const [enabled, setEnabled] = useState(false);
  const [delay, setDelay] = useState("0");
  const REPORT_DEFAULT = "📊 RELATÓRIO {SESSAO_NOME}\n{OPERACOES_LISTA}\n\n✅ Wins: {TOTAL_WINS}\n🔴 Losses: {TOTAL_LOSSES}\n📈 Operações: {TOTAL_OPERACOES}\n🎯 Win rate: {WIN_RATE}%";
  const [tpl, setTpl] = useState(REPORT_DEFAULT);
  const [includeStats, setIncludeStats] = useState(true);
  const [imagePath, setImagePath] = useState(null);
  const [imageMime, setImageMime] = useState(null);
  const [imageExt, setImageExt] = useState(null);
  useEffect(() => {
    if (!report.data) return;
    setEnabled(report.data.enabled);
    setDelay(String(report.data.delay_minutes ?? 0));
    setTpl(report.data.template && report.data.template.trim().length > 0 ? report.data.template : REPORT_DEFAULT);
    setIncludeStats(report.data.include_stats ?? true);
    setImagePath(report.data.image_path ?? null);
    setImageMime(report.data.image_mime ?? null);
    setImageExt(report.data.image_ext ?? null);
  }, [report.data?.id, report.data?.enabled, report.data?.delay_minutes, report.data?.template, report.data?.include_stats, report.data?.image_path, report.data?.image_mime, report.data?.image_ext]);
  const save = useMutation({
    mutationFn: async () => {
      const {
        data: u
      } = await supabase.auth.getUser();
      const payload = {
        enabled,
        delay_minutes: parseInt(delay, 10) || 0,
        template: tpl,
        include_stats: includeStats,
        image_path: imagePath,
        image_mime: imageMime,
        image_ext: imageExt
      };
      if (report.data) {
        const {
          error
        } = await supabase.from("room_reports").update(payload).eq("id", report.data.id);
        if (error) throw error;
      } else {
        const {
          error
        } = await supabase.from("room_reports").insert({
          ...payload,
          room_id: roomId,
          user_id: u.user.id
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success("Relatório salvo");
      qc.invalidateQueries({
        queryKey: ["room_reports", roomId]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  useSaveAll(() => save.mutate());
  return /* @__PURE__ */ jsxs(Card, { className: "p-6 space-y-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Relatório de Fim de Sessão" }),
      /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer", children: [
        /* @__PURE__ */ jsx(Switch, { checked: enabled, onCheckedChange: setEnabled }),
        /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: enabled ? "Ativo" : "Desativado" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("p", { className: "text-xs text-muted-foreground", children: [
      "Envia um resumo automático ao final de cada janela de operação. Macros disponíveis: ",
      /* @__PURE__ */ jsx("code", { children: `{SESSAO_NOME}, {OPERACOES_LISTA}, {TOTAL_WINS}, {TOTAL_LOSSES}, {WIN_RATE}, {TOTAL_OPERACOES}` }),
      ".",
      " ",
      /* @__PURE__ */ jsx("code", { children: `{OPERACOES_LISTA}` }),
      " expande para cada operação no formato ",
      /* @__PURE__ */ jsx("code", { children: "HH:MM ATIVO ✅/❌" }),
      "."
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Delay após fechamento (minutos)" }),
        /* @__PURE__ */ jsx(Input, { value: delay, onChange: (e) => setDelay(e.target.value), className: "h-9", inputMode: "numeric" })
      ] }),
      /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer w-fit self-end", children: [
        /* @__PURE__ */ jsx(Checkbox, { checked: includeStats, onCheckedChange: (v) => setIncludeStats(!!v) }),
        /* @__PURE__ */ jsx("span", { className: "text-sm", children: "Incluir estatísticas (wins/losses/winrate)" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-xs", children: "Template do relatório" }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end -mb-1", children: /* @__PURE__ */ jsx(PremiumEmojiPicker, { value: tpl, onChange: setTpl }) }),
      /* @__PURE__ */ jsx(Textarea, { value: tpl, onChange: (e) => setTpl(e.target.value), rows: 8, className: "font-mono text-sm", placeholder: "📊 RELATÓRIO {SESSAO_NOME}\n{OPERACOES_LISTA}\n\n✅ Wins: {TOTAL_WINS}\n🔴 Losses: {TOTAL_LOSSES}\n📈 Operações: {TOTAL_OPERACOES}\n🎯 Win rate: {WIN_RATE}%" })
    ] }),
    /* @__PURE__ */ jsx(ImageAttachment, { tone: "RELATÓRIO", roomId, value: {
      path: imagePath,
      mime: imageMime,
      ext: imageExt
    }, onChange: (v) => {
      setImagePath(v.path);
      setImageMime(v.mime);
      setImageExt(v.ext);
    } }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-border", children: [
      /* @__PURE__ */ jsxs(Button, { variant: "secondary", size: "sm", onClick: onTest, disabled: testing, children: [
        "📩 ",
        testing ? "Enviando..." : "Enviar teste"
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => save.mutate(), disabled: save.isPending, children: save.isPending ? "Salvando..." : "Salvar seção" })
    ] })
  ] });
}
export {
  EditRoomPage as component
};
