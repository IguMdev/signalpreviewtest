import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate } from "@tanstack/react-router";
import { useEffect, useState, useMemo } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { s as supabase } from "./client-bD0og8Nx.js";
import { u as useAuth, s as syncPremiumEmojis, M as getPremiumEmojiThumbs, C as Card, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem, B as Button, I as Input, N as Switch, L as Label } from "./router-Cw6OHOsO.js";
import { g as getCachedEmojis, p as putCachedEmojis, a as PremiumEmojiMedia } from "./PremiumEmojiPicker-KRfbHKuL.js";
import { toast } from "sonner";
import { Home, ChevronRight, Sparkles, Play, Square, Search, Zap, Trash2, Save, Pencil } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import "@supabase/supabase-js";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "./engagement.functions-BnPQkoHV.js";
import "./server-Bg62lSXL.js";
import "node:async_hooks";
import "h3-v2";
import "@tanstack/router-core";
import "seroval";
import "@tanstack/history";
import "@tanstack/router-core/ssr/client";
import "@tanstack/router-core/ssr/server";
import "@tanstack/react-router/ssr/server";
import "zod";
import "./auth-middleware-76zZrGAr.js";
import "./createMiddleware-BvN2ghIY.js";
import "./client.server-CDheR9QG.js";
import "./telegram.server-CxWEOea-.js";
import "@radix-ui/react-dialog";
import "crypto";
import "./meta-capi.server-BrVcTWbs.js";
import "./registry.server-BHRe8HTK.js";
import "./forwarder.server-aBU8sP40.js";
import "./videos.functions-DCpzn6E3.js";
import "./premium-send.server-B6I-0YLO.js";
import "./signals.server-CxsfAlOW.js";
import "@radix-ui/react-label";
import "@radix-ui/react-popover";
import "@radix-ui/react-switch";
import "@radix-ui/react-select";
function PremiumEmojisGuard() {
  const {
    user
  } = useAuth();
  const navigate = useNavigate();
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["has-premium-account-guard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const {
        count
      } = await supabase.from("telegram_accounts").select("id", {
        count: "exact",
        head: true
      }).eq("account_type", "premium").eq("is_active", true).not("tg_session", "is", null);
      return (count ?? 0) > 0;
    }
  });
  useEffect(() => {
    if (data === false) navigate({
      to: "/telegram-accounts"
    });
  }, [data, navigate]);
  if (isLoading || data !== true) {
    return /* @__PURE__ */ jsx("div", { className: "min-h-[40vh] grid place-items-center text-sm text-muted-foreground", children: isLoading ? "Carregando..." : "Cadastre uma conta premium em Contas Telegram para acessar." });
  }
  return /* @__PURE__ */ jsx(PremiumEmojisPage, {});
}
function EmojiPreview({
  item,
  animate
}) {
  return /* @__PURE__ */ jsx(PremiumEmojiMedia, { cached: item.thumb_data_url ? {
    custom_emoji_id: "",
    preview_char: item.preview_char,
    thumb_data_url: item.thumb_data_url,
    thumb_mime: item.thumb_mime,
    cached_at: 0
  } : void 0, fallback: item.preview_char, className: "size-12", animate });
}
function PremiumEmojisPage() {
  useAuth();
  const qc = useQueryClient();
  const [accountId, setAccountId] = useState("");
  const [capturing, setCapturing] = useState(false);
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");
  const [editEmojiId, setEditEmojiId] = useState("");
  const [captureStartedAt, setCaptureStartedAt] = useState(null);
  const [captured, setCaptured] = useState([]);
  const [animate, setAnimate] = useState(() => {
    if (typeof window === "undefined") return true;
    return localStorage.getItem("emoji-animate") !== "false";
  });
  const [savedThumbs, setSavedThumbs] = useState(/* @__PURE__ */ new Map());
  const syncEmojis = useServerFn(syncPremiumEmojis);
  const fetchThumbs = useServerFn(getPremiumEmojiThumbs);
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("emoji-animate", animate ? "true" : "false");
    }
  }, [animate]);
  const accounts = useQuery({
    queryKey: ["telegram-accounts", "premium"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("telegram_accounts").select("id, label, phone").eq("account_type", "premium");
      if (error) throw error;
      return data;
    }
  });
  const list = useQuery({
    queryKey: ["emojis"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("premium_emojis").select("*").order("created_at", {
        ascending: false
      });
      if (error) throw error;
      return data;
    }
  });
  useEffect(() => {
    if (!list.data?.length) return;
    const ids = list.data.map((e) => e.custom_emoji_id);
    getCachedEmojis(ids).then(async (cached) => {
      setSavedThumbs(cached);
      const missing = ids.filter((id) => {
        const item = cached.get(id);
        return !item?.thumb_data_url || item.thumb_mime === "application/x-tgsticker";
      });
      if (!missing.length) return;
      const previewById = new Map(list.data.map((e) => [e.custom_emoji_id, e.preview_char]));
      for (let i = 0; i < missing.length; i += 24) {
        const fresh = await fetchThumbs({
          data: {
            ids: missing.slice(i, i + 24)
          }
        }).catch(() => null);
        if (!fresh?.ok || !fresh.items.length) continue;
        await putCachedEmojis(fresh.items.map((it) => ({
          custom_emoji_id: it.custom_emoji_id,
          preview_char: previewById.get(it.custom_emoji_id) ?? null,
          thumb_data_url: it.thumb_data_url,
          thumb_mime: it.thumb_mime
        })));
        setSavedThumbs((prev) => new Map([...prev, ...fresh.items.map((it) => [it.custom_emoji_id, {
          ...it,
          preview_char: previewById.get(it.custom_emoji_id) ?? null,
          cached_at: Date.now()
        }])]));
      }
    });
  }, [list.data, fetchThumbs]);
  const updateMut = useMutation({
    mutationFn: async () => {
      const {
        error
      } = await supabase.from("premium_emojis").update({
        name: editName,
        custom_emoji_id: editEmojiId
      }).eq("id", editingId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Emoji atualizado");
      setEditingId(null);
      qc.invalidateQueries({
        queryKey: ["emojis"]
      });
    },
    onError: (e) => toast.error(e.message)
  });
  const delMut = useMutation({
    mutationFn: async (id) => {
      const {
        error
      } = await supabase.from("premium_emojis").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Emoji removido");
      qc.invalidateQueries({
        queryKey: ["emojis"]
      });
    }
  });
  const mergeFresh = (items) => {
    void putCachedEmojis(items.map((it) => ({
      custom_emoji_id: it.custom_emoji_id,
      preview_char: it.preview_char,
      thumb_data_url: it.thumb_data_url ?? null,
      thumb_mime: it.thumb_mime ?? null
    })));
    setCaptured((prev) => {
      const seen = new Set(prev.map((p) => p.custom_emoji_id));
      const merged = [...prev];
      for (const it of items) {
        if (!seen.has(it.custom_emoji_id)) {
          merged.push({
            custom_emoji_id: it.custom_emoji_id,
            preview_char: it.preview_char,
            thumb_data_url: it.thumb_data_url ?? null,
            thumb_mime: it.thumb_mime ?? null,
            name: ""
          });
        }
      }
      return merged;
    });
  };
  const syncMut = useMutation({
    mutationFn: async () => {
      if (!accountId) throw new Error("Selecione uma conta premium");
      return syncEmojis({
        data: {
          accountId,
          since: captureStartedAt ?? void 0
        }
      });
    },
    onSuccess: (r) => {
      if (r.items?.length) {
        mergeFresh(r.items);
        toast.success(`${r.items.length} novos emojis capturados`);
      }
    },
    onError: (e) => toast.error(e.message)
  });
  useEffect(() => {
    if (!capturing || !accountId) return;
    const timer = window.setInterval(() => {
      if (!syncMut.isPending) syncMut.mutate();
    }, 8e3);
    return () => window.clearInterval(timer);
  }, [capturing, accountId, syncMut.isPending]);
  const saveCaptured = async (item) => {
    if (!item.name.trim()) {
      toast.error("Defina uma nomenclatura");
      return;
    }
    const {
      data: userRes
    } = await supabase.auth.getUser();
    const uid = userRes.user?.id;
    if (!uid) return toast.error("Sessão inválida");
    const {
      error
    } = await supabase.from("premium_emojis").insert({
      user_id: uid,
      name: item.name.trim().toUpperCase(),
      custom_emoji_id: item.custom_emoji_id,
      preview_char: item.preview_char
    });
    if (error) return toast.error(error.message);
    toast.success("Emoji salvo");
    setCaptured((prev) => prev.filter((c) => c.custom_emoji_id !== item.custom_emoji_id));
    qc.invalidateQueries({
      queryKey: ["emojis"]
    });
  };
  const filtered = useMemo(() => {
    if (!list.data) return [];
    const q = search.toLowerCase().trim();
    if (!q) return list.data;
    return list.data.filter((e) => e.name.toLowerCase().includes(q));
  }, [list.data, search]);
  const startEdit = (e) => {
    setEditingId(e.id);
    setEditName(e.name);
    setEditEmojiId(e.custom_emoji_id);
  };
  const startCapture = () => {
    if (!accountId) {
      toast.error("Selecione uma conta premium");
      return;
    }
    const startedAt = (/* @__PURE__ */ new Date()).toISOString();
    setCaptureStartedAt(startedAt);
    setCapturing(true);
    syncEmojis({
      data: {
        accountId,
        since: startedAt
      }
    }).then((r) => {
      if (r.items?.length) {
        mergeFresh(r.items);
        toast.success(`${r.items.length} novos emojis capturados`);
      }
    }).catch((e) => toast.error(e.message));
    toast.info("Captura iniciada. Envie emojis premium na conta selecionada.");
  };
  const stopCapture = () => {
    setCapturing(false);
    setCaptureStartedAt(null);
    toast.success("Captura parada");
  };
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsx(Home, { className: "size-4" }),
      /* @__PURE__ */ jsx("span", { children: "Trading" }),
      /* @__PURE__ */ jsx(ChevronRight, { className: "size-4" }),
      /* @__PURE__ */ jsx(Sparkles, { className: "size-4 text-amber-400" }),
      /* @__PURE__ */ jsx("span", { children: "Emojis Premium" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "border-b border-border pb-6", children: [
      /* @__PURE__ */ jsxs("h1", { className: "text-3xl font-bold tracking-tight flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Sparkles, { className: "size-7 text-amber-400" }),
        "Emojis Premium"
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground mt-1", children: "Capture, nomeie e gerencie seus emojis premium do Telegram" })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-4 mb-5", children: [
        /* @__PURE__ */ jsx("div", { className: "size-11 rounded-lg bg-gradient-to-br from-fuchsia-500 to-purple-600 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsx(Sparkles, { className: "size-5 text-white" }) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Captura Automática de Emojis" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Selecione uma conta premium e envie emojis nela — eles aparecerão abaixo para você nomear." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx("label", { className: "text-sm font-medium", children: "Conta Premium do Telegram" }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxs(Select, { value: accountId, onValueChange: setAccountId, disabled: capturing, children: [
            /* @__PURE__ */ jsx(SelectTrigger, { className: "flex-1", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: "Selecione uma conta premium..." }) }),
            /* @__PURE__ */ jsxs(SelectContent, { children: [
              accounts.data?.length === 0 && /* @__PURE__ */ jsx("div", { className: "px-2 py-1.5 text-sm text-muted-foreground", children: "Nenhuma conta premium cadastrada" }),
              accounts.data?.map((a) => /* @__PURE__ */ jsxs(SelectItem, { value: a.id, children: [
                a.label,
                " ",
                a.phone ? `(${a.phone})` : ""
              ] }, a.id))
            ] })
          ] }),
          /* @__PURE__ */ jsxs(Button, { onClick: startCapture, disabled: capturing || syncMut.isPending, className: "gap-2", children: [
            /* @__PURE__ */ jsx(Play, { className: "size-4" }),
            syncMut.isPending ? "Sincronizando" : "Iniciar Captura"
          ] }),
          /* @__PURE__ */ jsxs(Button, { onClick: stopCapture, disabled: !capturing, variant: "secondary", className: "gap-2", children: [
            /* @__PURE__ */ jsx(Square, { className: "size-4" }),
            "Parar Captura"
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative", children: [
      /* @__PURE__ */ jsx(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" }),
      /* @__PURE__ */ jsx(Input, { placeholder: "Buscar por nomenclatura...", value: search, onChange: (e) => setSearch(e.target.value), className: "pl-9" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-2", children: [
      /* @__PURE__ */ jsx(Switch, { id: "animate-toggle", checked: animate, onCheckedChange: setAnimate }),
      /* @__PURE__ */ jsx(Label, { htmlFor: "animate-toggle", className: "text-sm cursor-pointer", children: animate ? "Animado" : "Estático" })
    ] }),
    captured.length > 0 && /* @__PURE__ */ jsxs(Card, { className: "p-6", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-4", children: [
        /* @__PURE__ */ jsxs("h2", { className: "text-lg font-semibold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Zap, { className: "size-5 text-amber-400" }),
          "Emojis Capturados",
          /* @__PURE__ */ jsxs("span", { className: "text-sm font-normal text-muted-foreground", children: [
            "(",
            captured.length,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxs(Button, { variant: "destructive", size: "sm", className: "gap-2", onClick: () => setCaptured([]), children: [
          /* @__PURE__ */ jsx(Trash2, { className: "size-4" }),
          "Limpar Capturas"
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: captured.map((item) => /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-border bg-muted/20 p-5 flex flex-col items-center gap-3", children: [
        /* @__PURE__ */ jsx(EmojiPreview, { item, animate }),
        /* @__PURE__ */ jsxs("div", { className: "text-xs text-muted-foreground break-all text-center", children: [
          "ID: ",
          item.custom_emoji_id
        ] }),
        /* @__PURE__ */ jsx(Input, { placeholder: "NOMENCLATURA (ex: APERTOMAO)", value: item.name, onChange: (e) => setCaptured((prev) => prev.map((c) => c.custom_emoji_id === item.custom_emoji_id ? {
          ...c,
          name: e.target.value
        } : c)), className: "text-center font-mono uppercase" }),
        /* @__PURE__ */ jsxs(Button, { className: "w-full gap-2 bg-emerald-600 hover:bg-emerald-700 text-white", onClick: () => saveCaptured(item), children: [
          /* @__PURE__ */ jsx(Save, { className: "size-4" }),
          "Salvar"
        ] })
      ] }, item.custom_emoji_id)) })
    ] }),
    /* @__PURE__ */ jsxs(Card, { className: "overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[100px_1fr_2fr_180px_100px] gap-4 px-6 py-3 border-b border-border bg-muted/30 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsx("div", { children: "Emoji" }),
        /* @__PURE__ */ jsx("div", { children: "Nomenclatura" }),
        /* @__PURE__ */ jsx("div", { children: "ID Telegram" }),
        /* @__PURE__ */ jsx("div", { children: "Criado" }),
        /* @__PURE__ */ jsx("div", { className: "text-right", children: "Ações" })
      ] }),
      filtered.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "p-12 text-center text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsx(Sparkles, { className: "size-8 mx-auto mb-2 opacity-40" }),
        "Nenhum emoji salvo."
      ] }) : filtered.map((e) => /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[100px_1fr_2fr_180px_100px] gap-4 px-6 py-3 border-b border-border last:border-0 items-center hover:bg-muted/20", children: [
        /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center size-12", children: /* @__PURE__ */ jsx(EmojiPreview, { item: {
          preview_char: e.preview_char,
          thumb_data_url: savedThumbs.get(e.custom_emoji_id)?.thumb_data_url ?? null,
          thumb_mime: savedThumbs.get(e.custom_emoji_id)?.thumb_mime ?? null
        }, animate }) }),
        /* @__PURE__ */ jsx("div", { children: editingId === e.id ? /* @__PURE__ */ jsx(Input, { value: editName, onChange: (ev) => setEditName(ev.target.value), className: "h-8" }) : /* @__PURE__ */ jsx("code", { className: "px-2 py-1 rounded bg-muted/50 text-sm font-mono", children: `{${e.name}}` }) }),
        /* @__PURE__ */ jsx("div", { children: editingId === e.id ? /* @__PURE__ */ jsx(Input, { value: editEmojiId, onChange: (ev) => setEditEmojiId(ev.target.value), className: "h-8 font-mono text-sm" }) : /* @__PURE__ */ jsx("code", { className: "block px-3 py-1.5 rounded bg-muted/50 text-sm font-mono truncate", children: e.custom_emoji_id }) }),
        /* @__PURE__ */ jsx("div", { className: "text-sm text-muted-foreground", children: formatDistanceToNow(new Date(e.created_at), {
          addSuffix: true,
          locale: ptBR
        }) }),
        /* @__PURE__ */ jsx("div", { className: "flex justify-end gap-1", children: editingId === e.id ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(Button, { size: "sm", onClick: () => updateMut.mutate(), children: "Salvar" }),
          /* @__PURE__ */ jsx(Button, { size: "sm", variant: "ghost", onClick: () => setEditingId(null), children: "✕" })
        ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => startEdit(e), children: /* @__PURE__ */ jsx(Pencil, { className: "size-4 text-blue-400" }) }),
          /* @__PURE__ */ jsx(Button, { size: "icon", variant: "ghost", onClick: () => delMut.mutate(e.id), children: /* @__PURE__ */ jsx(Trash2, { className: "size-4 text-destructive" }) })
        ] }) })
      ] }, e.id))
    ] })
  ] });
}
export {
  PremiumEmojisGuard as component
};
