import { c as createSsrRpc } from "./engagement.functions-BnPQkoHV.js";
import { z } from "zod";
import { r as requireSupabaseAuth } from "./auth-middleware-76zZrGAr.js";
import { c as createServerFn } from "./server-Bg62lSXL.js";
const enableMemberTracking = createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("73562d24cd31fbd26f4cab24ac3b6e132c58ee857d20f8bbae7d26c33088d38a"));
createServerFn({
  method: "POST"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  accountId: z.string().uuid()
}).parse(d)).handler(createSsrRpc("466f3e9f548b02e4b45cb9628872cce1539e03478760d01fe3a29070c2fc5b91"));
const getMemberStats = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).inputValidator((d) => z.object({
  from: z.string().optional(),
  to: z.string().optional()
}).optional().parse(d ?? {})).handler(createSsrRpc("6d56c54f8361e3f4a856af7bdd3239d6c8196c320aec96e6194653ea5841d2f9"));
const getCurrentMemberCounts = createServerFn({
  method: "GET"
}).middleware([requireSupabaseAuth]).handler(createSsrRpc("636af64b9c4b9e724ed8981b4acc7661c7099eb373fab9234898005009f700e0"));
export {
  getCurrentMemberCounts as a,
  enableMemberTracking as e,
  getMemberStats as g
};
