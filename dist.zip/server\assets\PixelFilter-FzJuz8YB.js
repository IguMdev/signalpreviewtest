import { jsxs, jsx } from "react/jsx-runtime";
import { useNavigate, useSearch, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { u as useServerFn } from "./useServerFn-DL2oePlL.js";
import { a as listPixels } from "./tracking.functions-jGKb0ig9.js";
import { B as Button, L as Label, S as Select, b as SelectTrigger, d as SelectValue, e as SelectContent, f as SelectItem } from "./router-Cw6OHOsO.js";
import { Plus } from "lucide-react";
function usePixelFilter() {
  const navigate = useNavigate();
  const search = useSearch({ strict: false });
  const listFn = useServerFn(listPixels);
  const q = useQuery({ queryKey: ["tracking-pixels"], queryFn: () => listFn() });
  const pixels = q.data ?? [];
  const currentId = search.pixel ?? null;
  return {
    pixelId: currentId,
    pixels,
    isLoading: q.isLoading,
    setPixel: (id) => {
      navigate({
        to: ".",
        search: (prev) => ({ ...prev, pixel: id ?? void 0 }),
        replace: true
      });
    }
  };
}
function PixelFilterBar({
  pixelId,
  pixels,
  setPixel,
  allowAll = false
}) {
  if (pixels.length === 0) {
    return /* @__PURE__ */ jsxs("div", { className: "rounded-xl border border-dashed p-6 text-center space-y-3", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: "Você ainda não criou nenhum pixel." }),
      /* @__PURE__ */ jsx(Link, { to: "/trackeamento/pixels", children: /* @__PURE__ */ jsxs(Button, { size: "sm", children: [
        /* @__PURE__ */ jsx(Plus, { className: "size-4" }),
        " Criar pixel"
      ] }) })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [
    /* @__PURE__ */ jsx(Label, { className: "text-sm", children: "Pixel:" }),
    /* @__PURE__ */ jsxs(
      Select,
      {
        value: pixelId ?? (allowAll ? "all" : pixels[0]?.id ?? ""),
        onValueChange: (v) => setPixel(v === "all" ? null : v),
        children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-72", children: /* @__PURE__ */ jsx(SelectValue, {}) }),
          /* @__PURE__ */ jsxs(SelectContent, { children: [
            allowAll && /* @__PURE__ */ jsx(SelectItem, { value: "all", children: "Todos os pixels" }),
            pixels.map((p) => /* @__PURE__ */ jsxs(SelectItem, { value: p.id, children: [
              p.name,
              " ",
              p.bot_username ? `· @${p.bot_username}` : ""
            ] }, p.id))
          ] })
        ]
      }
    )
  ] });
}
export {
  PixelFilterBar as P,
  usePixelFilter as u
};
