# Migração Lovable Cloud → Supabase

Guia completo para migrar **schema + dados + auth (usuários e senhas) + storage + edge functions + cron jobs** de um projeto Lovable Cloud para um projeto Supabase próprio, sem perder nada.

---

## Como este repo está organizado

| Pasta | O que tem |
|---|---|
| [`01-lovable/`](01-lovable/) | O que o **Lovable** faz — gerar a edge function temporária que devolve as credenciais |
| [`02-manual/`](02-manual/) | O que **você faz manualmente** — painel Supabase, gerenciador de senhas, navegador |
| [`03-ide/`](03-ide/) | O que acontece **na IDE** (Cursor / VS Code) — clone, deps, env vars, rodar pipeline |
| [`scripts/`](scripts/) | Os **scripts em si** — pipeline read-only de 8 fases |

> 📁 Cada pasta tem um `README.md` interno explicando a etapa em detalhe.

---

## Sequência completa

| # | Onde | O quê | Detalhe |
|---|---|---|---|
| 1 | [`01-lovable/`](01-lovable/) | Conectar Lovable ao GitHub | manual no Lovable |
| 2 | [`01-lovable/`](01-lovable/) | Lovable cria edge function `temp-export-credentials` | colar o prompt |
| 3 | [`02-manual/`](02-manual/01-coletar-credenciais-origem.md) | Acessar `/export-credentials` e copiar o JSON | navegador |
| 4 | [`02-manual/`](02-manual/02-criar-projeto-destino.md) | Criar projeto destino + extensions | painel Supabase |
| 5 | [`02-manual/`](02-manual/03-pegar-pooler-urls.md) | Pegar Session Pooler URL dos dois projetos | painel Supabase |
| 6 | [`03-ide/`](03-ide/01-instalar-dependencias.md) | Cursor: clone + winget Git/Postgres17/Node + Supabase CLI | terminal |
| 7 | [`03-ide/`](03-ide/02-variaveis-ambiente.md) | Exportar 8 variáveis no Git Bash | terminal |
| 8 | [`03-ide/`](03-ide/03-executar-pipeline.md) | Rodar `00-precheck.sh` até `07-report.sh` | terminal |
| 9 | [`02-manual/`](02-manual/04-configurar-secrets-destino.md) | Replicar secrets das edge functions no destino | terminal + gerenciador de senhas |
| 10 | [`02-manual/`](02-manual/05-apontar-aplicacao.md) | Trocar URL/anon key da app pro destino | hosting / Lovable |
| 11 | [`02-manual/`](02-manual/06-limpeza-rotacao.md) | **CRÍTICO:** remover edge function temp + rotacionar service_role da origem | terminal + painel |

---

## Garantias

- **Nada é alterado na origem.** Toda a pipeline é `SELECT` ou `pg_dump --schema-only` / `--data-only`. Origem fica intocada.
- **Senhas dos usuários são preservadas.** A tabela `auth.users` é copiada inteira (com hash bcrypt) e UUIDs são mantidos — login no destino funciona com a mesma senha que funcionava na origem.
- **Idempotente.** Se uma fase falhar, conserta e roda de novo. (Excessão: rodar 02-auth e 03-data num destino que já tem linhas pode dar conflito de PK — limpa o destino antes.)

---

## Não está incluído

- Apontar webhooks externos (gateways de pagamento, providers etc.) — continuam na origem
- Apontar domínios customizados — DNS continua na origem
- Reconfigurar Auth providers (Google/Apple/etc.) — fazer manual no destino
- Reconfigurar templates de email custom no Auth — fazer manual no destino

Isso é intencional: você roda a pipeline, valida tudo no destino com a URL `<TARGET_PROJECT_REF>.supabase.co`, só **depois** "vira a chave" trocando webhook + DNS + variáveis da app.

---

## Por onde começar

Se ainda não fez nada → [`01-lovable/README.md`](01-lovable/README.md).

Se já tem a edge function rodando e o JSON copiado → [`02-manual/02-criar-projeto-destino.md`](02-manual/02-criar-projeto-destino.md).

Se já tem o destino criado e as duas pooler URLs → [`03-ide/01-instalar-dependencias.md`](03-ide/01-instalar-dependencias.md).

---

## Sobre este repositório

Este repo é **genérico e público**. Não contém credenciais, project refs, nomes de tabela específicos, nomes de secrets ou qualquer outra informação sensível.

Os scripts são parametrizados via variáveis de ambiente (`$SOURCE_*` / `$TARGET_*`). Você fornece os valores localmente — eles nunca vão pro Git.

Pull requests com correções, melhorias de troubleshooting ou suporte a outros casos de uso são bem-vindos.

## Licença

MIT. Use à vontade, sem garantias. Migrações de banco de dados são operações sensíveis — sempre faça um backup do destino antes de rodar a pipeline e teste primeiro num projeto descartável.
