#!/usr/bin/env bash
# Fase 1 — Schema. pg_dump --schema-only da origem (read-only) → aplica no destino.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs dumps
LOG="logs/01-schema-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Fase 1: Schema ==="
date

DUMP="dumps/schema-$(date +%Y%m%d-%H%M%S).sql"

echo "--- Dumping schema da origem (read-only) ---"
# --schema-only: só DDL
# --no-owner / --no-privileges: ignora ownership específico do projeto origem
# Schemas: public + storage (buckets/policies) — auth e outras gerenciadas são deixadas em paz
pg_dump "$SOURCE_DB_URL" \
  --schema-only \
  --no-owner \
  --no-privileges \
  --schema=public \
  -f "$DUMP"

echo "Dump gerado: $DUMP ($(wc -l < "$DUMP") linhas)"

echo ""
echo "--- Pós-processamento ---"
# Remove referências problemáticas: extension owners, comentários em objetos do sistema
PROCESSED="${DUMP%.sql}-processed.sql"
sed \
  -e '/^CREATE SCHEMA public/d' \
  -e '/^COMMENT ON SCHEMA public/d' \
  -e '/^CREATE SCHEMA storage/d' \
  -e '/^ALTER SCHEMA storage OWNER/d' \
  -e '/^CREATE SCHEMA auth/d' \
  -e '/^ALTER SCHEMA auth OWNER/d' \
  -e '/EXTENSION.*OWNER/d' \
  "$DUMP" > "$PROCESSED"

echo "Arquivo processado: $PROCESSED"

echo ""
echo "--- Aplicando schema no DESTINO ---"
echo "AVISO: o destino deve estar vazio ou com tabelas compatíveis."
echo "Pressione Ctrl+C nos próximos 5s para abortar..."
sleep 5

# ON_ERROR_STOP=1 para parar no primeiro erro
psql "$TARGET_DB_URL" \
  -v ON_ERROR_STOP=1 \
  --single-transaction \
  -f "$PROCESSED" 2>&1 | tee -a "$LOG"

echo ""
echo "--- Validação ---"
SRC_TABLES=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from information_schema.tables where table_schema='public'")
DST_TABLES=$(psql "$TARGET_DB_URL" -tAc "select count(*) from information_schema.tables where table_schema='public'")
SRC_FUNCS=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public'")
DST_FUNCS=$(psql "$TARGET_DB_URL" -tAc "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public'")

echo "Tabelas public — origem: $SRC_TABLES | destino: $DST_TABLES"
echo "Funções public — origem: $SRC_FUNCS | destino: $DST_FUNCS"

if [ "$SRC_TABLES" != "$DST_TABLES" ]; then
  echo "AVISO: contagem de tabelas diverge. Verifique o log."
fi

echo ""
echo "OK. Schema aplicado."
