-- Recriando os cron jobs com suporte a multi-linha e aspas seguras

SELECT cron.unschedule('dispatch-signals-every-minute');
SELECT cron.schedule('dispatch-signals-every-minute', '* * * * *', $$
  select net.http_post(
    url := 'https://signalpreviewtest.lovable.app/api/public/cron/dispatch-signals',
    headers := '{"Content-Type":"application/json","apikey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body := '{}'::jsonb
  );
$$);

SELECT cron.unschedule('dispatch-recurring-schedules');
SELECT cron.schedule('dispatch-recurring-schedules', '* * * * *', $$
  select net.http_post(
    url := 'https://signalpreviewtest.lovable.app/api/public/cron/dispatch-recurring',
    headers := '{"Content-Type":"application/json","apikey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body := '{}'::jsonb
  );
$$);

SELECT cron.unschedule('check-telegram-webhooks');
SELECT cron.schedule('check-telegram-webhooks', '*/5 * * * *', $$
  SELECT net.http_post(
    url:='https://signalpreviewtest.lovable.app/api/public/cron/check-telegram-webhooks',
    headers:='{"Content-Type": "application/json"}'::jsonb,
    body:='{}'::jsonb
  ) AS request_id;
$$);

SELECT cron.unschedule('check-premium-accounts');
SELECT cron.schedule('check-premium-accounts', '*/30 * * * *', $$
  select net.http_post(
    url:='https://signalpreviewtest.lovable.app/api/public/cron/check-premium-accounts',
    headers:='{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
$$);

SELECT cron.unschedule('dispatch-market-tips-every-minute');
SELECT cron.schedule('dispatch-market-tips-every-minute', '* * * * *', $$
  SELECT net.http_post(
    url := 'https://signalpreviewtest.lovable.app/api/public/cron/dispatch-market-tips',
    headers := '{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body := '{}'::jsonb
  ) as request_id;
$$);

SELECT cron.unschedule('dispatch-sessions-every-minute');
SELECT cron.schedule('dispatch-sessions-every-minute', '* * * * *', $$
  SELECT net.http_post(
    url := 'https://signalpreviewtest.lovable.app/api/public/cron/dispatch-sessions',
    headers := '{"Content-Type":"application/json","apikey":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body := '{}'::jsonb
  );
$$);

SELECT cron.unschedule('dispatch-followups-every-minute');
SELECT cron.schedule('dispatch-followups-every-minute', '* * * * *', $$
  select net.http_post(
    url:='https://signalpreviewtest.lovable.app/api/public/cron/dispatch-followups',
    headers:='{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
$$);

SELECT cron.unschedule('sync-engagement-orders-every-5min');
SELECT cron.schedule('sync-engagement-orders-every-5min', '*/5 * * * *', $$
  SELECT net.http_post(
    url := 'https://project--8dafe7ca-cf53-49eb-9c75-fa970d91c13f.lovable.app/api/public/cron/sync-engagement-orders',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := '{}'::jsonb
  ) AS request_id;
$$);

SELECT cron.unschedule('dispatch-promos-every-5min');
SELECT cron.schedule('dispatch-promos-every-5min', '*/5 * * * *', $$
  SELECT net.http_post(
    url := 'https://project--8dafe7ca-cf53-49eb-9c75-fa970d91c13f.lovable.app/api/public/cron/dispatch-promos',
    headers := '{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body := '{}'::jsonb
  ) as request_id;
$$);

SELECT cron.unschedule('sync-promo-conversions-hourly');
SELECT cron.schedule('sync-promo-conversions-hourly', '0 * * * *', $$
  SELECT net.http_post(
    url := 'https://project--8dafe7ca-cf53-49eb-9c75-fa970d91c13f.lovable.app/api/public/cron/sync-promo-conversions',
    headers := '{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body := '{}'::jsonb
  ) as request_id;
$$);

SELECT cron.unschedule('hot-teasers-15min');
SELECT cron.schedule('hot-teasers-15min', '*/15 * * * *', $$
  select net.http_post(
    url:='https://project--8dafe7ca-cf53-49eb-9c75-fa970d91c13f.lovable.app/api/public/cron/hot-teasers',
    headers:='{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
$$);

SELECT cron.unschedule('expert-engagement-1min');
SELECT cron.schedule('expert-engagement-1min', '* * * * *', $$
  select net.http_post(
    url:='https://project--8dafe7ca-cf53-49eb-9c75-fa970d91c13f.lovable.app/api/public/cron/expert-engagement',
    headers:='{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR4bW91aHl5bGhueWFwYWh4bmpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg3MTM0NDMsImV4cCI6MjA5NDI4OTQ0M30.BCkU4JfKgZy11CKdCnRNnqDk6qXB1x8N0LXA7FJVlrw"}'::jsonb,
    body:='{}'::jsonb
  ) as request_id;
$$);

-- Lista para validar
SELECT jobid, schedule, jobname, active FROM cron.job ORDER BY jobname;
