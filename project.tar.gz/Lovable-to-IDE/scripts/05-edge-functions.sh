#!/usr/bin/env bash
# Fase 5 — Edge Functions. Deploy do código local (já versionado em supabase/functions/)
# para o projeto destino. Não toca a origem.
set -euo pipefail
cd "$(dirname "$0")/../.."   # raiz do projeto
mkdir -p scripts/mirror/logs
LOG="scripts/mirror/logs/05-edge-functions-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Fase 5: Edge Functions ==="
date
echo "Projeto destino: $TARGET_PROJECT_REF"

if ! command -v supabase >/dev/null; then
  echo "ERRO: supabase CLI não instalada (npm i -g supabase)"
  exit 1
fi

echo ""
echo "--- Login (se necessário) ---"
supabase --version
# Assume que você já fez 'supabase login' uma vez. Se não, ele pede.

echo ""
echo "--- Link com destino ---"
supabase link --project-ref "$TARGET_PROJECT_REF" || true

echo ""
echo "--- Funções a deployar ---"
FUNCS=$(ls -1 supabase/functions/ | grep -v '^_')
echo "$FUNCS"
TOTAL=$(echo "$FUNCS" | wc -l)
echo "Total: $TOTAL funções"

echo ""
echo "--- Deploy em lote ---"
i=0
for f in $FUNCS; do
  i=$((i+1))
  echo "[$i/$TOTAL] $f"
  supabase functions deploy "$f" --project-ref "$TARGET_PROJECT_REF" 2>&1 | tail -3 || \
    echo "  FAIL: $f"
done

echo ""
echo "OK. Edge functions deployadas."
echo ""
echo "PRÓXIMO PASSO MANUAL: configure os secrets no destino — ver fase 07."
