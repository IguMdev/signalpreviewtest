#!/usr/bin/env node
// Fase 4 — Storage. Lista cada bucket na origem (READ), download de cada arquivo,
// e upload no destino. Não deleta nada na origem.

import { createClient } from '@supabase/supabase-js';
import { mkdirSync, appendFileSync } from 'node:fs';

const {
  SOURCE_URL, SOURCE_SERVICE_ROLE,
  TARGET_URL, TARGET_SERVICE_ROLE,
} = process.env;

for (const v of ['SOURCE_URL','SOURCE_SERVICE_ROLE','TARGET_URL','TARGET_SERVICE_ROLE']) {
  if (!process.env[v]) { console.error(`ERRO: ${v} não definido`); process.exit(1); }
}

mkdirSync('logs', { recursive: true });
const LOG = `logs/04-storage-${new Date().toISOString().replace(/[:.]/g,'-')}.log`;
const log = (...args) => {
  const line = args.join(' ');
  console.log(line);
  appendFileSync(LOG, line + '\n');
};

const src = createClient(SOURCE_URL, SOURCE_SERVICE_ROLE, { auth: { persistSession: false } });
const dst = createClient(TARGET_URL, TARGET_SERVICE_ROLE, { auth: { persistSession: false } });

log('=== Fase 4: Storage ===');
log(new Date().toISOString());

// 1) Listar buckets origem
const { data: srcBuckets, error: bErr } = await src.storage.listBuckets();
if (bErr) { log('ERRO listando buckets origem:', bErr.message); process.exit(1); }
log(`Buckets origem: ${srcBuckets.map(b=>b.name).join(', ')}`);

// 2) Garantir buckets no destino
const { data: dstBuckets } = await dst.storage.listBuckets();
const dstBucketNames = new Set((dstBuckets||[]).map(b=>b.name));

for (const b of srcBuckets) {
  if (!dstBucketNames.has(b.name)) {
    log(`Criando bucket destino: ${b.name} (public=${b.public})`);
    const { error } = await dst.storage.createBucket(b.name, {
      public: b.public,
      fileSizeLimit: b.file_size_limit ?? undefined,
      allowedMimeTypes: b.allowed_mime_types ?? undefined,
    });
    if (error && !/already exists/i.test(error.message)) {
      log(`  ERRO: ${error.message}`);
    }
  } else {
    log(`Bucket destino já existe: ${b.name}`);
  }
}

// 3) Para cada bucket, listar recursivamente e copiar
async function listAll(bucket, prefix = '') {
  const out = [];
  let offset = 0;
  const limit = 1000;
  while (true) {
    const { data, error } = await src.storage.from(bucket).list(prefix, {
      limit, offset, sortBy: { column: 'name', order: 'asc' },
    });
    if (error) throw error;
    if (!data || data.length === 0) break;
    for (const item of data) {
      // Pasta (id null) → recursa; arquivo → adiciona
      if (item.id === null) {
        const sub = prefix ? `${prefix}/${item.name}` : item.name;
        out.push(...await listAll(bucket, sub));
      } else {
        out.push(prefix ? `${prefix}/${item.name}` : item.name);
      }
    }
    if (data.length < limit) break;
    offset += limit;
  }
  return out;
}

const summary = [];
for (const b of srcBuckets) {
  log(`\n--- Bucket: ${b.name} ---`);
  let files;
  try { files = await listAll(b.name); }
  catch (e) { log(`  ERRO listando: ${e.message}`); continue; }
  log(`  ${files.length} arquivos a copiar`);

  let ok = 0, skip = 0, fail = 0;
  for (const path of files) {
    try {
      // Pular se já existe no destino (idempotência: pode rodar várias vezes)
      const { data: existing } = await dst.storage.from(b.name).list(
        path.includes('/') ? path.substring(0, path.lastIndexOf('/')) : '',
        { limit: 1, search: path.split('/').pop() }
      );
      if (existing && existing.find(f => f.name === path.split('/').pop())) {
        skip++; continue;
      }

      // Download da origem (read-only)
      const { data: blob, error: dErr } = await src.storage.from(b.name).download(path);
      if (dErr) { log(`  FAIL download ${path}: ${dErr.message}`); fail++; continue; }

      // Upload no destino
      const { error: uErr } = await dst.storage.from(b.name).upload(path, blob, {
        contentType: blob.type || 'application/octet-stream',
        upsert: true,
      });
      if (uErr) { log(`  FAIL upload ${path}: ${uErr.message}`); fail++; continue; }
      ok++;
      if (ok % 50 === 0) log(`  progresso: ${ok}/${files.length}`);
    } catch (e) {
      log(`  EXC ${path}: ${e.message}`); fail++;
    }
  }
  log(`  Resultado: ok=${ok} skip=${skip} fail=${fail}`);
  summary.push({ bucket: b.name, total: files.length, ok, skip, fail });
}

log('\n=== Resumo Storage ===');
for (const s of summary) {
  log(`  ${s.bucket}: total=${s.total} ok=${s.ok} skip=${s.skip} fail=${s.fail}`);
}
log('\nOK. Storage copiado.');
