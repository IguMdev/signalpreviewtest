#!/usr/bin/env bash
# Fase 6 — Cron jobs (pg_cron). Lê schedule da origem (read-only) e recria no destino.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
LOG="logs/06-cron-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Fase 6: Cron jobs ==="
date

echo "--- Cron jobs da ORIGEM (read-only) ---"
psql "$SOURCE_DB_URL" -c "
  select jobid, schedule, command, jobname, active
  from cron.job
  order by jobname
" 2>&1 | tee logs/cron-source-snapshot.txt || \
  echo "AVISO: pg_cron não disponível ou sem permissão de leitura."

echo ""
echo "--- Gerando script de recriação ---"
psql "$SOURCE_DB_URL" -tAF '|' -c "
  select jobname, schedule, command
  from cron.job
  where active = true
" 2>/dev/null > logs/cron-jobs.txt || true

if [ -s logs/cron-jobs.txt ]; then
  echo "Cron jobs ativos encontrados:"
  cat logs/cron-jobs.txt
  echo ""
  echo "--- Aplicando no DESTINO ---"
  while IFS='|' read -r name schedule command; do
    [ -z "$name" ] && continue
    echo "Schedulando: $name"
    psql "$TARGET_DB_URL" -c "
      select cron.schedule(
        '$name',
        '$schedule',
        \$cmd\$$command\$cmd\$
      );
    " 2>&1 | tail -3 || echo "  FAIL: $name"
  done < logs/cron-jobs.txt
else
  echo "Nenhum cron job ativo na origem (ou pg_cron sem permissão de leitura via pooler)."
  echo ""
  echo "Se você sabe que existem jobs na origem, recrie manualmente:"
  echo "  1. No painel da ORIGEM (Database -> Cron Jobs), copie schedule + comando de cada job."
  echo "  2. Adapte fix_cron.sql (template na mesma pasta deste script)."
  echo "  3. Rode:"
  echo "       psql \"\$TARGET_DB_URL\" \\\\"
  echo "         -v target_url=\"\$TARGET_URL\" \\\\"
  echo "         -v service_role=\"\$TARGET_SERVICE_ROLE\" \\\\"
  echo "         -f fix_cron.sql"
fi

echo ""
echo "OK. Cron processado."
