#!/usr/bin/env bash
# Fase 7 — Relatório final + checklist de secrets manuais.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
REPORT="logs/mirror-report-$(date +%Y%m%d-%H%M%S).md"

{
  echo "# Mirror report"
  echo ""
  echo "- Data: $(date)"
  echo "- Origem: \`$SOURCE_PROJECT_REF\`"
  echo "- Destino: \`$TARGET_PROJECT_REF\`"
  echo ""

  echo "## Contagens por tabela (public)"
  echo ""
  echo "| Tabela | Origem | Destino | Status |"
  echo "|---|---:|---:|---|"
  TABLES=$(psql "$SOURCE_DB_URL" -tAc "select tablename from pg_tables where schemaname='public' order by tablename")
  for t in $TABLES; do
    SRC=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from public.\"$t\"" 2>/dev/null || echo "?")
    DST=$(psql "$TARGET_DB_URL" -tAc "select count(*) from public.\"$t\"" 2>/dev/null || echo "?")
    STATUS="OK"
    [ "$SRC" != "$DST" ] && STATUS="DIVERGE"
    echo "| $t | $SRC | $DST | $STATUS |"
  done

  echo ""
  echo "## Auth"
  SRC=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from auth.users")
  DST=$(psql "$TARGET_DB_URL" -tAc "select count(*) from auth.users")
  echo "- auth.users — origem: $SRC | destino: $DST"

  echo ""
  echo "## Storage"
  echo ""
  echo "| Bucket | Public | Origem (objetos) | Destino (objetos) |"
  echo "|---|---|---:|---:|"
  BUCKETS=$(psql "$SOURCE_DB_URL" -tAc "select id from storage.buckets order by id")
  for b in $BUCKETS; do
    PUB=$(psql "$SOURCE_DB_URL" -tAc "select public from storage.buckets where id='$b'")
    SRC_O=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from storage.objects where bucket_id='$b'")
    DST_O=$(psql "$TARGET_DB_URL" -tAc "select count(*) from storage.objects where bucket_id='$b'" 2>/dev/null || echo "?")
    echo "| $b | $PUB | $SRC_O | $DST_O |"
  done

  echo ""
  echo "## Checklist manual (você precisa fazer)"
  echo ""
  echo "### Secrets a configurar no destino"
  echo ""
  echo "Supabase Dashboard do destino → Edge Functions → Manage secrets."
  echo ""
  echo "Liste os secrets da ORIGEM com:"
  echo "    supabase link --project-ref \$SOURCE_PROJECT_REF"
  echo "    supabase secrets list"
  echo ""
  echo "E recrie cada um no DESTINO com os mesmos valores (que você guardou no seu gerenciador de senhas):"
  echo "    supabase link --project-ref \$TARGET_PROJECT_REF"
  echo "    supabase secrets set NOME_DO_SECRET=valor"
  echo ""
  echo "(Este script não copia valores por segurança — chaves de API ficam apenas em variáveis de ambiente.)"

  echo ""
  echo "### Itens NÃO migrados automaticamente (intencional)"
  echo ""
  echo "- Webhooks externos (Stripe, gateways de pagamento, providers etc.) continuam apontando para a ORIGEM. Atualize a URL no painel de cada provider quando decidir promover o destino."
  echo "- Domínios customizados continuam apontando para a ORIGEM (atualize DNS / Custom Domain quando promover)."
  echo "- Auth providers (Google, Apple, GitHub, etc.) — reconfigure no destino se usar."
  echo "- Templates de email custom no Auth — reconfigure no destino se usar."
  echo ""
  echo "### Verificações pós-mirror sugeridas"
  echo ""
  echo "1. No destino, faça login com um usuário existente — confirma que senhas (hash bcrypt) foram preservadas."
  echo "2. Faça uma query autenticada que dependa de RLS — confirma que policies foram migradas."
  echo "3. Baixe/visualize um arquivo de storage que existia na origem — confirma buckets e objetos acessíveis."
  echo "4. Dispare uma edge function trivial e veja logs no destino — confirma deploy + secrets."

} > "$REPORT"

echo "Relatório gerado: $REPORT"
echo ""
cat "$REPORT"
