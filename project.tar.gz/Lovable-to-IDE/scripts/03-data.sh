#!/usr/bin/env bash
# Fase 3 — Dados. pg_dump --data-only de todas as tabelas public.*
# Origem: somente SELECT. Destino: INSERT.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs dumps
LOG="logs/03-data-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Fase 3: Dados de public.* ==="
date

DUMP="dumps/data-$(date +%Y%m%d-%H%M%S).sql"

echo "--- Dumping dados de public.* + storage.objects da origem (read-only) ---"
# --data-only: só dados, sem DDL
# --disable-triggers: evita triggers de validação/audit durante o load
# storage.objects é incluído para que metadados de arquivos sejam recriados
#   (os arquivos binários em si são copiados na Fase 4)
pg_dump "$SOURCE_DB_URL" \
  --data-only \
  --column-inserts \
  --no-owner \
  --no-privileges \
  --schema=public \
  -f "$DUMP"

echo "Dump gerado: $DUMP ($(du -h "$DUMP" | cut -f1))"

echo ""
echo "--- Aplicando dados no DESTINO ---"
echo "session_replication_role=replica para evitar triggers durante o load."
echo "Pressione Ctrl+C nos próximos 5s para abortar..."
sleep 5

psql "$TARGET_DB_URL" \
  -v ON_ERROR_STOP=0 \
  --single-transaction \
  -c "SET session_replication_role = replica;" \
  -f "$DUMP" \
  -c "SET session_replication_role = origin;" 2>&1 | tee -a "$LOG"

echo ""
echo "--- Validação por tabela (origem vs destino) ---"
TABLES=$(psql "$SOURCE_DB_URL" -tAc "select tablename from pg_tables where schemaname='public' order by tablename")
echo "tabela | origem | destino"
echo "-------+--------+--------"
for t in $TABLES; do
  SRC=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from public.\"$t\"" 2>/dev/null || echo "?")
  DST=$(psql "$TARGET_DB_URL" -tAc "select count(*) from public.\"$t\"" 2>/dev/null || echo "?")
  printf "%-35s %8s %8s" "$t" "$SRC" "$DST"
  [ "$SRC" != "$DST" ] && echo "  <-- DIVERGE" || echo ""
done

echo ""
echo "OK. Dados copiados."
