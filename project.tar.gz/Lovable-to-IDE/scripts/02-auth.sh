#!/usr/bin/env bash
# Fase 2 — Auth. Copia auth.users + auth.identities preservando UUIDs e senhas.
# Origem: somente SELECT. Destino: INSERT.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs dumps
LOG="logs/02-auth-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Fase 2: Auth users ==="
date

DUMP="dumps/auth-$(date +%Y%m%d-%H%M%S).sql"

echo "--- Dumping auth.users e auth.identities da origem (read-only) ---"
# --data-only: não recria schema (já existe gerenciado pelo Supabase)
#                                  e não dispara triggers durante o load
# --column-inserts: usa INSERT com lista de colunas (mais robusto a mudanças de schema)
pg_dump "$SOURCE_DB_URL" \
  --data-only \
  --no-owner \
  --no-privileges \
  --column-inserts \
  --table=auth.users \
  --table=auth.identities \
  -f "$DUMP"

echo "Dump gerado: $DUMP ($(wc -l < "$DUMP") linhas)"

echo ""
echo "--- Aplicando auth no DESTINO ---"
echo "Pressione Ctrl+C nos próximos 5s para abortar..."
sleep 5

# session_replication_role=replica desativa triggers normais (handle_new_user etc.)
# durante o load. Profiles serão preenchidos pela Fase 3 a partir do dump de dados.
psql "$TARGET_DB_URL" \
  -v ON_ERROR_STOP=0 \
  --single-transaction \
  -c "SET session_replication_role = replica;" \
  -f "$DUMP" \
  -c "SET session_replication_role = origin;" 2>&1 | tee -a "$LOG"

echo ""
echo "--- Validação ---"
SRC=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from auth.users")
DST=$(psql "$TARGET_DB_URL" -tAc "select count(*) from auth.users")
echo "auth.users — origem: $SRC | destino: $DST"

SRC_ID=$(psql "$SOURCE_DB_URL" -tAc "select count(*) from auth.identities")
DST_ID=$(psql "$TARGET_DB_URL" -tAc "select count(*) from auth.identities")
echo "auth.identities — origem: $SRC_ID | destino: $DST_ID"

if [ "$SRC" != "$DST" ]; then
  echo "AVISO: contagem de auth.users diverge. Pode ser usuários já existentes no destino."
fi

echo ""
echo "OK. Auth copiado."
