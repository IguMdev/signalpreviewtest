--
-- PostgreSQL database dump
--

\restrict lNqJXPnVjdaUawZBpafmb9vJwlDgYG2g8gWuzIUegGi7X2SnR2era0bVdIJBo92

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: account_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.account_status AS ENUM (
    'unknown',
    'ok',
    'error'
);


--
-- Name: account_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.account_type AS ENUM (
    'bot',
    'premium'
);


--
-- Name: affiliate_store; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.affiliate_store AS ENUM (
    'amazon',
    'shopee',
    'aliexpress',
    'mercadolivre',
    'privacy',
    'crakrevenue',
    'awempire',
    'bet365',
    'betano',
    'blaze',
    'kto',
    'sportingbet'
);


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'admin',
    'user'
);


--
-- Name: engagement_bot_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.engagement_bot_type AS ENUM (
    'inscritos',
    'interacoes',
    'boasvindas',
    'encaminhador',
    'salas',
    'followup'
);


--
-- Name: engagement_order_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.engagement_order_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'partial',
    'canceled',
    'failed'
);


--
-- Name: engagement_order_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.engagement_order_type AS ENUM (
    'reaction',
    'members'
);


--
-- Name: engagement_sub_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.engagement_sub_status AS ENUM (
    'pending',
    'active',
    'canceled',
    'expired'
);


--
-- Name: expert_prompt_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.expert_prompt_kind AS ENUM (
    'question',
    'poll'
);


--
-- Name: igaming_signal_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.igaming_signal_result AS ENUM (
    'win',
    'loss',
    'gale_win'
);


--
-- Name: message_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.message_status AS ENUM (
    'pending',
    'sending',
    'sent',
    'failed',
    'cancelled'
);


--
-- Name: room_image_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.room_image_kind AS ENUM (
    'gain',
    'loss'
);


--
-- Name: room_niche; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.room_niche AS ENUM (
    'ob',
    'promo',
    'hot',
    'igaming',
    'expert'
);


--
-- Name: session_msg_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.session_msg_kind AS ENUM (
    'open',
    'close'
);


--
-- Name: signal_event_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.signal_event_status AS ENUM (
    'scheduled',
    'sent',
    'win',
    'win_g1',
    'win_g2',
    'loss',
    'error'
);


--
-- Name: template_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.template_kind AS ENUM (
    'entry',
    'gain',
    'loss',
    'event',
    'signal',
    'win',
    'win_martingale',
    'buy_direction',
    'sell_direction',
    'gale'
);


--
-- Name: consume_room_credit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.consume_room_credit() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  remaining int;
BEGIN
  UPDATE public.profiles
     SET credits = credits - 1
   WHERE id = NEW.user_id
     AND credits >= 1
   RETURNING credits INTO remaining;

  IF remaining IS NULL THEN
    RAISE EXCEPTION 'Créditos insuficientes para criar uma sala. Adquira o Plano Básico ou Premium na aba Recarga.'
      USING ERRCODE = 'P0001';
  END IF;

  INSERT INTO public.credit_transactions (user_id, delta, reason)
  VALUES (NEW.user_id, -1, 'room_create');

  RETURN NEW;
END;
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  insert into public.user_roles (user_id, role) values (new.id, 'user');
  return new;
end;
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;


--
-- Name: prevent_room_niche_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_room_niche_change() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN
  IF NEW.niche IS DISTINCT FROM OLD.niche THEN
    RAISE EXCEPTION 'O nicho da sala não pode ser alterado após a criação.'
      USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin new.updated_at = now(); return new; end; $$;


--
-- Name: tracking_attribution(uuid, text, timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tracking_attribution(_pixel_id uuid, _group_col text, _from timestamp with time zone, _to timestamp with time zone) RETURNS TABLE(dimension text, clicks bigint, joins bigint, offer_clicks bigint, registers bigint, deposits bigint, revenue numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $_$
DECLARE
  col TEXT;
BEGIN
  -- whitelist column names to prevent SQL injection
  IF _group_col NOT IN ('utm_source','utm_medium','utm_campaign','utm_content','utm_term') THEN
    RAISE EXCEPTION 'invalid group_col: %', _group_col;
  END IF;
  col := _group_col;

  -- ensure caller owns this pixel
  IF NOT EXISTS (SELECT 1 FROM public.tracking_pixels WHERE id = _pixel_id AND user_id = auth.uid()) THEN
    RAISE EXCEPTION 'pixel not found or not owned';
  END IF;

  RETURN QUERY EXECUTE format($f$
    SELECT
      COALESCE(%I, '(sem valor)')::TEXT AS dimension,
      COUNT(*)::BIGINT AS clicks,
      COUNT(joined_at)::BIGINT AS joins,
      COUNT(clicked_offer_at)::BIGINT AS offer_clicks,
      COUNT(registered_at)::BIGINT AS registers,
      COUNT(deposited_at)::BIGINT AS deposits,
      COALESCE(SUM(sale_value), 0)::NUMERIC AS revenue
    FROM public.tracking_clicks
    WHERE pixel_id = $1
      AND created_at >= $2
      AND created_at < $3
    GROUP BY COALESCE(%I, '(sem valor)')
    ORDER BY clicks DESC
    LIMIT 200
  $f$, col, col) USING _pixel_id, _from, _to;
END;
$_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: affiliate_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.affiliate_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    store public.affiliate_store NOT NULL,
    label text NOT NULL,
    credentials jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_check_at timestamp with time zone,
    last_error text,
    last_sync_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bot_execution_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bot_execution_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    account_id uuid,
    room_id uuid,
    bot_type text NOT NULL,
    event text NOT NULL,
    chat_id bigint,
    target_chat_id bigint,
    tg_user_id bigint,
    tg_username text,
    tg_first_name text,
    message text,
    error text,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: credit_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    delta integer NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: engagement_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid,
    subscription_id uuid,
    type public.engagement_order_type NOT NULL,
    target text NOT NULL,
    quantity integer NOT NULL,
    smm_order_id text,
    smm_service_id integer,
    status public.engagement_order_status DEFAULT 'pending'::public.engagement_order_status NOT NULL,
    cost_usd numeric(10,4),
    raw_response jsonb,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: engagement_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    description text,
    price_brl numeric(10,2) NOT NULL,
    monthly_reactions_quota integer DEFAULT 0 NOT NULL,
    monthly_members_quota integer DEFAULT 0 NOT NULL,
    kirvano_checkout_url text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    bot_type public.engagement_bot_type NOT NULL,
    monthly_quota integer DEFAULT 0 NOT NULL,
    smm_service_id integer,
    smm_default_quantity integer
);


--
-- Name: engagement_reaction_dispatches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_reaction_dispatches (
    chat_id bigint NOT NULL,
    telegram_message_id bigint NOT NULL,
    user_id uuid NOT NULL,
    subscription_id uuid,
    smm_order_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: expert_engagement_prompts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expert_engagement_prompts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    kind public.expert_prompt_kind DEFAULT 'question'::public.expert_prompt_kind NOT NULL,
    content text NOT NULL,
    options jsonb DEFAULT '[]'::jsonb NOT NULL,
    send_time time without time zone DEFAULT '10:00:00'::time without time zone NOT NULL,
    weekdays smallint[] DEFAULT ARRAY[(1)::smallint, (2)::smallint, (3)::smallint, (4)::smallint, (5)::smallint] NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: expert_funnel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expert_funnel (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    product_name text,
    checkout_url text,
    price_brl numeric,
    cta_button_text text DEFAULT 'Quero participar 🎓'::text NOT NULL,
    welcome_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: followup_dispatch_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.followup_dispatch_log (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    lead_id uuid NOT NULL,
    day_number integer NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    ok boolean NOT NULL,
    error text
);


--
-- Name: followup_dispatch_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.followup_dispatch_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: followup_dispatch_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.followup_dispatch_log_id_seq OWNED BY public.followup_dispatch_log.id;


--
-- Name: followup_leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.followup_leads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    account_id uuid NOT NULL,
    tg_user_id bigint NOT NULL,
    chat_id bigint NOT NULL,
    first_name text,
    username text,
    status text DEFAULT 'active'::text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_sent_day integer,
    last_sent_at timestamp with time zone,
    stopped_at timestamp with time zone,
    stopped_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: followup_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.followup_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    day_number integer NOT NULL,
    send_time time without time zone DEFAULT '09:00:00'::time without time zone NOT NULL,
    content text,
    image_path text,
    image_mime text,
    video_id uuid,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    premium_enabled boolean DEFAULT false NOT NULL,
    premium_account_id uuid,
    button_text text,
    button_url text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT followup_messages_day_number_check CHECK (((day_number >= 1) AND (day_number <= 365)))
);


--
-- Name: followup_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.followup_settings (
    room_id uuid NOT NULL,
    user_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    timezone text DEFAULT 'America/Sao_Paulo'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: forwarder_dedupe; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forwarder_dedupe (
    chat_id bigint NOT NULL,
    message_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hot_teasers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hot_teasers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    caption text,
    image_path text,
    image_mime text,
    video_id uuid,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hot_vip_funnel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hot_vip_funnel (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    vip_checkout_url text,
    vip_price_brl numeric,
    teaser_interval_hours integer DEFAULT 3 NOT NULL,
    cta_button_text text DEFAULT 'Entrar no VIP 🔥'::text NOT NULL,
    welcome_message text,
    last_teaser_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: igaming_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.igaming_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    window_id uuid,
    signal_message_id bigint,
    chat_id bigint,
    result public.igaming_signal_result NOT NULL,
    confirmed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: market_tips_sent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_tips_sent (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    link_hash text NOT NULL,
    title text,
    link text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: message_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scheduled_message_id uuid,
    user_id uuid NOT NULL,
    chat_id bigint NOT NULL,
    ok boolean NOT NULL,
    telegram_message_id bigint,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    premium_status text,
    account_id uuid,
    room_id uuid,
    source text
);


--
-- Name: COLUMN message_logs.premium_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.message_logs.premium_status IS 'premium_sent | premium_blocked | no_premium_account | plain | plain_forced | mirror_premium | mirror_copy';


--
-- Name: meta_event_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_event_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_name text NOT NULL,
    event_id text,
    ok boolean NOT NULL,
    request_payload jsonb,
    response_payload jsonb,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: meta_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    pixel_id text NOT NULL,
    access_token text NOT NULL,
    test_event_code text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    event_mappings jsonb DEFAULT jsonb_build_object('join', 'CompleteRegistration', 'leave', 'off', 'kicked', 'off') NOT NULL
);


--
-- Name: premium_emojis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.premium_emojis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    custom_emoji_id text NOT NULL,
    preview_char text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    display_name text,
    avatar_url text,
    credits integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: promo_bot_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_bot_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    interval_hours integer DEFAULT 4 NOT NULL,
    stores public.affiliate_store[] DEFAULT '{}'::public.affiliate_store[] NOT NULL,
    min_discount_pct integer DEFAULT 0 NOT NULL,
    min_price numeric,
    max_price numeric,
    categories text[] DEFAULT '{}'::text[] NOT NULL,
    keywords text[] DEFAULT '{}'::text[] NOT NULL,
    blacklist_keywords text[] DEFAULT '{}'::text[] NOT NULL,
    message_template text DEFAULT '🔥 <b>{title}</b>

<s>De R$ {old_price}</s> por <b>R$ {price}</b>
💰 {discount}% OFF

👉 {link}'::text NOT NULL,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    send_image boolean DEFAULT true NOT NULL,
    premium_account_id uuid,
    premium_enabled boolean DEFAULT false NOT NULL,
    last_fire_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: promo_clicks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_clicks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dispatch_id uuid NOT NULL,
    user_id uuid NOT NULL,
    clicked_at timestamp with time zone DEFAULT now() NOT NULL,
    ip_hash text,
    user_agent text,
    country text,
    referrer text
);


--
-- Name: promo_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_conversions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    dispatch_id uuid,
    store public.affiliate_store NOT NULL,
    order_id text NOT NULL,
    sub_id text,
    commission_value numeric DEFAULT 0 NOT NULL,
    sale_value numeric DEFAULT 0 NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    confirmed_at timestamp with time zone,
    raw jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: promo_dispatches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_dispatches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    offer_id uuid,
    store public.affiliate_store NOT NULL,
    external_id text NOT NULL,
    chat_id bigint NOT NULL,
    affiliate_link text NOT NULL,
    short_url text,
    telegram_message_id bigint,
    ok boolean DEFAULT false NOT NULL,
    error text,
    sent_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: promo_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_offers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    store public.affiliate_store NOT NULL,
    external_id text NOT NULL,
    title text NOT NULL,
    description text,
    price numeric,
    old_price numeric,
    discount_pct integer,
    image_url text,
    product_url text NOT NULL,
    category text,
    raw jsonb DEFAULT '{}'::jsonb NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


--
-- Name: quick_send_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quick_send_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    image_path text,
    image_mime text,
    image_ext text,
    default_room_id uuid,
    default_account_id uuid,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_premium boolean DEFAULT false NOT NULL,
    is_meet_button boolean DEFAULT false NOT NULL
);


--
-- Name: recurring_pending_followups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_pending_followups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    schedule_id uuid NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    account_id uuid,
    scheduled_at timestamp with time zone NOT NULL,
    content text,
    image_path text,
    image_mime text,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    video_id uuid,
    button_text text,
    button_url text
);


--
-- Name: recurring_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    account_id uuid,
    title text NOT NULL,
    content text,
    video_id uuid,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    times text[] DEFAULT '{}'::text[] NOT NULL,
    weekdays smallint[] DEFAULT '{}'::smallint[] NOT NULL,
    is_premium boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    timezone text DEFAULT 'America/Sao_Paulo'::text NOT NULL,
    last_fire_key text,
    last_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_path text,
    image_mime text,
    weekday_overrides jsonb DEFAULT '{}'::jsonb NOT NULL,
    follow_ups jsonb DEFAULT '[]'::jsonb NOT NULL,
    button_text text,
    button_url text,
    folder_id uuid
);


--
-- Name: room_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    asset_code text NOT NULL,
    category text NOT NULL,
    payout numeric(5,2) DEFAULT 1.85 NOT NULL,
    is_open boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    window_id uuid
);


--
-- Name: room_chats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_chats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    room_id uuid NOT NULL,
    user_id uuid NOT NULL,
    chat_id bigint NOT NULL,
    chat_title text
);


--
-- Name: room_engagement_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_engagement_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    room_id uuid NOT NULL,
    user_id uuid NOT NULL,
    auto_react_enabled boolean DEFAULT false NOT NULL,
    reactions_per_signal integer DEFAULT 30 NOT NULL,
    react_emojis text[] DEFAULT ARRAY['👍'::text, '❤️'::text, '🔥'::text] NOT NULL,
    delay_seconds_min integer DEFAULT 5 NOT NULL,
    delay_seconds_max integer DEFAULT 60 NOT NULL,
    auto_members_enabled boolean DEFAULT false NOT NULL,
    members_per_day integer DEFAULT 50 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    welcome_bot_enabled boolean DEFAULT false NOT NULL,
    welcome_message text DEFAULT 'Seja bem-vindo(a) ao grupo! 🎉'::text,
    forwarder_enabled boolean DEFAULT false NOT NULL,
    forwarder_source_chat_id bigint,
    forwarder_target_chat_ids bigint[] DEFAULT '{}'::bigint[] NOT NULL,
    welcome_image_path text,
    welcome_image_mime text,
    welcome_video_id uuid,
    welcome_parse_mode text DEFAULT 'HTML'::text NOT NULL,
    welcome_premium_enabled boolean DEFAULT false NOT NULL,
    welcome_premium_account_id uuid,
    forwarder_allowed_types text[] DEFAULT '{}'::text[] NOT NULL,
    forwarder_marked_recurring uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    forwarder_marked_scheduled uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    forwarder_marked_templates text[] DEFAULT '{}'::text[] NOT NULL,
    forwarder_premium_enabled boolean DEFAULT false NOT NULL,
    forwarder_premium_account_id uuid,
    followup_cta_enabled boolean DEFAULT false NOT NULL,
    followup_cta_button_text text DEFAULT 'Iniciar conversa privada 💬'::text NOT NULL
);


--
-- Name: room_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    kind public.room_image_kind NOT NULL,
    storage_path text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: room_report_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_report_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    window_id uuid NOT NULL,
    report_key text NOT NULL,
    message_ids jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: room_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    send_time time without time zone DEFAULT '23:00:00'::time without time zone NOT NULL,
    include_stats boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    delay_minutes integer DEFAULT 0 NOT NULL,
    template text DEFAULT ''::text NOT NULL,
    image_path text,
    image_mime text,
    image_ext text
);


--
-- Name: room_session_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_session_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    kind public.session_msg_kind NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_path text,
    enabled boolean DEFAULT true NOT NULL,
    lead_minutes integer DEFAULT 5 NOT NULL,
    image_mime text,
    image_ext text
);


--
-- Name: room_template_buttons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_template_buttons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    template_kind public.template_kind NOT NULL,
    label text NOT NULL,
    url text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: room_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    kind public.template_kind NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_path text,
    image_mime text,
    image_ext text
);


--
-- Name: room_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.room_windows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    name text NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    weekdays smallint[] DEFAULT '{}'::smallint[] NOT NULL,
    asset_filter text[] DEFAULT '{}'::text[] NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    signals_qty integer DEFAULT 10 NOT NULL,
    max_losses integer DEFAULT 0 NOT NULL,
    martingale integer DEFAULT 2 NOT NULL,
    signal_type text DEFAULT 'message'::text NOT NULL,
    timeframes text[] DEFAULT ARRAY['M1'::text] NOT NULL,
    use_all_assets boolean DEFAULT true NOT NULL,
    last_session_fire jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rooms (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    default_account_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_url text,
    photo_updated_at timestamp with time zone,
    broker text,
    welcome_message text,
    timezone text DEFAULT 'America/Sao_Paulo'::text NOT NULL,
    stop_loss_enabled boolean DEFAULT false NOT NULL,
    stop_loss_value numeric,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    premium_account_id uuid,
    access_url text,
    stop_loss_message text,
    market_tips_enabled boolean DEFAULT false NOT NULL,
    market_tips_interval_hours integer DEFAULT 6 NOT NULL,
    market_tips_categories text[] DEFAULT ARRAY['forex'::text, 'crypto'::text] NOT NULL,
    market_tips_last_fire_at timestamp with time zone,
    niche public.room_niche DEFAULT 'ob'::public.room_niche NOT NULL
);


--
-- Name: schedule_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schedule_folders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#6366f1'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: scheduled_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    account_id uuid,
    content text,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    status public.message_status DEFAULT 'pending'::public.message_status NOT NULL,
    sent_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    video_id uuid,
    is_premium boolean DEFAULT false NOT NULL
);


--
-- Name: signal_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.signal_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    window_id uuid NOT NULL,
    asset_code text NOT NULL,
    asset_category text,
    direction text NOT NULL,
    timeframe text DEFAULT 'M1'::text NOT NULL,
    entry_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    gale_level smallint DEFAULT 0 NOT NULL,
    max_gales smallint DEFAULT 2 NOT NULL,
    entry_price numeric,
    close_price numeric,
    status public.signal_event_status DEFAULT 'scheduled'::public.signal_event_status NOT NULL,
    signal_message_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    result_message_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT signal_events_direction_check CHECK ((direction = ANY (ARRAY['buy'::text, 'sell'::text])))
);


--
-- Name: telegram_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telegram_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    label text NOT NULL,
    bot_token text,
    bot_username text,
    bot_first_name text,
    status public.account_status DEFAULT 'unknown'::public.account_status NOT NULL,
    last_check_at timestamp with time zone,
    last_error text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    account_type public.account_type DEFAULT 'bot'::public.account_type NOT NULL,
    phone text,
    daily_limit integer DEFAULT 1000 NOT NULL,
    tg_api_id bigint,
    tg_api_hash text,
    tg_session text,
    tg_phone_code_hash text,
    member_tracking_enabled boolean DEFAULT false NOT NULL,
    member_tracking_last_check timestamp with time zone,
    member_tracking_last_error text,
    member_tracking_recovered_at timestamp with time zone
);


--
-- Name: telegram_chats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telegram_chats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    user_id uuid NOT NULL,
    chat_id bigint NOT NULL,
    title text,
    type text,
    username text,
    cached_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: telegram_member_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telegram_member_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    account_id uuid NOT NULL,
    chat_id bigint NOT NULL,
    chat_title text,
    tg_user_id bigint NOT NULL,
    tg_username text,
    tg_first_name text,
    event_type text NOT NULL,
    old_status text,
    new_status text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT telegram_member_events_event_type_check CHECK ((event_type = ANY (ARRAY['join'::text, 'leave'::text, 'kicked'::text])))
);


--
-- Name: tracking_clicks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracking_clicks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    click_id text NOT NULL,
    pixel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    fbp text,
    fbc text,
    fbclid text,
    ttclid text,
    gclid text,
    kwai_click_id text,
    utm_source text,
    utm_medium text,
    utm_campaign text,
    utm_content text,
    utm_term text,
    ip text,
    user_agent text,
    referrer text,
    landing_url text,
    external_id text,
    joined_at timestamp with time zone,
    clicked_offer_at timestamp with time zone,
    registered_at timestamp with time zone,
    deposited_at timestamp with time zone,
    tg_user_id bigint,
    tg_username text,
    sale_value numeric,
    sale_currency text,
    external_user_id text,
    meta_events_sent jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    viewed_at timestamp with time zone,
    lead_at timestamp with time zone,
    checkout_at timestamp with time zone,
    payment_info_at timestamp with time zone,
    purchased_at timestamp with time zone
);


--
-- Name: tracking_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracking_domains (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    domain text NOT NULL,
    verification_token text DEFAULT encode(extensions.gen_random_bytes(16), 'hex'::text) NOT NULL,
    verified_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tracking_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracking_integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    pixel_id uuid NOT NULL,
    name text NOT NULL,
    event_type text NOT NULL,
    custom_event_name text,
    redirect_url text NOT NULL,
    meta_custom_event text,
    meta_value numeric,
    meta_currency text DEFAULT 'BRL'::text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tracking_integrations_event_type_check CHECK ((event_type = ANY (ARRAY['register'::text, 'ftd'::text, 'deposit'::text, 'custom'::text])))
);


--
-- Name: tracking_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracking_offers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    pixel_id uuid NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    destination_url text NOT NULL,
    subid_param text DEFAULT 'sub1'::text NOT NULL,
    default_event text DEFAULT 'InitiateCheckout'::text NOT NULL,
    default_value numeric,
    default_currency text DEFAULT 'BRL'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tracking_pixels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracking_pixels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    vertical text DEFAULT 'outro'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    meta_integration_id uuid,
    account_id uuid,
    room_id uuid,
    bot_username text,
    event_on_join text DEFAULT 'Lead'::text NOT NULL,
    event_on_offer_click text DEFAULT 'InitiateCheckout'::text NOT NULL,
    event_on_register text DEFAULT 'CompleteRegistration'::text NOT NULL,
    event_on_deposit text DEFAULT 'Purchase'::text NOT NULL,
    postback_secret text DEFAULT encode(extensions.gen_random_bytes(24), 'base64'::text) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    meta_pixel_id text,
    meta_access_token text,
    meta_test_event_code text,
    tracking_mode text DEFAULT 'telegram'::text NOT NULL,
    sales_page_url text,
    event_on_view text DEFAULT 'ViewContent'::text NOT NULL,
    event_on_lead text DEFAULT 'Lead'::text NOT NULL,
    event_on_checkout text DEFAULT 'InitiateCheckout'::text NOT NULL,
    event_on_payment_info text DEFAULT 'AddPaymentInfo'::text NOT NULL,
    event_on_purchase text DEFAULT 'Purchase'::text NOT NULL,
    CONSTRAINT tracking_pixels_tracking_mode_check CHECK ((tracking_mode = ANY (ARRAY['telegram'::text, 'direct_response'::text]))),
    CONSTRAINT tracking_pixels_vertical_check CHECK ((vertical = ANY (ARRAY['bet'::text, 'igaming'::text, 'hot'::text, 'promo'::text, 'outro'::text])))
);


--
-- Name: tracking_postbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tracking_postbacks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    pixel_id uuid NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    event text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tracking_postbacks_event_check CHECK ((event = ANY (ARRAY['viewpage'::text, 'click_button'::text, 'channel_enter'::text, 'channel_leave'::text])))
);


--
-- Name: user_engagement_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_engagement_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status public.engagement_sub_status DEFAULT 'pending'::public.engagement_sub_status NOT NULL,
    reactions_used integer DEFAULT 0 NOT NULL,
    members_used integer DEFAULT 0 NOT NULL,
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    kirvano_sale_id text,
    kirvano_customer_email text,
    last_event jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    bot_type public.engagement_bot_type,
    units_used integer DEFAULT 0 NOT NULL,
    target_link text,
    target_room_id uuid,
    auto_dispatched_at timestamp with time zone
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: videos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.videos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    storage_path text NOT NULL,
    file_size bigint,
    duration_seconds integer,
    mime_type text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    kind text DEFAULT 'round'::text NOT NULL,
    width integer,
    height integer,
    CONSTRAINT videos_kind_check CHECK ((kind = ANY (ARRAY['round'::text, 'normal'::text])))
);


--
-- Name: welcome_extra_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.welcome_extra_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    room_id uuid NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    content text,
    image_path text,
    image_mime text,
    video_id uuid,
    delay_seconds integer DEFAULT 2 NOT NULL,
    parse_mode text DEFAULT 'HTML'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    premium_enabled boolean DEFAULT false NOT NULL,
    premium_account_id uuid
);


--
-- Name: followup_dispatch_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_dispatch_log ALTER COLUMN id SET DEFAULT nextval('public.followup_dispatch_log_id_seq'::regclass);


--
-- Name: affiliate_accounts affiliate_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.affiliate_accounts
    ADD CONSTRAINT affiliate_accounts_pkey PRIMARY KEY (id);


--
-- Name: affiliate_accounts affiliate_accounts_user_id_store_label_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.affiliate_accounts
    ADD CONSTRAINT affiliate_accounts_user_id_store_label_key UNIQUE (user_id, store, label);


--
-- Name: bot_execution_logs bot_execution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_execution_logs
    ADD CONSTRAINT bot_execution_logs_pkey PRIMARY KEY (id);


--
-- Name: credit_transactions credit_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transactions
    ADD CONSTRAINT credit_transactions_pkey PRIMARY KEY (id);


--
-- Name: engagement_orders engagement_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_orders
    ADD CONSTRAINT engagement_orders_pkey PRIMARY KEY (id);


--
-- Name: engagement_plans engagement_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_plans
    ADD CONSTRAINT engagement_plans_pkey PRIMARY KEY (id);


--
-- Name: engagement_plans engagement_plans_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_plans
    ADD CONSTRAINT engagement_plans_slug_key UNIQUE (slug);


--
-- Name: engagement_reaction_dispatches engagement_reaction_dispatches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_reaction_dispatches
    ADD CONSTRAINT engagement_reaction_dispatches_pkey PRIMARY KEY (chat_id, telegram_message_id);


--
-- Name: expert_engagement_prompts expert_engagement_prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expert_engagement_prompts
    ADD CONSTRAINT expert_engagement_prompts_pkey PRIMARY KEY (id);


--
-- Name: expert_funnel expert_funnel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expert_funnel
    ADD CONSTRAINT expert_funnel_pkey PRIMARY KEY (id);


--
-- Name: expert_funnel expert_funnel_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expert_funnel
    ADD CONSTRAINT expert_funnel_room_id_key UNIQUE (room_id);


--
-- Name: followup_dispatch_log followup_dispatch_log_lead_id_day_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_dispatch_log
    ADD CONSTRAINT followup_dispatch_log_lead_id_day_number_key UNIQUE (lead_id, day_number);


--
-- Name: followup_dispatch_log followup_dispatch_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_dispatch_log
    ADD CONSTRAINT followup_dispatch_log_pkey PRIMARY KEY (id);


--
-- Name: followup_leads followup_leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_leads
    ADD CONSTRAINT followup_leads_pkey PRIMARY KEY (id);


--
-- Name: followup_leads followup_leads_room_id_tg_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_leads
    ADD CONSTRAINT followup_leads_room_id_tg_user_id_key UNIQUE (room_id, tg_user_id);


--
-- Name: followup_messages followup_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_messages
    ADD CONSTRAINT followup_messages_pkey PRIMARY KEY (id);


--
-- Name: followup_messages followup_messages_room_id_day_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_messages
    ADD CONSTRAINT followup_messages_room_id_day_number_key UNIQUE (room_id, day_number);


--
-- Name: followup_settings followup_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.followup_settings
    ADD CONSTRAINT followup_settings_pkey PRIMARY KEY (room_id);


--
-- Name: forwarder_dedupe forwarder_dedupe_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forwarder_dedupe
    ADD CONSTRAINT forwarder_dedupe_pkey PRIMARY KEY (chat_id, message_id);


--
-- Name: hot_teasers hot_teasers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hot_teasers
    ADD CONSTRAINT hot_teasers_pkey PRIMARY KEY (id);


--
-- Name: hot_vip_funnel hot_vip_funnel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hot_vip_funnel
    ADD CONSTRAINT hot_vip_funnel_pkey PRIMARY KEY (id);


--
-- Name: hot_vip_funnel hot_vip_funnel_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hot_vip_funnel
    ADD CONSTRAINT hot_vip_funnel_room_id_key UNIQUE (room_id);


--
-- Name: igaming_results igaming_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.igaming_results
    ADD CONSTRAINT igaming_results_pkey PRIMARY KEY (id);


--
-- Name: market_tips_sent market_tips_sent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_tips_sent
    ADD CONSTRAINT market_tips_sent_pkey PRIMARY KEY (id);


--
-- Name: market_tips_sent market_tips_sent_room_id_link_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_tips_sent
    ADD CONSTRAINT market_tips_sent_room_id_link_hash_key UNIQUE (room_id, link_hash);


--
-- Name: message_logs message_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_pkey PRIMARY KEY (id);


--
-- Name: meta_event_logs meta_event_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_event_logs
    ADD CONSTRAINT meta_event_logs_pkey PRIMARY KEY (id);


--
-- Name: meta_integrations meta_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_integrations
    ADD CONSTRAINT meta_integrations_pkey PRIMARY KEY (id);


--
-- Name: meta_integrations meta_integrations_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_integrations
    ADD CONSTRAINT meta_integrations_user_id_key UNIQUE (user_id);


--
-- Name: premium_emojis premium_emojis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.premium_emojis
    ADD CONSTRAINT premium_emojis_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: promo_bot_settings promo_bot_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_bot_settings
    ADD CONSTRAINT promo_bot_settings_pkey PRIMARY KEY (id);


--
-- Name: promo_bot_settings promo_bot_settings_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_bot_settings
    ADD CONSTRAINT promo_bot_settings_room_id_key UNIQUE (room_id);


--
-- Name: promo_clicks promo_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_clicks
    ADD CONSTRAINT promo_clicks_pkey PRIMARY KEY (id);


--
-- Name: promo_conversions promo_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_conversions
    ADD CONSTRAINT promo_conversions_pkey PRIMARY KEY (id);


--
-- Name: promo_conversions promo_conversions_user_id_store_order_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_conversions
    ADD CONSTRAINT promo_conversions_user_id_store_order_id_key UNIQUE (user_id, store, order_id);


--
-- Name: promo_dispatches promo_dispatches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_dispatches
    ADD CONSTRAINT promo_dispatches_pkey PRIMARY KEY (id);


--
-- Name: promo_offers promo_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_offers
    ADD CONSTRAINT promo_offers_pkey PRIMARY KEY (id);


--
-- Name: promo_offers promo_offers_user_id_store_external_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_offers
    ADD CONSTRAINT promo_offers_user_id_store_external_id_key UNIQUE (user_id, store, external_id);


--
-- Name: quick_send_templates quick_send_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quick_send_templates
    ADD CONSTRAINT quick_send_templates_pkey PRIMARY KEY (id);


--
-- Name: recurring_pending_followups recurring_pending_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_pending_followups
    ADD CONSTRAINT recurring_pending_followups_pkey PRIMARY KEY (id);


--
-- Name: recurring_schedules recurring_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_schedules
    ADD CONSTRAINT recurring_schedules_pkey PRIMARY KEY (id);


--
-- Name: room_assets room_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_assets
    ADD CONSTRAINT room_assets_pkey PRIMARY KEY (id);


--
-- Name: room_assets room_assets_room_id_asset_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_assets
    ADD CONSTRAINT room_assets_room_id_asset_code_key UNIQUE (room_id, asset_code);


--
-- Name: room_chats room_chats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_chats
    ADD CONSTRAINT room_chats_pkey PRIMARY KEY (id);


--
-- Name: room_chats room_chats_room_id_chat_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_chats
    ADD CONSTRAINT room_chats_room_id_chat_id_key UNIQUE (room_id, chat_id);


--
-- Name: room_engagement_settings room_engagement_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_engagement_settings
    ADD CONSTRAINT room_engagement_settings_pkey PRIMARY KEY (id);


--
-- Name: room_engagement_settings room_engagement_settings_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_engagement_settings
    ADD CONSTRAINT room_engagement_settings_room_id_key UNIQUE (room_id);


--
-- Name: room_images room_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_images
    ADD CONSTRAINT room_images_pkey PRIMARY KEY (id);


--
-- Name: room_report_runs room_report_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_report_runs
    ADD CONSTRAINT room_report_runs_pkey PRIMARY KEY (id);


--
-- Name: room_report_runs room_report_runs_room_id_window_id_report_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_report_runs
    ADD CONSTRAINT room_report_runs_room_id_window_id_report_key_key UNIQUE (room_id, window_id, report_key);


--
-- Name: room_reports room_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_reports
    ADD CONSTRAINT room_reports_pkey PRIMARY KEY (id);


--
-- Name: room_reports room_reports_room_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_reports
    ADD CONSTRAINT room_reports_room_id_key UNIQUE (room_id);


--
-- Name: room_session_messages room_session_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_session_messages
    ADD CONSTRAINT room_session_messages_pkey PRIMARY KEY (id);


--
-- Name: room_session_messages room_session_messages_room_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_session_messages
    ADD CONSTRAINT room_session_messages_room_id_kind_key UNIQUE (room_id, kind);


--
-- Name: room_template_buttons room_template_buttons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_template_buttons
    ADD CONSTRAINT room_template_buttons_pkey PRIMARY KEY (id);


--
-- Name: room_templates room_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_templates
    ADD CONSTRAINT room_templates_pkey PRIMARY KEY (id);


--
-- Name: room_templates room_templates_room_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_templates
    ADD CONSTRAINT room_templates_room_id_kind_key UNIQUE (room_id, kind);


--
-- Name: room_windows room_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_windows
    ADD CONSTRAINT room_windows_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: schedule_folders schedule_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_folders
    ADD CONSTRAINT schedule_folders_pkey PRIMARY KEY (id);


--
-- Name: scheduled_messages scheduled_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_pkey PRIMARY KEY (id);


--
-- Name: signal_events signal_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signal_events
    ADD CONSTRAINT signal_events_pkey PRIMARY KEY (id);


--
-- Name: telegram_accounts telegram_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_accounts
    ADD CONSTRAINT telegram_accounts_pkey PRIMARY KEY (id);


--
-- Name: telegram_chats telegram_chats_account_id_chat_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_account_id_chat_id_key UNIQUE (account_id, chat_id);


--
-- Name: telegram_chats telegram_chats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_pkey PRIMARY KEY (id);


--
-- Name: telegram_member_events telegram_member_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_member_events
    ADD CONSTRAINT telegram_member_events_pkey PRIMARY KEY (id);


--
-- Name: tracking_clicks tracking_clicks_click_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_clicks
    ADD CONSTRAINT tracking_clicks_click_id_key UNIQUE (click_id);


--
-- Name: tracking_clicks tracking_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_clicks
    ADD CONSTRAINT tracking_clicks_pkey PRIMARY KEY (id);


--
-- Name: tracking_domains tracking_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_domains
    ADD CONSTRAINT tracking_domains_pkey PRIMARY KEY (id);


--
-- Name: tracking_domains tracking_domains_user_id_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_domains
    ADD CONSTRAINT tracking_domains_user_id_domain_key UNIQUE (user_id, domain);


--
-- Name: tracking_integrations tracking_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_integrations
    ADD CONSTRAINT tracking_integrations_pkey PRIMARY KEY (id);


--
-- Name: tracking_offers tracking_offers_pixel_id_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_offers
    ADD CONSTRAINT tracking_offers_pixel_id_slug_key UNIQUE (pixel_id, slug);


--
-- Name: tracking_offers tracking_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_offers
    ADD CONSTRAINT tracking_offers_pkey PRIMARY KEY (id);


--
-- Name: tracking_pixels tracking_pixels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_pixels
    ADD CONSTRAINT tracking_pixels_pkey PRIMARY KEY (id);


--
-- Name: tracking_postbacks tracking_postbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_postbacks
    ADD CONSTRAINT tracking_postbacks_pkey PRIMARY KEY (id);


--
-- Name: user_engagement_subscriptions user_engagement_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_engagement_subscriptions
    ADD CONSTRAINT user_engagement_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- Name: welcome_extra_messages welcome_extra_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.welcome_extra_messages
    ADD CONSTRAINT welcome_extra_messages_pkey PRIMARY KEY (id);


--
-- Name: bel_user_bot_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bel_user_bot_idx ON public.bot_execution_logs USING btree (user_id, bot_type, created_at DESC);


--
-- Name: bel_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bel_user_created_idx ON public.bot_execution_logs USING btree (user_id, created_at DESC);


--
-- Name: eep_room_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX eep_room_idx ON public.expert_engagement_prompts USING btree (room_id, send_time);


--
-- Name: hot_teasers_room_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hot_teasers_room_idx ON public.hot_teasers USING btree (room_id, sort_order);


--
-- Name: idx_credit_tx_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_tx_user_created ON public.credit_transactions USING btree (user_id, created_at DESC);


--
-- Name: idx_eo_smm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eo_smm ON public.engagement_orders USING btree (smm_order_id);


--
-- Name: idx_eo_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eo_status ON public.engagement_orders USING btree (status);


--
-- Name: idx_eo_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eo_user ON public.engagement_orders USING btree (user_id);


--
-- Name: idx_erd_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_erd_user_created ON public.engagement_reaction_dispatches USING btree (user_id, created_at DESC);


--
-- Name: idx_followup_dispatch_lead; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_followup_dispatch_lead ON public.followup_dispatch_log USING btree (lead_id);


--
-- Name: idx_followup_leads_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_followup_leads_status ON public.followup_leads USING btree (status);


--
-- Name: idx_followup_leads_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_followup_leads_user ON public.followup_leads USING btree (user_id);


--
-- Name: idx_followup_messages_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_followup_messages_room ON public.followup_messages USING btree (room_id);


--
-- Name: idx_forwarder_dedupe_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_forwarder_dedupe_created ON public.forwarder_dedupe USING btree (created_at);


--
-- Name: idx_message_logs_room_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_logs_room_created ON public.message_logs USING btree (room_id, created_at DESC);


--
-- Name: idx_message_logs_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_logs_user_created ON public.message_logs USING btree (user_id, created_at DESC);


--
-- Name: idx_meta_event_logs_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_meta_event_logs_user_created ON public.meta_event_logs USING btree (user_id, created_at DESC);


--
-- Name: idx_promo_clicks_dispatch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_clicks_dispatch ON public.promo_clicks USING btree (dispatch_id, clicked_at DESC);


--
-- Name: idx_promo_clicks_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_clicks_user ON public.promo_clicks USING btree (user_id, clicked_at DESC);


--
-- Name: idx_promo_conversions_dispatch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_conversions_dispatch ON public.promo_conversions USING btree (dispatch_id);


--
-- Name: idx_promo_conversions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_conversions_user ON public.promo_conversions USING btree (user_id, confirmed_at DESC NULLS LAST);


--
-- Name: idx_promo_dispatches_dedupe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_dispatches_dedupe ON public.promo_dispatches USING btree (room_id, store, external_id, sent_at DESC);


--
-- Name: idx_promo_dispatches_user_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_dispatches_user_room ON public.promo_dispatches USING btree (user_id, room_id, sent_at DESC);


--
-- Name: idx_promo_offers_user_store; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_promo_offers_user_store ON public.promo_offers USING btree (user_id, store, fetched_at DESC);


--
-- Name: idx_recurring_schedules_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recurring_schedules_folder ON public.recurring_schedules USING btree (folder_id);


--
-- Name: idx_room_assets_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_assets_room ON public.room_assets USING btree (room_id);


--
-- Name: idx_room_images_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_images_room ON public.room_images USING btree (room_id);


--
-- Name: idx_room_windows_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_room_windows_room ON public.room_windows USING btree (room_id);


--
-- Name: idx_rpf_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rpf_due ON public.recurring_pending_followups USING btree (status, scheduled_at);


--
-- Name: idx_rs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rs_active ON public.recurring_schedules USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_rs_user_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rs_user_room ON public.recurring_schedules USING btree (user_id, room_id);


--
-- Name: idx_sm_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sm_due ON public.scheduled_messages USING btree (status, scheduled_at);


--
-- Name: idx_tc_pixel_campaign; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tc_pixel_campaign ON public.tracking_clicks USING btree (pixel_id, utm_campaign);


--
-- Name: idx_tc_pixel_content; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tc_pixel_content ON public.tracking_clicks USING btree (pixel_id, utm_content);


--
-- Name: idx_tc_pixel_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tc_pixel_created ON public.tracking_clicks USING btree (pixel_id, created_at DESC);


--
-- Name: idx_tc_pixel_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tc_pixel_source ON public.tracking_clicks USING btree (pixel_id, utm_source);


--
-- Name: idx_tc_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tc_user ON public.tracking_clicks USING btree (user_id);


--
-- Name: idx_ti_pixel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ti_pixel ON public.tracking_integrations USING btree (pixel_id);


--
-- Name: idx_ti_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ti_user ON public.tracking_integrations USING btree (user_id);


--
-- Name: idx_tme_account_chat_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tme_account_chat_date ON public.telegram_member_events USING btree (account_id, chat_id, occurred_at DESC);


--
-- Name: idx_tme_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tme_user_date ON public.telegram_member_events USING btree (user_id, occurred_at DESC);


--
-- Name: idx_tracking_domains_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_domains_domain ON public.tracking_domains USING btree (domain);


--
-- Name: idx_tracking_domains_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_domains_user ON public.tracking_domains USING btree (user_id);


--
-- Name: idx_tracking_offers_pixel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_offers_pixel ON public.tracking_offers USING btree (pixel_id);


--
-- Name: idx_tracking_offers_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_offers_user ON public.tracking_offers USING btree (user_id);


--
-- Name: idx_tracking_pixels_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_pixels_user ON public.tracking_pixels USING btree (user_id);


--
-- Name: idx_tracking_postbacks_pixel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_postbacks_pixel ON public.tracking_postbacks USING btree (pixel_id);


--
-- Name: idx_tracking_postbacks_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tracking_postbacks_user ON public.tracking_postbacks USING btree (user_id);


--
-- Name: idx_ues_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ues_status ON public.user_engagement_subscriptions USING btree (status);


--
-- Name: idx_ues_target_room; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ues_target_room ON public.user_engagement_subscriptions USING btree (target_room_id);


--
-- Name: idx_ues_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ues_user ON public.user_engagement_subscriptions USING btree (user_id);


--
-- Name: idx_ues_user_pending_alloc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ues_user_pending_alloc ON public.user_engagement_subscriptions USING btree (user_id, status, bot_type) WHERE (target_room_id IS NULL);


--
-- Name: igr_room_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX igr_room_idx ON public.igaming_results USING btree (room_id, confirmed_at DESC);


--
-- Name: market_tips_sent_room_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_tips_sent_room_created_idx ON public.market_tips_sent USING btree (room_id, created_at DESC);


--
-- Name: quick_send_templates_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX quick_send_templates_user_idx ON public.quick_send_templates USING btree (user_id, sort_order);


--
-- Name: room_report_runs_room_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX room_report_runs_room_created_idx ON public.room_report_runs USING btree (room_id, created_at DESC);


--
-- Name: signal_events_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX signal_events_pending_idx ON public.signal_events USING btree (status, expires_at) WHERE (status = ANY (ARRAY['sent'::public.signal_event_status, 'scheduled'::public.signal_event_status]));


--
-- Name: signal_events_room_entry_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX signal_events_room_entry_unique ON public.signal_events USING btree (room_id, entry_at);


--
-- Name: signal_events_room_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX signal_events_room_idx ON public.signal_events USING btree (room_id, entry_at DESC);


--
-- Name: signal_events_window_entry_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX signal_events_window_entry_uniq ON public.signal_events USING btree (window_id, entry_at);


--
-- Name: wem_room_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wem_room_idx ON public.welcome_extra_messages USING btree (room_id, sort_order);


--
-- Name: expert_engagement_prompts eep_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER eep_touch BEFORE UPDATE ON public.expert_engagement_prompts FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: expert_funnel expert_funnel_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER expert_funnel_touch BEFORE UPDATE ON public.expert_funnel FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: hot_teasers hot_teasers_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hot_teasers_touch BEFORE UPDATE ON public.hot_teasers FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: hot_vip_funnel hot_vip_funnel_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hot_vip_funnel_touch BEFORE UPDATE ON public.hot_vip_funnel FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: profiles profiles_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: quick_send_templates quick_send_templates_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER quick_send_templates_touch BEFORE UPDATE ON public.quick_send_templates FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: recurring_schedules rs_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER rs_touch BEFORE UPDATE ON public.recurring_schedules FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: schedule_folders schedule_folders_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER schedule_folders_touch BEFORE UPDATE ON public.schedule_folders FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: telegram_accounts ta_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ta_touch BEFORE UPDATE ON public.telegram_accounts FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: tracking_offers tof_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tof_touch BEFORE UPDATE ON public.tracking_offers FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: tracking_pixels tp_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tp_touch BEFORE UPDATE ON public.tracking_pixels FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: affiliate_accounts trg_aa_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_aa_updated_at BEFORE UPDATE ON public.affiliate_accounts FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: rooms trg_consume_room_credit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_consume_room_credit BEFORE INSERT ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.consume_room_credit();


--
-- Name: engagement_plans trg_engagement_plans_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_engagement_plans_updated BEFORE UPDATE ON public.engagement_plans FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: engagement_orders trg_eo_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_eo_updated BEFORE UPDATE ON public.engagement_orders FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: followup_leads trg_followup_leads_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_followup_leads_updated_at BEFORE UPDATE ON public.followup_leads FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: followup_messages trg_followup_messages_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_followup_messages_updated_at BEFORE UPDATE ON public.followup_messages FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: followup_settings trg_followup_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_followup_settings_updated_at BEFORE UPDATE ON public.followup_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: meta_integrations trg_meta_integrations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_meta_integrations_updated_at BEFORE UPDATE ON public.meta_integrations FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: promo_bot_settings trg_pbs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_pbs_updated_at BEFORE UPDATE ON public.promo_bot_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: rooms trg_prevent_room_niche_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_prevent_room_niche_change BEFORE UPDATE ON public.rooms FOR EACH ROW EXECUTE FUNCTION public.prevent_room_niche_change();


--
-- Name: room_engagement_settings trg_res_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_res_updated BEFORE UPDATE ON public.room_engagement_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: room_assets trg_room_assets_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_room_assets_updated BEFORE UPDATE ON public.room_assets FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: room_reports trg_rr_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_rr_updated BEFORE UPDATE ON public.room_reports FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: room_session_messages trg_rsm_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_rsm_updated BEFORE UPDATE ON public.room_session_messages FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: room_templates trg_rt_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_rt_updated BEFORE UPDATE ON public.room_templates FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: room_template_buttons trg_rtb_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_rtb_updated BEFORE UPDATE ON public.room_template_buttons FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: room_windows trg_rw_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_rw_updated BEFORE UPDATE ON public.room_windows FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: signal_events trg_signal_events_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_signal_events_updated BEFORE UPDATE ON public.signal_events FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: tracking_integrations trg_ti_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ti_touch BEFORE UPDATE ON public.tracking_integrations FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: tracking_domains trg_tracking_domains_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tracking_domains_updated BEFORE UPDATE ON public.tracking_domains FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: tracking_postbacks trg_tracking_postbacks_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tracking_postbacks_updated BEFORE UPDATE ON public.tracking_postbacks FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: user_engagement_subscriptions trg_ues_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ues_updated BEFORE UPDATE ON public.user_engagement_subscriptions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: videos videos_touch_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER videos_touch_updated_at BEFORE UPDATE ON public.videos FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: welcome_extra_messages wem_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER wem_touch BEFORE UPDATE ON public.welcome_extra_messages FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: credit_transactions credit_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_transactions
    ADD CONSTRAINT credit_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: engagement_orders engagement_orders_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_orders
    ADD CONSTRAINT engagement_orders_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.user_engagement_subscriptions(id) ON DELETE SET NULL;


--
-- Name: message_logs message_logs_scheduled_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_scheduled_message_id_fkey FOREIGN KEY (scheduled_message_id) REFERENCES public.scheduled_messages(id) ON DELETE CASCADE;


--
-- Name: message_logs message_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: premium_emojis premium_emojis_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.premium_emojis
    ADD CONSTRAINT premium_emojis_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: recurring_pending_followups recurring_pending_followups_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_pending_followups
    ADD CONSTRAINT recurring_pending_followups_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.recurring_schedules(id) ON DELETE CASCADE;


--
-- Name: recurring_schedules recurring_schedules_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_schedules
    ADD CONSTRAINT recurring_schedules_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.schedule_folders(id) ON DELETE SET NULL;


--
-- Name: room_assets room_assets_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_assets
    ADD CONSTRAINT room_assets_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_assets room_assets_window_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_assets
    ADD CONSTRAINT room_assets_window_id_fkey FOREIGN KEY (window_id) REFERENCES public.room_windows(id) ON DELETE CASCADE;


--
-- Name: room_chats room_chats_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_chats
    ADD CONSTRAINT room_chats_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_chats room_chats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_chats
    ADD CONSTRAINT room_chats_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: room_images room_images_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_images
    ADD CONSTRAINT room_images_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_reports room_reports_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_reports
    ADD CONSTRAINT room_reports_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_session_messages room_session_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_session_messages
    ADD CONSTRAINT room_session_messages_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_template_buttons room_template_buttons_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_template_buttons
    ADD CONSTRAINT room_template_buttons_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_templates room_templates_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_templates
    ADD CONSTRAINT room_templates_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: room_windows room_windows_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.room_windows
    ADD CONSTRAINT room_windows_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: rooms rooms_default_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_default_account_id_fkey FOREIGN KEY (default_account_id) REFERENCES public.telegram_accounts(id) ON DELETE SET NULL;


--
-- Name: rooms rooms_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.telegram_accounts(id) ON DELETE SET NULL;


--
-- Name: scheduled_messages scheduled_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: scheduled_messages scheduled_messages_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_messages
    ADD CONSTRAINT scheduled_messages_video_id_fkey FOREIGN KEY (video_id) REFERENCES public.videos(id) ON DELETE SET NULL;


--
-- Name: telegram_accounts telegram_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_accounts
    ADD CONSTRAINT telegram_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: telegram_chats telegram_chats_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.telegram_accounts(id) ON DELETE CASCADE;


--
-- Name: telegram_chats telegram_chats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: tracking_clicks tracking_clicks_pixel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_clicks
    ADD CONSTRAINT tracking_clicks_pixel_id_fkey FOREIGN KEY (pixel_id) REFERENCES public.tracking_pixels(id) ON DELETE CASCADE;


--
-- Name: tracking_integrations tracking_integrations_pixel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_integrations
    ADD CONSTRAINT tracking_integrations_pixel_id_fkey FOREIGN KEY (pixel_id) REFERENCES public.tracking_pixels(id) ON DELETE CASCADE;


--
-- Name: tracking_offers tracking_offers_pixel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_offers
    ADD CONSTRAINT tracking_offers_pixel_id_fkey FOREIGN KEY (pixel_id) REFERENCES public.tracking_pixels(id) ON DELETE CASCADE;


--
-- Name: tracking_pixels tracking_pixels_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_pixels
    ADD CONSTRAINT tracking_pixels_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.telegram_accounts(id) ON DELETE SET NULL;


--
-- Name: tracking_pixels tracking_pixels_meta_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_pixels
    ADD CONSTRAINT tracking_pixels_meta_integration_id_fkey FOREIGN KEY (meta_integration_id) REFERENCES public.meta_integrations(id) ON DELETE SET NULL;


--
-- Name: tracking_pixels tracking_pixels_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_pixels
    ADD CONSTRAINT tracking_pixels_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE SET NULL;


--
-- Name: tracking_postbacks tracking_postbacks_pixel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tracking_postbacks
    ADD CONSTRAINT tracking_postbacks_pixel_id_fkey FOREIGN KEY (pixel_id) REFERENCES public.tracking_pixels(id) ON DELETE CASCADE;


--
-- Name: user_engagement_subscriptions user_engagement_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_engagement_subscriptions
    ADD CONSTRAINT user_engagement_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.engagement_plans(id) ON DELETE RESTRICT;


--
-- Name: user_engagement_subscriptions user_engagement_subscriptions_target_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_engagement_subscriptions
    ADD CONSTRAINT user_engagement_subscriptions_target_room_id_fkey FOREIGN KEY (target_room_id) REFERENCES public.rooms(id) ON DELETE SET NULL;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: recurring_pending_followups Users view own pending followups; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users view own pending followups" ON public.recurring_pending_followups FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: affiliate_accounts aa_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aa_delete_own ON public.affiliate_accounts FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: affiliate_accounts aa_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aa_insert_own ON public.affiliate_accounts FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: affiliate_accounts aa_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aa_select_own ON public.affiliate_accounts FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: affiliate_accounts aa_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aa_update_own ON public.affiliate_accounts FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: affiliate_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.affiliate_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: bot_execution_logs bel_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bel_select_own ON public.bot_execution_logs FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: bot_execution_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bot_execution_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: credit_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credit_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: credit_transactions ct_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ct_select_own ON public.credit_transactions FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: expert_engagement_prompts eep_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eep_delete_own ON public.expert_engagement_prompts FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: expert_engagement_prompts eep_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eep_insert_own ON public.expert_engagement_prompts FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: expert_engagement_prompts eep_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eep_select_own ON public.expert_engagement_prompts FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: expert_engagement_prompts eep_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eep_update_own ON public.expert_engagement_prompts FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: expert_funnel ef_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ef_delete_own ON public.expert_funnel FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: expert_funnel ef_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ef_insert_own ON public.expert_funnel FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: expert_funnel ef_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ef_select_own ON public.expert_funnel FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: expert_funnel ef_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ef_update_own ON public.expert_funnel FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: engagement_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engagement_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: engagement_plans; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engagement_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: engagement_reaction_dispatches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engagement_reaction_dispatches ENABLE ROW LEVEL SECURITY;

--
-- Name: engagement_orders eo_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY eo_select_own ON public.engagement_orders FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: engagement_plans ep_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ep_select_all ON public.engagement_plans FOR SELECT USING (true);


--
-- Name: engagement_reaction_dispatches erd_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY erd_select_own ON public.engagement_reaction_dispatches FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: expert_engagement_prompts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.expert_engagement_prompts ENABLE ROW LEVEL SECURITY;

--
-- Name: expert_funnel; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.expert_funnel ENABLE ROW LEVEL SECURITY;

--
-- Name: followup_dispatch_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.followup_dispatch_log ENABLE ROW LEVEL SECURITY;

--
-- Name: followup_leads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.followup_leads ENABLE ROW LEVEL SECURITY;

--
-- Name: followup_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.followup_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: followup_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.followup_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: forwarder_dedupe; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.forwarder_dedupe ENABLE ROW LEVEL SECURITY;

--
-- Name: followup_dispatch_log fudl_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fudl_select_own ON public.followup_dispatch_log FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: followup_leads ful_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ful_delete_own ON public.followup_leads FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: followup_leads ful_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ful_select_own ON public.followup_leads FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: followup_leads ful_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ful_update_own ON public.followup_leads FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: followup_messages fum_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fum_delete_own ON public.followup_messages FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: followup_messages fum_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fum_insert_own ON public.followup_messages FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: followup_messages fum_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fum_select_own ON public.followup_messages FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: followup_messages fum_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fum_update_own ON public.followup_messages FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: followup_settings fus_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fus_delete_own ON public.followup_settings FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: followup_settings fus_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fus_insert_own ON public.followup_settings FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: followup_settings fus_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fus_select_own ON public.followup_settings FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: followup_settings fus_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fus_update_own ON public.followup_settings FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: hot_teasers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hot_teasers ENABLE ROW LEVEL SECURITY;

--
-- Name: hot_vip_funnel; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hot_vip_funnel ENABLE ROW LEVEL SECURITY;

--
-- Name: hot_teasers ht_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ht_delete_own ON public.hot_teasers FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: hot_teasers ht_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ht_insert_own ON public.hot_teasers FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: hot_teasers ht_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ht_select_own ON public.hot_teasers FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: hot_teasers ht_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ht_update_own ON public.hot_teasers FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: hot_vip_funnel hvf_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY hvf_delete_own ON public.hot_vip_funnel FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: hot_vip_funnel hvf_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY hvf_insert_own ON public.hot_vip_funnel FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: hot_vip_funnel hvf_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY hvf_select_own ON public.hot_vip_funnel FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: hot_vip_funnel hvf_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY hvf_update_own ON public.hot_vip_funnel FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: igaming_results; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.igaming_results ENABLE ROW LEVEL SECURITY;

--
-- Name: igaming_results igr_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY igr_delete_own ON public.igaming_results FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: igaming_results igr_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY igr_insert_own ON public.igaming_results FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: igaming_results igr_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY igr_select_own ON public.igaming_results FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: igaming_results igr_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY igr_update_own ON public.igaming_results FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: market_tips_sent; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.market_tips_sent ENABLE ROW LEVEL SECURITY;

--
-- Name: meta_event_logs mel_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mel_select_own ON public.meta_event_logs FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: message_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.message_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: meta_event_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.meta_event_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: meta_integrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.meta_integrations ENABLE ROW LEVEL SECURITY;

--
-- Name: meta_integrations mi_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mi_delete_own ON public.meta_integrations FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: meta_integrations mi_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mi_insert_own ON public.meta_integrations FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: meta_integrations mi_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mi_select_own ON public.meta_integrations FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: meta_integrations mi_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mi_update_own ON public.meta_integrations FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: message_logs ml_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ml_select_own ON public.message_logs FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: market_tips_sent mts_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mts_select_own ON public.market_tips_sent FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_postbacks own postbacks delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own postbacks delete" ON public.tracking_postbacks FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: tracking_postbacks own postbacks insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own postbacks insert" ON public.tracking_postbacks FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: tracking_postbacks own postbacks select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own postbacks select" ON public.tracking_postbacks FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_postbacks own postbacks update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "own postbacks update" ON public.tracking_postbacks FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: promo_bot_settings pbs_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pbs_delete_own ON public.promo_bot_settings FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: promo_bot_settings pbs_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pbs_insert_own ON public.promo_bot_settings FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: promo_bot_settings pbs_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pbs_select_own ON public.promo_bot_settings FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: promo_bot_settings pbs_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pbs_update_own ON public.promo_bot_settings FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: promo_clicks pc_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pc_select_own ON public.promo_clicks FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: promo_conversions pcv_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pcv_select_own ON public.promo_conversions FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: promo_dispatches pd_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pd_select_own ON public.promo_dispatches FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: premium_emojis pe_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pe_delete_own ON public.premium_emojis FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: premium_emojis pe_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pe_insert_own ON public.premium_emojis FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: premium_emojis pe_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pe_select_own ON public.premium_emojis FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: premium_emojis pe_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pe_update_own ON public.premium_emojis FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: promo_offers po_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY po_select_own ON public.promo_offers FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: premium_emojis; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.premium_emojis ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_insert_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_insert_self ON public.profiles FOR INSERT WITH CHECK ((auth.uid() = id));


--
-- Name: profiles profiles_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select_own ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- Name: profiles profiles_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- Name: promo_bot_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.promo_bot_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: promo_clicks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.promo_clicks ENABLE ROW LEVEL SECURITY;

--
-- Name: promo_conversions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.promo_conversions ENABLE ROW LEVEL SECURITY;

--
-- Name: promo_dispatches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.promo_dispatches ENABLE ROW LEVEL SECURITY;

--
-- Name: promo_offers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.promo_offers ENABLE ROW LEVEL SECURITY;

--
-- Name: quick_send_templates qst_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qst_delete_own ON public.quick_send_templates FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: quick_send_templates qst_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qst_insert_own ON public.quick_send_templates FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: quick_send_templates qst_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qst_select_own ON public.quick_send_templates FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: quick_send_templates qst_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY qst_update_own ON public.quick_send_templates FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: quick_send_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.quick_send_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: room_assets ra_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ra_delete_own ON public.room_assets FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_assets ra_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ra_insert_own ON public.room_assets FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_assets ra_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ra_select_own ON public.room_assets FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_assets ra_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ra_update_own ON public.room_assets FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_chats rc_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rc_delete_own ON public.room_chats FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_chats rc_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rc_insert_own ON public.room_chats FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_chats rc_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rc_select_own ON public.room_chats FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_chats rc_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rc_update_own ON public.room_chats FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: recurring_pending_followups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recurring_pending_followups ENABLE ROW LEVEL SECURITY;

--
-- Name: recurring_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recurring_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: room_engagement_settings res_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_delete_own ON public.room_engagement_settings FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_engagement_settings res_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_insert_own ON public.room_engagement_settings FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_engagement_settings res_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_select_own ON public.room_engagement_settings FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_engagement_settings res_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY res_update_own ON public.room_engagement_settings FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_images ri_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ri_delete_own ON public.room_images FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_images ri_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ri_insert_own ON public.room_images FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_images ri_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ri_select_own ON public.room_images FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_images ri_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ri_update_own ON public.room_images FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_assets ENABLE ROW LEVEL SECURITY;

--
-- Name: room_chats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_chats ENABLE ROW LEVEL SECURITY;

--
-- Name: room_engagement_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_engagement_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: room_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_images ENABLE ROW LEVEL SECURITY;

--
-- Name: room_report_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_report_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: room_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: room_session_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_session_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: room_template_buttons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_template_buttons ENABLE ROW LEVEL SECURITY;

--
-- Name: room_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: room_windows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.room_windows ENABLE ROW LEVEL SECURITY;

--
-- Name: rooms; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;

--
-- Name: rooms rooms_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rooms_delete_own ON public.rooms FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: rooms rooms_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rooms_insert_own ON public.rooms FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: rooms rooms_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rooms_select_own ON public.rooms FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: rooms rooms_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rooms_update_own ON public.rooms FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_reports rr_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rr_delete_own ON public.room_reports FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_reports rr_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rr_insert_own ON public.room_reports FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_reports rr_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rr_select_own ON public.room_reports FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_reports rr_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rr_update_own ON public.room_reports FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_report_runs rrr_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rrr_select_own ON public.room_report_runs FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: recurring_schedules rs_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rs_delete_own ON public.recurring_schedules FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: recurring_schedules rs_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rs_insert_own ON public.recurring_schedules FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: recurring_schedules rs_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rs_select_own ON public.recurring_schedules FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: recurring_schedules rs_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rs_update_own ON public.recurring_schedules FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_session_messages rsm_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rsm_delete_own ON public.room_session_messages FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_session_messages rsm_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rsm_insert_own ON public.room_session_messages FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_session_messages rsm_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rsm_select_own ON public.room_session_messages FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_session_messages rsm_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rsm_update_own ON public.room_session_messages FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_templates rt_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rt_delete_own ON public.room_templates FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_templates rt_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rt_insert_own ON public.room_templates FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_templates rt_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rt_select_own ON public.room_templates FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_templates rt_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rt_update_own ON public.room_templates FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_template_buttons rtb_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rtb_delete_own ON public.room_template_buttons FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_template_buttons rtb_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rtb_insert_own ON public.room_template_buttons FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_template_buttons rtb_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rtb_select_own ON public.room_template_buttons FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_template_buttons rtb_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rtb_update_own ON public.room_template_buttons FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: room_windows rw_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rw_delete_own ON public.room_windows FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: room_windows rw_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rw_insert_own ON public.room_windows FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: room_windows rw_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rw_select_own ON public.room_windows FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: room_windows rw_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rw_update_own ON public.room_windows FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: schedule_folders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.schedule_folders ENABLE ROW LEVEL SECURITY;

--
-- Name: scheduled_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.scheduled_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: signal_events se_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY se_select_own ON public.signal_events FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: schedule_folders sf_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_delete_own ON public.schedule_folders FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: schedule_folders sf_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_insert_own ON public.schedule_folders FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: schedule_folders sf_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_select_own ON public.schedule_folders FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: schedule_folders sf_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_update_own ON public.schedule_folders FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: signal_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.signal_events ENABLE ROW LEVEL SECURITY;

--
-- Name: scheduled_messages sm_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sm_delete_own ON public.scheduled_messages FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: scheduled_messages sm_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sm_insert_own ON public.scheduled_messages FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: scheduled_messages sm_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sm_select_own ON public.scheduled_messages FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: scheduled_messages sm_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sm_update_own ON public.scheduled_messages FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: telegram_accounts ta_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ta_delete_own ON public.telegram_accounts FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: telegram_accounts ta_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ta_insert_own ON public.telegram_accounts FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: telegram_accounts ta_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ta_select_own ON public.telegram_accounts FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: telegram_accounts ta_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ta_update_own ON public.telegram_accounts FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: telegram_chats tc_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tc_delete_own ON public.telegram_chats FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: telegram_chats tc_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tc_insert_own ON public.telegram_chats FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: telegram_chats tc_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tc_select_own ON public.telegram_chats FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_clicks tc_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tc_select_own ON public.tracking_clicks FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: telegram_chats tc_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tc_update_own ON public.telegram_chats FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: tracking_domains td_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY td_delete_own ON public.tracking_domains FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: tracking_domains td_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY td_insert_own ON public.tracking_domains FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: tracking_domains td_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY td_select_own ON public.tracking_domains FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_domains td_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY td_update_own ON public.tracking_domains FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: telegram_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.telegram_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: telegram_chats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.telegram_chats ENABLE ROW LEVEL SECURITY;

--
-- Name: telegram_member_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.telegram_member_events ENABLE ROW LEVEL SECURITY;

--
-- Name: tracking_integrations ti_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ti_delete_own ON public.tracking_integrations FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: tracking_integrations ti_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ti_insert_own ON public.tracking_integrations FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: tracking_integrations ti_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ti_select_own ON public.tracking_integrations FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_integrations ti_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ti_update_own ON public.tracking_integrations FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: telegram_member_events tme_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tme_select_own ON public.telegram_member_events FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_offers tof_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tof_delete_own ON public.tracking_offers FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: tracking_offers tof_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tof_insert_own ON public.tracking_offers FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: tracking_offers tof_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tof_select_own ON public.tracking_offers FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_offers tof_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tof_update_own ON public.tracking_offers FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: tracking_pixels tp_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tp_delete_own ON public.tracking_pixels FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: tracking_pixels tp_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tp_insert_own ON public.tracking_pixels FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: tracking_pixels tp_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tp_select_own ON public.tracking_pixels FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: tracking_pixels tp_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tp_update_own ON public.tracking_pixels FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: tracking_clicks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tracking_clicks ENABLE ROW LEVEL SECURITY;

--
-- Name: tracking_domains; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tracking_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: tracking_integrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tracking_integrations ENABLE ROW LEVEL SECURITY;

--
-- Name: tracking_offers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tracking_offers ENABLE ROW LEVEL SECURITY;

--
-- Name: tracking_pixels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tracking_pixels ENABLE ROW LEVEL SECURITY;

--
-- Name: tracking_postbacks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tracking_postbacks ENABLE ROW LEVEL SECURITY;

--
-- Name: user_engagement_subscriptions ues_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ues_select_own ON public.user_engagement_subscriptions FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: user_engagement_subscriptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_engagement_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles user_roles_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_roles_select_own ON public.user_roles FOR SELECT USING (((auth.uid() = user_id) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: videos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.videos ENABLE ROW LEVEL SECURITY;

--
-- Name: videos videos_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY videos_delete_own ON public.videos FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: videos videos_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY videos_insert_own ON public.videos FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: videos videos_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY videos_select_own ON public.videos FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: videos videos_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY videos_update_own ON public.videos FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: welcome_extra_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.welcome_extra_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: welcome_extra_messages wem_delete_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY wem_delete_own ON public.welcome_extra_messages FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: welcome_extra_messages wem_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY wem_insert_own ON public.welcome_extra_messages FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: welcome_extra_messages wem_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY wem_select_own ON public.welcome_extra_messages FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: welcome_extra_messages wem_update_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY wem_update_own ON public.welcome_extra_messages FOR UPDATE USING ((auth.uid() = user_id));


--
-- PostgreSQL database dump complete
--

\unrestrict lNqJXPnVjdaUawZBpafmb9vJwlDgYG2g8gWuzIUegGi7X2SnR2era0bVdIJBo92

