--
-- PostgreSQL database dump
--

\restrict xgoLAGNWcMqWcqMelGbzXH3yAHQKuSpR4Br6379NythyIZEN0KHRV69ewgWkhJK

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) VALUES ('00000000-0000-0000-0000-000000000000', 'bbdb040e-ea86-4744-829c-d5211b2c4895', 'authenticated', 'authenticated', 'igor.mcontato@gmail.com', '$2a$10$Q35YAr6W0skBsnZXGwENGOIzOGoNeal9htBxoQO4Dxd/FAZcFMBTS', '2026-05-14 03:43:53.184028+00', NULL, '', '2026-05-14 03:43:27.210776+00', '', NULL, '', '', NULL, '2026-05-28 17:53:43.372305+00', '{"provider": "email", "providers": ["email"]}', '{"sub": "bbdb040e-ea86-4744-829c-d5211b2c4895", "email": "igor.mcontato@gmail.com", "display_name": "Igor Matheus Gonçalves Geraldo", "email_verified": true, "phone_verified": false}', NULL, '2026-05-14 03:43:27.176506+00', '2026-05-31 21:39:28.805096+00', NULL, NULL, '', '', NULL, '', 0, NULL, '', NULL, false, NULL, false);


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) VALUES ('bbdb040e-ea86-4744-829c-d5211b2c4895', 'bbdb040e-ea86-4744-829c-d5211b2c4895', '{"sub": "bbdb040e-ea86-4744-829c-d5211b2c4895", "email": "igor.mcontato@gmail.com", "display_name": "Igor Matheus Gonçalves Geraldo", "email_verified": true, "phone_verified": false}', 'email', '2026-05-14 03:43:27.206688+00', '2026-05-14 03:43:27.206735+00', '2026-05-14 03:43:27.206735+00', '3da51f4b-491f-4015-a4ca-7346ebbb6b0a');


--
-- PostgreSQL database dump complete
--

\unrestrict xgoLAGNWcMqWcqMelGbzXH3yAHQKuSpR4Br6379NythyIZEN0KHRV69ewgWkhJK

