# Scripts de migração

Pipeline **read-only na origem** que copia schema, dados, auth, storage, edge functions e cron jobs para o projeto destino.

> **Garantia inegociável:** nenhum script aqui executa `INSERT`, `UPDATE`, `DELETE`, `DROP`, `TRUNCATE` ou `ALTER` na origem. Tudo é `SELECT` ou `pg_dump`. O destino pode ser limpo e refeito quantas vezes quiser sem afetar a origem.

---

## Pré-requisitos

- `psql` e `pg_dump` versão **17+** (igual ao Postgres do Supabase)
- `node` 20+ (para `04-storage.mjs` e `05-edge-functions.sh`)
- `supabase` CLI (`npm i -g supabase`)
- `curl` e `jq`

Instalação detalhada (Windows): ver [`../03-ide/01-instalar-dependencias.md`](../03-ide/01-instalar-dependencias.md).

---

## Variáveis de ambiente

Antes de rodar qualquer script, exporta no terminal (Git Bash):

```bash
# === ORIGEM — só leitura ===
export SOURCE_DB_URL="postgresql://postgres.<SOURCE_PROJECT_REF>:<SENHA_ORIGEM>@aws-0-XX.pooler.supabase.com:5432/postgres?sslmode=require"
export SOURCE_PROJECT_REF="<SOURCE_PROJECT_REF>"
export SOURCE_URL="https://<SOURCE_PROJECT_REF>.supabase.co"
export SOURCE_SERVICE_ROLE="<service_role da origem>"

# === DESTINO ===
export TARGET_DB_URL="postgresql://postgres.<TARGET_PROJECT_REF>:<SENHA_DESTINO>@aws-0-XX.pooler.supabase.com:5432/postgres?sslmode=require"
export TARGET_PROJECT_REF="<TARGET_PROJECT_REF>"
export TARGET_URL="https://<TARGET_PROJECT_REF>.supabase.co"
export TARGET_SERVICE_ROLE="<service_role do destino>"
```

> **Use Session Pooler (porta 5432).** Transaction Pooler (6543) não funciona em `pg_dump`. Host direto `db.*.supabase.co` não responde em IPv4 e cai em redes sem IPv6.

Onde achar:
- DB URL: Dashboard → Settings → Database → Connection string → **Session pooler** (substitua `[YOUR-PASSWORD]` e adicione `?sslmode=require` no final)
- service_role: Dashboard → Settings → API → `service_role` secret

Detalhes em [`../02-manual/03-pegar-pooler-urls.md`](../02-manual/03-pegar-pooler-urls.md).

---

## Ordem de execução

Cada fase é independente e idempotente. Se uma falhar, conserta e roda de novo. Nenhuma toca a origem.

```bash
cd scripts/

# Fase 0: Sanity check — confirma read-only na origem e conexão no destino
bash 00-precheck.sh

# Fase 1: Schema (tabelas, funções, triggers, RLS, enums, views)
bash 01-schema.sh

# Fase 2: Auth users (preserva UUIDs e senhas)
bash 02-auth.sh

# Fase 3: Dados de todas as tabelas public.*
bash 03-data.sh

# Fase 4: Storage — recriar buckets e copiar todos os arquivos
node 04-storage.mjs

# Fase 5: Edge Functions — deploy do código local para o destino
bash 05-edge-functions.sh

# Fase 6: Cron jobs (pg_cron)
bash 06-cron.sh

# Fase 6b (se 06 falhar via pooler ou pg_cron não puder ser lido):
# recria cron jobs com URLs e service_role do destino
psql "$TARGET_DB_URL" \
  -v target_url="$TARGET_URL" \
  -v service_role="$TARGET_SERVICE_ROLE" \
  -f fix_cron.sql

# Fase 7: Relatório final + checklist de secrets manuais
bash 07-report.sh
```

Logs vão para `./logs/<fase>-<timestamp>.log`. Dumps SQL ficam em `./dumps/`.

---

## O que cada fase faz

| Fase | Origem | Destino | Operação |
|---|---|---|---|
| 00-precheck | SELECT | SELECT | confere conexão e versões |
| 01-schema | `pg_dump --schema-only` | `psql -f` | DDL de `public` |
| 02-auth | `pg_dump --data-only` de `auth.users` + `auth.identities` | INSERT (`session_replication_role=replica`) | preserva UUIDs e hash de senha |
| 03-data | `pg_dump --data-only --schema=public` | INSERT | dados das tabelas |
| 04-storage | API Storage (download) | API Storage (upload) | buckets + objetos binários |
| 05-edge-functions | — | `supabase functions deploy` | deploy do código já no repo |
| 06-cron | SELECT em `cron.job` | `cron.schedule` | reagenda jobs no destino |
| 07-report | SELECT | SELECT | relatório markdown comparando contagens |

---

## O que NÃO está incluído (tem que fazer manualmente — ver [`../02-manual/`](../02-manual/))

- Configurar **secrets** das edge functions no destino (apenas a lista de nomes é gerada — ver saída de `07-report.sh`)
- Apontar webhooks externos para o destino
- Apontar domínios customizados para o destino
- Reconfigurar Auth providers (Google/Apple/etc.) no destino
- Reconfigurar templates de email custom no Auth
- Promover o destino a produção (DNS / variáveis da app)
