#!/usr/bin/env bash
# Fase 0 — Sanity check. Apenas SELECT na origem; SELECT no destino.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
LOG="logs/00-precheck-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Fase 0: Pré-check ==="
date

req_var() { [ -n "${!1:-}" ] || { echo "ERRO: variável $1 não definida"; exit 1; }; }
for v in SOURCE_DB_URL SOURCE_PROJECT_REF SOURCE_URL SOURCE_SERVICE_ROLE \
         TARGET_DB_URL TARGET_PROJECT_REF TARGET_URL TARGET_SERVICE_ROLE; do
  req_var "$v"
done

echo ""
echo "--- Versões de tooling ---"
psql --version
pg_dump --version
node --version
supabase --version || true

echo ""
echo "--- Conexão ORIGEM (read-only) ---"
psql "$SOURCE_DB_URL" -tAc "select current_database(), current_user, version()" | head -3
echo "Tabelas em public:"
psql "$SOURCE_DB_URL" -tAc "select count(*) from information_schema.tables where table_schema='public'"
echo "Usuários em auth:"
psql "$SOURCE_DB_URL" -tAc "select count(*) from auth.users"
echo "Buckets de storage:"
psql "$SOURCE_DB_URL" -tAc "select id, public from storage.buckets order by id"

echo ""
echo "--- Conexão DESTINO ---"
psql "$TARGET_DB_URL" -tAc "select current_database(), current_user, version()" | head -3
echo "Tabelas em public (destino):"
psql "$TARGET_DB_URL" -tAc "select count(*) from information_schema.tables where table_schema='public'"
echo "Usuários em auth (destino):"
psql "$TARGET_DB_URL" -tAc "select count(*) from auth.users"

echo ""
echo "--- Garantia read-only na origem ---"
echo "Este script NÃO executa nenhum comando de escrita na origem."
echo "Confirme acima que SOURCE_PROJECT_REF=$SOURCE_PROJECT_REF é o projeto de origem correto."

echo ""
echo "OK. Pré-check concluído."
