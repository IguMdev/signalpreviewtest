-- ──────────────────────────────────────────────────────────────────
-- fix_cron.sql — Template para recriar cron jobs (pg_cron) no DESTINO.
--
-- Quando usar:
--   - 06-cron.sh falhou ao ler cron.job da origem via pooler
--   - você quer ter controle declarativo dos jobs no destino
--
-- Como usar:
--   1. Liste os jobs ativos da ORIGEM (no painel: Database → Cron Jobs)
--   2. Para cada job, copie/adapte um dos blocos de exemplo abaixo
--   3. Rode contra o DESTINO:
--
--      psql "$TARGET_DB_URL" \
--        -v target_url="$TARGET_URL" \
--        -v service_role="$TARGET_SERVICE_ROLE" \
--        -f fix_cron.sql
--
-- ⚠️ Os tokens vêm de variáveis (-v), nunca hardcoded neste arquivo.
--    Não comite este arquivo com valores reais.
-- ──────────────────────────────────────────────────────────────────

-- ── 1. Limpa jobs antigos com os mesmos nomes (idempotência) ───────
-- Adicione aqui os nomes dos jobs que este script vai recriar:
--
-- SELECT cron.unschedule(jobname) FROM cron.job
--  WHERE jobname IN ('meu-job-1', 'meu-job-2');


-- ── 2. EXEMPLO: cron job que chama uma função SQL local ─────────────
-- Schedule cron padrão Postgres: '*/5 * * * *' = a cada 5 minutos.
--
-- SELECT cron.schedule(
--   'nome-do-job',
--   '*/5 * * * *',
--   'SELECT public.minha_funcao()'
-- );


-- ── 3. EXEMPLO: cron job que chama uma Edge Function via HTTP ──────
-- Requer extension pg_net habilitada no destino.
-- A URL é montada com :'target_url' e a Authorization com :'service_role',
-- ambos passados via -v na linha do psql.
--
-- SELECT cron.schedule(
--   'nome-do-job-http',
--   '*/10 * * * *',
--   format(
--     $cmd$SELECT net.http_post(
--       url := %L,
--       headers := %L::jsonb,
--       body := '{}'::jsonb
--     ) AS request_id;$cmd$,
--     :'target_url' || '/functions/v1/nome-da-edge-function',
--     json_build_object(
--       'Content-Type','application/json',
--       'Authorization','Bearer ' || :'service_role'
--     )::text
--   )
-- );


-- ── 4. Verificação final: lista os jobs schedulados ────────────────
SELECT jobid, schedule, jobname, active FROM cron.job ORDER BY jobname;
