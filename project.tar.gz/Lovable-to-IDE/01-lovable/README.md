# Etapa 1 — Lovable

O que acontece **dentro do Lovable**. Único objetivo desta etapa: gerar um endpoint temporário que devolve as credenciais do Supabase Cloud da origem em JSON, pra você puxar pra IDE depois.

---

## Pré-requisito

Antes de tudo, **conecte o projeto Lovable ao GitHub**:

1. No Lovable, abra o projeto.
2. Canto superior direito → **GitHub** → **Connect to GitHub**.
3. Autorize o Lovable na sua conta GitHub.
4. Escolha "Create a new repository" (ou conecte a um existente).
5. Aguarde o primeiro push terminar.

A partir daqui, qualquer alteração que o Lovable fizer já vai parar no GitHub. Guarde a URL do repo (`https://github.com/<você>/<repo>.git`) — você vai cloná-lo na Etapa 3.

---

## Passo único — pedir ao Lovable que crie a edge function

No chat do Lovable, **cole o conteúdo de [`prompt-edge-function.md`](prompt-edge-function.md)** exatamente como está. Ele vai instruir o Lovable a criar:

| Arquivo | O quê |
|---|---|
| `supabase/functions/temp-export-credentials/index.ts` | edge function que devolve `SUPABASE_URL`, `SERVICE_ROLE_KEY`, `DB_URL`, `ANON_KEY` em JSON |
| `supabase/config.toml` | adiciona `[functions.temp-export-credentials] verify_jwt = false` |
| `src/pages/ExportCredentials.tsx` (ou similar) | rota `/export-credentials` com botão "Exportar" e botão "Copiar JSON" |

Aguarde o Lovable:
- criar os arquivos,
- atualizar o `config.toml`,
- fazer deploy automático da function,
- comitar pro GitHub.

---

## Como saber que terminou

1. Abra a URL pública da app Lovable + `/export-credentials`.
2. A página tem que carregar o título "Exportar Credenciais do Supabase".
3. Clicar no botão deve retornar um JSON sem erro.

Se der erro 404 na página, espere o redeploy do Lovable e atualize.
Se der erro na chamada da function, cheque se o Lovable comitou o `config.toml`.

---

## ⚠️ Avisos críticos de segurança

- A função **é pública por design** (`verify_jwt = false`). Qualquer pessoa com a URL pega o `SERVICE_ROLE_KEY`. Use uma vez e **delete imediatamente** depois — ver Etapa 4 (limpeza).
- Não publique a URL `/export-credentials` em lugar nenhum (Slack, redes, screenshots).
- Depois da migração, **rotacione**: Settings → API → Reset Service Role Key + Settings → Database → Reset password.

---

## Próxima etapa

→ [`../02-manual/`](../02-manual/) — coletar o JSON, pegar pooler URLs, configurar secrets, etc.
