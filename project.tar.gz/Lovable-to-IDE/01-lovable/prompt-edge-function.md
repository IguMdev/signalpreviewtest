Preciso que você implemente uma ferramenta TEMPORÁRIA para exportar as credenciais do Supabase deste projeto. Ela será usada uma única vez para migração e depois deletada.

═══════════════════════════════════════════
PASSO 1 — Criar a Edge Function
═══════════════════════════════════════════

Crie o arquivo `supabase/functions/temp-export-credentials/index.ts` com EXATAMENTE este conteúdo:

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-master-password",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload = {
      warning: "DELETE THIS FUNCTION IMMEDIATELY AFTER USE.",
      SOURCE_SUPABASE_URL: Deno.env.get("SUPABASE_URL") ?? null,
      SOURCE_SUPABASE_SERVICE_ROLE_KEY:
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? null,
      SOURCE_SUPABASE_DB_URL: Deno.env.get("SUPABASE_DB_URL") ?? null,
      SOURCE_SUPABASE_ANON_KEY:
        Deno.env.get("SUPABASE_ANON_KEY") ??
        Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ??
        null,
    };

    return new Response(JSON.stringify(payload, null, 2), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: (e as Error).message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

═══════════════════════════════════════════
PASSO 2 — Atualizar o config.toml
═══════════════════════════════════════════

No arquivo `supabase/config.toml`, ADICIONE este bloco ao final (mantendo todos os outros blocos [functions.*] já existentes — não remova nada):

[functions.temp-export-credentials]
verify_jwt = false

═══════════════════════════════════════════
PASSO 3 — Criar a tela /export-credentials
═══════════════════════════════════════════

Crie uma nova rota `/export-credentials` com uma página que tenha:

1. Um título grande: "Exportar Credenciais do Supabase"

2. Um banner de aviso vermelho/laranja BEM visível no topo com o texto:
   "⚠️ ATENÇÃO: Esta página expõe credenciais sensíveis. Use apenas para migração e DELETE a edge function `temp-export-credentials` imediatamente após usar."

3. Um botão grande e centralizado: "Exportar Credenciais"
   - Ao clicar, deve chamar a edge function usando:
     `const { data, error } = await supabase.functions.invoke('temp-export-credentials')`
   - Mostrar estado de loading no botão enquanto carrega
   - Em caso de erro, exibir uma mensagem de erro vermelha

4. Após receber a resposta, exibir:
   - Uma área de código (`<pre>` com fundo escuro estilo terminal, fonte monospace) com o JSON formatado e indentado
   - Um botão "📋 Copiar JSON" acima do bloco de código que copia o conteúdo para o clipboard usando `navigator.clipboard.writeText()` e mostra um toast/feedback de "Copiado!"
   - Cada credencial em campos individuais também (URL, Service Role Key, DB URL, Anon Key), cada uma com seu próprio botão "Copiar" individual ao lado, para facilitar copiar uma de cada vez

5. No rodapé da página, instruções claras em uma caixa destacada:
   "✅ Após copiar as credenciais e concluir a migração:
   1. Delete a pasta `supabase/functions/temp-export-credentials`
   2. Remova o bloco `[functions.temp-export-credentials]` do `config.toml`
   3. Faça deploy das alterações"

Use Tailwind para estilização. Use os componentes shadcn/ui (Button, Card, Alert, toast com sonner) que já devem estar disponíveis no projeto. A página deve estar acessível apenas para mim (não precisa de auth especial, apenas a rota direta serve).

NÃO crie link no menu/navegação para essa página — ela deve ser acessível APENAS pela URL direta `/export-credentials`.