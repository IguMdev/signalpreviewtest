# 01 · Clonar o repo + instalar dependências

---

## Passo 1 — Clonar o repo Lovable na sua máquina

1. Abra o **Cursor** (ou VS Code).
2. `Ctrl+Shift+P` → `Git: Clone` → cole a URL do GitHub do projeto Lovable → escolha pasta (ex: `C:\Users\<você>\Documents`).
3. Abra a pasta clonada.

> **Importante:** clona em pasta do **Windows**, não dentro do WSL. Mesmo se você tiver WSL instalado, fica no `C:\`.

---

## Passo 2 — Instalar tooling via `winget`

Abra um **PowerShell como administrador** (botão direito no Iniciar → Terminal como administrador, ou abre fora da IDE como admin):

```powershell
winget install --id Git.Git -e
winget install --id PostgreSQL.PostgreSQL.17 -e
winget install --id OpenJS.NodeJS.LTS -e
```

> Durante a instalação do Postgres:
> - Senha do superuser `postgres`: qualquer coisa (não vai usar localmente)
> - Pode desmarcar "Stack Builder" no fim
> - Pode desmarcar pgAdmin se não quiser

Depois, em qualquer terminal:

```powershell
npm install -g supabase
```

---

## Passo 3 — Verificar que tudo está no PATH

**Fecha e reabre o terminal** (PATH só é recarregado em terminal novo). Em PowerShell:

```powershell
psql --version       # → 17.x
pg_dump --version    # → 17.x
node --version       # → v20+
supabase --version
```

Se `psql --version` retornar "comando não encontrado":

1. Menu Iniciar → "Editar variáveis de ambiente do sistema".
2. **Variáveis de Ambiente** → em **Variáveis do sistema**, edita `Path`.
3. Adiciona `C:\Program Files\PostgreSQL\17\bin`.
4. OK em tudo, **fecha e reabre o terminal**.

---

## Passo 4 — Abrir terminal Git Bash dentro da IDE

A pipeline são scripts `.sh` que rodam em Git Bash, não PowerShell.

No Cursor / VS Code:
1. Abra terminal: ``Ctrl + ` `` (crase) ou `View → Terminal`.
2. No painel de terminal, na seta ao lado do `+`, escolhe **Git Bash**.
3. Confere:
   ```bash
   which psql      # → /c/Program Files/PostgreSQL/17/bin/psql
   which pg_dump
   which supabase
   ```

Se algum não aparecer, fecha e reabre o Git Bash.

---

## Próximo passo

→ [`02-variaveis-ambiente.md`](02-variaveis-ambiente.md) — exportar as 8 variáveis que a pipeline precisa.
