# Etapa 3 — IDE (Cursor / VS Code)

O que acontece **na IDE** com terminal Git Bash. Faça nesta ordem:

| # | Arquivo | O que faz |
|---|---|---|
| 1 | [`01-instalar-dependencias.md`](01-instalar-dependencias.md) | Clone do repo + winget Git/Postgres17/Node + Supabase CLI |
| 2 | [`02-variaveis-ambiente.md`](02-variaveis-ambiente.md) | `export SOURCE_*` e `TARGET_*` no Git Bash |
| 3 | [`03-executar-pipeline.md`](03-executar-pipeline.md) | Rodar `00-precheck.sh` até `07-report.sh` |

---

## Por que Windows nativo (e não WSL)

Supabase resolve o host direto `db.<ref>.supabase.co` **só em IPv6**. WSL2 não tem rota IPv6 saindo da máquina por padrão — a conexão morre antes de chegar no servidor.

Windows nativo + Git Bash:
- Resolve IPv6 normalmente quando precisa
- Roda os scripts `.sh` sem ajuste (Git Bash faz emulação POSIX o suficiente)
- Tem suporte a `pg_dump`/`psql`/`supabase` CLI direto via `winget`

E **também** vamos usar Session Pooler (IPv4, porta 5432) na maioria dos casos, então mesmo se a rede não tivesse IPv6, funcionaria.
