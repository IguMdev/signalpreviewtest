# 03 · Executar a pipeline

Com as variáveis exportadas (Etapa anterior) e o repo da migração na sua máquina, rode os scripts em ordem.

> Onde estão os scripts: pasta [`../scripts/`](../scripts/) deste repo de migração. Para rodar, copia esses scripts (ou o repo todo) pra dentro do projeto Lovable clonado, ou roda direto desta pasta apontando os `$SOURCE_DB_URL` / `$TARGET_DB_URL`.

---

## Sequência

```bash
cd <pasta-com-os-scripts>

# Fase 0: Sanity check
bash 00-precheck.sh

# Fase 1: Schema (DDL de public)
bash 01-schema.sh

# Fase 2: Auth (auth.users + auth.identities — preserva senhas)
bash 02-auth.sh

# Fase 3: Dados de public.*
bash 03-data.sh

# Fase 4: Storage (buckets + binários)
node 04-storage.mjs

# Fase 5: Edge Functions (deploy do código local)
bash 05-edge-functions.sh

# Fase 6: Cron jobs
bash 06-cron.sh
# Se 06 reclamar de pg_cron sem permissão (acontece via pooler), use:
psql "$TARGET_DB_URL" \
  -v target_url="$TARGET_URL" \
  -v service_role="$TARGET_SERVICE_ROLE" \
  -f fix_cron.sql

# Fase 7: Relatório
bash 07-report.sh
```

Cada script:
- Cria `logs/<fase>-<timestamp>.log` com saída completa
- É idempotente — pode rodar de novo se falhou no meio (com a ressalva de que dados duplicados podem aparecer se reaplicar `02-auth` ou `03-data` num destino que já tem linhas)

---

## O que checar entre fases

### Depois de `01-schema.sh`
```bash
psql "$TARGET_DB_URL" -tAc "select count(*) from information_schema.tables where table_schema='public'"
```
Tem que bater com a contagem da origem (mostrada no log do precheck).

### Depois de `02-auth.sh`
```bash
psql "$TARGET_DB_URL" -tAc "select count(*) from auth.users"
```
Tem que bater com a origem.

### Depois de `03-data.sh`
O log do próprio `03-data.sh` já imprime tabela por tabela com `<-- DIVERGE` em vermelho onde diferiu.

### Depois de `04-storage.mjs`
Painel destino → Storage → confere se os buckets aparecem e tem objetos dentro.

### Depois de `05-edge-functions.sh`
Painel destino → Edge Functions → lista deve ter as mesmas functions da origem (menos a `temp-export-credentials`, se você deixou ela sumir antes do deploy — ver Etapa 02-manual/06-limpeza-rotacao).

### Depois de `06-cron.sh` ou `fix_cron.sql`
```bash
psql "$TARGET_DB_URL" -c "select jobid, schedule, jobname, active from cron.job order by jobname"
```

### Depois de `07-report.sh`
Lê `logs/mirror-report-*.md` — é uma tabela markdown com tudo. Se tiver `DIVERGE`, investigue antes de virar a chave.

---

## Troubleshooting

**`psql: command not found` no Git Bash**
PATH não pegou. Fecha e reabre o Git Bash. Persiste? Refaz Etapa 01.

**`SCRAM authentication requires libpq version 10 or above`**
Versão antiga do `psql`. Garante PostgreSQL 17.

**`FATAL: Tenant or user not found`**
Username errado na URI. Tem que ser `postgres.<REF>`, não só `postgres`.

**`password authentication failed`**
Senha errada. Reset no painel: Settings → Database → Reset password.

**`Network is unreachable` em `db.<ref>.supabase.co`**
Você está usando o host direto (IPv6) no lugar do pooler. Refaz `SOURCE_DB_URL` / `TARGET_DB_URL` com `pooler.supabase.com:5432`.

**`permission denied for schema auth`** ao migrar `auth.users`
Confere se está conectando com `postgres.<REF>` (do pooler), não com role limitada.

**Contagens batem mas login falha com "Invalid credentials"**
Algum campo do `auth.users` ficou faltando (geralmente `encrypted_password` ou `email_confirmed_at`). O `02-auth.sh` deve copiar a tabela inteira — confere o dump.

**`pg_cron: permission denied` no `06-cron.sh`**
Pooler bloqueia leitura direta de `cron.job`. Usa o `fix_cron.sql` que recria os jobs declarativamente sem precisar ler da origem.

---

## Próximo passo

Pipeline rodada → vai pra [`../02-manual/04-configurar-secrets-destino.md`](../02-manual/04-configurar-secrets-destino.md).
