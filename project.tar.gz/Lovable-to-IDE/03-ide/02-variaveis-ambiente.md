# 02 · Variáveis de ambiente

A pipeline lê 8 variáveis. Você cola num terminal Git Bash uma única vez, e elas valem pra todos os scripts da sessão.

---

## De onde vem cada uma

| Variável | Vem de |
|---|---|
| `SOURCE_SUPABASE_URL` | JSON da Etapa 1 (`SOURCE_SUPABASE_URL`) |
| `SOURCE_SERVICE_ROLE` | JSON da Etapa 1 (`SOURCE_SUPABASE_SERVICE_ROLE_KEY`) |
| `SOURCE_PROJECT_REF` | parte da `SOURCE_SUPABASE_URL` (entre `https://` e `.supabase.co`) |
| `SOURCE_DB_URL` | painel da origem (Etapa 02-manual/03-pegar-pooler-urls) — **não use o `SOURCE_SUPABASE_DB_URL` do JSON** |
| `TARGET_SUPABASE_URL` | painel destino → Settings → API |
| `TARGET_SERVICE_ROLE` | painel destino → Settings → API → `service_role` |
| `TARGET_PROJECT_REF` | parte da `TARGET_SUPABASE_URL` |
| `TARGET_DB_URL` | painel destino (Etapa 02-manual/03-pegar-pooler-urls) |

> A pipeline também usa `SOURCE_URL` e `TARGET_URL` (sem `SUPABASE_` no nome) — são **a mesma coisa** que `SOURCE_SUPABASE_URL` / `TARGET_SUPABASE_URL`. O bloco abaixo seta os dois nomes.

---

## Bloco para colar no Git Bash

Substitui os `<...>` e cola:

```bash
# ── ORIGEM ─────────────────────────────────────────
export SOURCE_PROJECT_REF='<SOURCE_PROJECT_REF>'
export SOURCE_URL='https://<SOURCE_PROJECT_REF>.supabase.co'
export SOURCE_SERVICE_ROLE='<SOURCE_SUPABASE_SERVICE_ROLE_KEY do JSON>'
export SOURCE_DB_URL='postgresql://postgres.<SOURCE_PROJECT_REF>:<SENHA_ORIGEM>@aws-0-sa-east-1.pooler.supabase.com:5432/postgres?sslmode=require'

# ── DESTINO ────────────────────────────────────────
export TARGET_PROJECT_REF='<TARGET_PROJECT_REF>'
export TARGET_URL='https://<TARGET_PROJECT_REF>.supabase.co'
export TARGET_SERVICE_ROLE='<service_role do destino>'
export TARGET_DB_URL='postgresql://postgres.<TARGET_PROJECT_REF>:<SENHA_DESTINO>@aws-0-sa-east-1.pooler.supabase.com:5432/postgres?sslmode=require'
```

> ⚠️ **Aspas simples (`'`) são obrigatórias.** Senhas podem ter `$`, `!`, `` ` `` que o bash tentaria expandir e quebraria a string.

---

## Validar

```bash
# Confere que tudo está setado
for v in SOURCE_DB_URL SOURCE_PROJECT_REF SOURCE_URL SOURCE_SERVICE_ROLE \
         TARGET_DB_URL TARGET_PROJECT_REF TARGET_URL TARGET_SERVICE_ROLE; do
  if [ -z "${!v:-}" ]; then echo "FALTA: $v"; else echo "OK: $v"; fi
done

# Confere que as URLs estão no pooler e na porta certa
echo "$SOURCE_DB_URL" | grep -q "pooler" && echo "OK: SOURCE pooler" || echo "ERRO: SOURCE host direto"
echo "$TARGET_DB_URL" | grep -q ":5432"  && echo "OK: TARGET porta 5432" || echo "ERRO: TARGET porta errada"

# Testa conexão de fato
psql "$SOURCE_DB_URL" -tAc "select current_database(), current_user"
psql "$TARGET_DB_URL" -tAc "select current_database(), current_user"
```

Se tudo der "OK" e as duas conexões responderem `postgres|postgres.<ref>`, você está pronto pra rodar a pipeline.

---

## Persistência da sessão

Variáveis com `export` somem se você fechar o terminal. Se quiser manter:

- Cola o bloco acima num arquivo `.env.migracao` **fora do repo**
- Antes de cada sessão: `source ~/.env.migracao`
- **Nunca** comita esse arquivo

---

## Próximo passo

→ [`03-executar-pipeline.md`](03-executar-pipeline.md) — rodar `00-precheck.sh` até `07-report.sh`.
