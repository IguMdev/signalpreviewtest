# Etapa 2 — Tarefas manuais

Coisas que **não dão pra automatizar** e você precisa fazer no navegador / painel / gerenciador de senhas.

Faça nesta ordem:

| # | Arquivo | Quando |
|---|---|---|
| 1 | [`01-coletar-credenciais-origem.md`](01-coletar-credenciais-origem.md) | Depois que o Lovable terminou (Etapa 1) |
| 2 | [`02-criar-projeto-destino.md`](02-criar-projeto-destino.md) | Antes de qualquer coisa no destino |
| 3 | [`03-pegar-pooler-urls.md`](03-pegar-pooler-urls.md) | Antes de rodar os scripts |
| 4 | [`04-configurar-secrets-destino.md`](04-configurar-secrets-destino.md) | Depois que rodou `05-edge-functions.sh` |
| 5 | [`05-apontar-aplicacao.md`](05-apontar-aplicacao.md) | Depois de validar tudo no destino |
| 6 | [`06-limpeza-rotacao.md`](06-limpeza-rotacao.md) | **CRÍTICO** — depois da migração ter terminado |

---

## Itens que ficam de fora da pipeline (decida quando promover)

A pipeline copia banco + storage + edge functions, mas **não** mexe em:

- **Webhooks externos** (gateways de pagamento, providers etc.) — continuam apontando pra origem
- **Domínios customizados** — DNS continua na origem
- **Auth providers** (Google, Apple, GitHub, etc.) — recriar no destino
- **Templates de email custom** do Auth — recriar no destino

Isso é intencional: você roda a pipeline, valida tudo no destino com URL `<TARGET_PROJECT_REF>.supabase.co`, só depois "vira a chave" trocando webhook + DNS + variáveis da app.
