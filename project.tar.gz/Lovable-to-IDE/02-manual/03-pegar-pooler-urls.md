# 03 · Pegar Session Pooler URLs (origem + destino)

A pipeline precisa de duas connection strings. Faça **para cada projeto** (origem e destino):

---

## Passos

1. Abra o painel:
   - **Origem:** `https://supabase.com/dashboard/project/<SOURCE_PROJECT_REF>/settings/database`
   - **Destino:** `https://supabase.com/dashboard/project/<TARGET_PROJECT_REF>/settings/database`

2. Em **Connection string**, troca a aba para **Session pooler** (porta 5432).

3. Copia a URI. Formato:
   ```
   postgresql://postgres.<REF>:[YOUR-PASSWORD]@aws-0-XX-XXXX-X.pooler.supabase.com:5432/postgres
   ```

4. **Substitui `[YOUR-PASSWORD]`** pela senha real do banco.
   - Não lembra? Mesma página → **Reset database password** → anota antes de fechar (Supabase só mostra uma vez).

5. Adiciona `?sslmode=require` no final.

---

## Resultado final por projeto

```
postgresql://postgres.<REF>:<SENHA>@aws-0-sa-east-1.pooler.supabase.com:5432/postgres?sslmode=require
```

(O `aws-0-sa-east-1` muda conforme a região do projeto — copie do painel.)

---

## ❌ NÃO usar

| ❌ | ✅ |
|---|---|
| Transaction Pooler (`:6543`) | Session Pooler (`:5432`) |
| Host direto `db.<ref>.supabase.co` | `<algo>.pooler.supabase.com` |
| Sem `?sslmode=require` | Com `?sslmode=require` |

**Por quê:**
- `pg_dump` não funciona em transaction pooler (precisa de prepared statements/sessões persistentes).
- Host direto resolve só em IPv6 — falha em rede sem IPv6 (WSL, alguns provedores).
- Sem SSL pode ser recusado pelo Supabase ou logar warning desnecessário.

---

## Próximo passo

Com as duas URIs em mãos, vai pra Etapa IDE → [`../03-ide/02-variaveis-ambiente.md`](../03-ide/02-variaveis-ambiente.md).
