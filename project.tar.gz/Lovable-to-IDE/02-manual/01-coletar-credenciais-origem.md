# 01 · Coletar credenciais da origem

Depois que o Lovable criou a edge function (Etapa 1), você puxa o JSON pelo navegador.

---

## Passos

1. Abra `https://<sua-url-lovable>/export-credentials`.
2. Clique em **Exportar Credenciais**.
3. Clique em **📋 Copiar JSON**.
4. Cole temporariamente num gerenciador de senhas (1Password, Bitwarden) ou num arquivo local que NÃO vai pro Git.

---

## Formato do JSON

```json
{
  "warning": "DELETE THIS FUNCTION IMMEDIATELY AFTER USE.",
  "SOURCE_SUPABASE_URL": "https://<SOURCE_PROJECT_REF>.supabase.co",
  "SOURCE_SUPABASE_SERVICE_ROLE_KEY": "eyJhbGc...",
  "SOURCE_SUPABASE_DB_URL": "postgresql://postgres:...@db.<SOURCE_PROJECT_REF>.supabase.co:5432/postgres",
  "SOURCE_SUPABASE_ANON_KEY": "eyJhbGc..."
}
```

---

## ⚠️ O que IGNORAR

**Ignore o `SOURCE_SUPABASE_DB_URL`.** Ele é o host direto (`db.<ref>.supabase.co`) que só responde em IPv6. Vai falhar em rede sem IPv6 (WSL, alguns provedores).

Em vez dele, na Etapa 03 você vai pegar a **Session Pooler URL** manualmente do painel — ela é IPv4 e estável.

Os outros 3 campos do JSON (`SOURCE_SUPABASE_URL`, `SOURCE_SUPABASE_SERVICE_ROLE_KEY`, `SOURCE_SUPABASE_ANON_KEY`) você usa direto na Etapa IDE.
