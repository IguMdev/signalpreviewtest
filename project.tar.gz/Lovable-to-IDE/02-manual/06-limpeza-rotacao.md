# 06 · Limpeza e rotação de credenciais (CRÍTICO)

Não pule. A edge function `temp-export-credentials` expôs publicamente o `SERVICE_ROLE_KEY` da origem. Isso precisa ser remediado mesmo se você for desativar a origem.

---

## 1) Remover a edge function temporária

Na IDE, na raiz do repo Lovable já clonado (ver `03-ide`):

```bash
rm -rf supabase/functions/temp-export-credentials
```

Edite `supabase/config.toml` e remova o bloco:

```toml
[functions.temp-export-credentials]
verify_jwt = false
```

---

## 2) Remover a rota `/export-credentials` do frontend

Apague o arquivo de página criado pelo Lovable e qualquer referência no router (`App.tsx`, `routes.tsx`, etc.).

---

## 3) Comitar e pushar

```bash
git add -A
git commit -m "chore: remove temp-export-credentials após migração"
git push
```

O Lovable detecta o push e redeploya automaticamente sem a function exposta.

---

## 4) Rotacionar credenciais da ORIGEM

Mesmo que você vá desativar a origem em alguns dias, **rotacione já**:

1. Painel da origem → **Settings → API** → **Reset Service Role Key**.
2. Painel da origem → **Settings → Database** → **Reset database password**.

Isso invalida qualquer JWT antigo que tenha vazado pela edge function durante a janela em que ela esteve no ar.

> Se a app ainda estava lendo da origem na hora do reset, ela vai cair até você atualizar a anon/service role keys nela. Faça num momento de baixa carga.

---

## 5) (Opcional) Pausar / deletar o projeto origem

Depois que confirmou por uns dias que tudo funciona no destino:

1. Painel da origem → **Settings → General** → **Pause project** (suspende, não apaga).
2. Depois de mais alguns dias sem ninguém reclamar → **Delete project** (irreversível).

Antes de deletar, tira backup do dump SQL (`scripts/dumps/`) e dos arquivos de storage que você baixou.

---

## Checklist final

- [ ] `temp-export-credentials` removida do código
- [ ] Bloco `[functions.temp-export-credentials]` removido do `config.toml`
- [ ] Rota `/export-credentials` removida do frontend
- [ ] Push pro GitHub feito (Lovable redeployou)
- [ ] Service Role Key da origem rotacionada
- [ ] Senha do banco da origem rotacionada
- [ ] App apontando pro destino e funcionando
- [ ] Senhas dos dois bancos guardadas no gerenciador de senhas
