# 05 · Apontar a aplicação para o novo projeto

Depois que a pipeline rodou e os secrets estão configurados, vire a chave nas variáveis públicas da app.

---

## Variáveis a trocar

Dependendo do framework, os nomes mudam:

| Framework | URL var | Anon key var |
|---|---|---|
| Vite (React) | `VITE_SUPABASE_URL` | `VITE_SUPABASE_ANON_KEY` |
| Next.js | `NEXT_PUBLIC_SUPABASE_URL` | `NEXT_PUBLIC_SUPABASE_ANON_KEY` |
| Lovable Cloud | gerenciado pelo Lovable | gerenciado pelo Lovable |

Trocar para os valores do destino:
- URL → `https://<TARGET_PROJECT_REF>.supabase.co`
- Anon key → painel do destino → Settings → API → `anon public`

---

## Onde trocar

### Se é Lovable Cloud
A app conecta automaticamente no Lovable Cloud da workspace. Para apontar pra um Supabase externo, você vai precisar:
1. **Desconectar** o Lovable Cloud nativo (se possível) ou
2. **Sobrescrever** as vars no client `supabase.ts` com a URL/anon do destino

Detalhe específico depende de como o projeto Lovable usa o cliente. Procure em `src/integrations/supabase/client.ts` (ou similar) e troque os valores hardcoded/env vars lá.

### Se você forkou pra rodar fora do Lovable
1. Variáveis de ambiente do hosting (Vercel, Netlify, etc.) → trocar URL e anon
2. Build & deploy
3. Limpar cache de CDN se houver

---

## Teste end-to-end

1. Abra a app em janela anônima.
2. Faça login com um **usuário antigo** (que existia na origem). Senha deve ser a mesma.
3. Verifica se aparece os dados do usuário (perfil, registros, fotos).
4. Verifica se rotas que escrevem no banco funcionam.
5. Verifica se uploads de storage funcionam.

Se algo falhar, o destino ainda está intocado funcionalmente — a origem segue de pé. Investiga e refaz.
