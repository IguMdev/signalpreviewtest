# 04 · Configurar secrets das edge functions no destino

A pipeline copia o **código** das edge functions, mas o Supabase **não copia secrets** entre projetos. Você precisa replicar manualmente.

Faça isto **depois** de rodar `05-edge-functions.sh`.

---

## Passo 1 — Listar secrets que a origem usa

Na IDE, com a Supabase CLI instalada:

```bash
supabase login
supabase link --project-ref <SOURCE_PROJECT_REF>
supabase secrets list
```

Anote todos os nomes (não os valores — eles não aparecem por segurança).

A pipeline também já gera essa lista em `scripts/logs/mirror-report-*.md` (ver Fase 7 do `07-report.sh`).

---

## Passo 2 — Pegar os valores

Os valores você tem em duas fontes:
1. **Gerenciador de senhas / Notion / etc.** — onde você guardou quando configurou na origem
2. **Provider externo** (re-emitir a chave no painel do provider) — caso tenha perdido

⚠️ Não há forma de exportar valores secrets do Supabase via CLI. Se você não tem onde guardou e o provider não permite re-exibir, **gere um novo secret** no provider e usa o novo.

---

## Passo 3 — Setar no destino

```bash
supabase link --project-ref <TARGET_PROJECT_REF>

supabase secrets set NOME_DO_SECRET=valor
supabase secrets set OUTRO_SECRET=outro_valor
# repita pra cada um
```

Ou, mais ergonômico, num arquivo `.env.secrets` (NÃO commitar):

```
NOME_DO_SECRET=valor
OUTRO_SECRET=outro_valor
```

E aplica:
```bash
supabase secrets set --env-file .env.secrets
```

---

## Passo 4 — Verificar

```bash
supabase secrets list --project-ref <TARGET_PROJECT_REF>
```

Compara com a lista da origem. Tem que bater nome a nome (com exceção de `SUPABASE_*` que o Supabase gerencia sozinho).

---

## Passo 5 — Testar uma edge function

Dispare uma function trivial no destino e veja em **Edge Functions → Logs** se ela consegue ler o secret. Se der `undefined` no log, faltou setar ou o nome está errado.
