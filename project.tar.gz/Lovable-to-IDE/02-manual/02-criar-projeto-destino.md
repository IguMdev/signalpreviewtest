# 02 · Criar / preparar o projeto destino

Se ainda não criou o projeto Supabase de destino, faça agora.

---

## Passos no painel Supabase

1. Acesse https://supabase.com/dashboard.
2. Clique em **New Project**.
3. Configure:
   - **Name:** o que quiser
   - **Database Password:** GERA UMA FORTE — anota imediatamente no gerenciador de senhas, o Supabase não mostra de novo
   - **Region:** mesma região da origem para evitar latência (ex: `sa-east-1` se a origem for São Paulo)
   - **Plan:** o adequado pro tamanho dos dados
4. Aguarde provisionar (1–2 minutos).
5. Anote o **Project Ref** (aparece na URL: `https://supabase.com/dashboard/project/<TARGET_PROJECT_REF>`).

---

## Depois de criar — configurações iniciais

Antes de rodar a pipeline, garanta que o destino tem:

### Extensions necessárias
Database → Extensions → habilite:
- `pg_cron` (para os cron jobs da Etapa 06)
- `pg_net` (para `net.http_post` dos cron jobs)
- Outras que a origem use (rode no `psql` da origem: `select extname from pg_extension order by extname` para listar)

### Settings → API
Já anota os valores que vão virar variáveis de ambiente na Etapa IDE:
- **Project URL** → `TARGET_URL`
- **anon public** → `TARGET_SUPABASE_ANON_KEY` (precisa quando for apontar a app)
- **service_role secret** → `TARGET_SERVICE_ROLE` (CRÍTICO — não exponha)

### Settings → Database
- **Database password** — se você não anotou na criação, faça **Reset database password** agora e anota
- **Connection string** → copie a aba **Session pooler** (vai usar na Etapa 03)
