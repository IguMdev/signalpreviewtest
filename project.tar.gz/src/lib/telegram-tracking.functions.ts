import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createHash } from "crypto";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { callTelegram } from "./telegram.server";

function publicBaseUrl() {
  const explicit = process.env.PUBLIC_BASE_URL;
  if (explicit) return explicit.replace(/\/$/, "");
  const projectId = process.env.LOVABLE_PROJECT_ID || "8dafe7ca-cf53-49eb-9c75-fa970d91c13f";
  return `https://project--${projectId}-dev.lovable.app`;
}

const ALLOWED_UPDATES = ["chat_member", "my_chat_member", "message", "channel_post"];

function webhookUrlFor(accountId: string) {
  return `${publicBaseUrl()}/api/public/telegram/webhook/${accountId}`;
}
function webhookSecretFor(botToken: string) {
  return createHash("sha256").update(`tg-tracking:${botToken}`).digest("base64url");
}

/**
 * Drena os updates pendentes do Telegram chamando getUpdates em lote e
 * reentregando cada update ao nosso próprio webhook (mesmo secret).
 * Retorna a contagem de itens processados/erros.
 * Requer que o webhook esteja DESREGISTRADO antes (Telegram retorna 409 caso contrário).
 */
async function* drainPendingUpdates(accountId: string, botToken: string) {
  const url = webhookUrlFor(accountId);
  const secret = webhookSecretFor(botToken);
  let offset: number | undefined;
  let processed = 0;
  let errors = 0;
  let total = 0;

  for (let i = 0; i < 100; i++) {
    const r = await callTelegram<Array<{ update_id: number }>>(botToken, "getUpdates", {
      offset,
      limit: 100,
      timeout: 0,
      allowed_updates: ALLOWED_UPDATES,
    });
    if (!r.ok) throw new Error(r.description ?? "getUpdates falhou");
    const batch = r.result ?? [];
    if (batch.length === 0) break;
    total += batch.length;
    yield { phase: "draining" as const, processed, errors, total };

    for (const upd of batch) {
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-telegram-bot-api-secret-token": secret,
          },
          body: JSON.stringify(upd),
        });
        if (resp.ok) processed++;
        else errors++;
      } catch {
        errors++;
      }
      offset = upd.update_id + 1;
    }
    yield { phase: "draining" as const, processed, errors, total };
    if (batch.length < 100) break;
  }
  return { processed, errors, total };
}

export const enableMemberTracking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ accountId: z.string().uuid() }).parse(d))
  .handler(async function* ({ data, context }) {
    const { supabase } = context;
    const { data: acc, error } = await supabase
      .from("telegram_accounts")
      .select("id, bot_token")
      .eq("id", data.accountId)
      .maybeSingle();
    if (error || !acc?.bot_token) throw new Error("Conta não encontrada");

    const url = webhookUrlFor(acc.id);
    const secret = webhookSecretFor(acc.bot_token);

    yield { phase: "preparing" as const, processed: 0, errors: 0, total: 0 };

    // 1) Remove webhook preservando a fila pendente
    await callTelegram<boolean>(acc.bot_token, "deleteWebhook", { drop_pending_updates: false });

    // 2) Drena tudo que está pendente, reentregando ao nosso próprio webhook
    let processed = 0;
    let errors = 0;
    let total = 0;
    try {
      for await (const p of drainPendingUpdates(acc.id, acc.bot_token)) {
        processed = p.processed;
        errors = p.errors;
        total = p.total;
        yield p;
      }
    } catch (e) {
      yield {
        phase: "drain_error" as const,
        processed,
        errors,
        total,
        message: e instanceof Error ? e.message : String(e),
      };
    }

    // 3) (Re)registra o webhook
    yield { phase: "registering" as const, processed, errors, total };
    const r = await callTelegram<boolean>(acc.bot_token, "setWebhook", {
      url,
      secret_token: secret,
      allowed_updates: ALLOWED_UPDATES,
      drop_pending_updates: false,
    });
    if (!r.ok) {
      await supabase
        .from("telegram_accounts")
        .update({
          member_tracking_last_check: new Date().toISOString(),
          member_tracking_last_error: r.description ?? "setWebhook falhou",
        })
        .eq("id", acc.id);
      throw new Error(r.description ?? "Falha ao registrar webhook");
    }

    await supabase
      .from("telegram_accounts")
      .update({
        member_tracking_enabled: true,
        member_tracking_last_check: new Date().toISOString(),
        member_tracking_last_error: null,
      })
      .eq("id", acc.id);

    yield { phase: "done" as const, processed, errors, total, url };
  });

export const disableMemberTracking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ accountId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: acc } = await supabase
      .from("telegram_accounts")
      .select("bot_token")
      .eq("id", data.accountId)
      .maybeSingle();
    if (!acc) throw new Error("Conta não encontrada");
    const r = await callTelegram<boolean>(acc.bot_token, "deleteWebhook", {});
    if (!r.ok) throw new Error(r.description ?? "Falha");
    await supabase
      .from("telegram_accounts")
      .update({ member_tracking_enabled: false, member_tracking_last_check: new Date().toISOString() })
      .eq("id", data.accountId);
    return { ok: true };
  });

export const getMemberStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        from: z.string().optional(),
        to: z.string().optional(),
      })
      .optional()
      .parse(d ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const TZ = "America/Sao_Paulo";
    // Format a Date as YYYY-MM-DD in the given timezone
    const dayInTZ = (d: Date) =>
      new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
    // Convert YYYY-MM-DD (interpreted in TZ) to a UTC instant at start/end of day
    const tzDayBoundary = (ymd: string, end: boolean) => {
      // BRT is UTC-3 (no DST since 2019). Build the ISO with explicit offset.
      const time = end ? "23:59:59.999" : "00:00:00.000";
      return new Date(`${ymd}T${time}-03:00`);
    };
    const todayYmd = dayInTZ(new Date());
    const defaultFromYmd = dayInTZ(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));
    const fromYmd = data?.from || defaultFromYmd;
    const toYmd = data?.to || todayYmd;
    const since = tzDayBoundary(fromYmd, false).toISOString();
    const until = tzDayBoundary(toYmd, true).toISOString();

    const [{ data: events }, { data: recent }] = await Promise.all([
      supabase
        .from("telegram_member_events")
        .select("event_type, occurred_at, chat_id, chat_title")
        .gte("occurred_at", since)
        .lte("occurred_at", until)
        .order("occurred_at", { ascending: false })
        .limit(5000),
      supabase
        .from("telegram_member_events")
        .select("id, chat_title, chat_id, tg_first_name, tg_username, event_type, occurred_at")
        .gte("occurred_at", since)
        .lte("occurred_at", until)
        .order("occurred_at", { ascending: false })
        .limit(200),
    ]);

    const list = events ?? [];
    let joinsToday = 0;
    let leavesToday = 0;
    let joins30 = 0;
    let leaves30 = 0;
    const byDay = new Map<string, { day: string; joins: number; leaves: number }>();
    const byChat = new Map<number, { chat_id: number; chat_title: string | null; joins: number; leaves: number }>();

    for (const e of list) {
      const occurred = new Date(e.occurred_at);
      const day = dayInTZ(occurred);
      const bd = byDay.get(day) ?? { day, joins: 0, leaves: 0 };
      const isJoin = e.event_type === "join";
      const isLeave = e.event_type === "leave" || e.event_type === "kicked";
      if (isJoin) {
        joins30++;
        bd.joins++;
        if (day === todayYmd) joinsToday++;
      }
      if (isLeave) {
        leaves30++;
        bd.leaves++;
        if (day === todayYmd) leavesToday++;
      }
      byDay.set(day, bd);

      const bc = byChat.get(e.chat_id) ?? { chat_id: e.chat_id, chat_title: e.chat_title, joins: 0, leaves: 0 };
      if (isJoin) bc.joins++;
      if (isLeave) bc.leaves++;
      byChat.set(e.chat_id, bc);
    }

    return {
      joinsToday,
      leavesToday,
      joins30,
      leaves30,
      net30: joins30 - leaves30,
      daily: Array.from(byDay.values()).sort((a, b) => a.day.localeCompare(b.day)),
      perChat: Array.from(byChat.values()).sort((a, b) => b.joins - a.joins),
      recent: recent ?? [],
    };
  });

export const getCurrentMemberCounts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data: rooms, error } = await supabase
      .from("rooms")
      .select("id, name, default_account_id, premium_account_id")
      .eq("is_active", true)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const roomIds = (rooms ?? []).map((room) => room.id);
    const { data: chats, error: chatsError } = await supabase
      .from("room_chats")
      .select("room_id, chat_id, chat_title")
      .in("room_id", roomIds.length ? roomIds : ["00000000-0000-0000-0000-000000000000"]);
    if (chatsError) throw new Error(chatsError.message);
    const chatsByRoom = new Map<string, typeof chats>();
    for (const chat of chats ?? []) {
      const roomChats = chatsByRoom.get(chat.room_id) ?? [];
      roomChats.push(chat);
      chatsByRoom.set(chat.room_id, roomChats);
    }

    const accountIds = Array.from(
      new Set(
        (rooms ?? [])
          .map((room) => room.default_account_id ?? room.premium_account_id)
          .filter(Boolean) as string[],
      ),
    );

    const { data: accounts, error: accountsError } = await supabase
      .from("telegram_accounts")
      .select("id, bot_token, label, bot_username")
      .in("id", accountIds.length ? accountIds : ["00000000-0000-0000-0000-000000000000"]);
    if (accountsError) throw new Error(accountsError.message);
    const accountById = new Map((accounts ?? []).map((account) => [account.id, account]));

    const results: Array<{
      roomId: string;
      roomName: string;
      chatId: number;
      chatTitle: string | null;
      accountLabel: string | null;
      count: number | null;
      error: string | null;
      chatType: "group" | "channel" | "unknown";
    }> = [];

    for (const room of rooms ?? []) {
      const accountId = room.default_account_id ?? room.premium_account_id;
      const account = accountId ? accountById.get(accountId) : null;
      for (const chat of chatsByRoom.get(room.id) ?? []) {
        if (!account?.bot_token) {
          results.push({
            roomId: room.id,
            roomName: room.name,
            chatId: chat.chat_id,
            chatTitle: chat.chat_title,
            accountLabel: account?.label ?? null,
            count: null,
            error: "Sala sem bot padrão com token.",
            chatType: "unknown",
          });
          continue;
        }
        const [response, info] = await Promise.all([
          callTelegram<number>(account.bot_token, "getChatMemberCount", { chat_id: chat.chat_id }),
          callTelegram<{ type?: string }>(account.bot_token, "getChat", { chat_id: chat.chat_id }),
        ]);
        const tgType = info.ok ? info.result?.type : undefined;
        const chatType: "group" | "channel" | "unknown" =
          tgType === "channel" ? "channel" : tgType === "group" || tgType === "supergroup" ? "group" : "unknown";
        results.push({
          roomId: room.id,
          roomName: room.name,
          chatId: chat.chat_id,
          chatTitle: chat.chat_title,
          accountLabel: account.label ?? account.bot_username ?? null,
          count: response.ok ? response.result ?? 0 : null,
          error: response.ok ? null : response.description ?? "Falha ao consultar membros.",
          chatType,
        });
      }
    }

    return {
      total: results.reduce((sum, row) => sum + (row.count ?? 0), 0),
      chats: results,
    };
  });