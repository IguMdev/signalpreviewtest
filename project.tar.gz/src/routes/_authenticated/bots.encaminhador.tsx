import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Forward, ImageIcon, RefreshCw, Sparkles, CheckCircle2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { getForwarderConfig, upsertForwarderConfig, listAccountChats, listForwarderSourceItems } from "@/lib/engagement.functions";
import { getPremiumAccountAvatar } from "@/lib/premium-account.functions";

export const Route = createFileRoute("/_authenticated/bots/encaminhador")({
  component: EncaminhadorPage,
});

function templateKindLabel(kind: string): string {
  const map: Record<string, string> = {
    entry: "Entrada", gain: "Ganho", loss: "Perda", event: "Evento",
    signal: "Sinal", win: "Win", win_martingale: "Win martingale",
    buy_direction: "Direção compra", sell_direction: "Direção venda",
  };
  return map[kind] ?? kind;
}

function PremiumAvatar({ accountId, label }: { accountId: string; label: string }) {
  const avatarQ = useQuery({
    queryKey: ["premium-avatar", accountId],
    queryFn: () => getPremiumAccountAvatar({ data: { accountId } }),
    enabled: Boolean(accountId),
    staleTime: 1000 * 60 * 60,
    refetchOnWindowFocus: false,
  });
  const url = avatarQ.data?.dataUrl ?? null;
  const initials = label.split(/\s+/).map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return url ? (
    <img src={url} alt={label} className="size-7 rounded-full object-cover border border-border/60 shrink-0" />
  ) : (
    <div className="size-7 rounded-full flex items-center justify-center bg-primary text-[10px] font-bold text-primary-foreground shrink-0">
      {initials || "?"}
    </div>
  );
}

function ItemList({ title, empty, items, value, onChange }: {
  title: string; empty: string;
  items: { id: string; label: string }[];
  value: string[]; onChange: (v: string[]) => void;
}) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs font-medium text-foreground">{title}</p>
      <div className="border rounded-md p-3 max-h-48 overflow-auto space-y-2">
        {items.length === 0 ? (
          <p className="text-xs text-muted-foreground">{empty}</p>
        ) : items.map((it) => {
          const checked = value.includes(it.id);
          return (
            <label key={it.id} className="flex items-center gap-2 text-sm">
              <Checkbox checked={checked} onCheckedChange={(v) => {
                onChange(v ? [...value, it.id] : value.filter((x) => x !== it.id));
              }} />
              <span className="truncate">{it.label}</span>
            </label>
          );
        })}
      </div>
    </div>
  );
}

// ╔══════════════════════════════════════════════════════════╗
// ║  PÁGINA — BOT ENCAMINHADOR                               ║
// ║  Origem/Destinos + Premium + marcação de templates       ║
// ║  para replicar via Encaminhador.                         ║
// ╚══════════════════════════════════════════════════════════╝

function EncaminhadorPage() {
  const qc = useQueryClient();
  const get = useServerFn(getForwarderConfig);
  const upsert = useServerFn(upsertForwarderConfig);
  const listChats = useServerFn(listAccountChats);
  const listItems = useServerFn(listForwarderSourceItems);

  const roomsQ = useQuery({
    queryKey: ["rooms-pick"],
    queryFn: async () => (await supabase.from("rooms").select("id, name, photo_url").order("created_at", { ascending: false })).data ?? [],
  });
  const chatsQ = useQuery({ queryKey: ["account-chats"], queryFn: () => listChats() });

  const [roomId, setRoomId] = useState("");
  useEffect(() => { if (!roomId && roomsQ.data?.[0]?.id) setRoomId(roomsQ.data[0].id); }, [roomsQ.data, roomId]);

  const selectedRoom = (roomsQ.data ?? []).find((r: any) => r.id === roomId);
  const [roomPhotoError, setRoomPhotoError] = useState(false);
  useEffect(() => { setRoomPhotoError(false); }, [roomId]);

  const roomAccountQ = useQuery({
    queryKey: ["room-forwarder-account", roomId],
    enabled: !!roomId,
    queryFn: async () => {
      const { data } = await supabase
        .from("rooms")
        .select("default_account_id, telegram_accounts:default_account_id(id, label, bot_username, bot_first_name)")
        .eq("id", roomId)
        .maybeSingle();
      return data as unknown as { default_account_id: string | null; telegram_accounts: { id: string; label: string; bot_username: string | null; bot_first_name: string | null } | null } | null;
    },
  });

  const cfgQ = useQuery({ queryKey: ["fwd-cfg", roomId], enabled: !!roomId, queryFn: () => get({ data: { roomId } }) });
  const itemsQ = useQuery({ queryKey: ["fwd-items", roomId], enabled: !!roomId, queryFn: () => listItems({ data: { roomId } }) });

  const [enabled, setEnabled] = useState(false);
  const [source, setSource] = useState<string>("");
  const [targets, setTargets] = useState<number[]>([]);
  const [markedTemplates, setMarkedTemplates] = useState<string[]>([]);
  const [markedScheduled, setMarkedScheduled] = useState<string[]>([]);
  const [markedRecurring, setMarkedRecurring] = useState<string[]>([]);
  const [premiumEnabled, setPremiumEnabled] = useState(false);
  const [premiumAccountId, setPremiumAccountId] = useState<string>("");

  const premiumAccountsQ = useQuery({
    queryKey: ["premium-accounts-list"],
    queryFn: async () => {
      const { data } = await supabase
        .from("telegram_accounts")
        .select("id, label, phone, is_active, tg_session")
        .eq("account_type", "premium")
        .order("created_at", { ascending: false });
      return (data ?? []) as Array<{ id: string; label: string; phone: string | null; is_active: boolean; tg_session: string | null }>;
    },
  });
  const activePremiumAccounts = (premiumAccountsQ.data ?? []).filter((a) => a.is_active && a.tg_session);

  useEffect(() => {
    const c = cfgQ.data;
    if (!c) return;
    setEnabled(c.forwarder_enabled ?? false);
    setSource(c.forwarder_source_chat_id ? String(c.forwarder_source_chat_id) : "");
    setTargets((c.forwarder_target_chat_ids ?? []) as number[]);
    setMarkedTemplates(((c as any).forwarder_marked_templates ?? []) as string[]);
    setMarkedScheduled(((c as any).forwarder_marked_scheduled ?? []) as string[]);
    setMarkedRecurring(((c as any).forwarder_marked_recurring ?? []) as string[]);
    setPremiumEnabled(((c as any).forwarder_premium_enabled ?? false) as boolean);
    setPremiumAccountId(((c as any).forwarder_premium_account_id ?? "") as string);
  }, [cfgQ.data]);

  const save = useMutation({
    mutationFn: () => upsert({
      data: {
        roomId,
        enabled,
        sourceChatId: source ? Number(source) : null,
        targetChatIds: targets,
        markedTemplates,
        markedScheduled,
        markedRecurring,
        premiumEnabled,
        premiumAccountId: premiumAccountId || null,
      },
    }),
    onSuccess: () => { toast.success("Salvo"); qc.invalidateQueries({ queryKey: ["fwd-cfg", roomId] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const roomAccount = roomAccountQ.data?.telegram_accounts;
  const roomBotName = roomAccount?.bot_username ? `@${roomAccount.bot_username}` : (roomAccount?.bot_first_name ?? roomAccount?.label ?? "bot padrão da sala");
  const chats = ((chatsQ.data ?? []) as any[]).filter((c) => !roomAccountQ.data?.default_account_id || c.account_id === roomAccountQ.data.default_account_id);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Forward className="size-6 text-primary" /> BotEncaminhador</h1>
        <p className="text-sm text-muted-foreground">Copia mensagens de um canal/grupo para outros automaticamente. O bot precisa estar como administrador no canal de origem.</p>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Sala</CardTitle></CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            {selectedRoom?.photo_url && !roomPhotoError ? (
              <img
                src={selectedRoom.photo_url}
                alt={selectedRoom.name}
                className="size-14 rounded-md object-cover border border-border/60 shrink-0"
                onError={() => setRoomPhotoError(true)}
              />
            ) : (
              <div className="size-14 rounded-md border border-border/60 bg-muted shrink-0 flex items-center justify-center">
                <ImageIcon className="size-6 text-muted-foreground" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              {selectedRoom && (
                <p className="text-sm font-medium truncate mb-1">{selectedRoom.name}</p>
              )}
              <Select value={roomId} onValueChange={setRoomId}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {(roomsQ.data ?? []).map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ─── BLOCO: CONFIGURAÇÃO (origem/destinos/premium/marcações) ─ */}
      {roomId && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center justify-between">
              Configuração
              <div className="flex items-center gap-2 text-xs">Ativado <Switch checked={enabled} onCheckedChange={setEnabled} /></div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Canal de origem</Label>
              <Select value={source} onValueChange={setSource}>
                <SelectTrigger><SelectValue placeholder="Selecione o canal" /></SelectTrigger>
                <SelectContent>
                  {chats.map((c) => <SelectItem key={c.chat_id} value={String(c.chat_id)}>{c.title ?? c.username ?? c.chat_id}</SelectItem>)}
                </SelectContent>
              </Select>
              {chats.length === 0 && (
                <div className="rounded-md border border-border bg-muted/40 p-3 text-xs text-muted-foreground space-y-2">
                  <p>Nenhum chat detectado para o bot desta sala.</p>
                  <ol className="list-decimal pl-4 space-y-1">
                    <li>Use o bot da sala: <span className="font-medium text-foreground">{roomBotName}</span>.</li>
                    <li>Na página Contas Telegram, clique em <span className="font-medium text-foreground">Ativar rastreamento</span> nesse bot.</li>
                    <li>Adicione esse bot como administrador no canal/grupo e envie uma mensagem nova no canal.</li>
                    <li>Volte aqui e clique em atualizar.</li>
                  </ol>
                  <Button type="button" variant="outline" size="sm" className="gap-2" onClick={() => chatsQ.refetch()}>
                    <RefreshCw className="size-3.5" /> Atualizar chats
                  </Button>
                </div>
              )}
            </div>

            <div className="rounded-md border border-border bg-muted/30 p-3 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2">
                  <Sparkles className="size-4 text-primary mt-0.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Emojis Premium animados</p>
                    <p className="text-xs text-muted-foreground">
                      Quando a mensagem original tiver emojis premium, reenviamos pela sua conta Telegram Premium para preservar a animação. Sem isso o Telegram remove os emojis no encaminhamento.
                    </p>
                  </div>
                </div>
                <Switch checked={premiumEnabled} onCheckedChange={setPremiumEnabled} />
              </div>

              {premiumEnabled && (
                <div className="space-y-1.5 pl-6">
                  <Label className="text-xs">Conta Premium</Label>
                  {activePremiumAccounts.length === 0 ? (
                    <div className="flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/5 p-2 text-xs">
                      <AlertCircle className="size-4 text-destructive shrink-0 mt-0.5" />
                      <span>Nenhuma conta Telegram Premium conectada. Vá em Contas Telegram e conecte uma conta Premium para usar esse recurso.</span>
                    </div>
                  ) : (
                    <>
                      <Select value={premiumAccountId} onValueChange={setPremiumAccountId}>
                        <SelectTrigger><SelectValue placeholder="Selecione a conta Premium" /></SelectTrigger>
                        <SelectContent>
                          {activePremiumAccounts.map((a) => (
                            <SelectItem key={a.id} value={a.id}>
                              {a.label}{a.phone ? ` — ${a.phone}` : ""}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {premiumAccountId && (
                        <div className="flex items-center gap-2 mt-1">
                          {(() => {
                            const acc = activePremiumAccounts.find((a) => a.id === premiumAccountId);
                            return acc ? <PremiumAvatar accountId={acc.id} label={acc.label} /> : null;
                          })()}
                          <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="size-3.5" /> Conta conectada e pronta para uso.
                          </div>
                        </div>
                      )}
                      <p className="text-[11px] text-muted-foreground">
                        A conta Premium precisa estar nos canais/grupos de destino com permissão de postar (admin em canais).
                      </p>
                    </>
                  )}
                </div>
              )}
            </div>

            <div className="space-y-1.5">
              <Label>Canais de destino</Label>
              <div className="space-y-2 border rounded-md p-3 max-h-72 overflow-auto">
                {chats.filter((c) => String(c.chat_id) !== source).map((c) => {
                  const checked = targets.includes(c.chat_id);
                  return (
                    <label key={c.chat_id} className="flex items-center gap-2 text-sm">
                      <Checkbox checked={checked} onCheckedChange={(v) => {
                        setTargets((prev) => v ? [...prev, c.chat_id] : prev.filter((x) => x !== c.chat_id));
                      }} />
                      <span>{c.title ?? c.username ?? c.chat_id}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <Label>Itens da sala para encaminhar</Label>
                <p className="text-xs text-muted-foreground">
                  Marque os modelos e agendamentos que devem ser copiados para os canais de destino quando dispararem no canal de origem. O que não estiver marcado fica somente no canal de origem.
                </p>
              </div>

              <ItemList
                title="Modelos da sala"
                empty="Nenhum modelo de envio rápido vinculado a esta sala. Defina a sala padrão em Modelos para que apareçam aqui."
                items={(itemsQ.data?.templates ?? []).map((t) => ({ id: t.id, label: t.name }))}
                value={markedTemplates}
                onChange={setMarkedTemplates}
              />

              <ItemList
                title="Agendamentos recorrentes"
                empty="Nenhum agendamento recorrente nesta sala."
                items={(itemsQ.data?.recurring ?? []).map((r) => ({ id: r.id, label: `${r.title}${r.is_active ? "" : " (inativo)"}` }))}
                value={markedRecurring}
                onChange={setMarkedRecurring}
              />

              <ItemList
                title="Agendamentos únicos"
                empty="Nenhum agendamento único nesta sala."
                items={(itemsQ.data?.scheduled ?? []).map((s) => ({
                  id: s.id,
                  label: `${new Date(s.scheduled_at).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })} — ${(s.content ?? "").slice(0, 60) || "(sem texto)"}`,
                }))}
                value={markedScheduled}
                onChange={setMarkedScheduled}
              />
            </div>

            <Button onClick={() => save.mutate()} disabled={save.isPending}>{save.isPending ? "Salvando..." : "Salvar"}</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}