import { createFileRoute } from "@tanstack/react-router";
import { createHash, timingSafeEqual } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { sendMetaEvent } from "@/lib/meta-capi.server";
import { callTelegram } from "@/lib/telegram.server";
import { fireTrackingEvent } from "@/lib/tracking.server";
import { sendTextWithPremiumEmojis, sendPhotoWithPremiumEmojiCaption } from "@/lib/premium-send.server";
import { forwardWithPremiumEmojis, hasPremiumEmojiEntities, type BotApiPost } from "@/lib/forwarder-premium.server";
import { dispatchVideo, dispatchVideoNote } from "@/lib/videos.functions";

// ╔══════════════════════════════════════════════════════════╗
// ║  WEBHOOK DO TELEGRAM — roteador único por conta de bot   ║
// ║  Despacha para: BoasVindas, Encaminhador, Tracking,      ║
// ║  Follow-Up e Meta CAPI conforme o tipo de update.        ║
// ╚══════════════════════════════════════════════════════════╝

// ╔══════════════════════════════════════════════════════════╗
// ║  HELPERS COMPARTILHADOS                                  ║
// ╚══════════════════════════════════════════════════════════╝

function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

function classify(oldStatus: string | undefined, newStatus: string | undefined) {
  const wasIn = oldStatus === "member" || oldStatus === "administrator" || oldStatus === "creator" || oldStatus === "restricted";
  const isIn = newStatus === "member" || newStatus === "administrator" || newStatus === "creator" || newStatus === "restricted";
  if (!wasIn && isIn) return "join" as const;
  if (wasIn && !isIn) {
    if (newStatus === "kicked" || newStatus === "banned") return "kicked" as const;
    return "leave" as const;
  }
  return null;
}

function publicUrl(bucket: string, path: string): string {
  const base = (process.env.SUPABASE_URL ?? "").replace(/\/$/, "");
  return `${base}/storage/v1/object/public/${bucket}/${path}`;
}

async function hasActiveSub(userId: string, botType: "boasvindas" | "encaminhador"): Promise<boolean> {
  const { data } = await supabaseAdmin
    .from("user_engagement_subscriptions")
    .select("id")
    .eq("user_id", userId)
    .eq("bot_type", botType)
    .eq("status", "active")
    .limit(1)
    .maybeSingle();
  return !!data;
}

async function logBot(entry: {
  userId: string;
  accountId?: string | null;
  roomId?: string | null;
  botType: "boasvindas" | "encaminhador";
  event: "received" | "sent" | "skipped" | "failed";
  chatId?: number | null;
  targetChatId?: number | null;
  tgUserId?: number | null;
  tgUsername?: string | null;
  tgFirstName?: string | null;
  message?: string | null;
  error?: string | null;
  details?: Record<string, unknown> | null;
}) {
  try {
    await supabaseAdmin.from("bot_execution_logs").insert({
      user_id: entry.userId,
      account_id: entry.accountId ?? null,
      room_id: entry.roomId ?? null,
      bot_type: entry.botType,
      event: entry.event,
      chat_id: entry.chatId ?? null,
      target_chat_id: entry.targetChatId ?? null,
      tg_user_id: entry.tgUserId ?? null,
      tg_username: entry.tgUsername ?? null,
      tg_first_name: entry.tgFirstName ?? null,
      message: entry.message ?? null,
      error: entry.error ?? null,
      details: (entry.details ?? null) as never,
    });
  } catch (e) {
    console.error("[bot-log] insert failed:", e);
  }
}

function renderTemplate(tpl: string, vars: Record<string, string>) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? "");
}

async function sendWelcomeBlock(opts: {
  userId: string;
  botToken: string;
  chatId: number;
  text: string;
  parseMode: string;
  imagePath: string | null | undefined;
  videoId: string | null | undefined;
  premiumEnabled?: boolean | null;
  premiumAccountId?: string | null;
  replyMarkup?: Record<string, unknown> | null;
}): Promise<{ ok: boolean; description?: string; mediaKind: "video_note" | "video" | "photo" | "text" }> {
  const parse_mode = opts.parseMode || "HTML";
  const usePremium = !!opts.premiumEnabled && !!opts.premiumAccountId;
  const reply_markup = opts.replyMarkup ?? undefined;

  if (opts.videoId) {
    const { data: vid } = await supabaseAdmin
      .from("videos").select("storage_path, kind, mime_type, duration_seconds, title, width, height").eq("id", opts.videoId).maybeSingle();
    if (vid?.storage_path) {
      const isRound = vid.kind === "round";
      const resp = isRound
        ? await dispatchVideoNote({
            botToken: opts.botToken,
            storagePath: vid.storage_path,
            chatId: opts.chatId,
            duration: vid.duration_seconds,
            mimeType: vid.mime_type,
            filename: (vid.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
          })
        : await dispatchVideo({
            botToken: opts.botToken,
            storagePath: vid.storage_path,
            chatId: opts.chatId,
            duration: vid.duration_seconds,
            width: (vid as { width?: number | null }).width,
            height: (vid as { height?: number | null }).height,
            mimeType: vid.mime_type,
            filename: (vid.title || "video").replace(/[^\w.-]+/g, "_") + ".mp4",
            caption: opts.text,
            parseMode: parse_mode,
            replyMarkup: reply_markup,
          });
      if (isRound) {
        if (usePremium) {
          await sendTextWithPremiumEmojis({
            userId: opts.userId, accountId: opts.premiumAccountId!, chatId: opts.chatId,
            text: opts.text, allowPlain: true,
          }).catch(() => callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: opts.text, parse_mode, reply_markup }));
          if (reply_markup) {
            await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: "\u2063", reply_markup });
          }
        } else {
          await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: opts.text, parse_mode, reply_markup });
        }
      }
      return { ok: !!resp?.ok, description: resp?.description, mediaKind: isRound ? "video_note" : "video" };
    }
  }

  if (opts.imagePath) {
    const url = publicUrl("room-images", opts.imagePath);
    if (usePremium) {
      const r = await sendPhotoWithPremiumEmojiCaption({
        userId: opts.userId, accountId: opts.premiumAccountId!, chatId: opts.chatId,
        photoUrl: url, caption: opts.text, strict: false,
      }).catch((e) => ({ applied: true, ok: false, error: e instanceof Error ? e.message : String(e) } as const));
      if (r.applied && r.ok) {
        if (reply_markup) {
          await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: "\u2063", reply_markup });
        }
        return { ok: true, mediaKind: "photo" };
      }
      // fall back to bot api
    }
    const resp = await callTelegram(opts.botToken, "sendPhoto", {
      chat_id: opts.chatId, photo: url, caption: opts.text, parse_mode, reply_markup,
    });
    return { ok: !!resp?.ok, description: resp?.description, mediaKind: "photo" };
  }

  if (usePremium) {
    const r = await sendTextWithPremiumEmojis({
      userId: opts.userId, accountId: opts.premiumAccountId!, chatId: opts.chatId,
      text: opts.text, allowPlain: true,
    }).catch((e) => ({ applied: true, ok: false, error: e instanceof Error ? e.message : String(e) } as const));
    if (r.applied && r.ok) {
      if (reply_markup) {
        await callTelegram(opts.botToken, "sendMessage", { chat_id: opts.chatId, text: "\u2063", reply_markup });
      }
      return { ok: true, mediaKind: "text" };
    }
    // fall back to bot api
  }
  const resp = await callTelegram(opts.botToken, "sendMessage", {
    chat_id: opts.chatId, text: opts.text, parse_mode, reply_markup,
    disable_web_page_preview: true,
  });
  return { ok: !!resp?.ok, description: resp?.description, mediaKind: "text" };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function runWelcomeBot(opts: {
  userId: string;
  accountId: string;
  botToken: string | null | undefined;
  chatId: number;
  user: { id?: number; first_name?: string; last_name?: string; username?: string };
}) {
  if (!opts.botToken || !opts.user.id) return;
  await logBot({
    userId: opts.userId, accountId: opts.accountId, botType: "boasvindas",
    event: "received", chatId: opts.chatId, tgUserId: opts.user.id ?? null,
    tgUsername: opts.user.username ?? null, tgFirstName: opts.user.first_name ?? null,
  });
  if (!(await hasActiveSub(opts.userId, "boasvindas"))) {
    await logBot({
      userId: opts.userId, accountId: opts.accountId, botType: "boasvindas",
      event: "skipped", chatId: opts.chatId, tgUserId: opts.user.id ?? null,
      message: "Sem assinatura ativa do BotBoasVindas",
    });
    return;
  }

  // Find any room owned by this user that maps this chat_id
  const { data: rc } = await supabaseAdmin
    .from("room_chats")
    .select("room_id")
    .eq("user_id", opts.userId)
    .eq("chat_id", opts.chatId)
    .limit(1)
    .maybeSingle();
  if (!rc?.room_id) {
    await logBot({
      userId: opts.userId, accountId: opts.accountId, botType: "boasvindas",
      event: "skipped", chatId: opts.chatId, message: "Chat não está vinculado a nenhuma sala",
    });
    return;
  }

  const { data: cfg } = await supabaseAdmin
    .from("room_engagement_settings")
    .select("welcome_bot_enabled, welcome_message, welcome_image_path, welcome_image_mime, welcome_video_id, welcome_parse_mode, welcome_premium_enabled, welcome_premium_account_id, followup_cta_enabled, followup_cta_button_text")
    .eq("room_id", rc.room_id)
    .maybeSingle();
  if (!cfg?.welcome_bot_enabled) {
    await logBot({
      userId: opts.userId, accountId: opts.accountId, roomId: rc.room_id, botType: "boasvindas",
      event: "skipped", chatId: opts.chatId, message: "BotBoasVindas desativado para esta sala",
    });
    return;
  }

  const firstName = (opts.user.first_name ?? "amigo(a)").replace(/[<>&]/g, "");
  const mention = `<a href="tg://user?id=${opts.user.id}">${firstName}</a>`;
  const text = renderTemplate(cfg.welcome_message ?? "Seja bem-vindo(a), {name}! 🎉", {
    name: mention,
    first_name: firstName,
    username: opts.user.username ?? "",
  });

  const parse_mode = cfg.welcome_parse_mode ?? "HTML";

  // Build CTA reply_markup if follow-up CTA enabled
  let ctaReplyMarkup: Record<string, unknown> | null = null;
  const ctaEnabled = (cfg as { followup_cta_enabled?: boolean }).followup_cta_enabled;
  if (ctaEnabled) {
    const { data: bot } = await supabaseAdmin
      .from("telegram_accounts")
      .select("bot_username")
      .eq("id", opts.accountId)
      .maybeSingle();
    if (bot?.bot_username) {
      const ctaText =
        (cfg as { followup_cta_button_text?: string }).followup_cta_button_text ||
        "Iniciar conversa privada 💬";
      ctaReplyMarkup = {
        inline_keyboard: [
          [{ text: ctaText, url: `https://t.me/${bot.bot_username}?start=fu_${rc.room_id}` }],
        ],
      };
    }
  }

  const first = await sendWelcomeBlock({
    userId: opts.userId,
    botToken: opts.botToken,
    chatId: opts.chatId,
    text,
    parseMode: parse_mode,
    imagePath: cfg.welcome_image_path,
    videoId: cfg.welcome_video_id,
    premiumEnabled: (cfg as any).welcome_premium_enabled,
    premiumAccountId: (cfg as any).welcome_premium_account_id,
    replyMarkup: ctaReplyMarkup,
  });
  await logBot({
    userId: opts.userId, accountId: opts.accountId, roomId: rc.room_id, botType: "boasvindas",
    event: first.ok ? "sent" : "failed", chatId: opts.chatId, tgUserId: opts.user.id ?? null,
    tgFirstName: opts.user.first_name ?? null, message: text,
    error: first.ok ? null : (first.description ?? "telegram error"),
    details: { media: first.mediaKind, step: 0 },
  });

  // Sequência (mensagens extras)
  const { data: extras } = await supabaseAdmin
    .from("welcome_extra_messages" as never)
    .select("*")
    .eq("room_id", rc.room_id)
    .order("sort_order", { ascending: true });
  const list = (extras as any[] | null) ?? [];
  for (let i = 0; i < list.length; i++) {
    const ex = list[i];
    const wait = Math.max(0, Math.min(300, Number(ex.delay_seconds ?? 2)));
    if (wait > 0) await sleep(wait * 1000);
    const body = renderTemplate(ex.content ?? "", {
      name: mention, first_name: firstName, username: opts.user.username ?? "",
    });
    const r = await sendWelcomeBlock({
      userId: opts.userId,
      botToken: opts.botToken,
      chatId: opts.chatId,
      text: body,
      parseMode: ex.parse_mode || "HTML",
      imagePath: ex.image_path,
      videoId: ex.video_id,
      premiumEnabled: ex.premium_enabled,
      premiumAccountId: ex.premium_account_id,
    });
    await logBot({
      userId: opts.userId, accountId: opts.accountId, roomId: rc.room_id, botType: "boasvindas",
      event: r.ok ? "sent" : "failed", chatId: opts.chatId, tgUserId: opts.user.id ?? null,
      tgFirstName: opts.user.first_name ?? null, message: body,
      error: r.ok ? null : (r.description ?? "telegram error"),
      details: { media: r.mediaKind, step: i + 1 },
    });
  }
}

async function runForwarder(opts: {
  userId: string;
  accountId: string;
  botToken: string | null | undefined;
  fromChatId: number;
  messageId: number;
  messageType: string;
  post: BotApiPost;
}) {
  if (!opts.botToken) return;
  const { data: cfgs } = await supabaseAdmin
    .from("room_engagement_settings")
    .select("forwarder_enabled, forwarder_target_chat_ids, forwarder_allowed_types, forwarder_premium_enabled, forwarder_premium_account_id")
    .eq("user_id", opts.userId)
    .eq("forwarder_enabled", true)
    .eq("forwarder_source_chat_id", opts.fromChatId);
  if (!cfgs?.length) return; // não loga: barulho de mensagens não relacionadas

  // Dedupe: se esta mensagem foi enviada pelo nosso próprio sistema (quick-send/agendado/recorrente)
  // e já replicada via mirrorIfMarked, pulamos para não duplicar no destino.
  const { data: dedupeHit } = await supabaseAdmin
    .from("forwarder_dedupe")
    .select("chat_id")
    .eq("chat_id", opts.fromChatId)
    .eq("message_id", opts.messageId)
    .maybeSingle();
  if (dedupeHit) {
    await logBot({
      userId: opts.userId, accountId: opts.accountId, botType: "encaminhador",
      event: "skipped", chatId: opts.fromChatId,
      message: "Mensagem já replicada internamente (mirror) — evitando duplicação",
      details: { message_id: opts.messageId, type: opts.messageType, dedupe: true },
    });
    return;
  }

  await logBot({
    userId: opts.userId, accountId: opts.accountId, botType: "encaminhador",
    event: "received", chatId: opts.fromChatId, details: { message_id: opts.messageId, type: opts.messageType },
  });
  if (!(await hasActiveSub(opts.userId, "encaminhador"))) {
    await logBot({
      userId: opts.userId, accountId: opts.accountId, botType: "encaminhador",
      event: "skipped", chatId: opts.fromChatId, message: "Sem assinatura ativa do BotEncaminhador",
    });
    return;
  }

  const allowed = new Set<string>();
  for (const c of cfgs) for (const t of (c.forwarder_allowed_types ?? [])) allowed.add(t);
  if (!allowed.has(opts.messageType)) {
    await logBot({
      userId: opts.userId, accountId: opts.accountId, botType: "encaminhador",
      event: "skipped", chatId: opts.fromChatId,
      message: `Tipo "${opts.messageType}" não está habilitado para encaminhamento`,
      details: { message_id: opts.messageId, type: opts.messageType },
    });
    return;
  }

  const targets = new Set<number>();
  for (const c of cfgs) for (const t of (c.forwarder_target_chat_ids ?? [])) targets.add(t);
  const premiumEnabled = cfgs.some((c) => (c as { forwarder_premium_enabled?: boolean }).forwarder_premium_enabled);
  const premiumAccountId = (cfgs.find((c) => (c as { forwarder_premium_account_id?: string | null }).forwarder_premium_account_id) as { forwarder_premium_account_id?: string | null } | undefined)?.forwarder_premium_account_id ?? null;
  const hasPremiumEmoji = premiumEnabled && hasPremiumEmojiEntities(opts.post);
  for (const target of targets) {
    if (target === opts.fromChatId) continue;
    let okSent = false;
    let errStr: string | null = null;
    let via: "bot-api" | "premium-mtproto" = "bot-api";

    if (hasPremiumEmoji) {
      via = "premium-mtproto";
      const pr = await forwardWithPremiumEmojis({
        userId: opts.userId,
        botToken: opts.botToken,
        post: opts.post,
        targetChatId: target,
        premiumAccountId,
      }).catch((e) => ({ applied: true as const, ok: false as const, error: e instanceof Error ? e.message : String(e) }));
      if (pr.applied && pr.ok) {
        okSent = true;
      } else if (pr.applied && !pr.ok) {
        okSent = false;
        errStr = pr.error;
      } else {
        // applied:false → cai para Bot API (sem premium account ou mídia não suportada)
        via = "bot-api";
        const r = await callTelegram(opts.botToken, "copyMessage", {
          chat_id: target,
          from_chat_id: opts.fromChatId,
          message_id: opts.messageId,
        });
        okSent = !!r?.ok;
        errStr = r?.ok ? null : (r?.description ?? "telegram error");
        if (okSent) {
          errStr = "premium emojis removidos (sem conta Premium ativa) — usei Bot API";
        }
      }
    } else {
      const r = await callTelegram(opts.botToken, "copyMessage", {
        chat_id: target,
        from_chat_id: opts.fromChatId,
        message_id: opts.messageId,
      });
      okSent = !!r?.ok;
      errStr = r?.ok ? null : (r?.description ?? "telegram error");
    }

    await logBot({
      userId: opts.userId, accountId: opts.accountId, botType: "encaminhador",
      event: okSent ? "sent" : "failed", chatId: opts.fromChatId, targetChatId: target,
      error: okSent ? null : errStr,
      details: { message_id: opts.messageId, type: opts.messageType, via, premium_emojis: hasPremiumEmoji, note: okSent ? errStr : undefined },
    });
  }
}

async function cacheDetectedChat(opts: {
  userId: string;
  accountId: string;
  chat?: { id?: number; type?: string; title?: string; username?: string } | null;
}) {
  const chat = opts.chat;
  if (!chat?.id || !chat.type) return;
  if (!['group', 'supergroup', 'channel'].includes(chat.type)) return;

  await supabaseAdmin.from("telegram_chats").upsert(
    {
      account_id: opts.accountId,
      user_id: opts.userId,
      chat_id: chat.id,
      title: chat.title ?? null,
      type: chat.type,
      username: chat.username ?? null,
      cached_at: new Date().toISOString(),
    },
    { onConflict: "account_id,chat_id" },
  );
}

// ── FIM: HELPERS COMPARTILHADOS ──────────────────────────────

export const Route = createFileRoute("/api/public/telegram/webhook/$accountId")({
  server: {
    handlers: {
      POST: async ({ request, params }) => {
        const accountId = params.accountId;
        const { data: acc } = await supabaseAdmin
          .from("telegram_accounts")
          .select("id, user_id, bot_token")
          .eq("id", accountId)
          .maybeSingle();

        if (!acc) return new Response("not found", { status: 404 });

        const expected = createHash("sha256")
          .update(`tg-tracking:${acc.bot_token}`)
          .digest("base64url");
        const provided = request.headers.get("x-telegram-bot-api-secret-token") ?? "";
        if (!safeEqual(provided, expected)) {
          return new Response("unauthorized", { status: 401 });
        }

        const update = await request.json().catch(() => null);
        if (!update) return Response.json({ ok: true });

        // ╔══════════════════════════════════════════════════════╗
        // ║  TRACKEAMENTO AVANÇADO — /start tk_<click_id>        ║
        // ║  Marca o lead como "joined" e dispara Meta CAPI.     ║
        // ╚══════════════════════════════════════════════════════╝
        const msg = update.message;
        const text: string | undefined = msg?.text;
        if (msg?.from?.id && typeof text === "string" && text.startsWith("/start ")) {
          const payload = text.slice(7).trim();
          const m = payload.match(/^tk_([A-Za-z0-9]{6,32})$/);
          if (m) {
            const clickId = m[1];
            const { data: click } = await supabaseAdmin
              .from("tracking_clicks" as never)
              .select("click_id, user_id, joined_at")
              .eq("click_id", clickId)
              .maybeSingle();
            if (click && (click as any).user_id === acc.user_id) {
              const c = click as any;
              if (!c.joined_at) {
                await supabaseAdmin
                  .from("tracking_clicks" as never)
                  .update({
                    joined_at: new Date().toISOString(),
                    tg_user_id: msg.from.id,
                    tg_username: msg.from.username ?? null,
                  } as never)
                  .eq("click_id", clickId);
              }
              await fireTrackingEvent({
                clickId,
                stage: "join",
                extraUserData: {
                  firstName: msg.from.first_name ?? null,
                  lastName: msg.from.last_name ?? null,
                  externalId: msg.from.id,
                },
              }).catch((e) => console.error("[track4you] capi failed:", e));
            }
          }
          // ── FIM: TRACKEAMENTO AVANÇADO ─────────────────────────

          // ╔══════════════════════════════════════════════════════╗
          // ║  FOLLOW-UP — /start fu_<room_id> (chat privado)      ║
          // ║  Registra o lead em followup_leads para receber a    ║
          // ║  sequência diária no privado.                        ║
          // ╚══════════════════════════════════════════════════════╝
          const fm = payload.match(/^fu_([0-9a-fA-F-]{36})$/);
          if (fm && msg.chat?.type === "private") {
            const roomId = fm[1];
            const { data: room } = await supabaseAdmin
              .from("rooms")
              .select("id, user_id")
              .eq("id", roomId)
              .maybeSingle();
            if (room && room.user_id === acc.user_id) {
              await supabaseAdmin
                .from("followup_leads" as never)
                .upsert(
                  {
                    user_id: acc.user_id,
                    room_id: roomId,
                    account_id: acc.id,
                    tg_user_id: msg.from.id,
                    chat_id: msg.chat.id,
                    first_name: msg.from.first_name ?? null,
                    username: msg.from.username ?? null,
                    status: "active",
                  } as never,
                  { onConflict: "room_id,tg_user_id" },
                );
              // Welcome confirmation
              await callTelegram(acc.bot_token, "sendMessage", {
                chat_id: msg.chat.id,
                text: `Olá ${msg.from.first_name ?? ""}! Você está inscrito para receber novidades diárias. 🎉`,
              }).catch(() => undefined);
            }
          }
          // ── FIM: FOLLOW-UP /start ──────────────────────────────
        }

        await cacheDetectedChat({
          userId: acc.user_id,
          accountId: acc.id,
          chat: update.channel_post?.chat ?? update.message?.chat ?? update.chat_member?.chat ?? update.my_chat_member?.chat,
        }).catch((e) => console.error("[telegram-chat-cache] failed:", e));

        const cm = update.chat_member ?? update.my_chat_member;
        if (cm) {
          // ╔══════════════════════════════════════════════════════╗
          // ║  FOLLOW-UP — DETECÇÃO DE BLOQUEIO DO BOT             ║
          // ║  Quando o lead bloqueia/sai do privado, marca o      ║
          // ║  lead como "stopped" para parar a sequência.         ║
          // ╚══════════════════════════════════════════════════════╝
          if (
            update.my_chat_member &&
            cm.chat?.type === "private" &&
            (cm.new_chat_member?.status === "kicked" || cm.new_chat_member?.status === "left")
          ) {
            const u = cm.new_chat_member?.user ?? cm.from ?? {};
            if (u.id) {
              await supabaseAdmin
                .from("followup_leads" as never)
                .update({
                  status: "stopped",
                  stopped_at: new Date().toISOString(),
                  stopped_reason: "blocked",
                } as never)
                .eq("account_id", acc.id)
                .eq("tg_user_id", u.id);
            }
          }
          // ── FIM: FOLLOW-UP DETECÇÃO DE BLOQUEIO ────────────────

          // ╔══════════════════════════════════════════════════════╗
          // ║  TRACKEAMENTO DE MEMBROS (join/leave/kicked)         ║
          // ║  Registra eventos em telegram_member_events e        ║
          // ║  dispara Meta CAPI conforme mapeamento do usuário.   ║
          // ╚══════════════════════════════════════════════════════╝
          const eventType = classify(cm.old_chat_member?.status, cm.new_chat_member?.status);
          if (eventType) {
            const u = cm.new_chat_member?.user ?? cm.old_chat_member?.user ?? {};
            await supabaseAdmin.from("telegram_member_events").insert({
              user_id: acc.user_id,
              account_id: acc.id,
              chat_id: cm.chat.id,
              chat_title: cm.chat.title ?? null,
              tg_user_id: u.id ?? 0,
              tg_username: u.username ?? null,
              tg_first_name: u.first_name ?? null,
              event_type: eventType,
              old_status: cm.old_chat_member?.status ?? null,
              new_status: cm.new_chat_member?.status ?? null,
              occurred_at: new Date((cm.date ?? Math.floor(Date.now() / 1000)) * 1000).toISOString(),
            });

            // ─── Meta CAPI: dispara evento conforme mapeamento ───
            if (u.id) {
              const { data: integ } = await supabaseAdmin
                .from("meta_integrations")
                .select("event_mappings, is_active")
                .eq("user_id", acc.user_id)
                .maybeSingle();
              const mappings = (integ?.event_mappings ?? {}) as Record<string, string>;
              const chosen = mappings[eventType];
              if (integ?.is_active && chosen && chosen !== "off") {
                await sendMetaEvent({
                  userId: acc.user_id,
                  eventName: chosen,
                  eventId: `tg-${eventType}-${cm.chat.id}-${u.id}-${cm.date ?? Math.floor(Date.now() / 1000)}`,
                  actionSource: "system_generated",
                  userData: {
                    externalId: u.id,
                    firstName: u.first_name ?? null,
                    lastName: u.last_name ?? null,
                  },
                  customData: {
                    content_name: cm.chat.title ?? "Telegram group",
                    content_ids: [String(cm.chat.id)],
                    content_type: "telegram_group",
                  },
                });
              }
            }

            // ─── Bot Boas-Vindas: dispara saudação ao novo membro ─
            if (eventType === "join") {
              await runWelcomeBot({
                userId: acc.user_id,
                accountId: acc.id,
                botToken: acc.bot_token,
                chatId: cm.chat.id,
                user: u,
              }).catch((e) => console.error("[welcome-bot] failed:", e));
            }
          }
          // ── FIM: TRACKEAMENTO DE MEMBROS ───────────────────────
        }

        // ╔══════════════════════════════════════════════════════╗
        // ║  BOT ENCAMINHADOR                                    ║
        // ║  Copia mensagens do chat de origem para os destinos. ║
        // ╚══════════════════════════════════════════════════════╝
        const post = update.channel_post ?? update.message;
        if (post?.chat?.id && post?.message_id) {
          const messageType =
            post.text ? "text" :
            post.photo ? "photo" :
            post.video ? "video" :
            post.video_note ? "video_note" :
            post.animation ? "animation" :
            post.document ? "document" :
            post.audio ? "audio" :
            post.voice ? "voice" :
            post.sticker ? "sticker" :
            post.poll ? "poll" :
            post.location ? "location" :
            post.contact ? "contact" :
            "other";
          await runForwarder({
            userId: acc.user_id,
            accountId: acc.id,
            botToken: acc.bot_token,
            fromChatId: post.chat.id,
            messageId: post.message_id,
            messageType,
            post: post as BotApiPost,
          }).catch((e) => console.error("[forwarder] failed:", e));
        }
        // ── FIM: BOT ENCAMINHADOR ───────────────────────────────

        return Response.json({ ok: true });
      },
    },
  },
});